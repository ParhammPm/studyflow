#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""StudyFlow server — Gemini client (audit §5 item 3.5, v1.11.20).

The stored key is NEVER logged and NEVER returned to the browser;
only the masked form ever leaves the server. Moved verbatim out of
server.py; behaviour is identical.
"""
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request

from srv.common import (DEFAULT_GEMINI_MODEL, GEMINI_API_BASE, KEY_FILE,
                        MODEL_FILE, open_https_url)

def read_key():
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE, encoding="utf-8") as f:
            return f.read().strip()
    return ""


# Gemini model names are used inside a URL path, so only the characters
# Google allows in a model id may pass (letters, digits, dot, dash, _).
MODEL_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$")


def read_model():
    if os.path.exists(MODEL_FILE):
        try:
            with open(MODEL_FILE, encoding="utf-8") as f:
                m = f.read().strip()
            if MODEL_RE.match(m):
                return m
        except Exception:
            pass
    return DEFAULT_GEMINI_MODEL


def valid_model(name):
    return bool(name) and bool(MODEL_RE.match(name))


def masked_key(key):
    if not key:
        return ""
    if len(key) <= 8:
        return "••••••••"
    return key[:4] + "••••••••" + key[-4:]


# ---------- Gemini request core (shared by /api/gemini and /api/gemini-test) ----------
# The stored key is NEVER logged and NEVER returned to the browser; only the
# masked form (first/last 4 chars) ever leaves the server. Error messages from
# Google do not contain the key.
TEST_PROMPT = "Reply with exactly this word: OK"
TEST_MAX_TOKENS = 8


def _gemini_request(model, prompt, timeout=60, max_tokens=None):
    """One generateContent call with the stored key.

    Returns a dict: {"ok", "text", "kind", "code", "message"}.
    kind is None on success, else one of: auth | rate_limit | not_found |
    network | model | unknown. "message" is the exact upstream error text
    (or a local message for network/empty-response failures).
    """
    key = read_key()
    if not key:
        return {"ok": False, "text": "", "kind": "auth", "code": None,
                "message": "کلید API جمینای معتبر نیست"}
    body = {"contents": [{"parts": [{"text": prompt}]}]}
    if max_tokens:
        body["generationConfig"] = {"maxOutputTokens": max_tokens}
    payload = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        GEMINI_API_BASE + "/models/" + model + ":generateContent?key=" + key,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        # v1.11.24 (QA BUG-012): redirects are re-checked for https.
        with open_https_url(req, timeout=timeout) as resp:
            result = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail_msg = ""
        try:
            detail = json.loads(exc.read().decode("utf-8", "replace"))
            detail_msg = str(((detail.get("error") or {}).get("message") or "")).strip()
        except Exception:
            pass
        if exc.code in (400, 401, 403):
            kind = "auth"
        elif exc.code == 404:
            kind = "not_found"
        elif exc.code == 429:
            kind = "rate_limit"
        elif exc.code >= 500:
            kind = "model"
        else:
            kind = "unknown"
        if not detail_msg:
            detail_msg = "خطای سرور جمینای: HTTP " + str(exc.code)
        return {"ok": False, "text": "", "kind": kind, "code": exc.code,
                "message": detail_msg}
    except Exception as exc:
        return {"ok": False, "text": "", "kind": "network", "code": None,
                "message": "ارتباط با جمینای برقرار نشد: " + str(exc)}
    cands = result.get("candidates") or [{}]
    parts = cands[0].get("content", {}).get("parts", [])
    text = "".join(p.get("text", "") for p in parts).strip()
    if not text:
        return {"ok": False, "text": "", "kind": "model", "code": None,
                "message": "جمینای پاسخی نداد"}
    return {"ok": True, "text": text, "kind": None, "code": None, "message": ""}

