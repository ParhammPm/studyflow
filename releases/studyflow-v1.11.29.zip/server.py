#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Konkur local site server — Python standard library only, no pip installs.
Run:  python server.py        (or start.bat on Windows)
Then open http://localhost:8765

DATA LIVES OUTSIDE THE APP FOLDER (Layer 0):
  Windows:  %APPDATA%\\KonkurApp\\   (state.json, testbook.json,
            gemini_key.txt, b2_config.json, google_oauth.json,
            google_push_state.json, calendar_config.json,
            calendar_data.json, backups\\)
  Linux:    ~/.local/share/KonkurApp/   macOS: ~/Library/Application Support/KonkurApp/
  Override for tests:  KONKUR_DATA_DIR env var.
  On first run the server MIGRATES any state.json / testbook.json /
  gemini_key.txt found in the app folder into the data dir (move, not copy),
  so extracting a new zip over the old folder can never lose data. The app
  folder itself is replaceable code only — the shipped zip contains NO
  state.json / testbook.json / gemini_key.txt / b2_config.json.

BACKUPS (Layer 1): every save is atomic (temp file + os.replace) and creates
a versioned local backup (backups/<kind>-<ts>-<sha8>.json, ~30 kept per kind,
SHA-256 in backup_meta.json). A missing/corrupt state.json or testbook.json
is auto-restored from the newest VERIFIED backup (local first, then cloud)
before empty defaults are ever served.

CLOUD (Layer 2): Backblaze B2, S3-compatible, pure-stdlib SigV4 (b2.py).
A background thread uploads versioned snapshots + a latest.json manifest.
The cloud layer is DISABLED until B2 credentials are entered in the app's
Backup tab (saved server-side in the data dir, never shipped, never sent to
the browser). On conflict the remote version is kept and the local one is
uploaded as a new version — nothing is ever auto-overwritten.

Endpoints:
  GET  /                -> public/index.html
  GET  /api/health      -> {"ok": true}
  GET  /api/state       -> saved state (ticks, test counts, edits, subjects, theme, daysDone, topicLinks, assignments, examResults)
  POST /api/state       -> save state (atomic + versioned backup + cloud sync request)
  GET  /api/testbook    -> test books (chapters/topics, tests_total, manual_solved)
  POST /api/testbook    -> save test books (atomic + versioned backup + cloud sync request)
  GET  /api/gemini-key  -> {"has_key": bool} (only a boolean, v1.11.28 — the old masked form leaked key chars)
  POST /api/gemini-key  -> {"key": "..."} saves the key to gemini_key.txt (server-side only)
  GET  /api/gemini-model -> {"model": "..."} (selected model, default gemini-2.5-flash)
  POST /api/gemini-model -> {"model": "..."} saves the selected model to gemini_model.txt
  GET  /api/gemini-models -> {"models": [...]} lists the models this key can use (generateContent)
  POST /api/gemini      -> {"prompt": "..."} proxies to Gemini with the selected model, returns {"text": "..."}
  GET  /api/backup      -> backup status (data dir, local counts, cloud state)
  GET  /api/backup/list -> local versions + cloud manifest entries
  POST /api/backup/now  -> snapshot both files now + request immediate cloud sync
  POST /api/backup/restore       -> {"kind": "state"|"testbook", "file": "..."} restore a local version
  POST /api/backup/restore-cloud -> {"kind": ..., "key": "..."} restore a cloud version
  GET  /api/backup/b2-config -> masked B2 settings (never secrets)
  POST /api/backup/b2-config -> save B2 settings {endpoint, key_id, application_key, bucket, enabled}
  POST /api/backup/b2-test    -> read-only connection test (list 1 object)
  POST /api/backup/b2-clear   -> delete the stored B2 credentials
  GET  /api/version           -> current app version {version, build_date} (from version.json)
  GET  /data.json            -> merged programme (calendar_data.json) when present, else shipped data.json
  GET  /api/calendar/status  -> masked calendar config + programme stats + sync log + OAuth/push status
  GET  /api/calendar/config  -> masked calendar config (ICS URL never in full)
  POST /api/calendar/config  -> save {ics_url, interval_minutes, enabled}
  POST /api/calendar/sync    -> fetch the ICS URL now and merge (PULL)
  POST /api/calendar/import-preview -> dry-run merge of an uploaded .ics/.json file
  POST /api/calendar/import  -> apply the uploaded file's merge (after preview)
  POST /api/calendar/clear   -> remove the calendar config (programme data kept)
  GET  /api/calendar/oauth/status -> OAuth credentials status (masked) + push status
  POST /api/calendar/oauth/credentials -> save {client_id, client_secret} (server-side only)
  POST /api/calendar/oauth/clear-credentials -> revoke + delete the stored OAuth credentials
  GET  /api/calendar/oauth/auth-url -> the Google sign-in URL (opened by the browser)
  GET  /oauth/callback        -> Google OAuth redirect: exchanges the code, stores tokens
  POST /api/calendar/oauth/disconnect -> revoke the token at Google, clear stored tokens
  POST /api/calendar/push     -> push app-side box changes to Google Calendar now
  GET  /api/calendar/push-status -> pending push count, last push result, conflicts
  GET  /api/boxes            -> effective boxes (programme + edits + custom), sorted by date/time
  POST /api/boxes/create     -> {title, date, start, end, subject?, topic?, note?, is_test?, tests_total?, type?} new custom box
  POST /api/boxes/update     -> {id, title?, subject?, topic?, date?, start?, end?, note?, is_test?, tests_total?, type?} edit/move a box
  POST /api/boxes/delete     -> {id} delete a box (programme or custom -> state.deleted; the push deletes its Google event too, v1.11.12)
  POST /api/boxes/reconnect  -> {boxId, uid} link a programme box to an EXISTING Google event (manual reconnect)
  POST /api/boxes/push-one   -> {box_id} create ONE Google event for a disconnected box (programme or custom); idempotent
  GET  /api/update/status     -> {version, backups:[code-backup metas]} (code backups live in the data dir)
  POST /api/update/upload     -> raw .zip bytes in the body; validate, back up current code, install, restart
  POST /api/update/url        -> {url} download a .zip, then the same install flow
  POST /api/update/rollback   -> {backup?} restore the newest (or named) code backup, then restart
  GET  /api/update/auto       -> auto-update status: manifest URL, last check result, live install state
  GET  /api/update/auto-progress -> live download/install progress {phase, percent, ...}
  POST /api/update/check      -> fetch the release manifest now and compare (never installs)
  POST /api/update/auto-config -> save {manifest_url} (empty resets to the default)
  POST /api/update/install-auto -> start a background download (SHA-256 verified) + install + restart
  An update NEVER touches the data dir (state.json, testbook.json, gemini_key.txt,
  gemini_model.txt, b2_config.json, google_oauth.json, google_push_state.json,
  calendar_config.json, calendar_data.json) — it only replaces the code/app folder, after
  copying the current code to a versioned backup inside the data dir.
"""
import base64
# (difflib was used only by the v1.11.7 title-similarity matcher, removed in
# v1.11.9 — the merge never links by similarity any more.)
import hashlib
import json
import os
import re
import secrets
import shutil
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
try:
    from zoneinfo import ZoneInfo
except Exception:  # very old Python without zoneinfo
    ZoneInfo = None

try:
    import b2 as b2mod
except Exception:
    b2mod = None

# Audit §5 item 3.5 (v1.11.20): the server is split into modules.
# Shared core (paths, locks, state schema, pure helpers) lives in
# srv.common, the Gemini client in srv.gemini, the self-updater in
# srv.update. The names are re-exported here so the rest of this
# file — handler, calendar sync, backup/cloud, main() — is unchanged.
# v1.11.26 (QA BUG-033): the lists below hold only names this file
# actually uses — plus sanitize_state, kept as a re-export because
# verify1117_driver calls server.sanitize_state. (The full check
# lives in tests/run_tests.py as TestUnusedImports.)
from srv.common import (
    APP_KEY_FILE,
    APP_STATE_FILE,
    APP_TESTBOOK_FILE,
    B2_CONFIG_FILE,
    BACKUP_DIR,
    BACKUP_META_FILE,
    BASE,
    CLOUD_MANIFEST_KEY,
    CLOUD_PREFIX,
    DATA_DIR,
    DEFAULT_STATE,
    GEMINI_API_BASE,
    KEY_FILE,
    MAX_BACKUPS_PER_KIND,
    MODEL_FILE,
    NOTE_MAX_LEN,
    PORT,
    PUBLIC,
    STATE_FILE,
    STATE_LOCK,
    STATE_SCHEMA_VERSION,
    SUBJECT_MAX_LEN,
    SYNC_LOCK,
    TEHRAN,
    TESTBOOK_FILE,
    TITLE_MAX_LEN,
    _PUSH_IN_FLIGHT,
    _with_lock,
    _with_sync_lock,
    atomic_write,
    atomic_write_json,
    ensure_data_dir,
    iso_now,
    merge_state,
    merge_state_update,
    now_ts,
    open_https_url,
    read_json_file,
    read_version,
    sanitize_state,
    sha256_bytes,
    state_rejected_keys,
    state_wrong_typed_keys,
    valid_state,
    valid_testbook,
)
from srv.gemini import (
    TEST_MAX_TOKENS,
    TEST_PROMPT,
    _gemini_request,
    check_gemini_rate_limit,
    read_key,
    read_model,
    valid_model,
)
from srv.update import (
    AUTO_UPDATE_ACTIVE,
    DEFAULT_MANIFEST_URL,
    MAX_UPDATE_ZIP_BYTES,
    UPDATE_STAGING_DIR,
    _auto_update_set,
    auto_update_release,
    auto_update_status,
    auto_update_try_claim,
    download_and_install_auto,
    install_update_zip,
    list_code_backups,
    load_update_config,
    restore_code_backup,
    run_update_check,
    save_update_config,
    schedule_restart,
    staging_zip_name,
    update_startup_check,
)


# ---------- Layer 0: one-time migration out of the app folder ----------
def migrate_legacy_files():
    """Move app-folder data files into the data dir — only when the data-dir
    file does not exist yet. The app folder becomes replaceable code."""
    ensure_data_dir()
    for app_path, data_path in ((APP_STATE_FILE, STATE_FILE),
                                (APP_TESTBOOK_FILE, TESTBOOK_FILE),
                                (APP_KEY_FILE, KEY_FILE)):
        if os.path.exists(data_path) or not os.path.exists(app_path):
            continue
        try:
            if app_path.endswith(".json"):
                data, err = read_json_file(app_path)
                if data is None:
                    print("Migration skipped (unreadable): {}".format(app_path))
                    continue
            shutil.move(app_path, data_path)
            print("Migrated {} -> {}".format(app_path, data_path))
            # Snapshot the migrated file at once, so the pre-migration
            # content is preserved as the first backup version.
            if app_path.endswith(".json"):
                kind = "state" if "state" in os.path.basename(app_path) else "testbook"
                create_backup(kind, force=True)
        except Exception as exc:
            print("Migration failed for {}: {}".format(app_path, exc))


# ---------- Layer 1: versioned local backups ----------
def rebuild_backup_meta():
    """Rebuild backup_meta.json by scanning backups/ (audit §5 item 1.10):
    every versioned file is re-verified (filename pattern, SHA-256,
    JSON parses, schema valid) and re-listed newest-first, capped at
    MAX_BACKUPS_PER_KIND per kind. Files that fail verification are
    skipped, never listed. The rebuilt meta is saved and returned."""
    versions = []
    if os.path.isdir(BACKUP_DIR):
        for fname in sorted(os.listdir(BACKUP_DIR)):
            m = re.match(r"^(state|testbook|programme|push)-(\d{8}-\d{6})-([0-9a-f]{8})\.json$", fname)
            if not m:
                continue
            kind, tsstr, short = m.groups()
            path = os.path.join(BACKUP_DIR, fname)
            try:
                with open(path, "rb") as f:
                    raw = f.read()
                digest = sha256_bytes(raw)
                if not digest.startswith(short):
                    continue
                data = json.loads(raw.decode("utf-8"))
                if kind == "state" and not valid_state(data):
                    continue
                if kind == "testbook" and not valid_testbook(data):
                    continue
                if kind == "programme" and not (
                        isinstance(data, dict) and isinstance(data.get("boxes"), list)):
                    continue
                if kind == "push" and not isinstance(data, dict):
                    continue
                ts = datetime.strptime(tsstr, "%Y%m%d-%H%M%S").timestamp()
                versions.append({"kind": kind, "file": fname, "ts": ts,
                                 "ts_iso": datetime.fromtimestamp(ts).isoformat(),
                                 "sha256": digest, "size": len(raw), "source": "local"})
            except Exception:
                continue
    versions.sort(key=lambda v: v.get("ts", 0), reverse=True)
    kept = []
    counts = {}
    for v in versions:
        k = v.get("kind")
        counts[k] = counts.get(k, 0) + 1
        if counts[k] <= MAX_BACKUPS_PER_KIND:
            kept.append(v)
    meta = {"versions": kept}
    save_backup_meta(meta)
    print("Rebuilt backup_meta.json from backups/ scan: {} versions".format(len(kept)))
    return meta


def load_backup_meta():
    data, _ = read_json_file(BACKUP_META_FILE)
    if isinstance(data, dict) and isinstance(data.get("versions"), list):
        return data
    # Missing or corrupt meta: the backup files themselves are the source
    # of truth — rebuild the index from them (audit §5 item 1.10).
    return rebuild_backup_meta()


def save_backup_meta(meta):
    try:
        atomic_write_json(BACKUP_META_FILE, meta)
    except Exception as exc:
        print("Could not save backup meta: {}".format(exc))


def list_local_versions(kind=None):
    meta = load_backup_meta()
    versions = meta.get("versions", [])
    if kind:
        versions = [v for v in versions if v.get("kind") == kind]
    return sorted(versions, key=lambda v: v.get("ts", 0), reverse=True)


def verify_backup_entry(entry):
    """Verify one backup version: file exists, SHA-256 matches, JSON parses,
    schema is valid. Returns the parsed data or None."""
    if not entry or not entry.get("file"):
        return None
    path = os.path.join(BACKUP_DIR, entry["file"])
    if not os.path.exists(path):
        return None
    try:
        with open(path, "rb") as f:
            raw = f.read()
    except Exception:
        return None
    if sha256_bytes(raw) != entry.get("sha256"):
        return None
    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception:
        return None
    if entry.get("kind") == "state" and not valid_state(data):
        return None
    if entry.get("kind") == "testbook" and not valid_testbook(data):
        return None
    if entry.get("kind") == "programme" and not (
            isinstance(data, dict) and isinstance(data.get("boxes"), list)):
        return None
    if entry.get("kind") == "push" and not isinstance(data, dict):
        return None
    return data


_VERIFY_BOOL_CACHE = {}


def backup_entry_verified(entry):
    """Cached verified? check for the backup list: backup files are
    immutable (versioned filenames carry their hash), so a (file, sha,
    size) key stays valid. Avoids re-reading + re-hashing + re-parsing
    every backup on every GET /api/backup/list."""
    key = (entry.get("file"), entry.get("sha256"), entry.get("size"))
    if key in _VERIFY_BOOL_CACHE:
        return _VERIFY_BOOL_CACHE[key]
    ok = verify_backup_entry(entry) is not None
    if len(_VERIFY_BOOL_CACHE) > 500:
        _VERIFY_BOOL_CACHE.clear()
    _VERIFY_BOOL_CACHE[key] = ok
    return ok


def create_backup(kind, force=False):
    """Snapshot the current data file into backups/. Skips when the content
    is identical to the newest backup of that kind (unless force=True).
    Returns the version entry or None."""
    src = {"state": STATE_FILE, "testbook": TESTBOOK_FILE,
           "programme": CALENDAR_DATA_FILE, "push": GOOGLE_PUSH_FILE}.get(kind, STATE_FILE)
    if not os.path.exists(src):
        return None
    try:
        with open(src, "rb") as f:
            raw = f.read()
    except Exception as exc:
        print("Backup failed (read {}): {}".format(src, exc))
        return None
    digest = sha256_bytes(raw)
    meta = load_backup_meta()
    existing = [v for v in meta.get("versions", []) if v.get("kind") == kind]
    existing.sort(key=lambda v: v.get("ts", 0), reverse=True)
    if not force and existing and existing[0].get("sha256") == digest:
        return existing[0]
    ts = now_ts()
    fname = "{}-{}-{}.json".format(
        kind, datetime.fromtimestamp(ts).strftime("%Y%m%d-%H%M%S"), digest[:8])
    try:
        atomic_write(os.path.join(BACKUP_DIR, fname), raw)
    except Exception as exc:
        print("Backup failed (write {}): {}".format(fname, exc))
        return None
    entry = {"kind": kind, "file": fname, "ts": ts, "ts_iso": iso_now(),
             "sha256": digest, "size": len(raw), "source": "local"}
    versions = [entry] + [v for v in meta.get("versions", []) if v != entry]
    # Prune to MAX_BACKUPS_PER_KIND per kind (oldest first), deleting files.
    kept = []
    counts = {}
    for v in versions:
        k = v.get("kind")
        counts[k] = counts.get(k, 0) + 1
        if counts[k] <= MAX_BACKUPS_PER_KIND:
            kept.append(v)
        else:
            try:
                os.remove(os.path.join(BACKUP_DIR, v["file"]))
            except Exception:
                pass
    meta["versions"] = kept
    save_backup_meta(meta)
    return entry


def newest_verified_backup(kind):
    for entry in list_local_versions(kind):
        data = verify_backup_entry(entry)
        if data is not None:
            return entry, data
    return None, None


# ---------- Layer 2: Backblaze B2 cloud sync ----------
def load_b2_config():
    data, _ = read_json_file(B2_CONFIG_FILE)
    if isinstance(data, dict):
        return data
    return None


def save_b2_config(cfg):
    # Credential file (holds the B2 application key): 0600, owner only
    # (audit §5 item 1.10).
    atomic_write_json(B2_CONFIG_FILE, cfg, mode=0o600)


def masked_b2_config(cfg):
    if not cfg:
        return {"configured": False, "enabled": False, "bucket": None,
                "endpoint": None, "key_id_masked": ""}
    kid = str(cfg.get("key_id") or "")
    return {"configured": bool(cfg.get("key_id") and cfg.get("application_key")),
            "enabled": bool(cfg.get("enabled")),
            "bucket": cfg.get("bucket") or "konkur-backup",
            "endpoint": cfg.get("endpoint") or b2mod.DEFAULT_ENDPOINT if b2mod else None,
            "key_id_masked": (kid[:4] + "••••" + kid[-2:]) if len(kid) > 6 else "••••"}


def cloud_restore_latest(kind):
    """Last-resort restore: download the newest cloud snapshot for `kind`,
    verify SHA-256 + JSON + schema. Returns parsed data or None."""
    if not b2mod:
        return None
    cfg = load_b2_config()
    if not cfg or not cfg.get("enabled"):
        return None
    try:
        client = b2mod.B2Client(cfg)
        manifest = client.get_json(CLOUD_MANIFEST_KEY)
        if not manifest or kind not in manifest:
            return None
        entry = manifest[kind]
        raw = client.get_object(entry["key"])
        if sha256_bytes(raw) != entry.get("sha256"):
            print("Cloud restore rejected: SHA mismatch for {}".format(entry["key"]))
            return None
        data = json.loads(raw.decode("utf-8"))
        if kind == "state" and not valid_state(data):
            return None
        if kind == "testbook" and not valid_testbook(data):
            return None
        print("Restored {} from cloud snapshot {}".format(kind, entry["key"]))
        return data
    except Exception as exc:
        print("Cloud restore failed: {}".format(exc))
        return None


class CloudSync:
    """Background sync thread: uploads versioned snapshots + latest.json
    manifest to B2. Never overwrites a newer remote version — on conflict it
    keeps BOTH and records the conflict for the UI to resolve."""

    def __init__(self):
        self._event = threading.Event()
        self._immediate = threading.Event()
        self._lock = threading.Lock()
        self.last_sync = None          # {"ts", "ts_iso", "ok", "error"}
        self.last_synced_sha = {"state": None, "testbook": None,
                                "programme": None}
        self.conflict = None           # {"kind", "remote_ts", "remote_key", "remote_sha256"}

    def request(self, immediate=False):
        self._event.set()
        if immediate:
            self._immediate.set()

    def run(self):
        while True:
            self._event.wait(timeout=60)
            self._event.clear()
            if self._immediate.is_set():
                self._immediate.clear()
            else:
                # Debounce: wait a little in case more saves arrive.
                time.sleep(15)
            try:
                self.sync_once()
            except Exception as exc:
                with self._lock:
                    self.last_sync = {"ts": now_ts(), "ts_iso": iso_now(),
                                      "ok": False, "error": str(exc)}
                print("Cloud sync error: {}".format(exc))

    def sync_once(self):
        if not b2mod:
            return
        cfg = load_b2_config()
        if not cfg or not cfg.get("enabled"):
            return
        client = b2mod.B2Client(cfg)
        try:
            manifest = client.get_json(CLOUD_MANIFEST_KEY) or {}
        except Exception as exc:
            raise b2mod.B2Error("Could not read cloud manifest: {}".format(exc))
        changed = False
        uploaded = {}  # kinds uploaded this run; marked synced only after the manifest lands
        for kind, path in (("state", STATE_FILE), ("testbook", TESTBOOK_FILE),
                           ("programme", CALENDAR_DATA_FILE)):
            if not os.path.exists(path):
                continue
            with open(path, "rb") as f:
                raw = f.read()
            digest = sha256_bytes(raw)
            if self.last_synced_sha.get(kind) == digest:
                continue
            remote = manifest.get(kind) or {}
            if remote.get("sha256") and remote.get("sha256") != digest:
                # Remote holds different content. If it is NEWER than the
                # local file, do not overwrite it — record the conflict and
                # keep both versions; the user resolves it in the UI.
                if remote.get("ts", 0) > int(os.path.getmtime(path)):
                    with self._lock:
                        self.conflict = {"kind": kind,
                                         "remote_ts": remote.get("ts"),
                                         "remote_key": remote.get("key"),
                                         "remote_sha256": remote.get("sha256")}
                    print("Cloud sync conflict on {}: remote is newer, keeping both".format(kind))
                    continue
            ts = now_ts()
            key = "{}-{}-{}.json".format(
                kind, datetime.fromtimestamp(ts).strftime("%Y%m%d-%H%M%S"), digest[:8])
            client.put_object(CLOUD_PREFIX + key, raw, "application/json")
            manifest[kind] = {"key": CLOUD_PREFIX + key, "sha256": digest, "ts": ts}
            manifest["updated_ts"] = ts
            changed = True
            # Record the upload only AFTER the manifest below is written:
            # marking it synced here would orphan the object if the
            # manifest upload then failed (never retried until the
            # content changed again or the server restarted).
            uploaded[kind] = digest
            if self.conflict and self.conflict.get("kind") == kind:
                with self._lock:
                    self.conflict = None
        if changed:
            client.put_object(CLOUD_MANIFEST_KEY,
                              json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8"),
                              "application/json")
            with self._lock:
                for k, d in uploaded.items():
                    self.last_synced_sha[k] = d
        with self._lock:
            self.last_sync = {"ts": now_ts(), "ts_iso": iso_now(), "ok": True, "error": None}


CLOUD_SYNC = CloudSync()


def cloud_status():
    cfg = load_b2_config()
    masked = masked_b2_config(cfg)
    with CLOUD_SYNC._lock:
        last_sync = CLOUD_SYNC.last_sync
        conflict = CLOUD_SYNC.conflict
        last_synced = dict(CLOUD_SYNC.last_synced_sha)
    return {"configured": masked["configured"], "enabled": masked["enabled"],
            "bucket": masked["bucket"], "endpoint": masked["endpoint"],
            "key_id_masked": masked["key_id_masked"],
            "last_sync": last_sync, "conflict": conflict,
            "last_synced": last_synced}


# ---------- State / testbook load & save (with auto-restore) ----------
def _preserve_corrupt(path):
    """Copy a corrupt data file aside as <file>.corrupt-<ts> BEFORE any
    recovery overwrites it (v1.11.23, QA BUG-009). The auto-restore used
    to overwrite the corrupt bytes with a backup (or defaults) and the
    next save destroyed them for good. Returns the preserved path or
    None (missing file is not corrupt — first run — and is not preserved)."""
    try:
        if not os.path.isfile(path):
            return None
        dst = "{}.corrupt-{}".format(path, int(time.time()))
        shutil.copyfile(path, dst)
        print("Preserved corrupt file as {}".format(dst))
        return dst
    except Exception as exc:
        print("Could not preserve corrupt file {}: {}".format(path, exc))
        return None


def load_testbook():
    data, _ = read_json_file(TESTBOOK_FILE)
    if data is not None and valid_testbook(data):
        return data
    if os.path.isfile(TESTBOOK_FILE):
        # Corrupt (unparseable, or valid JSON with the wrong shape) —
        # preserve it before any recovery overwrites it (BUG-009).
        _preserve_corrupt(TESTBOOK_FILE)
        print("testbook.json is corrupt — restoring from backup")
    entry, backup = newest_verified_backup("testbook")
    if backup is not None:
        atomic_write_json(TESTBOOK_FILE, backup)
        print("Restored testbook.json from backup {}".format(entry["file"]))
        return backup
    data, _ = read_json_file(APP_TESTBOOK_FILE)
    if data is not None and valid_testbook(data):
        atomic_write_json(TESTBOOK_FILE, data)
        return data
    data = cloud_restore_latest("testbook")
    if data is not None:
        atomic_write_json(TESTBOOK_FILE, data)
        return data
    return {"books": []}


def save_testbook(data):
    with STATE_LOCK:
        atomic_write_json(TESTBOOK_FILE, data)
        create_backup("testbook")
        CLOUD_SYNC.request()
    return data


def load_state():
    data, _ = read_json_file(STATE_FILE)
    if data is not None and valid_state(data):
        merged = merge_state(data)
        # Migration on load (audit §5 item 1.9): a file written before
        # the schema existed (no version field) or carrying rejected
        # keys is rewritten once, migrated, so the disk copy is clean
        # and future loads need no migration.
        if data.get("version") != STATE_SCHEMA_VERSION or state_rejected_keys(data):
            try:
                atomic_write_json(STATE_FILE, merged)
                print("Migrated state.json to schema v{}".format(STATE_SCHEMA_VERSION))
            except Exception as exc:
                print("state migration write failed: {}".format(exc))
        return merged
    if os.path.isfile(STATE_FILE):
        # Corrupt (unparseable, or valid JSON with the wrong shape) —
        # preserve it before any recovery overwrites it (BUG-009).
        _preserve_corrupt(STATE_FILE)
        print("state.json is corrupt — restoring from backup")
    entry, backup = newest_verified_backup("state")
    if backup is not None:
        atomic_write_json(STATE_FILE, backup)
        print("Restored state.json from backup {}".format(entry["file"]))
        return merge_state(backup)
    data, _ = read_json_file(APP_STATE_FILE)
    if data is not None and valid_state(data):
        atomic_write_json(STATE_FILE, data)
        return merge_state(data)
    data = cloud_restore_latest("state")
    if data is not None:
        atomic_write_json(STATE_FILE, data)
        return merge_state(data)
    return dict(DEFAULT_STATE)


def save_state(data):
    with STATE_LOCK:
        merged = merge_state(data)
        atomic_write_json(STATE_FILE, merged)
        create_backup("state")
        CLOUD_SYNC.request()
    return merged


def backup_status_payload():
    state_versions = list_local_versions("state")
    tb_versions = list_local_versions("testbook")
    prog_versions = list_local_versions("programme")
    push_versions = list_local_versions("push")
    all_versions = list_local_versions()
    last = all_versions[0] if all_versions else None
    # v1.11.23 (QA BUG-009): surface preserved corrupt files so a
    # silent auto-recovery is visible in the Backup tab / API instead
    # of only in the server console.
    corrupt_files = []
    try:
        for name in sorted(os.listdir(DATA_DIR), reverse=True):
            if ".corrupt-" in name:
                p = os.path.join(DATA_DIR, name)
                if os.path.isfile(p):
                    corrupt_files.append({"file": name,
                                          "size": os.path.getsize(p)})
    except Exception:
        pass
    return {
        "data_dir": DATA_DIR,
        "local": {
            "state_backups": len(state_versions),
            "testbook_backups": len(tb_versions),
            "programme_backups": len(prog_versions),
            "push_backups": len(push_versions),
            "last_backup": last,
            "corrupt_files": corrupt_files,
        },
        "cloud": cloud_status(),
    }


# ---------- Calendar sync (Part A, v1.8.0; two-way since v1.11.0) ----------
# Google Calendar sync. The merged programme lives in the DATA DIR
# (calendar_data.json), never in the shipped data.json, because the app folder
# is replaceable code (self-update wipes it). The shipped data.json stays the
# seed: the first sync matches its 318 boxes to feed events and persists the
# UID -> boxId mapping, so later syncs are stable.
#
# PULL (read path, unchanged): the private ICS feed, or a manually imported
# .ics/.json file. Google Calendar is ALWAYS the plan's source of truth (he
# plans with Muse + Gemini and the changes land in Google Calendar), so a
# pull applies Google's changes to the app's calendar UNCONDITIONALLY: if
# the same box was edited in the app AND changed in Google since the last
# pull, GOOGLE WINS — the app's conflicting local edit is dropped (never
# pushed over Google's version) and the dropped edit is noted in the sync
# log and the conflicts list, so nothing disappears silently.
#
# PUSH (write path, v1.11.0): OAuth 2.0 with a Desktop-app client. Client ID
# is pre-filled (the StudyFlow client, a public identifier); the Client
# Secret is pasted once by the user in settings and, like the tokens, lives
# ONLY in the data dir (google_oauth.json); the browser never sees them.
# The sign-in uses PKCE (RFC 8252, S256). The push compares the EFFECTIVE
# boxes (programme + state.edits overlay + custom boxes) with the
# last-pushed snapshot and only calls the API for what changed — and only
# when Google has not changed that box since the last pull: before PATCHing,
# the push reads the event's CURRENT values from Google and skips the box
# (leaving it for the next pull to resolve) if Google moved first.
# Deletions only ever touch Google events the app itself created. A
# debounced auto-push runs ~15s after any state save that changed a box
# (title/time/new/delete); a manual «ارسال تغییرات به گوگل» button pushes
# immediately. Push errors are recorded in Persian and nothing is lost
# locally.
#
# Sources (all parsed server-side, stdlib only):
#   * Auto sync: the private ICS ("Secret address in iCal format") the user
#     pastes once. Fetched on demand, on server start, and on a schedule.
#   * Manual import: an uploaded .ics file, or a JSON export in the Google
#     Calendar API shape ({items: [...]} — the shape the programme was built
#     from) or a plain array of {date, start, end, title} events. Works
#     offline, with no ICS URL configured.
# Both paths run the SAME merge (merge_calendar_events). Imports first run a
# dry-run preview; applying needs a second, explicit call.
#
# Merge rules (never lose his work):
#   * New event -> new box, fresh id continuing after the highest bNNN,
#     tests_total 0, subject/topic/is_test derived from the title.
#   * Moved/renamed event -> the matching box gets the new date/time/title,
#     but state is NEVER touched (done, tests, tests_total, edits, notes,
#     daysDone all live in state.json and the merge never writes there).
#   * Cancelled/missing event -> the box is removed ONLY if it was never
#     touched in the app (no tick, no tests, no edit, no tests_total). A
#     touched box is kept and unlinked instead. Removals are scoped to the
#     feed's own date span, so a partial export (e.g. 23 Nov-18 Dec) can
#     never delete boxes outside its range. For file imports, mere absence
#     never removes (the file may be partial) — only events the file marks
#     cancelled do; the live sync (the feed IS the whole calendar) also
#     removes events that disappeared from the feed.
#   * A box the user deleted in the app (state.deleted) tombstones its UID:
#     the event is never recreated by a later sync, and the UID stays in
#     tombstone_uids in the data dir.
#   * CONFLICT (Google always wins, 2026-11-24): if a box was edited in the
#     app after the last pull AND Google changed it too, the pull applies
#     Google's title/date/time unconditionally, the app's conflicting edit
#     is dropped (overlay reconciled to Google's values, app_edited_at
#     cleared, last_pushed set to Google's values so the push never
#     re-sends it), and the dropped edit is noted in the sync log and the
#     conflicts list. An app edit with NO Google change is untouched by the
#     pull and is pushed to Google as before.
# Every applied sync appends a summary + decision lines to the sync log
# (calendar_config.json, last 100 entries).
CALENDAR_CONFIG_FILE = os.path.join(DATA_DIR, "calendar_config.json")
CALENDAR_DATA_FILE = os.path.join(DATA_DIR, "calendar_data.json")
CALENDAR_LOG_MAX = 100
CALENDAR_FETCH_TIMEOUT = 25
CALENDAR_MAX_BYTES = 5 * 1024 * 1024
SLEEP_MARKER = "گوشی رو بذار کنار"
KNOWN_SUBJECTS = ["تحلیل آزمون", "مرور دفترچه خطا", "مرور و جمع‌بندی آزمون",
                  "جلسه مشاور درسی", "زبان انگلیسی", "حسابان", "شیمی", "فیزیک",
                  "هندسه", "گسسته", "عربی", "دینی", "ادبیات", "آزمون"]


def _split_outside_parens(text):
    """Last ': ' outside any parentheses, or None (so '(پارت ۲: …)' never
    splits a topic but 'دیدن جلسه: §۸' does)."""
    depth = 0
    last = None
    i = 0
    while i < len(text) - 1:
        ch = text[i]
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth = max(0, depth - 1)
        elif ch == ":" and text[i + 1] == " " and depth == 0:
            last = i
        i += 1
    return last


def clean_event_title(title):
    t = (title or "").strip()
    t = re.sub(r"\s*\(مفید:[^)]*\)\s*$", "", t)
    t = re.sub(r"\s*\(انجام شد\)\s*$", "", t)
    return t.strip()


def derive_subject_topic(title):
    """Subject/topic for a calendar summary, matching how the shipped 318
    boxes were derived from their summaries (verified against data.json:
    'X: rest' -> subject X; 'X — rest' -> subject X; 'کلاس X …' and
    'X آفلاین پایه' -> subject X with the full cleaned title as topic;
    'X دهم/دوازدهم (آزمون) — rest' -> subject X, topic rest)."""
    t = clean_event_title(title)
    if not t:
        return ("", "")
    # 'تست آزمون ۷: <rest>' / 'تست آزمون ۲ (هفته ۳): <rest>' — the original
    # build stripped that planning prefix: topic is the whole remainder,
    # subject is derived from the remainder ('آزمون' when it names none).
    m = re.match(r"^تست آزمون\s*\d*\s*(\([^)]*\))?\s*:\s*(.+)$", t)
    if m:
        rest = m.group(2).strip()
        s2, _ = derive_subject_topic(rest)
        return (rest if s2 == rest else s2, rest) if s2 != rest else ("آزمون", rest)
    for special in ("مرور دفترچه خطا", "جلسه مشاور درسی", "مرور و جمع‌بندی آزمون"):
        if t == special:
            return (special, t)
        if t.startswith(special + " — "):
            return (special, t.split(" — ", 1)[1].strip())
        if t.startswith(special + " "):
            return (special, t)
    if t.startswith("تحلیل آزمون"):
        if " — " in t:
            return ("تحلیل آزمون", t.split(" — ", 1)[1].strip())
        return ("تحلیل آزمون", t)
    if t.startswith("آزمون"):
        return ("آزمون", t)
    if ":" in t:
        left, right = t.split(":", 1)
        if left.strip() in KNOWN_SUBJECTS:
            return (left.strip(), right.strip())
    if " — " in t:
        left, right = t.split(" — ", 1)
        left = left.strip()
        right = right.strip()
        if left in KNOWN_SUBJECTS:
            ci = _split_outside_parens(right)
            return (left, right[ci + 2:] if ci is not None else right)
        # 'کلاس [زنده|آفلاین] <subject> … — <rest>' -> topic is
        # 'کلاس <subject> — <rest>' with a trailing parenthetical dropped.
        mc = re.match(r"^کلاس\s+(?:زنده|آفلاین)?\s*"
                      r"(حسابان|شیمی|فیزیک|هندسه|گسسته|عربی|دینی|ادبیات|زبان انگلیسی)\b", left)
        if mc:
            r2 = re.sub(r"\s*\([^)]*\)\s*$", "", right).strip()
            return (mc.group(1), "کلاس " + mc.group(1) + (" — " + r2 if r2 else ""))
        for s in KNOWN_SUBJECTS:
            if s in left:
                # Left is only the subject + grade words / a parenthetical
                # qualifier (e.g. 'هندسه دوازدهم', 'حسابان (آزمون)',
                # 'هندسه دوازدهم و دهم (تکلیف و آزمون)') -> topic = right.
                rest = left.replace(s, "", 1).strip()
                if re.fullmatch(r"((دهم|یازدهم|دوازدهم)(\s+و\s+(دهم|یازدهم|دوازدهم))?)?"
                                r"\s*(\([^)]*\))?", rest):
                    ci = _split_outside_parens(right)
                    return (s, right[ci + 2:] if ci is not None else right)
                return (s, t)
    # 'کلاس [زنده|آفلاین] <subject> …' -> topic is 'کلاس <subject>'.
    m = re.match(r"^کلاس\s+(?:زنده|آفلاین)?\s*"
                 r"(حسابان|شیمی|فیزیک|هندسه|گسسته|عربی|دینی|ادبیات|زبان انگلیسی)\b", t)
    if m:
        return (m.group(1), "کلاس " + m.group(1))
    for s in KNOWN_SUBJECTS:
        if s in t:
            return (s, t)
    return (t, t)


def event_is_test(title):
    """Test box? The shipped boxes are test boxes when the title carries
    تست / تکلیف / آزمون — except a parenthesised '(آزمون)' qualifier, a
    'بدون تکلیف' class, or the 'کلاس جبرانی … + آزمون + دوره' class.
    (Checked against all 318 shipped boxes: 0 mismatches.)"""
    t = clean_event_title(title)
    # A parenthetical qualifier naming an exam ('(آزمون)',
    # '(پارت ۵: آزمون ۱ ساعته)') does not make the box a test box — but
    # '(آمادگی آزمون)' (preparation FOR an exam) and '(تست آزمون)' do count.
    def _strip_qualifier(m):
        inner = m.group(1)
        if "آزمون" in inner and "تست" not in inner and "آمادگی" not in inner:
            return ""
        return m.group(0)
    t2 = re.sub(r"\(([^)]*)\)", _strip_qualifier, t)
    if "بدون تکلیف" in t or t.startswith("کلاس جبرانی") \
            or t.startswith("مرور و جمع‌بندی آزمون"):
        return False
    return bool(re.search(r"تست|تکلیف|آزمون", t2))


# ---------- ICS parsing (stdlib only) ----------
def _ics_unfold(text):
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    out = []
    for ln in lines:
        if ln[:1] in (" ", "\t") and out:
            out[-1] += ln[1:]
        else:
            out.append(ln)
    return out


def _ics_split(line):
    """'DTSTART;TZID=Asia/Tehran:20261124T090000' -> ({'TZID': ...}, value)."""
    if ":" not in line:
        return {}, line
    head, value = line.split(":", 1)
    parts = head.split(";")
    params = {}
    for p in parts[1:]:
        if "=" in p:
            k, v = p.split("=", 1)
            params[k.strip().upper()] = v.strip()
    return params, value.strip()


def _parse_ics_dt(value, params):
    """Returns (aware datetime in Tehran, is_all_day) or (None, False)."""
    value = (value or "").strip()
    if not value:
        return None, False
    if params.get("VALUE", "").upper() == "DATE" or re.match(r"^\d{8}$", value):
        try:
            d = datetime.strptime(value[:8], "%Y%m%d").date()
        except Exception:
            return None, False
        return datetime(d.year, d.month, d.day, tzinfo=TEHRAN), True
    m = re.match(r"^(\d{8})T(\d{6})(Z)?$", value)
    if not m:
        try:
            dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=TEHRAN)
            return dt.astimezone(TEHRAN), False
        except Exception:
            return None, False
    base = datetime.strptime(m.group(1) + m.group(2), "%Y%m%d%H%M%S")
    if m.group(3) == "Z":
        return base.replace(tzinfo=timezone.utc).astimezone(TEHRAN), False
    tzid = (params.get("TZID") or "").upper()
    if tzid in ("UTC", "GMT", "ETC/UTC"):
        return base.replace(tzinfo=timezone.utc).astimezone(TEHRAN), False
    # A known TZID (e.g. Asia/Dubai, Europe/London) resolves through
    # zoneinfo; unknown/custom zone names and floating times fall back
    # to Tehran local (the previous behaviour for every non-UTC TZID).
    tzid_raw = (params.get("TZID") or "").strip()
    if tzid_raw and ZoneInfo is not None:
        try:
            return base.replace(tzinfo=ZoneInfo(tzid_raw)).astimezone(TEHRAN), False
        except Exception:
            pass
    return base.replace(tzinfo=TEHRAN), False


def _parse_rrule(value):
    out = {}
    for part in (value or "").split(";"):
        if "=" in part:
            k, v = part.split("=", 1)
            out[k.strip().upper()] = v.strip()
    return out


def _nth_weekday_of_month(year, month, weekday, n):
    """Date of the nth weekday (n >= 1) or the last one (n == -1) in a
    month, or None when that nth weekday does not exist (e.g. 5th Monday)."""
    first = datetime(year, month, 1).date()
    offset = (weekday - first.weekday()) % 7
    if n >= 1:
        try:
            return datetime(year, month, 1 + offset + (n - 1) * 7).date()
        except ValueError:
            return None
    if month == 12:
        nxt = datetime(year + 1, 1, 1).date()
    else:
        nxt = datetime(year, month + 1, 1).date()
    last = nxt - timedelta(days=1)
    return last - timedelta(days=(last.weekday() - weekday) % 7)


def _expand_rrule(start_dt, end_dt, rrule, exdates, range_start, range_end):
    """Expand one recurring master into (start, end) instances inside the
    date range. Day-by-day walk: simple, and correct for DAILY / WEEKLY /
    MONTHLY / YEARLY with INTERVAL, COUNT, UNTIL, BYDAY and EXDATE.
    HOURLY / MINUTELY walk in time steps (bounded). COUNT always counts
    from the recurrence start, never from the programme-range start, and
    UNTIL is compared as a datetime, not a date."""
    freq = (rrule.get("FREQ") or "").upper()
    if freq not in ("DAILY", "WEEKLY", "MONTHLY", "YEARLY", "HOURLY", "MINUTELY"):
        return [(start_dt, end_dt)]
    try:
        interval = max(1, int(rrule.get("INTERVAL") or 1))
    except Exception:
        interval = 1
    count = None
    try:
        if rrule.get("COUNT"):
            count = int(rrule["COUNT"])
    except Exception:
        count = None
    until_dt = None
    if rrule.get("UNTIL"):
        u, _ = _parse_ics_dt(rrule["UNTIL"], {})
        if u is not None:
            until_dt = u
    days = {"MO": 0, "TU": 1, "WE": 2, "TH": 3, "FR": 4, "SA": 5, "SU": 6}
    byday = None
    byday_ord = []
    if rrule.get("BYDAY"):
        for part in rrule["BYDAY"].split(","):
            m = re.fullmatch(r"(-?\d+)?(MO|TU|WE|TH|FR|SA|SU)", part.strip())
            if not m:
                continue
            if m.group(1):
                byday_ord.append((days[m.group(2)], int(m.group(1))))
            else:
                byday = byday or []
                byday.append(days[m.group(2)])
        if byday:
            byday = sorted(set(byday))
    duration = end_dt - start_dt
    start_date = start_dt.date()
    ex = set()
    for e in exdates or []:
        ex.add(e.date() if hasattr(e, "date") else e)
        if hasattr(e, "hour"):
            ex.add(e)
    out = []
    if freq in ("HOURLY", "MINUTELY"):
        step = timedelta(hours=interval) if freq == "HOURLY" \
            else timedelta(minutes=interval)
        range_end_dt = datetime(range_end.year, range_end.month, range_end.day,
                                23, 59, 59, tzinfo=TEHRAN)
        t = start_dt
        made = 0
        while t <= range_end_dt and made < 5000:
            if until_dt is not None and t > until_dt:
                break
            if count is not None and made >= count:
                break
            if t.date() >= range_start and t not in ex and t.date() not in ex:
                out.append((t, t + duration))
            made += 1
            t += step
        return out
    made = 0
    d = start_date
    while d <= range_end:
        if count is not None and made >= count:
            break
        ok = False
        delta_days = (d - start_date).days
        if freq == "DAILY":
            ok = delta_days % interval == 0
        elif freq == "WEEKLY":
            wanted = byday if byday else [start_dt.weekday()]
            ok = d.weekday() in wanted and (delta_days // 7) % interval == 0
        elif freq == "MONTHLY":
            months = (d.year - start_date.year) * 12 + (d.month - start_date.month)
            if months % interval != 0:
                ok = False
            elif byday_ord or byday:
                ok = any(_nth_weekday_of_month(d.year, d.month, wd, n) == d
                         for wd, n in byday_ord) or (bool(byday) and d.weekday() in byday)
            else:
                ok = d.day == start_date.day
        elif freq == "YEARLY":
            ok = (d.month == start_date.month and d.day == start_date.day
                  and (d.year - start_date.year) % interval == 0)
        if ok:
            inst_start = datetime(d.year, d.month, d.day, start_dt.hour,
                                  start_dt.minute, start_dt.second, tzinfo=TEHRAN)
            if until_dt is not None and inst_start > until_dt:
                break
            if inst_start not in ex and d not in ex:
                if d >= range_start:
                    out.append((inst_start, inst_start + duration))
                made += 1
            elif count is not None:
                made += 1
        d += timedelta(days=1)
    return out


def parse_ics(text):
    """Parse ICS text into raw events: {uid, title, start_dt, end_dt,
    status, all_day}. Recurring masters are expanded into instances
    (uid suffixed with the instance start); a cancelled master cancels
    all its instances. A VEVENT with RECURRENCE-ID is an exception for
    ONE instance of its master (moved or cancelled): it replaces that
    instance in place, keeping the instance UID, so the merge updates
    (or deletes) the same box instead of duplicating it."""
    raw = []
    exceptions = []
    rng = None  # programme range, read once (not per recurring master)
    cur = None
    for ln in _ics_unfold(text or ""):
        line = ln.strip()
        if line == "BEGIN:VEVENT":
            cur = {"props": []}
        elif line == "END:VEVENT" and cur is not None:
            props = {}
            for name, params, value in cur["props"]:
                props.setdefault(name, []).append((params, value))
            uid = ""
            for params, value in props.get("UID", []):
                uid = value
                break
            title = ""
            for params, value in props.get("SUMMARY", []):
                title = value
                break
            status = "confirmed"
            for params, value in props.get("STATUS", []):
                status = value.strip().lower()
                break
            s_dt, s_all = None, False
            e_dt = None
            for params, value in props.get("DTSTART", []):
                s_dt, s_all = _parse_ics_dt(value, params)
                break
            for params, value in props.get("DTEND", []):
                e_dt, _ = _parse_ics_dt(value, params)
                break
            if uid and title and s_dt is not None:
                if e_dt is None:
                    e_dt = s_dt + timedelta(hours=1)
                exdates = []
                for params, value in props.get("EXDATE", []):
                    for piece in value.split(","):
                        ed, _ = _parse_ics_dt(piece.strip(), params)
                        if ed is not None:
                            exdates.append(ed)
                rrules = [v for _, v in props.get("RRULE", [])]
                rec_id = None
                for params, value in props.get("RECURRENCE-ID", []):
                    rec_id, _ = _parse_ics_dt(value, params)
                    break
                if rec_id is not None:
                    # Exception for one instance of the master: apply it
                    # after the masters are expanded (below).
                    exceptions.append({"uid": uid, "rec_id": rec_id,
                                       "title": title, "start_dt": s_dt,
                                       "end_dt": e_dt, "status": status,
                                       "all_day": s_all})
                elif rrules:
                    if rng is None:
                        rng = _programme_range()
                    for inst_s, inst_e in _expand_rrule(
                            s_dt, e_dt, _parse_rrule(rrules[0]), exdates,
                            rng[0], rng[1]):
                        raw.append({"uid": uid + "#" + inst_s.strftime("%Y%m%dT%H%M"),
                                    "title": title, "start_dt": inst_s,
                                    "end_dt": inst_e, "status": status,
                                    "all_day": s_all})
                else:
                    raw.append({"uid": uid, "title": title, "start_dt": s_dt,
                                "end_dt": e_dt, "status": status,
                                "all_day": s_all})
            cur = None
        elif cur is not None and ":" in line:
            name = line.split(":", 1)[0].split(";", 1)[0].strip().upper()
            params, value = _ics_split(line)
            cur["props"].append((name, params, value))
    # Apply RECURRENCE-ID exceptions onto the expanded instances.
    for exc in exceptions:
        target_uid = exc["uid"] + "#" + exc["rec_id"].strftime("%Y%m%dT%H%M")
        replaced = False
        for ev in raw:
            if ev["uid"] == target_uid:
                # Keep the original instance UID so the merge updates
                # (or, when cancelled, deletes) the same box.
                ev["title"] = exc["title"]
                ev["start_dt"] = exc["start_dt"]
                ev["end_dt"] = exc["end_dt"]
                ev["status"] = exc["status"]
                ev["all_day"] = exc["all_day"]
                replaced = True
                break
        if not replaced:
            # Master instance outside the programme range (or an
            # unexpanded master): keep the exception under the instance
            # UID so a moved instance is not lost.
            raw.append({"uid": target_uid, "title": exc["title"],
                        "start_dt": exc["start_dt"], "end_dt": exc["end_dt"],
                        "status": exc["status"], "all_day": exc["all_day"]})
    return raw


# ---------- JSON export parsing ----------
def _iso_to_tehran(value):
    """ISO datetime (with offset, Z, or floating) -> Tehran datetime."""
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except Exception:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=TEHRAN)
    return dt.astimezone(TEHRAN)


def _hhmm(value):
    """HH:MM (or HHMM, e.g. "0900") -> (hour, minute)."""
    s = str(value or "").strip()
    if re.fullmatch(r"\d{4}", s):
        return int(s[:2]), int(s[2:])
    parts = (s.split(":") + ["0", "0"])[:2]
    return int(parts[0]), int(parts[1])


def parse_calendar_json(text):
    """Parse a calendar JSON export into the same raw-event shape as
    parse_ics. Accepts: (a) the Google Calendar API export
    ({items: [{id, iCalUID, summary, start: {dateTime}, end: {dateTime},
    status, recurringEventId}]}); (b) a plain array of events
    ({date, start, end, title}); (c) {boxes: [...]} in the same shape."""
    try:
        data = json.loads(text)
    except Exception as exc:
        raise ValueError("فایل JSON معتبر نیست: {}".format(exc))
    items = None
    if isinstance(data, dict) and isinstance(data.get("items"), list):
        items = data["items"]
    elif isinstance(data, list):
        items = data
    elif isinstance(data, dict) and isinstance(data.get("boxes"), list):
        items = data["boxes"]
    else:
        raise ValueError("ساختار JSON شناخته نشد — باید {items: [...]} یا آرایه‌ای از رویدادها باشد")
    raw = []
    rng = None
    # Explicit instances of a recurring master (Google API exports list
    # them with recurringEventId + originalStartTime): the master
    # expansion must skip those original times, or every instance is
    # counted twice (once expanded, once explicit).
    explicit = {}
    for it in items:
        if not isinstance(it, dict) or not it.get("recurringEventId"):
            continue
        orig = it.get("originalStartTime") or {}
        odt = _iso_to_tehran(orig.get("dateTime")) if orig.get("dateTime") else None
        if odt is None:
            s = it.get("start") or {}
            odt = _iso_to_tehran(s.get("dateTime")) if isinstance(s, dict) and s.get("dateTime") else None
        if odt is not None:
            explicit.setdefault(str(it["recurringEventId"]), set()).add(odt)
    for it in items:
        if not isinstance(it, dict):
            continue
        title = it.get("summary") or it.get("title") or ""
        status = str(it.get("status") or "confirmed").lower()
        uid = it.get("iCalUID") or it.get("uid") or it.get("id") or ""
        if it.get("recurringEventId"):
            uid = str(it.get("id") or uid)  # instances are unique by id
        start = it.get("start")
        end = it.get("end")
        s_dt = e_dt = None
        all_day = False
        if isinstance(start, dict):
            if start.get("dateTime"):
                s_dt = _iso_to_tehran(start["dateTime"])
            elif start.get("date"):
                all_day = True
                try:
                    d = datetime.strptime(start["date"][:10], "%Y-%m-%d").date()
                    s_dt = datetime(d.year, d.month, d.day, tzinfo=TEHRAN)
                except Exception:
                    s_dt = None
        elif isinstance(start, str):
            if "T" in start:
                s_dt = _iso_to_tehran(start)
            elif it.get("date"):
                try:
                    d = datetime.strptime(str(it["date"])[:10], "%Y-%m-%d").date()
                    hh, mm = _hhmm(start)
                    s_dt = datetime(d.year, d.month, d.day, hh, mm, tzinfo=TEHRAN)
                except Exception:
                    s_dt = None
        if isinstance(end, dict):
            if end.get("dateTime"):
                e_dt = _iso_to_tehran(end["dateTime"])
            elif end.get("date"):
                try:
                    d = datetime.strptime(end["date"][:10], "%Y-%m-%d").date()
                    e_dt = datetime(d.year, d.month, d.day, tzinfo=TEHRAN)
                except Exception:
                    e_dt = None
        elif isinstance(end, str):
            if "T" in end:
                e_dt = _iso_to_tehran(end)
            elif s_dt is not None:
                try:
                    hh, mm = _hhmm(end)
                    e_dt = datetime(s_dt.year, s_dt.month, s_dt.day, hh, mm, tzinfo=TEHRAN)
                except Exception:
                    e_dt = None
        if not title or s_dt is None:
            continue
        if e_dt is None:
            e_dt = s_dt + timedelta(hours=1)
        if not uid:
            uid = "manual-" + sha256_bytes(
                (s_dt.strftime("%Y-%m-%d %H:%M") + "|" + title).encode("utf-8"))[:12]
        # A Google item carrying its own RRULE (no expanded instances in
        # the file): expand it the same way as an ICS master.
        recurrence = it.get("recurrence") or []
        rrule = None
        for r in recurrence:
            if isinstance(r, str) and r.startswith("RRULE:"):
                rrule = _parse_rrule(r[len("RRULE:"):])
                break
        if rrule:
            if rng is None:
                rng = _programme_range()
            skip = explicit.get(str(it.get("id") or uid), set())
            for inst_s, inst_e in _expand_rrule(s_dt, e_dt, rrule, [], rng[0], rng[1]):
                if inst_s in skip:
                    continue
                raw.append({"uid": str(uid) + "#" + inst_s.strftime("%Y%m%dT%H%M"),
                            "title": title, "start_dt": inst_s, "end_dt": inst_e,
                            "status": status, "all_day": all_day})
        else:
            raw.append({"uid": str(uid), "title": title, "start_dt": s_dt,
                        "end_dt": e_dt, "status": status, "all_day": all_day})
    return raw


def normalize_events(raw):
    """Raw events -> present events [{uid, title, date, start, end}],
    cancelled uids, and skip counts. Filters the nightly sleep reminder
    and zero-duration events (the same filter the original build used),
    skips all-day events, and dedupes by UID."""
    events = []
    cancelled = set()
    counts = {"skipped_sleep": 0, "skipped_zero": 0, "skipped_allday": 0,
              "cancelled": 0, "duplicates": 0}
    seen = {}
    for ev in raw or []:
        uid = str(ev.get("uid") or "")
        title = (ev.get("title") or "").strip()
        s_dt = ev.get("start_dt")
        e_dt = ev.get("end_dt")
        if not uid or not title or s_dt is None or e_dt is None:
            continue
        if str(ev.get("status") or "").lower() in ("cancelled", "canceled"):
            cancelled.add(uid)
            counts["cancelled"] += 1
            continue
        if SLEEP_MARKER in title:
            counts["skipped_sleep"] += 1
            continue
        if e_dt <= s_dt:
            counts["skipped_zero"] += 1
            continue
        if ev.get("all_day"):
            counts["skipped_allday"] += 1
            continue
        key = uid
        if key in seen and (seen[key]["date"], seen[key]["start"]) != (
                s_dt.strftime("%Y-%m-%d"), s_dt.strftime("%H:%M")):
            key = uid + "#" + s_dt.strftime("%Y%m%dT%H%M")
        if key in seen:
            counts["duplicates"] += 1
            continue
        item = {"uid": key, "title": title, "date": s_dt.strftime("%Y-%m-%d"),
                "start": s_dt.strftime("%H:%M"), "end": e_dt.strftime("%H:%M")}
        seen[key] = item
        events.append(item)
    events.sort(key=lambda e: (e["date"], e["start"], e["title"]))
    return events, cancelled, counts


# ---------- Programme store (data dir) ----------
def _programme_range():
    """(first, last) programme dates, for recurring-event expansion."""
    data, _ = read_json_file(CALENDAR_DATA_FILE)
    boxes = []
    if isinstance(data, dict) and isinstance(data.get("boxes"), list):
        boxes = data["boxes"]
    else:
        shipped, _ = read_json_file(os.path.join(BASE, "data.json"))
        if isinstance(shipped, dict) and isinstance(shipped.get("boxes"), list):
            boxes = shipped["boxes"]
    if boxes:
        dates = sorted(b["date"] for b in boxes if b.get("date"))
        if dates:
            return (datetime.strptime(dates[0], "%Y-%m-%d").date(),
                    datetime.strptime(dates[-1], "%Y-%m-%d").date())
    today = datetime.now(tz=TEHRAN).date()
    return (today, today + timedelta(days=180))


class ProgrammeCorruptError(Exception):
    """calendar_data.json exists but is unreadable and no verified backup
    restores it (v1.11.25, QA BUG-024). The shipped seed must NEVER be
    substituted silently here: it would drop every Google link and every
    programme change since install, and the next save would persist the
    stale seed over the real data. Handlers turn this into a 500 with
    this message; the sync path records it in the sync log."""


class _BadJsonBody(Exception):
    """Raised by _read_json when the request body is unusable (v1.11.26,
    QA BUG-030). The three cases used to collapse into one misleading
    {} — invalid JSON, an over-large body and an empty body all looked
    the same to the handler. Now each carries its own HTTP status and
    message, and handle() answers with it instead of letting the
    handler guess: invalid JSON → 400 «JSON نامعتبر», too large → 413,
    empty → 400 «بدنه خالی»."""
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status
        self.message = message


def load_programme():
    data, _ = read_json_file(CALENDAR_DATA_FILE)
    if isinstance(data, dict) and isinstance(data.get("boxes"), list):
        data.setdefault("uid_map", {})
        data.setdefault("tombstone_uids", [])
        data.setdefault("tombstone_box_ids", [])
        data.setdefault("meta", {})
        return data
    had_file = os.path.isfile(CALENDAR_DATA_FILE)
    if had_file:
        # Corrupt (unparseable, or valid JSON with the wrong shape) —
        # preserve it before any recovery overwrites it (v1.11.23, QA
        # BUG-009). Without this, a corrupt programme silently fell
        # back to the shipped 318-box seed with an empty uid_map —
        # every Google link lost.
        _preserve_corrupt(CALENDAR_DATA_FILE)
        print("calendar_data.json is corrupt — restoring from backup")
    entry, backup = newest_verified_backup("programme")
    if backup is not None:
        atomic_write_json(CALENDAR_DATA_FILE, backup)
        print("Restored calendar programme from backup {}".format(entry["file"]))
        return backup
    if had_file:
        # v1.11.25 (QA BUG-024): corrupt WITH no backup — never fall back
        # to the shipped seed. The corrupt bytes are already preserved
        # as .corrupt-<ts>; the user restores a backup or repairs the
        # file by hand. The seed is only for a first install (no file
        # ever existed).
        raise ProgrammeCorruptError(
            "فایل برنامه (calendar_data.json) خراب است و بکاپی برای بازیابی نیست — "
            "فایل خراب حفظ شده است؛ یک بکاپ را restore کن یا فایل را دستی برگردان")
    shipped, _ = read_json_file(os.path.join(BASE, "data.json"))
    if isinstance(shipped, dict) and isinstance(shipped.get("boxes"), list):
        return {"meta": dict(shipped.get("meta") or {}),
                "boxes": shipped["boxes"], "uid_map": {},
                "tombstone_uids": [], "tombstone_box_ids": []}
    return {"meta": {}, "boxes": [], "uid_map": {},
            "tombstone_uids": [], "tombstone_box_ids": []}


def save_programme(prog):
    with STATE_LOCK:
        atomic_write_json(CALENDAR_DATA_FILE, prog)
        create_backup("programme")
        CLOUD_SYNC.request()
    return prog


def _box_touched(state, box_id):
    """Was this box ever touched in the app? (tick, tests, edit, total)."""
    if (state.get("done") or {}).get(box_id):
        return True
    tr = (state.get("tests") or {}).get(box_id) or {}
    if (tr.get("completed") or 0) > 0:
        return True
    if box_id in (state.get("edits") or {}):
        return True
    if box_id in (state.get("tests_total") or {}):
        return True
    return False


def _hhmm_to_min(value):
    """'HH:MM' -> minutes since midnight, or None when unparsable."""
    try:
        h, m = str(value or "").split(":")
        h, m = int(h), int(m)
    except (ValueError, AttributeError):
        return None
    if not (0 <= h <= 23 and 0 <= m <= 59):
        return None
    return h * 60 + m


def _intervals_overlap(a_start, a_end, b_start, b_end):
    """Do two 'HH:MM' intervals overlap? An end <= start is an overnight
    interval (past midnight), so that end is read as +24h."""
    a0, a1 = _hhmm_to_min(a_start), _hhmm_to_min(a_end)
    b0, b1 = _hhmm_to_min(b_start), _hhmm_to_min(b_end)
    if a0 is None or a1 is None or b0 is None or b1 is None:
        return False
    if a1 <= a0:
        a1 += 1440
    if b1 <= b0:
        b1 += 1440
    return a0 < b1 and b0 < a1


def _study_day_of(date_iso, start):
    """Study day of a box: the day starts at 03:30 — a box starting
    before 03:30 belongs to the previous day (the same rule as
    app.js boxStudyDay)."""
    m = _hhmm_to_min(start)
    if m is None or m >= 210:
        return date_iso
    try:
        d = datetime.strptime(date_iso, "%Y-%m-%d").date() - timedelta(days=1)
        return d.isoformat()
    except Exception:
        return date_iso


def _box_minutes(start, end):
    """Planned minutes of one box; end <= start means overnight (+24h),
    and a zero-length box counts 0 (never 1440 — audit §5 item 1.5)."""
    a0, a1 = _hhmm_to_min(start), _hhmm_to_min(end)
    if a0 is None or a1 is None:
        return 0
    return (a1 - a0) % 1440


# ---------- Programme-issue detection (audit §5 item 2.8) ----------
# The server-side twin of app.js dayIssues(): (a) overlapping boxes in
# a study day, (b) a day over 12h planned, (c) more than 2 boxes of one
# subject in a day, (d) the hardest lesson in the day's last box.
# Warnings only — the box API never refuses a create/update because of
# them; the response just carries a "warnings" list for the caller.
# "Hardest" is the subject with the lowest test accuracy (attempted >= 10
# tests) — the only honest proxy the data supports; with no test data
# the rule is skipped silently instead of guessing.
def programme_issues(prog, state, day, extra=None, exclude_id=None):
    boxes = [b for b in _public_boxes_list(prog, state)
             if _study_day_of(b.get("date") or "", b.get("start") or "") == day
             and b.get("id") != exclude_id]
    if extra:
        boxes.append(extra)

    def _order(b):
        m = _hhmm_to_min(b.get("start") or "")
        return (m - 210 + 1440) % 1440 if m is not None else 0
    boxes.sort(key=_order)
    issues = []
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            a, b = boxes[i], boxes[j]
            if _intervals_overlap(a.get("start"), a.get("end"),
                                  b.get("start"), b.get("end")):
                issues.append({"kind": "overlap",
                               "titles": [a.get("title") or "",
                                          b.get("title") or ""]})
    total = sum(_box_minutes(b.get("start"), b.get("end")) for b in boxes)
    if total > 720:
        issues.append({"kind": "over12h", "minutes": total})
    counts = {}
    for b in boxes:
        counts[b.get("subject") or ""] = counts.get(b.get("subject") or "", 0) + 1
    for s, n in counts.items():
        if n > 2:
            issues.append({"kind": "over2", "subject": s, "count": n})
    tests = state.get("tests") or {}
    by_subj = {}
    for b in _public_boxes_list(prog, state):
        tr = tests.get(b.get("id")) or {}
        v = by_subj.setdefault(b.get("subject") or "", {"tests": 0, "correct": 0})
        v["tests"] += tr.get("completed") or 0
        v["correct"] += tr.get("correct") or 0
    worst = None
    worst_acc = None
    for s, v in by_subj.items():
        if v["tests"] < 10:
            continue
        acc = v["correct"] / v["tests"]
        if worst_acc is None or acc < worst_acc:
            worst_acc = acc
            worst = s
    if worst and boxes and (boxes[-1].get("subject") or "") == worst:
        issues.append({"kind": "hardest", "subject": worst})
    return issues


# (v1.11.9: _title_similarity was removed with the title-similarity
# matcher — the merge never links by similarity any more. Only the UID
# or an exact (date+start+title) match links a feed event to a box.)
@_with_lock
def merge_calendar_events(events, cancelled_uids, source_label, apply=True,
                          remove_missing=True):
    """The single merge used by auto sync AND manual import. With
    apply=False it is a dry run (preview): nothing is written, no log.
    remove_missing: True for the live auto/manual sync (the ICS feed IS
    the whole calendar, so an absent event was deleted in Google);
    False for file imports (a file may be a partial export — there only
    events explicitly marked cancelled in the file unlink boxes).
    A box is NEVER deleted by a pull (rules 2/5): a box whose Google
    event is gone is unlinked and flagged `orphaned`, so its record stays
    where it was — the dashboard is the primary source of task data and
    the calendar is only an external link (v1.11.9). The box stays in
    its section with no connection badge; only the user moves or deletes
    it, by hand. A later pull (or a manual reconnect) re-links it and
    clears the flag. Linking is by UID first, else by an exact
    (date+start+title) triple — and only when that triple is unambiguous.
    No similarity of any kind is ever used to link (v1.11.9, spec §4).
    Returns a summary dict with counts and capped title lists."""
    prog = load_programme()
    boxes = prog["boxes"]
    uid_map = dict(prog.get("uid_map") or {})
    tomb_uids = set(prog.get("tombstone_uids") or [])
    tomb_box = set(prog.get("tombstone_box_ids") or [])
    state = load_state()
    deleted = set(state.get("deleted") or [])
    edits = state.get("edits") or {}
    # Two-way bookkeeping (v1.11.0): Google is ALWAYS the authority for
    # programme content. last_pull_ts is an epoch float stored in prog
    # meta (see the apply block below). A box edited in the app AFTER the
    # last successful pull AND changed in Google too is a conflict — the
    # pull applies Google's values unconditionally and the app's edit is
    # dropped (see the conflict branch below); it is never pushed over
    # Google's version. An app edit with no Google change is untouched
    # by the pull and is pushed as before.
    pstate = load_push_state()
    last_pull_ts = (prog.get("meta") or {}).get("last_pull_ts") or 0
    push_last_updates = {}
    overlay_updates = {}
    conflict_notes = []
    push_forget = set()   # drop last_pushed + app_edited_at (keep event_map)
    push_unmap = set()    # also drop event_map (the Google event is gone)
    pstate_dirty = False
    # Boxes deleted in the app tombstone their UID: never resurrected.
    for uid, bid in list(uid_map.items()):
        if bid in deleted:
            tomb_uids.add(uid)
            tomb_box.add(bid)
            del uid_map[uid]
    tomb_box |= deleted
    by_id = {b["id"]: b for b in boxes}
    dates = sorted({e["date"] for e in events})
    span = (dates[0], dates[-1]) if dates else (None, None)
    log = []
    added, updated, removed, unlinked = [], [], [], []
    skipped_tomb = 0
    kept_touched = 0
    next_num = 318
    for b in boxes:
        m = re.match(r"^b(\d+)$", b.get("id") or "")
        if m:
            next_num = max(next_num, int(m.group(1)))

    def find_exact_matches(date, start, title):
        # v1.11.9: the ONLY first-time linking mechanism besides the UID.
        # An exact (date + start time + title) triple — how the 318 seed
        # boxes get their Event IDs on the first pull. Returns EVERY
        # match; the caller links only when there is exactly one, so an
        # ambiguous triple links nothing and waits for manual reconnect.
        # No similarity of any kind is ever used to link (user spec §4).
        out = []
        for b in boxes:
            if b["id"] in deleted or b["id"] in uid_map.values():
                continue
            if b["date"] == date and b["start"] == start and b["title"] == title:
                out.append(b)
        return out

    def find_deleted_match(date, start, title):
        # A box the user already deleted in the app: match it ONLY to
        # tombstone the UID — its event must never be recreated as a new box.
        for b in boxes:
            if b["id"] in deleted and b["date"] == date \
                    and b["start"] == start and b["title"] == title:
                return b
        return None

    seen_uids = set()
    for ev in events:
        uid = ev["uid"]
        seen_uids.add(uid)
        if uid in tomb_uids:
            skipped_tomb += 1
            log.append("رد شد (حذف‌شده در برنامه): {}".format(ev["title"]))
            continue
        bid = uid_map.get(uid)
        box = by_id.get(bid) if bid else None
        if bid and box is None:
            del uid_map[uid]
            bid = None
        if box is None:
            dm = find_deleted_match(ev["date"], ev["start"], ev["title"])
            if dm is not None:
                tomb_uids.add(uid)
                tomb_box.add(dm["id"])
                skipped_tomb += 1
                log.append("رد شد (حذف‌شده در برنامه): {}".format(ev["title"]))
                continue
            ms = find_exact_matches(ev["date"], ev["start"], ev["title"])
            if len(ms) == 1:
                m = ms[0]
                uid_map[uid] = m["id"]
                box = m
                bid = m["id"]
                log.append("تطبیق اول: {} -> {}".format(ev["title"], bid))
            elif len(ms) > 1:
                # Ambiguous exact triple: link NOTHING — the user reconnects
                # manually (spec §4). v1.11.25 (QA BUG-020): the event is
                # SKIPPED entirely — it used to fall through and be
                # created as a third duplicate box (b171, b900 AND b901)
                # even though the comment said it "waits for manual
                # reconnect". It still lands in meta["last_feed"] (every
                # feed event is recorded there), so the reconnect picker
                # can still suggest it.
                log.append("تطبیق دقیق مبهم ({} نامزد) — بدون پیوند، بدون باکس جدید: {}".format(
                    len(ms), ev["title"]))
                continue
        if box is not None:
            if bid in deleted:
                tomb_uids.add(uid)
                uid_map.pop(uid, None)
                skipped_tomb += 1
                log.append("رد شد (حذف‌شده در برنامه): {}".format(ev["title"]))
                continue
            # Re-linked: the Google event exists again, so the box is no
            # longer orphaned — it returns to the current programme.
            if box.pop("orphaned", None) is not None:
                log.append("وصل شد دوباره: {} ({})".format(ev["title"], bid))
            subj, topic = derive_subject_topic(ev["title"])
            # Effective values: what the user actually sees (programme box
            # + the state.edits overlay). The pull compares against these.
            ov = edits.get(bid) or {}
            eff = {"title": ov.get("title", box.get("title")),
                   "date": ov.get("date", box.get("date")),
                   "start": ov.get("start", box.get("start")),
                   "end": ov.get("end", box.get("end"))}
            evv = {"title": ev["title"], "date": ev["date"],
                   "start": ev["start"], "end": ev["end"]}
            if eff == evv:
                # Fully in sync with Google: any pending app edit is done.
                if (pstate.get("app_edited_at") or {}).pop(bid, None) is not None:
                    pstate_dirty = True
                if apply:
                    push_last_updates[bid] = evv
                continue
            edited_after_pull = (pstate.get("app_edited_at") or {}).get(bid, 0) > (last_pull_ts or 0)
            if edited_after_pull:
                last_google = (pstate.get("last_pushed") or {}).get(bid)
                if isinstance(last_google, dict) and last_google == evv:
                    # Google has NOT changed since the last pull — the
                    # only difference is the app's own edit. Keep it:
                    # the pending push sends it to Google. (Previously
                    # this was misread as a conflict and the app edit
                    # was dropped even when Google was byte-identical.)
                    log.append("حفظ شد (ویرایش برنامه؛ تقویم تغییری نکرده): {}".format(ov.get("title") or ev["title"]))
                    continue
                # CONFLICT (Google always wins, 2026-11-24): the box was
                # edited in the app after the last pull AND Google changed
                # it too. The app's edit is DROPPED — it is never pushed
                # over Google's version. Fall through to the Google-wins
                # application below, which overwrites the programme box
                # and reconciles the overlay to Google's values (so the
                # next push cannot re-send the dropped edit); this log
                # line and the conflicts list are the only trace of it.
                dropped_title = ov.get("title") or ev["title"]
                log.append("تعارض — نسخه‌ی تقویم اعمال شد؛ ویرایش برنامه برای «{}» کنار گذاشته شد".format(dropped_title))
                conflict_notes.append({"box_id": bid, "title": dropped_title, "ts": iso_now()})
            # Google wins: apply the event to the programme box AND to the
            # app-edit overlay (otherwise the overlay would mask the pull
            # and the next push would send the old values back to Google).
            changes = {k: v for k, v in evv.items() if box.get(k) != v}
            ov_changes = {k: v for k, v in evv.items()
                          if bid in edits and ov.get(k) != v}
            if changes or ov_changes:
                for k, v in changes.items():
                    box[k] = v
                if "title" in changes:
                    box["subject"] = subj
                    box["topic"] = topic
                    box["is_test"] = event_is_test(ev["title"])
                if ov_changes:
                    overlay_updates[bid] = evv
                if apply:
                    push_last_updates[bid] = evv
                if (pstate.get("app_edited_at") or {}).pop(bid, None) is not None:
                    pstate_dirty = True
                updated.append(ev["title"])
                log.append("به‌روز شد: {} ({})".format(ev["title"], bid))
            continue
        # Brand-new event -> brand-new box.
        next_num += 1
        nid = "b{}".format(next_num)
        subj, topic = derive_subject_topic(ev["title"])
        nb = {"id": nid, "date": ev["date"], "start": ev["start"],
              "end": ev["end"], "subject": subj, "topic": topic,
              "title": ev["title"], "is_test": event_is_test(ev["title"]),
              "tests_total": 0, "note": ""}
        boxes.append(nb)
        by_id[nid] = nb
        uid_map[uid] = nid
        added.append(ev["title"])
        if apply:
            push_last_updates[nid] = {"title": ev["title"], "date": ev["date"],
                                      "start": ev["start"], "end": ev["end"]}
        log.append("اضافه شد: {} ({})".format(ev["title"], nid))
    # Orphaned boxes (v1.11.7, kept in v1.11.9): a programme box with no
    # UID link that falls inside the feed's date span and has no feed
    # event claiming it is stale — Google deleted it or replaced it with
    # a renamed/moved event (which the loop above created anew, since the
    # merge never links by similarity). After the event loop every live
    # feed event is linked to exactly one box, so "unmapped" already means
    # "no event claims this box". The record is NEVER deleted (rules 2/5):
    # it is only flagged `orphaned`. v1.11.9: the box STAYS in its section
    # (dashboard / programme / review-past) with no connection badge —
    # only the user moves or deletes it, by hand. A later pull re-links
    # it and clears the flag. Live sync only: file imports never orphan
    # unmapped boxes (remove_missing=False) — a file may be a partial
    # export. Custom boxes live in state.custom_boxes and are untouched
    # here. This pass runs BEFORE the mapped loop below: a box the mapped
    # loop unlinks (touched) must not be counted a second time here.
    # Feed-freshness guard (v1.11.28, QA BUG-042): a stale/partial ICS
    # used to orphan every in-span box it did not mention — one bad
    # fetch cut the link for a whole stretch of the programme, and
    # those boxes could not push or sync done flags until the next
    # good pull. Count what this pull WOULD orphan first: unmapped
    # in-span boxes plus mapped UIDs absent from the feed (both
    # span-scoped; deleted and already-orphaned boxes excluded). The
    # feed is suspicious when that is 3+ boxes AND more than half of
    # the mapped in-span boxes, or 5+ boxes outright. A genuinely
    # deleted event orphans 1–2 boxes and stays well under the bar.
    # When suspicious, the adds/updates above still apply, but NO
    # link is dropped and no box is flagged — the previous links are
    # kept and the feed is flagged. The one exception: the SAME boxes
    # missing on two consecutive pulls means the feed is consistently
    # without them (genuine deletions, not a stale fetch), so the
    # orphaning applies on the second one and the flag clears.
    # Explicitly cancelled events in a file import
    # (remove_missing=False) are deliberate deletions, so the guard
    # only covers the absence-based orphaning of the live sync.
    would_orphan_ids = set()
    mapped_in_span = 0
    if remove_missing and span[0]:
        uid_bids = set(uid_map.values())
        for b in boxes:
            if b["id"] in deleted or b["id"] in tomb_box or b.get("orphaned"):
                continue
            if not (span[0] <= b.get("date", "") <= span[1]):
                continue
            if b["id"] not in uid_bids:
                would_orphan_ids.add(b["id"])
        for uid, bid in list(uid_map.items()):
            box = by_id.get(bid)
            if box is None or bid in deleted:
                continue
            if not (span[0] <= box.get("date", "") <= span[1]):
                continue
            mapped_in_span += 1
            if uid not in seen_uids:
                would_orphan_ids.add(bid)
    would_orphan = len(would_orphan_ids)
    suspicious_feed = (
        (would_orphan >= 3 and mapped_in_span > 0
         and would_orphan * 2 > mapped_in_span)
        or would_orphan >= 5)
    if suspicious_feed and apply:
        prev_blocked = set(((prog.get("meta") or {}).get("feed_guard_blocked") or []))
        if prev_blocked and prev_blocked <= would_orphan_ids:
            suspicious_feed = False
    if suspicious_feed:
        log.append("فید مشکوک — {} باکس یتیم می‌شد؛ لینک‌های قبلی حفظ شد".format(would_orphan))
    if remove_missing and not suspicious_feed:
        for b in list(boxes):
            bid = b["id"]
            if bid in uid_map.values():
                continue
            if bid in deleted or bid in tomb_box:
                continue
            if b.get("orphaned"):
                continue
            if span[0] and not (span[0] <= b.get("date", "") <= span[1]):
                continue
            b["orphaned"] = True
            if _box_touched(state, bid):
                kept_touched += 1
            push_unmap.add(bid)
            unlinked.append(b.get("title") or bid)
            log.append("حفظ شد (رویداد از تقویم حذف شده): {} ({})".format(
                b.get("title"), bid))
    # Unlinking (v1.11.7): mapped UIDs absent from the feed, scoped to the
    # feed's own date span (a partial export never unlinks outside its
    # range). With remove_missing=False (file imports) only events the
    # file marks cancelled are unlink candidates — mere absence means
    # nothing there. No box is ever deleted here (rules 2/5): the link is
    # dropped and the box is flagged orphaned, so its record stays in
    # history / review-past.
    for uid, bid in list(uid_map.items()):
        if uid in seen_uids:
            continue
        if not remove_missing and uid not in (cancelled_uids or set()):
            continue
        box = by_id.get(bid)
        if box is None:
            del uid_map[uid]
            continue
        if span[0] and not (span[0] <= box.get("date", "") <= span[1]):
            continue
        if bid in deleted:
            tomb_uids.add(uid)
            del uid_map[uid]
            push_forget.add(bid)
            continue
        if _box_touched(state, bid):
            if suspicious_feed:
                # Guarded (BUG-042): keep the link, flag nothing.
                continue
            del uid_map[uid]  # orphan: keep the box, drop the link
            box["orphaned"] = True
            kept_touched += 1
            push_unmap.add(bid)
            unlinked.append(box.get("title") or bid)
            log.append("حفظ شد (در برنامه لمس شده): {} ({})".format(box.get("title"), bid))
            continue
        # Never delete a box because Google deleted its event (rules 2/5):
        # keep the record in place, drop only the link, and flag it
        # orphaned — the box stays in its section with no connection badge
        # (v1.11.9: no hiding, no auto-move; the user decides by hand).
        if suspicious_feed:
            # Guarded (BUG-042): keep the link, flag nothing.
            continue
        del uid_map[uid]
        box["orphaned"] = True
        push_unmap.add(bid)
        unlinked.append(box.get("title") or bid)
        log.append("حفظ شد (رویداد از تقویم حذف شده): {} ({})".format(box.get("title"), bid))
    summary = {"added": len(added), "updated": len(updated),
               "removed": len(removed), "unlinked": len(unlinked),
               "skipped_tombstone": skipped_tomb,
               "kept_touched": kept_touched,
               "cancelled": len(cancelled_uids or []),
               "conflicts": len(conflict_notes),
               "suspicious_feed": suspicious_feed,
               "orphaned_blocked": would_orphan if suspicious_feed else 0,
               "dropped_titles": [c.get("title") for c in conflict_notes][:20],
               "span_from": span[0], "span_to": span[1],
               "box_count": len(boxes),
               "added_titles": added[:20], "updated_titles": updated[:20],
               "removed_titles": removed[:20],
               "unlinked_titles": unlinked[:20]}
    if apply:
        prog["boxes"] = boxes
        prog["uid_map"] = uid_map
        prog["tombstone_uids"] = sorted(tomb_uids)
        prog["tombstone_box_ids"] = sorted(tomb_box)
        meta = dict(prog.get("meta") or {})
        meta["last_sync"] = iso_now()
        meta["last_source"] = source_label
        meta["last_pull_ts"] = now_ts()
        # v1.11.9: remember the last successful pull's feed (uid/title/
        # date/start/end per event) so the reconnect picker can list the
        # currently-unlinked Google events without re-fetching. This is
        # feed data, not user data — it is replaced on every pull.
        meta["last_feed"] = [{"uid": e["uid"], "title": e["title"],
                              "date": e["date"], "start": e["start"],
                              "end": e["end"]} for e in events]
        meta["last_feed_ts"] = iso_now()
        # v1.11.28 (QA BUG-042): remember the blocked set so a second
        # consecutive pull missing the SAME boxes can confirm genuine
        # deletions; a clean pull clears it.
        if suspicious_feed:
            meta["feed_guard_blocked"] = sorted(would_orphan_ids)
        else:
            meta.pop("feed_guard_blocked", None)
        prog["meta"] = meta
        # Push-state bookkeeping from this pull: boxes now in sync with
        # Google, conflicts to push, overlay reconciliation, and cleanup
        # for boxes that left the programme.
        if push_last_updates:
            lp = dict(pstate.get("last_pushed") or {})
            lp.update(push_last_updates)
            pstate["last_pushed"] = lp
            pstate_dirty = True
        if conflict_notes:
            # Dropped local edits are recorded for the UI, but they are
            # RESOLVED — never queued for push (Google's version stands).
            conf = list(pstate.get("conflicts") or [])
            seen_c = {c.get("box_id") for c in conf}
            for c in conflict_notes:
                if c["box_id"] not in seen_c:
                    conf.append(c)
            pstate["conflicts"] = conf[-20:]
            pend = set(pstate.get("pending") or [])
            pend -= {c["box_id"] for c in conflict_notes}
            pstate["pending"] = sorted(pend)
            pstate_dirty = True
        if push_forget or push_unmap:
            lp = dict(pstate.get("last_pushed") or {})
            em = dict(pstate.get("event_map") or {})
            ae = dict(pstate.get("app_edited_at") or {})
            for bid in push_forget:
                lp.pop(bid, None)
                ae.pop(bid, None)
            for bid in push_unmap:
                lp.pop(bid, None)
                ae.pop(bid, None)
                em.pop(bid, None)
            pstate["last_pushed"] = lp
            pstate["event_map"] = em
            pstate["app_edited_at"] = ae
            pstate_dirty = True
        if overlay_updates:
            st = load_state()
            ed = st.get("edits") or {}
            for bid, vals in overlay_updates.items():
                if bid in ed:
                    ed[bid].update(vals)
            st["edits"] = ed
            save_state(st)
        if pstate_dirty:
            save_push_state(pstate)
        save_programme(prog)
        append_calendar_log(source_label, summary, log)
    return summary


# ---------- Calendar config + log ----------
def load_calendar_config():
    data, _ = read_json_file(CALENDAR_CONFIG_FILE)
    if isinstance(data, dict):
        data.setdefault("log", [])
        return data
    return {"ics_url": "", "interval_minutes": 30, "enabled": False,
            "last_sync": None, "last_error": None, "last_summary": None,
            "log": []}


def save_calendar_config(cfg):
    atomic_write_json(CALENDAR_CONFIG_FILE, cfg)


def masked_ics_url(url):
    url = (url or "").strip()
    if not url:
        return ""
    m = re.match(r"^(https?://[^/]+/).*$", url)
    if not m:
        return "•••"
    # Only the scheme + host: the path carries the private token, and
    # even its last 8 characters are part of that secret.
    return m.group(1) + "•••"


def masked_calendar_config(cfg):
    return {"configured": bool((cfg.get("ics_url") or "").strip()),
            "enabled": bool(cfg.get("enabled")),
            "ics_url_masked": masked_ics_url(cfg.get("ics_url") or ""),
            "interval_minutes": int(cfg.get("interval_minutes") or 30),
            "last_sync": cfg.get("last_sync"),
            "last_error": cfg.get("last_error"),
            "last_summary": cfg.get("last_summary")}


def append_calendar_log(source, summary, lines):
    cfg = load_calendar_config()
    log = cfg.get("log") or []
    log.append({"ts": iso_now(), "source": source, "summary": summary,
                "lines": (lines or [])[:60]})
    cfg["log"] = log[-CALENDAR_LOG_MAX:]
    try:
        save_calendar_config(cfg)
    except Exception as exc:
        print("Could not save calendar log: {}".format(exc))


def calendar_status_payload():
    cfg = load_calendar_config()
    prog = load_programme()
    # v1.11.10: the frontend's boxes (data.json seed + state.edits) carry
    # no Google Event ID, so boxConnected() was false for every box and
    # the «متصل» badge never showed (user-reported bug, 24 Nov 20:09).
    # The status payload now ships the REAL per-box link data — the full
    # uid_map (Google Event ID -> boxId, the server's native shape) and
    # the orphaned box ids — so the frontend can stamp them onto the
    # rendered boxes (it inverts uid_map to boxId -> Event ID).
    return {"config": masked_calendar_config(cfg),
            "programme": {"box_count": len(prog.get("boxes") or []),
                          "mapped": len(prog.get("uid_map") or {}),
                          "tombstones": len(prog.get("tombstone_uids") or []),
                          "last_source": (prog.get("meta") or {}).get("last_source"),
                          "uid_map": dict(prog.get("uid_map") or {}),
                          "orphaned": [b.get("id") for b in (prog.get("boxes") or [])
                                       if b.get("orphaned") and b.get("id")]},
            "log": (cfg.get("log") or [])[-20:],
            "oauth": masked_oauth_status(),
            "push": push_status_payload()}


# ---------- Google Calendar two-way sync (Part B, v1.11.0) ----------
# OAuth 2.0 (Desktop-app client «StudyFlow Desktop», Google Cloud project
# «StudyFlow»). The Client ID is pre-filled as a default (a public
# identifier, not a secret); the Client Secret is pasted once by the user in
# settings. The secret is REQUIRED for this client: verified 2026-11-24
# against the real token endpoint — without it Google answers 400
# invalid_request «client_secret is missing». The sign-in uses PKCE
# (RFC 8252, code_challenge_method=S256) on top of the secret.
# Client Secret + access/refresh tokens live ONLY in the data dir
# (google_oauth.json) and are never sent to the browser; the UI only ever
# sees masked values. Google endpoints are overridable through env vars
# (GOOGLE_OAUTH_AUTH_URL / GOOGLE_OAUTH_TOKEN_URL / GOOGLE_OAUTH_REVOKE_URL /
# GOOGLE_CALENDAR_API_BASE) so tests can point the server at a local fake
# Google; production defaults are the real Google URLs.
GOOGLE_OAUTH_FILE = os.path.join(DATA_DIR, "google_oauth.json")
GOOGLE_PUSH_FILE = os.path.join(DATA_DIR, "google_push_state.json")
GOOGLE_AUTH_URL = os.environ.get(
    "GOOGLE_OAUTH_AUTH_URL", "https://accounts.google.com/o/oauth2/v2/auth")
GOOGLE_TOKEN_URL = os.environ.get(
    "GOOGLE_OAUTH_TOKEN_URL", "https://oauth2.googleapis.com/token")
GOOGLE_REVOKE_URL = os.environ.get(
    "GOOGLE_OAUTH_REVOKE_URL", "https://oauth2.googleapis.com/revoke")
GOOGLE_API_BASE = os.environ.get(
    "GOOGLE_CALENDAR_API_BASE", "https://www.googleapis.com/calendar/v3")
GOOGLE_REDIRECT_URI = "http://127.0.0.1:8765/oauth/callback"
GOOGLE_SCOPE = "https://www.googleapis.com/auth/calendar.events"
# The StudyFlow Desktop OAuth client (Google Cloud project «StudyFlow»).
# A client ID is a public identifier, not a secret, so it ships as the
# default — the user only ever has to paste the Client Secret once.
DEFAULT_GOOGLE_CLIENT_ID = ("695272599724-cv1g08aem3ajt079bj11dfdb96c1ibsg"
                            ".apps.googleusercontent.com")


class GoogleNotFound(ValueError):
    """A Google event that no longer exists (404/410)."""


def load_oauth():
    data, _ = read_json_file(GOOGLE_OAUTH_FILE)
    if isinstance(data, dict):
        # Backfill the default Client ID for installs that saved an empty
        # one before it existed (e.g. a cleared-credentials file).
        if not (data.get("client_id") or "").strip():
            data["client_id"] = DEFAULT_GOOGLE_CLIENT_ID
        return data
    return {"client_id": DEFAULT_GOOGLE_CLIENT_ID, "client_secret": "",
            "access_token": "", "refresh_token": "", "expires_at": 0,
            "account_email": "", "connected_at": "", "last_error": None,
            "pending_state": "", "pending_state_ts": 0,
            "pending_verifier": "", "pending_flows": {}}


def _mask_client_id(cid):
    """First/last-4 mask for the OAuth CLIENT ID (v1.11.28, QA BUG-046
    note): unlike the Gemini key, a client ID is a public identifier,
    not a secret — the UI shows it as the input placeholder — so it
    keeps the old first/last-4 form. The Gemini key itself now masks
    to bullets only (srv/gemini.py masked_key)."""
    cid = (cid or "").strip()
    if not cid:
        return ""
    if len(cid) <= 8:
        return "••••••••"
    return cid[:4] + "••••••••" + cid[-4:]


def _pending_flows(cfg):
    """The pending OAuth flows, keyed by state (v1.11.28, QA BUG-045):
    two rapid «connect» clicks used to share one pending_state /
    pending_verifier singleton, so the first flow broke when the
    second overwrote it. Each flow now keeps its own state/verifier
    in cfg["pending_flows"][state] = {"verifier", "ts"}. Migrates
    the pre-1.11.28 singleton fields once, in place, and prunes
    flows older than the 10-minute callback window."""
    flows = cfg.get("pending_flows")
    if not isinstance(flows, dict):
        flows = {}
        cfg["pending_flows"] = flows
    legacy_state = (cfg.get("pending_state") or "").strip()
    if legacy_state and legacy_state not in flows:
        flows[legacy_state] = {
            "verifier": (cfg.get("pending_verifier") or "").strip(),
            "ts": int(cfg.get("pending_state_ts") or 0)}
    if legacy_state:
        cfg["pending_state"] = ""
        cfg["pending_state_ts"] = 0
        cfg["pending_verifier"] = ""
    now = int(time.time())
    for st in [s for s, f in flows.items()
               if now - int((f or {}).get("ts") or 0) > 600]:
        del flows[st]
    return flows


def save_oauth(cfg):
    # Credential file (holds the Google OAuth tokens): 0600, owner only
    # (audit §5 item 1.10).
    atomic_write_json(GOOGLE_OAUTH_FILE, cfg, mode=0o600)


def masked_oauth_status():
    cfg = load_oauth()
    cid = (cfg.get("client_id") or "").strip()
    connected = bool((cfg.get("access_token") or "").strip())
    # v1.11.16 (audit §5 item 1.4): Testing-mode refresh tokens live
    # 7 days from the connect; warn while there is still time to
    # reconnect instead of failing with a raw Google error a week later.
    age_days = None
    try:
        ca = (cfg.get("connected_at") or "").strip()
        if ca:
            age_days = max(0, int((datetime.now(tz=TEHRAN)
                                   - datetime.fromisoformat(ca)).total_seconds() // 86400))
    except Exception:
        age_days = None
    return {"credentials_set": bool(cid and (cfg.get("client_secret") or "").strip()),
            "client_id_masked": _mask_client_id(cid) if cid else "",
            "connected": connected,
            "email": cfg.get("account_email") or "",
            "expires_at": int(cfg.get("expires_at") or 0),
            "connected_at": cfg.get("connected_at") or "",
            "token_age_days": age_days,
            "token_refresh_days_left": (max(0, 7 - age_days)
                                        if age_days is not None and connected else None),
            "token_refresh_expires_soon": bool(connected and age_days is not None
                                               and age_days >= 6),
            "last_error": cfg.get("last_error")}


def load_push_state():
    """Load google_push_state.json (the push bookkeeping: event_map,
    ical_map, created event ids, what the app edited, what is pending,
    last push, done_synced). v1.11.25 (QA BUG-025): this file had NO
    backup or recovery — losing it meant the next push re-created every
    event and duplicated Google's calendar. It now recovers exactly like
    the other stores: preserve the corrupt file (.corrupt-<ts>), restore
    the newest verified push backup."""
    data, _ = read_json_file(GOOGLE_PUSH_FILE)
    if not isinstance(data, dict):
        if os.path.isfile(GOOGLE_PUSH_FILE):
            _preserve_corrupt(GOOGLE_PUSH_FILE)
            print("google_push_state.json is corrupt — restoring from backup")
        entry, backup = newest_verified_backup("push")
        if backup is not None and isinstance(backup, dict):
            atomic_write_json(GOOGLE_PUSH_FILE, backup)
            print("Restored push state from backup {}".format(entry["file"]))
            data = backup
    if not isinstance(data, dict):
        data = {}
    data.setdefault("event_map", {})
    data.setdefault("ical_map", {})
    data.setdefault("created_event_ids", [])
    data.setdefault("app_edited_at", {})
    data.setdefault("last_pushed", {})
    data.setdefault("pending", [])
    data.setdefault("conflicts", [])
    data.setdefault("last_push", None)
    # done_synced (v1.11.7): boxId -> the done value Google last had
    # (True/False). The loop-prevention record for the two-way done
    # sync: a push PATCHes only when local != done_synced, and a pull
    # applies Google's flag only when local == done_synced (or the
    # box was never synced — first sync, Google wins).
    data.setdefault("done_synced", {})
    return data


def save_push_state(ps):
    with STATE_LOCK:
        atomic_write_json(GOOGLE_PUSH_FILE, ps)
    # v1.11.25 (QA BUG-025): the push state is backed up like the other
    # stores now — create_backup dedupes identical content, so the
    # frequent small saves stay cheap.
    create_backup("push")


def _invalidate_push_tracking():
    """After a state/programme restore the push bookkeeping (what Google
    last had, what the app edited, what is pending) describes content
    that no longer exists — clear it so the next push re-syncs from the
    restored values instead of PATCHing stale ones. The event map
    (box -> Google event id) is kept: box ids survive a restore."""
    with STATE_LOCK:
        ps = load_push_state()
        ps["last_pushed"] = {}
        ps["app_edited_at"] = {}
        ps["pending"] = []
        save_push_state(ps)


def push_status_payload():
    ps = load_push_state()
    cfg = load_oauth()
    return {"connected": bool((cfg.get("access_token") or "").strip()),
            "pending_count": len(ps.get("pending") or []),
            "pending": (ps.get("pending") or [])[:20],
            "last_push": ps.get("last_push"),
            "conflicts": (ps.get("conflicts") or [])[-5:],
            "mapped_events": len(ps.get("event_map") or {})}


def _google_request(method, url, headers=None, data=None):
    """One raw HTTPS call to Google. Returns (status, parsed_json).
    Network failures raise ValueError with a Persian message."""
    req = urllib.request.Request(url, data=data, headers=headers or {}, method=method)
    try:
        # v1.11.24 (QA BUG-012): redirects are re-checked for https.
        with open_https_url(req, timeout=30) as resp:
            raw = resp.read()
            if not raw:
                return resp.status, {}
            try:
                return resp.status, json.loads(raw.decode("utf-8"))
            except Exception:
                return resp.status, {"_raw": raw.decode("utf-8", "replace")}
    except urllib.error.HTTPError as exc:
        raw = exc.read()
        try:
            body = json.loads(raw.decode("utf-8"))
        except Exception:
            body = {"error": {"message": raw.decode("utf-8", "replace")[:300]}}
        return exc.code, body
    except Exception as exc:
        raise ValueError("ارتباط با گوگل ممکن نشد: {}".format(exc))


def _google_error_message(data, status):
    msg = ""
    err = data.get("error") if isinstance(data, dict) else None
    if isinstance(err, dict):
        msg = str(err.get("message") or "")
    elif isinstance(err, str):
        msg = err
    if not msg:
        msg = str(data)[:200]
    return "خطای گوگل ({}): {}".format(status, msg)


def _token_expired(cfg):
    if not (cfg.get("access_token") or "").strip():
        return True
    exp = int(cfg.get("expires_at") or 0)
    if not exp:
        return True
    return exp - 60 < int(time.time())


def refresh_access_token():
    """Exchange the stored refresh token for a fresh access token."""
    cfg = load_oauth()
    rt = (cfg.get("refresh_token") or "").strip()
    cid = (cfg.get("client_id") or "").strip()
    csec = (cfg.get("client_secret") or "").strip()
    if not rt or not cid or not csec:
        raise ValueError("توکن گوگل منقضی شده و توکن تمدید نیست — دوباره متصل شو")
    body = urllib.parse.urlencode({
        "grant_type": "refresh_token", "refresh_token": rt,
        "client_id": cid, "client_secret": csec}).encode("utf-8")
    status, data = _google_request(
        "POST", GOOGLE_TOKEN_URL,
        {"Content-Type": "application/x-www-form-urlencoded"}, body)
    if status >= 400:
        msg = _google_error_message(data, status)
        # v1.11.16 (audit §5 item 1.4): Testing-mode refresh tokens
        # expire after 7 days and Google answers invalid_grant — which
        # used to surface as a raw English error. Say plainly what
        # happened and what to do.
        if "invalid_grant" in msg:
            raise ValueError("توکن ۷روزه منقضی شد — دوباره وصل شو")
        raise ValueError(msg)
    cfg["access_token"] = str(data.get("access_token") or "")
    if data.get("refresh_token"):
        cfg["refresh_token"] = str(data.get("refresh_token"))
    cfg["expires_at"] = int(time.time()) + int(data.get("expires_in") or 3600) - 30
    cfg["last_error"] = None
    save_oauth(cfg)
    return cfg


def google_api(method, path, body=None):
    """One Calendar API call with automatic token refresh on 401.
    Raises ValueError (Persian) or GoogleNotFound on failure."""
    cfg = load_oauth()
    if not (cfg.get("access_token") or "").strip():
        raise ValueError("گوگل متصل نیست — اول «اتصال به گوگل» را بزن")
    if _token_expired(cfg):
        cfg = refresh_access_token()
    token = (cfg.get("access_token") or "").strip()
    payload = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
    headers = {"Authorization": "Bearer " + token}
    if payload is not None:
        headers["Content-Type"] = "application/json; charset=utf-8"
    status, data = _google_request(method, GOOGLE_API_BASE + path, headers, payload)
    if status == 401:
        cfg = refresh_access_token()
        token = (cfg.get("access_token") or "").strip()
        headers["Authorization"] = "Bearer " + token
        status, data = _google_request(method, GOOGLE_API_BASE + path, headers, payload)
        if status == 401:
            raise ValueError("توکن گوگل رد شد — دوباره متصل شو")
    if status in (404, 410):
        raise GoogleNotFound(_google_error_message(data, status))
    if status >= 400:
        raise ValueError(_google_error_message(data, status))
    return data


def _pkce_verifier():
    """RFC 7636 code_verifier: 43 URL-safe chars from 32 random bytes."""
    return base64.urlsafe_b64encode(
        secrets.token_bytes(32)).rstrip(b"=").decode("ascii")


def _pkce_challenge(verifier):
    """RFC 7636 S256 code_challenge for a verifier."""
    return base64.urlsafe_b64encode(
        hashlib.sha256(verifier.encode("ascii")).digest()
        ).rstrip(b"=").decode("ascii")


def build_auth_url():
    """The Google sign-in URL the browser opens. The random state and the
    PKCE verifier are stored server-side and checked/sent in
    /oauth/callback. Google requires the Client Secret for this Desktop
    client even with PKCE, so connecting needs it saved first."""
    cfg = load_oauth()
    cid = (cfg.get("client_id") or "").strip()
    csec = (cfg.get("client_secret") or "").strip()
    if not cid or not csec:
        raise ValueError("اول Client Secret را ذخیره کن")
    state = secrets.token_urlsafe(24)
    verifier = _pkce_verifier()
    # v1.11.28 (QA BUG-045): the flow is keyed by its own state — a
    # second rapid click no longer overwrites the first flow's
    # verifier (the old pending_state singleton did exactly that).
    flows = _pending_flows(cfg)
    flows[state] = {"verifier": verifier, "ts": int(time.time())}
    save_oauth(cfg)
    q = urllib.parse.urlencode({
        "client_id": cid, "redirect_uri": GOOGLE_REDIRECT_URI,
        "response_type": "code", "scope": GOOGLE_SCOPE,
        "access_type": "offline", "prompt": "consent",
        "include_granted_scopes": "true", "state": state,
        "code_challenge": _pkce_challenge(verifier),
        "code_challenge_method": "S256"})
    return GOOGLE_AUTH_URL + "?" + q


def exchange_code(code, state):
    """Exchange the callback code for tokens and remember the account email
    (the primary calendar's id IS the Google account email). Sends both
    the PKCE code_verifier and the Client Secret: Google enforces the
    secret for Desktop-app clients (verified 2026-11-24: without it the
    token endpoint answers 400 invalid_request «client_secret is missing»)."""
    cfg = load_oauth()
    # v1.11.28 (QA BUG-045): the flow is looked up by ITS OWN state —
    # a second flow started after this one no longer invalidates it.
    # The flow is single-use: it is consumed (popped) whether the
    # token exchange succeeds or not, since Google's code is too.
    flows = _pending_flows(cfg)
    flow = flows.get(state) or {}
    pts = int(flow.get("ts") or 0)
    if not flow or time.time() - pts > 600:
        raise ValueError("درخواست ورود معتبر نیست یا منقضی شده — دوباره «اتصال به گوگل» را بزن")
    cid = (cfg.get("client_id") or "").strip()
    csec = (cfg.get("client_secret") or "").strip()
    verifier = (flow.get("verifier") or "").strip()
    body = urllib.parse.urlencode({
        "grant_type": "authorization_code", "code": code,
        "redirect_uri": GOOGLE_REDIRECT_URI,
        "client_id": cid, "client_secret": csec,
        "code_verifier": verifier}).encode("utf-8")
    status, data = _google_request(
        "POST", GOOGLE_TOKEN_URL,
        {"Content-Type": "application/x-www-form-urlencoded"}, body)
    flows.pop(state, None)
    if status >= 400:
        save_oauth(cfg)
        raise ValueError(_google_error_message(data, status))
    cfg["access_token"] = str(data.get("access_token") or "")
    cfg["refresh_token"] = str(data.get("refresh_token") or "")
    cfg["expires_at"] = int(time.time()) + int(data.get("expires_in") or 3600) - 30
    cfg["connected_at"] = iso_now()
    cfg["last_error"] = None
    save_oauth(cfg)
    try:
        me = google_api("GET", "/users/me/calendarList/primary")
        cfg = load_oauth()
        cfg["account_email"] = str(me.get("id") or "")
        save_oauth(cfg)
    except Exception as exc:
        print("Could not fetch Google account email: {}".format(exc))
    return cfg


def revoke_google_tokens():
    """Revoke the token at Google (best effort) and clear stored tokens.
    Client ID/secret are kept so reconnecting is one click."""
    cfg = load_oauth()
    token = (cfg.get("refresh_token") or cfg.get("access_token") or "").strip()
    if token:
        try:
            body = urllib.parse.urlencode({"token": token}).encode("utf-8")
            _google_request("POST", GOOGLE_REVOKE_URL,
                            {"Content-Type": "application/x-www-form-urlencoded"}, body)
        except Exception as exc:
            print("Google revoke failed (ignored): {}".format(exc))
    cfg["access_token"] = ""
    cfg["refresh_token"] = ""
    cfg["expires_at"] = 0
    cfg["account_email"] = ""
    cfg["connected_at"] = ""
    save_oauth(cfg)


def _next_day_iso(d):
    return (datetime.strptime(d, "%Y-%m-%d").date() + timedelta(days=1)).isoformat()


def _api_event_date(part):
    """Jalali-free date (YYYY-MM-DD) from a Calendar API start/end part."""
    dt = str(part.get("dateTime") or "")
    if dt:
        return dt[:10]
    return str(part.get("date") or "")


def _api_event_time(part):
    """HH:MM from a Calendar API start/end part ('' for all-day events)."""
    dt = str(part.get("dateTime") or "")
    return dt[11:16] if dt else ""


def _api_event_done(item):
    """Done flag from the event's extended properties
    (studyflow.done = "1"/"0"), or None when the event carries none —
    no flag means "no information", never "not done"."""
    props = item.get("extendedProperties") or {}
    priv = props.get("private") or {}
    val = str(priv.get("studyflow.done") or "").strip().lower()
    if val in ("1", "true"):
        return True
    if val in ("0", "false"):
        return False
    return None


def _list_google_events(time_min, time_max):
    """List Google events in a window via the Calendar API (all pages).
    Returns {iCalUID: {id, title, date, start, end, done}} — the same
    shape the app's boxes use, so a live event can be compared with
    last_pushed; `done` is the studyflow.done extended property
    (True/False, or None when the event carries none)."""
    out = {}
    params = {"singleEvents": "true", "maxResults": 2500,
              "timeMin": time_min, "timeMax": time_max}
    page_token = None
    seen_tokens = set()
    for _ in range(20):  # capped: a runaway nextPageToken must end
        q = dict(params)
        if page_token:
            q["pageToken"] = page_token
        path = "/calendars/primary/events?" + urllib.parse.urlencode(q)
        data = google_api("GET", path)
        for item in data.get("items") or []:
            uid = str(item.get("iCalUID") or "")
            eid = str(item.get("id") or "")
            if not uid or not eid:
                continue
            out[uid] = {"id": eid, "title": str(item.get("summary") or ""),
                        "date": _api_event_date(item.get("start") or {}),
                        "start": _api_event_time(item.get("start") or {}),
                        "end": _api_event_time(item.get("end") or {}),
                        "done": _api_event_done(item)}
        page_token = data.get("nextPageToken")
        if not page_token or page_token in seen_tokens:
            break
        seen_tokens.add(page_token)
    return out


def refresh_event_id_map(time_min, time_max, base=None):
    """List events in a window and record iCalUID -> API event id.
    `base` (when given) is merged in first, so in-memory entries made
    earlier in the same push run are never lost. Returns the full map."""
    ps = load_push_state()
    imap = dict(base) if base is not None else dict(ps.get("ical_map") or {})
    for uid, ev in _list_google_events(time_min, time_max).items():
        imap[uid] = ev["id"]
    ps["ical_map"] = imap
    save_push_state(ps)
    return imap


def sync_done_from_google():
    """Pull done flags from Google (extendedProperties studyflow.done) and
    apply them to state.done. Loop-safe: a local change since the last
    sync is never silently overwritten — when both sides changed, Google
    wins (the house rule) and the conflict is recorded; when the local
    side is unchanged since the last sync, Google's value is applied.
    Events with no flag carry no information and are skipped, so a box
    Google never heard about keeps its local status. Changing done status
    never deletes the event or its history. No-op when not connected.
    Returns (applied, conflicts, error) — error is None on success.
    v1.11.16 (audit §5 item 1.4): a failed fetch used to vanish as a
    silent (0, 0); the error is now returned so the caller can show it
    in the sync log instead.
    v1.11.24 (QA BUG-019): split into a fetch phase and an apply phase.
    The Google list call used to run under STATE_LOCK, freezing every
    state save for the whole (up to 30 s) request. The fetch now runs
    with NO lock held; the apply re-loads state/push_state fresh under
    STATE_LOCK, so a tick landing during the fetch is seen (and
    protected by the pending check) instead of being overwritten."""
    cfg = load_oauth()
    if not (cfg.get("access_token") or "").strip() \
            and not (cfg.get("refresh_token") or "").strip():
        return 0, 0, None, 0
    try:
        first, last = _programme_range()
        live = _list_google_events(
            first.isoformat() + "T00:00:00+03:30",
            (last + timedelta(days=1)).isoformat() + "T00:00:00+03:30")
    except Exception as exc:
        err = "خطا در دریافت وضعیت انجام‌شده از گوگل: {}".format(exc)
        print("Done-status pull failed: {}".format(exc))
        return 0, 0, err, 0
    return _apply_done_from_google(live)


@_with_lock
def _apply_done_from_google(live):
    """Apply a fetched live-event map to state.done (BUG-019: the
    locked half of sync_done_from_google). Re-loads programme, state
    and push_state fresh, so it never overwrites a tick that landed
    while the fetch was in flight. Returns
    (applied, conflicts, None, skipped_pending) — skipped_pending is
    the v1.11.28 (QA BUG-041) count of boxes the pull had to skip
    because a local tick is still waiting to be pushed: skipping is
    correct (the pull must not revert it), but it used to be
    invisible — (0, 0, None) looked exactly like «everything is in
    sync» while a stuck push silently starved the done flags."""
    prog = load_programme()
    uid_map = dict(prog.get("uid_map") or {})
    state = load_state()
    ps = load_push_state()
    done = dict(state.get("done") or {})
    done_synced = dict(ps.get("done_synced") or {})
    applied = 0
    conflicts = 0
    skipped_pending = 0
    conf_notes = []
    for uid, ev in live.items():
        bid = uid_map.get(uid)
        if not bid:
            continue
        gdone = ev.get("done")
        if gdone is None:
            continue
        # A local change waiting to be pushed (the box is in pending)
        # wins for now: the pull must not revert a tick the user just
        # made before the debounced push has sent it to Google.
        if bid in (ps.get("pending") or []):
            skipped_pending += 1
            continue
        ldone = bool(done.get(bid))
        synced = done_synced.get(bid)
        if gdone == ldone:
            if synced != ldone:
                done_synced[bid] = ldone
            continue
        if synced is not None and ldone != synced:
            # Both sides changed since the last sync: Google wins.
            conflicts += 1
            conf_notes.append({"box_id": bid, "title": ev.get("title") or bid,
                               "ts": iso_now()})
        if gdone:
            done[bid] = True
        else:
            done.pop(bid, None)
        done_synced[bid] = gdone
        applied += 1
    if applied:
        state["done"] = done
        save_state(state)
    if applied or conf_notes or done_synced != (ps.get("done_synced") or {}):
        ps["done_synced"] = done_synced
        if conf_notes:
            conf = list(ps.get("conflicts") or [])
            seen_c = {c.get("box_id") for c in conf}
            for c in conf_notes:
                if c["box_id"] not in seen_c:
                    conf.append(c)
            ps["conflicts"] = conf[-20:]
        save_push_state(ps)
    return applied, conflicts, None, skipped_pending


def seed_push_state_after_connect():
    """First-time setup after OAuth: build the iCalUID -> event-id map for
    the whole programme range and seed last_pushed from the PROGRAMME box
    values (raw, no app overlay) — so boxes the app never edited are not
    re-pushed, while app-edited boxes still differ from the seed and get
    pushed on the next push run."""
    try:
        first, last = _programme_range()
        refresh_event_id_map(first.isoformat() + "T00:00:00+03:30",
                             (last + timedelta(days=1)).isoformat() + "T00:00:00+03:30")
        prog = load_programme()
        ps = load_push_state()
        lp = dict(ps.get("last_pushed") or {})
        for b in prog.get("boxes") or []:
            bid = b.get("id")
            if bid and bid not in lp:
                lp[bid] = {"title": b.get("title"), "date": b.get("date"),
                           "start": b.get("start"), "end": b.get("end")}
        ps["last_pushed"] = lp
        save_push_state(ps)
    except Exception as exc:
        print("Push seed after connect failed: {}".format(exc))
        ps = load_push_state()
        ps["last_push"] = {"ts": iso_now(), "ok": False,
                           "error": "آماده‌سازی همگام‌سازی دوطرفه ممکن نشد: {}".format(exc),
                           "summary": None}
        save_push_state(ps)


def effective_boxes(prog, state):
    """{boxId: {title, date, start, end, uid, is_custom}} — what the user
    actually sees: programme boxes with the state.edits overlay, plus
    custom boxes. Deleted boxes are excluded."""
    deleted = set(state.get("deleted") or [])
    edits = state.get("edits") or {}
    uid_by_box = {}
    for uid, bid in (prog.get("uid_map") or {}).items():
        uid_by_box[bid] = uid
    out = {}
    for b in prog.get("boxes") or []:
        bid = b.get("id")
        if not bid or bid in deleted:
            continue
        ov = edits.get(bid) or {}
        out[bid] = {"title": ov.get("title", b.get("title")),
                    "date": ov.get("date", b.get("date")),
                    "start": ov.get("start", b.get("start")),
                    "end": ov.get("end", b.get("end")),
                    "uid": uid_by_box.get(bid), "is_custom": False}
    for cb in state.get("custom_boxes") or []:
        bid = cb.get("id")
        if not bid or bid in deleted:
            continue
        out[bid] = {"title": cb.get("title"), "date": cb.get("date"),
                    "start": cb.get("start"), "end": cb.get("end"),
                    "uid": None, "is_custom": True}
    return out


def _box_event_times(box):
    """(start_iso, end_iso) for a box, Asia/Tehran. An end at/before the
    start (e.g. 23:30-01:00) rolls to the next calendar day."""
    s = datetime.strptime("{} {}".format(box["date"], box["start"]),
                          "%Y-%m-%d %H:%M").replace(tzinfo=TEHRAN)
    e = datetime.strptime("{} {}".format(box["date"], box["end"]),
                          "%Y-%m-%d %H:%M").replace(tzinfo=TEHRAN)
    if e <= s:
        e += timedelta(days=1)
    return s.isoformat(timespec="seconds"), e.isoformat(timespec="seconds")


def _google_event_body(eff, done=None):
    """Event body for a create/PATCH. `done` (True/False) adds the
    studyflow.done extended property; None leaves it untouched."""
    s_iso, e_iso = _box_event_times(eff)
    body = {"summary": eff["title"],
            "start": {"dateTime": s_iso, "timeZone": "Asia/Tehran"},
            "end": {"dateTime": e_iso, "timeZone": "Asia/Tehran"}}
    if done is not None:
        body["extendedProperties"] = {"private": {"studyflow.done": "1" if done else "0"}}
    return body


def _resolve_event_id(imap, eff):
    """Google API event id for a mapped box, or None. Tries the stored map,
    then a one-day list refresh, then the iCalUID convention (Google-created
    events use <eventId>@google.com)."""
    uid = eff.get("uid")
    if not uid:
        return None
    if imap.get(uid):
        return imap[uid]
    try:
        d = eff["date"]
        fresh = refresh_event_id_map(d + "T00:00:00+03:30",
                                     _next_day_iso(d) + "T00:00:00+03:30",
                                     base=imap)
        imap.update(fresh)
        if imap.get(uid):
            return imap[uid]
    except Exception as exc:
        print("Event-id map refresh failed: {}".format(exc))
    if uid.endswith("@google.com"):
        return uid[:-len("@google.com")]
    return None


# ---------- Internal box API (v1.11.0) ----------
# Targeted endpoints for changing the programme calendar (create / update
# incl. move / delete a box). They mutate state EXACTLY the way the UI
# does — programme boxes via the state.edits overlay, new boxes via
# state.custom_boxes, deletions via state.deleted — then save through
# save_state + note_app_edits, so the debounced auto-push sees them just
# like a UI edit. The pull-sync path (merge_calendar_events) is NOT used
# here: it writes programme values FROM Google, and a bare programme edit
# would be overwritten by the next pull. Same localhost-only server
# (127.0.0.1), no auth change: anything that can reach the port can call
# these, exactly like /api/state.
_BOX_TIME_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")
_BOX_TEST_RE = re.compile(r"تست|تکلیف|آزمون")


def _box_field_error(date, start, end):
    if date is not None:
        try:
            datetime.strptime(date or "", "%Y-%m-%d")
        except Exception:
            return "تاریخ باید به شکل YYYY-MM-DD باشد"
    for t in (start, end):
        if t is not None and not _BOX_TIME_RE.match(t or ""):
            return "ساعت باید به شکل HH:MM باشد"
    # v1.11.16 (audit §5 item 1.5): a zero-length box used to count as
    # 1440 minutes everywhere — refuse it (both values supplied here;
    # box_api_update also checks the effective values for partial edits).
    if start is not None and end is not None and start == end:
        return "شروع و پایان باکس نمی‌توانند برابر باشند"
    return None


def _programme_box(prog, bid):
    for b in prog.get("boxes") or []:
        if b.get("id") == bid:
            return b
    return None


def _box_type(stored, title):
    """Effective activity type (v1.11.5): an explicit stored "class" /
    "normal" wins; otherwise the v1.8.0 title rule backfills it (title
    contains «کلاس» -> "class", else "normal"). Same rule as the client's
    boxIsClass() — the server and the UI must agree on every box."""
    if stored in ("class", "normal"):
        return stored
    return "class" if "کلاس" in (title or "") else "normal"


def _box_uid(prog, bid):
    """Stored Google Event ID (ICS uid) for a programme box, or None.
    This is the ONLY connection signal the UI may use — never a
    title/date guess (v1.11.9, spec §4)."""
    for u, b in (prog.get("uid_map") or {}).items():
        if b == bid:
            return u
    return None


def _public_box(prog, state, bid):
    """The box as the UI shows it: programme values + overlay, or the
    custom-box entry. None if the box does not exist or is deleted."""
    if bid in (state.get("deleted") or []):
        return None
    cb = next((b for b in (state.get("custom_boxes") or [])
               if b.get("id") == bid), None)
    if cb is not None:
        return {"id": cb.get("id"), "title": cb.get("title"),
                "subject": cb.get("subject"), "topic": cb.get("topic"),
                "date": cb.get("date"), "start": cb.get("start"),
                "end": cb.get("end"), "is_test": bool(cb.get("is_test")),
                "tests_total": cb.get("tests_total") or 0,
                "note": cb.get("note") or "", "is_custom": True,
                "uid": None, "connected": False,
                "type": _box_type(cb.get("type"), cb.get("title"))}
    pb = _programme_box(prog, bid)
    if pb is None:
        return None
    ov = (state.get("edits") or {}).get(bid) or {}
    uid = _box_uid(prog, bid)
    return {"id": pb.get("id"),
            "title": ov.get("title", pb.get("title")),
            "subject": ov.get("subject", pb.get("subject")),
            "topic": pb.get("topic"),
            "date": ov.get("date", pb.get("date")),
            "start": ov.get("start", pb.get("start")),
            "end": ov.get("end", pb.get("end")),
            "is_test": bool(pb.get("is_test")),
            "tests_total": (state.get("tests_total") or {}).get(
                bid, pb.get("tests_total") or 0),
            "note": ov.get("note", pb.get("note") or ""),
            "is_custom": False,
            "uid": uid, "connected": bool(uid) and not pb.get("orphaned"),
            "type": _box_type(ov.get("type", pb.get("type")),
                              ov.get("title", pb.get("title")))}


def _public_boxes_list(prog, state):
    """All public boxes in one pass (same shape as _public_box): the
    GET /api/boxes handler used to call _public_box per box, which
    re-scanned the programme + custom lists for every one of the 318."""
    eff = effective_boxes(prog, state)
    by_id = {b.get("id"): b for b in prog.get("boxes") or [] if b.get("id")}
    cb_by_id = {b.get("id"): b for b in (state.get("custom_boxes") or [])
                if b.get("id")}
    tests_total = state.get("tests_total") or {}
    edits = state.get("edits") or {}
    boxes = []
    for bid in sorted(eff, key=lambda b: (eff[b]["date"] or "",
                                          eff[b]["start"] or "", b)):
        e = eff[bid]
        if bid in cb_by_id:
            cb = cb_by_id[bid]
            boxes.append({"id": bid, "title": cb.get("title"),
                          "subject": cb.get("subject"), "topic": cb.get("topic"),
                          "date": cb.get("date"), "start": cb.get("start"),
                          "end": cb.get("end"), "is_test": bool(cb.get("is_test")),
                          "tests_total": cb.get("tests_total") or 0,
                          "note": cb.get("note") or "", "is_custom": True,
                          "uid": None, "connected": False,
                          "type": _box_type(cb.get("type"), cb.get("title"))})
        else:
            pb = by_id.get(bid)
            if pb is None:
                continue
            ov = edits.get(bid) or {}
            boxes.append({"id": bid,
                          "title": ov.get("title", pb.get("title")),
                          "subject": ov.get("subject", pb.get("subject")),
                          "topic": pb.get("topic"),
                          "date": ov.get("date", pb.get("date")),
                          "start": ov.get("start", pb.get("start")),
                          "end": ov.get("end", pb.get("end")),
                          "is_test": bool(pb.get("is_test")),
                          "tests_total": tests_total.get(
                              bid, pb.get("tests_total") or 0),
                          "note": ov.get("note", pb.get("note") or ""),
                          "is_custom": False,
                          "uid": e.get("uid"),
                          "connected": bool(e.get("uid")) and not pb.get("orphaned"),
                          "type": _box_type(ov.get("type", pb.get("type")),
                                            ov.get("title", pb.get("title")))})
    return boxes


def _box_api_note(old_state, saved):
    try:
        note_app_edits(old_state, saved)
    except Exception as exc:
        print("note_app_edits failed: {}".format(exc))


@_with_lock
def box_api_create(payload):
    """Create a custom box. Returns (http_status, payload)."""
    title = str(payload.get("title") or "").strip()
    if not title:
        return 400, {"error": "عنوان باکس خالی است"}
    date = str(payload.get("date") or "").strip()
    start = str(payload.get("start") or "09:00").strip()
    end = str(payload.get("end") or "10:30").strip()
    if not date:
        return 400, {"error": "تاریخ باکس خالی است"}
    err = _box_field_error(date, start, end)
    if err:
        return 400, {"error": err}
    subject = str(payload.get("subject") or "").strip()
    if not subject:
        subject = title.split(":")[0].split("—")[0].strip() or "عمومی"
    topic = str(payload.get("topic") or "").strip() or title
    is_test = payload.get("is_test")
    is_test = bool(_BOX_TEST_RE.search(title)) if is_test is None else bool(is_test)
    try:
        total = max(0, int(payload.get("tests_total") or 0))
    except Exception:
        return 400, {"error": "tests_total باید عدد باشد"}
    note = str(payload.get("note") or "")
    # v1.11.24 (QA BUG-013): length caps at the API boundary (the
    # merge_state sanitizer truncates as a backstop for /api/state).
    if len(title) > TITLE_MAX_LEN:
        return 400, {"error": "عنوان باکس خیلی طولانی است"}
    if len(subject) > SUBJECT_MAX_LEN:
        return 400, {"error": "نام درس خیلی طولانی است"}
    if len(note) > NOTE_MAX_LEN:
        return 400, {"error": "یادداشت باکس خیلی طولانی است"}
    box_type = "class" if str(payload.get("type") or "").strip() == "class" else "normal"
    state = load_state()
    old_state = json.loads(json.dumps(state))
    nid = "custom-" + str(int(time.time() * 1000))
    existing = {b.get("id") for b in (state.get("custom_boxes") or [])}
    while nid in existing:
        nid += "x"
    nb = {"id": nid, "date": date, "start": start, "end": end,
          "subject": subject, "topic": topic, "title": title,
          "is_test": is_test, "tests_total": total, "note": note,
          "type": box_type}
    cbs = list(state.get("custom_boxes") or [])
    cbs.append(nb)
    state["custom_boxes"] = cbs
    saved = save_state(state)
    _box_api_note(old_state, saved)
    # (2.8) non-blocking warnings for the new box's study day.
    prog = load_programme()
    warn = programme_issues(prog, saved, _study_day_of(date, start))
    return 200, {"ok": True, "box": _public_box(prog, saved, nid), "warnings": warn}


@_with_lock
def box_api_update(payload):
    """Edit a box (title/subject/date/start/end/note/type); a new date/time
    IS the move. Programme boxes go through the edits overlay (same keys
    the UI's edit form writes); custom boxes are edited in place.
    Returns (http_status, payload)."""
    bid = str(payload.get("id") or "").strip()
    if not bid:
        return 400, {"error": "شناسه‌ی باکس خالی است"}
    prog = load_programme()
    state = load_state()
    if bid in (state.get("deleted") or []):
        return 404, {"error": "این باکس حذف شده است"}
    cb = next((b for b in (state.get("custom_boxes") or [])
               if b.get("id") == bid), None)
    pb = _programme_box(prog, bid) if cb is None else None
    if cb is None and pb is None:
        return 404, {"error": "باکسی با این شناسه پیدا نشد"}
    fields = {}
    for k in ("title", "subject", "note"):
        if payload.get(k) is not None:
            fields[k] = str(payload.get(k))
    for k in ("date", "start", "end"):
        if payload.get(k) is not None:
            fields[k] = str(payload.get(k)).strip()
    if "title" in fields and not fields["title"].strip():
        return 400, {"error": "عنوان باکس خالی است"}
    # v1.11.24 (QA BUG-013): length caps at the API boundary (the
    # merge_state sanitizer truncates as a backstop for /api/state).
    if "title" in fields and len(fields["title"]) > TITLE_MAX_LEN:
        return 400, {"error": "عنوان باکس خیلی طولانی است"}
    if "subject" in fields and len(fields["subject"]) > SUBJECT_MAX_LEN:
        return 400, {"error": "نام درس خیلی طولانی است"}
    if "note" in fields and len(fields["note"]) > NOTE_MAX_LEN:
        return 400, {"error": "یادداشت باکس خیلی طولانی است"}
    err = _box_field_error(fields.get("date"), fields.get("start"),
                           fields.get("end"))
    if err:
        return 400, {"error": err}
    # v1.11.16 (audit §5 item 1.5): a partial update can also make a
    # zero-length box (start moved onto the existing end) — check the
    # effective start/end, not only the supplied fields.
    if "start" in fields or "end" in fields:
        if cb is not None:
            eff_start = fields.get("start", cb.get("start"))
            eff_end = fields.get("end", cb.get("end"))
        else:
            ov = (state.get("edits") or {}).get(bid) or {}
            eff_start = fields.get("start", ov.get("start", pb.get("start")))
            eff_end = fields.get("end", ov.get("end", pb.get("end")))
        if eff_start is not None and eff_end is not None and eff_start == eff_end:
            return 400, {"error": "شروع و پایان باکس نمی‌توانند برابر باشند"}
    if not fields and "is_test" not in payload \
            and "tests_total" not in payload and "topic" not in payload \
            and "type" not in payload:
        return 400, {"error": "هیچ فیلدی برای تغییر داده نشده است"}
    if cb is None and ("topic" in payload or "is_test" in payload):
        # v1.11.24 (QA BUG-011): one rule for immutable fields — a
        # combined update used to silently DROP topic/is_test for
        # programme boxes (only the topic/is_test-only payload 400d),
        # so a caller believed the topic was saved when it was not.
        # Either field now 400s with its name, alone or combined.
        bad = "topic" if "topic" in payload else "is_test"
        return 400, {"error": "{} برای باکس برنامه قابل تغییر نیست".format(bad)}
    old_state = json.loads(json.dumps(state))
    if cb is not None:
        for k in ("title", "subject", "topic", "date", "start", "end", "note"):
            if k in fields:
                cb[k] = fields[k]
        if payload.get("topic") is not None:
            cb["topic"] = str(payload.get("topic"))
        if "is_test" in payload:
            cb["is_test"] = bool(payload.get("is_test"))
        if "type" in payload:
            cb["type"] = "class" if str(payload.get("type") or "").strip() == "class" else "normal"
        if "tests_total" in payload:
            try:
                cb["tests_total"] = max(0, int(payload.get("tests_total")))
            except Exception:
                return 400, {"error": "tests_total باید عدد باشد"}
    else:
        # Programme box: the overlay carries exactly the keys the UI's
        # edit form writes (topic/is_test stay on the programme box).
        ov = dict((state.get("edits") or {}).get(bid) or {})
        for k in ("title", "subject", "date", "start", "end", "note"):
            if k in fields:
                ov[k] = fields[k]
        if "type" in payload:
            ov["type"] = "class" if str(payload.get("type") or "").strip() == "class" else "normal"
        state.setdefault("edits", {})[bid] = ov
        if "tests_total" in payload:
            try:
                state.setdefault("tests_total", {})[bid] = max(
                    0, int(payload.get("tests_total")))
            except Exception:
                return 400, {"error": "tests_total باید عدد باشد"}
    saved = save_state(state)
    _box_api_note(old_state, saved)
    # (2.8) non-blocking warnings for the box's (possibly new) study day.
    eff = next((b for b in _public_boxes_list(prog, saved) if b.get("id") == bid), None)
    warn = []
    if eff is not None:
        warn = programme_issues(prog, saved,
                                _study_day_of(eff.get("date") or "", eff.get("start") or ""))
    return 200, {"ok": True, "box": _public_box(prog, saved, bid), "warnings": warn}


@_with_lock
def box_api_delete(payload):
    """Delete a box: it goes to state.deleted (programme or custom —
    exactly like the UI's delete, and like the T7 e2e case). The push
    then deletes its Google event too (v1.11.12 — any mapped event, not
    only app-created ones), and the merge tombstones its UID so the next
    pull never resurrects it. Returns (http_status, payload)."""
    bid = str(payload.get("id") or "").strip()
    if not bid:
        return 400, {"error": "شناسه‌ی باکس خالی است"}
    prog = load_programme()
    state = load_state()
    is_custom = any(b.get("id") == bid
                    for b in (state.get("custom_boxes") or []))
    if not is_custom and _programme_box(prog, bid) is None:
        return 404, {"error": "باکسی با این شناسه پیدا نشد"}
    deleted = list(state.get("deleted") or [])
    if bid in deleted:
        return 200, {"ok": True, "id": bid}
    old_state = json.loads(json.dumps(state))
    deleted.append(bid)
    state["deleted"] = deleted
    saved = save_state(state)
    _box_api_note(old_state, saved)
    return 200, {"ok": True, "id": bid}


def _box_has_user_data(state, bid):
    """Does this box hold any user data (ticks, tests, edits, minutes,
    links, assignments)? Used by reconnect: a duplicate box holding user
    data must NEVER be absorbed automatically (409 — the user chooses).
    v1.11.23 (QA BUG-022): the guard also sees usefulMinutes,
    timerSessions and testLog — all added after the guard was written
    (1.11.20/21). errorLog is deliberately NOT here: its entries carry
    no box reference (subject-scoped: {id, d, subject, source, q,
    type, ...}), so no per-box check is possible — and absorb never
    deletes errorLog entries either (it is not in the cleanup list), so
    no data-loss path exists for it through reconnect."""
    if (state.get("done") or {}).get(bid):
        return True
    tr = (state.get("tests") or {}).get(bid) or {}
    if (tr.get("completed") or 0) > 0 or (tr.get("correct") or 0) > 0:
        return True
    if bid in (state.get("edits") or {}):
        return True
    if bid in (state.get("tests_total") or {}):
        return True
    if (state.get("actualMinutes") or {}).get(bid):
        return True
    if (state.get("usefulMinutes") or {}).get(bid):
        return True
    if any((s or {}).get("boxId") == bid
           for s in (state.get("timerSessions") or [])):
        return True
    if any((e or {}).get("box") == bid
           for e in (state.get("testLog") or [])):
        return True
    if bid in (state.get("topicLinks") or {}):
        return True
    if bid in (state.get("boxBookLinks") or {}):
        return True
    if any((a or {}).get("boxId") == bid
           for a in (state.get("assignments") or [])):
        return True
    return False


def unlinked_calendar_payload():
    """Reconnect picker data: Google events from the last successful pull
    that no box is linked to, plus programme boxes with no Event ID.
    Both lists come from stored link data only — never from title/date
    similarity (v1.11.9, spec §4). Empty when no pull has run yet.
    v1.11.25 (QA BUG-021): when an unlinked event's (date+start) matches
    EXACTLY ONE orphaned box, the event carries suggested_box_id /
    suggested_box_title — the picker shows a one-click «looks like the
    same task — move history?» row for it. (date+start) only: the title
    may have changed (that is the whole bug — a delete + recreate in
    Google with a new title splits the history). Reconnecting that box
    to the event keeps its ticks/tests/minutes and absorbs the empty
    box the pull created, via the existing reconnect path."""
    prog = load_programme()
    state = load_state()
    uid_map = prog.get("uid_map") or {}
    tomb_uids = set(prog.get("tombstone_uids") or [])
    deleted = set(state.get("deleted") or [])
    feed = ((prog.get("meta") or {}).get("last_feed") or [])
    linked = set(uid_map)
    unlinked_events = [dict(e) for e in feed
                       if e.get("uid") not in linked
                       and e.get("uid") not in tomb_uids]
    unlinked_boxes = [{"id": b.get("id"), "title": b.get("title"),
                       "date": b.get("date"), "start": b.get("start"),
                       "end": b.get("end"), "subject": b.get("subject"),
                       "orphaned": bool(b.get("orphaned"))}
                      for b in (prog.get("boxes") or [])
                      if b.get("id") not in deleted
                      and b.get("id") not in uid_map.values()]
    # Orphaned boxes keyed by (date, start) — the delete+recreate
    # fingerprint. Only orphaned boxes (their event vanished) and only
    # an unambiguous single match: two orphans in the same slot mean
    # the user must choose by hand.
    by_slot = {}
    for b in (prog.get("boxes") or []):
        if not b.get("orphaned"):
            continue
        if b.get("id") in deleted or b.get("id") in uid_map.values():
            continue
        by_slot.setdefault((b.get("date"), b.get("start")), []).append(b)
    for e in unlinked_events:
        cands = by_slot.get((e.get("date"), e.get("start")), [])
        if len(cands) == 1:
            e["suggested_box_id"] = cands[0].get("id")
            e["suggested_box_title"] = cands[0].get("title")
    # The other direction — the one that fires in the real delete +
    # recreate case: the recreated event is LINKED (to the empty box the
    # pull just created), so it never appears in unlinked_events, and
    # the orphaned old box cannot even open the picker (canReconnect
    # needs an unlinked event). For each orphaned box, look for a feed
    # event in the same (date+start) slot that is linked to a DIFFERENT
    # box — the pull-created duplicate. The suggestion is offered only
    # when that box holds NO user data (the same rule box_api_reconnect
    # uses to absorb): tapping it can only merge an empty duplicate,
    # never swallow real work. The picker shows it one-click.
    linked_by_slot = {}
    for e in feed:
        bid = uid_map.get(e.get("uid"))
        if bid:
            linked_by_slot.setdefault((e.get("date"), e.get("start")), []).append(e)
    for ub in unlinked_boxes:
        if not ub.get("orphaned"):
            continue
        cands = [e for e in linked_by_slot.get(
            (ub.get("date"), ub.get("start")), [])
            if uid_map.get(e.get("uid")) not in (None, ub.get("id"))
            and not _box_has_user_data(state, uid_map.get(e.get("uid")))]
        if len(cands) == 1:
            ub["suggested_event_uid"] = cands[0].get("uid")
            ub["suggested_event_title"] = cands[0].get("title")
    return {"unlinked_events": unlinked_events,
            "unlinked_boxes": unlinked_boxes,
            # v1.11.29 (PI-04): the reconnect picker shows a clear-tombstones
            # action only when deleted-event IDs are stored.
            "tombstones": len(tomb_uids),
            "last_feed_ts": (prog.get("meta") or {}).get("last_feed_ts")}


@_with_lock
def clear_calendar_tombstones():
    """Clear all stored tombstones (v1.11.29, PI-04). A deleted box's UID
    stays tombstoned forever otherwise, so a restored Google event with
    the same ID is skipped on every pull. Clearing is explicit, one-click
    from the reconnect picker, and a verified programme backup is taken
    BEFORE the mutation (same rule as reconnect)."""
    prog = load_programme()
    n_uids = len(prog.get("tombstone_uids") or [])
    n_boxes = len(prog.get("tombstone_box_ids") or [])
    if not n_uids and not n_boxes:
        return 200, {"ok": True, "cleared_uids": 0, "cleared_boxes": 0}
    entry = create_backup("programme", force=True)
    if entry is None or verify_backup_entry(entry) is None:
        return 500, {"error": "پشتیبان‌گیری قبل از پاک کردن ممکن نشد — هیچ تغییری اعمال نشد"}
    prog["tombstone_uids"] = []
    prog["tombstone_box_ids"] = []
    save_programme(prog)
    return 200, {"ok": True, "cleared_uids": n_uids, "cleared_boxes": n_boxes}


@_with_lock
def box_api_reconnect(payload):
    """Manually reconnect a programme box to an existing Google event
    (spec §3.4). The user picks the event — the server never guesses.
    The box takes the event's values (title/date/time), the orphaned
    flag clears, and the UID is stored. If another box already holds
    that UID: absorb it ONLY when it holds no user data (it was created
    by a pull); when it holds user data, refuse with 409 and let the
    user choose. Reconnecting the same box+uid twice is a no-op.
    A verified programme backup is taken BEFORE any mutation."""
    bid = str(payload.get("boxId") or "").strip()
    uid = str(payload.get("uid") or "").strip()
    if not bid:
        return 400, {"error": "شناسه‌ی باکس خالی است"}
    if not uid:
        return 400, {"error": "شناسه‌ی رویداد خالی است"}
    prog = load_programme()
    state = load_state()
    if bid in (state.get("deleted") or []):
        return 404, {"error": "این باکس حذف شده است"}
    if any(b.get("id") == bid for b in (state.get("custom_boxes") or [])):
        return 400, {"error": "باکس دستی به رویداد تقویم وصل نمی‌شود"}
    box = _programme_box(prog, bid)
    if box is None:
        return 404, {"error": "باکسی با این شناسه پیدا نشد"}
    feed = ((prog.get("meta") or {}).get("last_feed") or [])
    ev = next((e for e in feed if e.get("uid") == uid), None)
    if ev is None:
        return 400, {"error": "رویدادی با این شناسه در آخرین سینک پیدا نشد"}
    uid_map = dict(prog.get("uid_map") or {})
    if uid in (prog.get("tombstone_uids") or []):
        return 400, {"error": "این رویداد قبلاً در برنامه حذف شده است"}
    if uid_map.get(uid) == bid:
        # Idempotent: already linked — just make sure the flag is clear.
        changed = box.pop("orphaned", None) is not None
        if changed:
            save_programme(prog)
        return 200, {"ok": True, "already": True,
                     "box": _public_box(load_programme(), load_state(), bid)}
    # Backup BEFORE any mutation, and verify it (spec §7).
    entry = create_backup("programme", force=True)
    if entry is None or verify_backup_entry(entry) is None:
        return 500, {"error": "پشتیبان‌گیری قبل از اتصال ممکن نشد — هیچ تغییری اعمال نشد"}
    absorbed = None
    other_bid = uid_map.get(uid)
    if other_bid and other_bid != bid:
        other = _programme_box(prog, other_bid)
        if other is None:
            del uid_map[uid]  # stale mapping, drop it
        elif other_bid in (state.get("deleted") or []):
            # Already deleted by the user: absorb unconditionally.
            prog["boxes"] = [b for b in prog["boxes"]
                             if b.get("id") != other_bid]
            absorbed = other_bid
        elif _box_has_user_data(state, other_bid):
            return 409, {"error": "این رویداد به باکس «{}» وصل است که داده‌ی کاربر دارد — اول آن را حذف یا جابه‌جا کن".format(
                other.get("title") or other_bid),
                "other_box": {"id": other_bid, "title": other.get("title")}}
        else:
            # Duplicate created by a pull, no user data: absorb it.
            prog["boxes"] = [b for b in prog["boxes"]
                             if b.get("id") != other_bid]
            for k in ("done", "tests", "actualMinutes", "edits",
                      "tests_total", "topicLinks", "boxBookLinks",
                      "usefulMinutes"):
                if isinstance(state.get(k), dict):
                    state[k].pop(other_bid, None)
            if isinstance(state.get("timerSessions"), list):
                state["timerSessions"] = [s for s in state["timerSessions"]
                                          if (s or {}).get("boxId") != other_bid]
            if isinstance(state.get("testLog"), list):
                state["testLog"] = [e for e in state["testLog"]
                                    if (e or {}).get("box") != other_bid]
            if isinstance(state.get("assignments"), list):
                state["assignments"] = [a for a in state["assignments"]
                                        if (a or {}).get("boxId") != other_bid]
            absorbed = other_bid
    # Drop the box's previous link, if any (the old event is gone — that
    # is why the box was disconnected).
    for u, b in list(uid_map.items()):
        if b == bid and u != uid:
            del uid_map[u]
    # Apply the event's values to the box (the event is the authority;
    # the user explicitly chose this link) and clear the orphaned flag.
    subj, topic = derive_subject_topic(ev["title"])
    box["title"] = ev["title"]
    box["date"] = ev["date"]
    box["start"] = ev["start"]
    box["end"] = ev["end"]
    box["subject"] = subj
    box["topic"] = topic
    box["is_test"] = event_is_test(ev["title"])
    box.pop("orphaned", None)
    uid_map[uid] = bid
    prog["uid_map"] = uid_map
    # Reconcile the app-edit overlay, so it cannot mask the reconnect.
    ed = state.get("edits") or {}
    if bid in ed:
        ed[bid].update({"title": ev["title"], "date": ev["date"],
                        "start": ev["start"], "end": ev["end"]})
        state["edits"] = ed
    # Push bookkeeping: the box now matches the event, so the next push
    # has nothing to send for it; drop the old event-id mapping (it
    # resolves on demand) and the old done baseline.
    ps = load_push_state()
    lp = dict(ps.get("last_pushed") or {})
    lp[bid] = {"title": ev["title"], "date": ev["date"],
               "start": ev["start"], "end": ev["end"]}
    ps["last_pushed"] = lp
    ae = dict(ps.get("app_edited_at") or {})
    ae.pop(bid, None)
    ps["app_edited_at"] = ae
    em = dict(ps.get("event_map") or {})
    em.pop(bid, None)
    ps["event_map"] = em
    ds = dict(ps.get("done_synced") or {})
    ds.pop(bid, None)
    ps["done_synced"] = ds
    save_push_state(ps)
    save_state(state)
    save_programme(prog)
    return 200, {"ok": True, "absorbed": absorbed,
                 "box": _public_box(load_programme(), load_state(), bid)}


@_with_sync_lock
def box_api_push_one(payload):
    """Create ONE Google Calendar event for a single disconnected box
    (v1.11.11, per-box «افزودن به تقویم»). Works for programme boxes
    and custom boxes. Idempotent: a box that is already linked (a
    uid_map entry — the pull's link — or the push event_map) creates
    NOTHING and returns already:true. On success the event id is
    recorded in event_map, created_ids, ical_map AND uid_map (so the
    corner box flips to «در تقویم ✓» via the status payload), plus
    last_pushed / done_synced; an orphaned flag on a programme box is
    cleared. OAuth not connected returns the same Persian error
    push_to_google uses and creates nothing. The three-dot
    «reconnect» (pick an EXISTING event) is untouched — this is the
    other direction (create a NEW event).

    v1.11.16 (audit §5 item 1.2): serialized under SYNC_LOCK with
    push_to_google and run_calendar_sync — a concurrent push can no
    longer create a duplicate event for the same box.
    v1.11.24 (QA BUG-019): three phases like push_to_google — the
    Google POST no longer runs under STATE_LOCK (a slow POST used to
    freeze every state save). Phase A validates + takes the
    per-box in-flight guard under a short lock; phase B POSTs with
    no state lock held; phase C persists the mapping onto FRESHLY
    re-loaded push_state/programme under a short lock."""
    bid = str(payload.get("box_id") or payload.get("boxId") or "").strip()
    if not bid:
        return 400, {"error": "شناسه‌ی باکس خالی است"}
    cfg = load_oauth()
    if not (cfg.get("access_token") or "").strip() \
            and not (cfg.get("refresh_token") or "").strip():
        return 200, {"ok": False,
                     "error": "گوگل متصل نیست — اول «اتصال به گوگل» را بزن"}
    # ---- Phase A: validate + in-flight guard (short, locked) ----
    with STATE_LOCK:
        prog = load_programme()
        state = load_state()
        if bid in (state.get("deleted") or []):
            return 404, {"error": "این باکس حذف شده است"}
        eff = effective_boxes(prog, state)
        e = eff.get(bid)
        if e is None:
            return 404, {"error": "باکسی با این شناسه پیدا نشد"}
        ps = load_push_state()
        emap = dict(ps.get("event_map") or {})
        if e.get("uid") or bid in emap:
            # Already linked — create nothing (idempotent). The merge
            # drops uid_map + event_map entries when it orphans a box,
            # so a disconnected box never reaches this branch.
            return 200, {"ok": True, "already": True,
                         "event_id": emap.get(bid),
                         "box": _public_box(prog, state, bid)}
        done_local = bool((state.get("done") or {}).get(bid))
        # Per-box in-flight guard (v1.11.16, audit §5 item 1.2): never
        # POST a second event for a box that is already being pushed.
        # Whole-run serialization (SYNC_LOCK) makes this unreachable
        # today; the set is belt-and-braces for any future caller that
        # bypasses the lock.
        if bid in _PUSH_IN_FLIGHT:
            return 200, {"ok": False,
                         "error": "این باکس در حال همگام‌سازی است — چند لحظه دیگر دوباره تلاش کن"}
        _PUSH_IN_FLIGHT.add(bid)
    # ---- Phase B: the Google POST (SYNC_LOCK only, NO STATE_LOCK) ----
    # v1.11.23 (QA BUG-003): the guard is released in a `finally` — a
    # bookkeeping exception after the Google POST used to escape the
    # handler (no try in do_POST), swallowing the HTTP response and
    # leaving the box locked until a server restart, with an orphan
    # Google event and no saved mapping. Bookkeeping failures now return
    # an error payload instead of raising.
    try:
        try:
            data = google_api("POST", "/calendars/primary/events",
                              _google_event_body(e, done=done_local))
        except Exception as exc:
            return 200, {"ok": False,
                         "error": "ساخت «{}»: {}".format(e["title"], exc)}
        eid = str(data.get("id") or "")
        ical_uid = str(data.get("iCalUID") or "")
        if not eid:
            return 200, {"ok": False, "error": "گوگل شناسه‌ی رویداد نداد"}
        # ---- Phase C: persist the mapping onto FRESH state ----
        # Re-load push_state fresh: an edit or a pull that landed
        # during the POST is never overwritten (BUG-019). Only this
        # box's entries are set, so nothing else can be clobbered.
        try:
            with STATE_LOCK:
                fresh_ps = load_push_state()
                f_emap = dict(fresh_ps.get("event_map") or {})
                f_emap[bid] = eid
                fresh_ps["event_map"] = f_emap
                f_imap = dict(fresh_ps.get("ical_map") or {})
                if ical_uid:
                    f_imap[ical_uid] = eid
                fresh_ps["ical_map"] = f_imap
                f_created = set(fresh_ps.get("created_event_ids") or [])
                f_created.add(eid)
                fresh_ps["created_event_ids"] = sorted(f_created)
                f_lp = dict(fresh_ps.get("last_pushed") or {})
                f_lp[bid] = {"title": e["title"], "date": e["date"],
                             "start": e["start"], "end": e["end"]}
                fresh_ps["last_pushed"] = f_lp
                f_ds = dict(fresh_ps.get("done_synced") or {})
                f_ds[bid] = done_local
                fresh_ps["done_synced"] = f_ds
                save_push_state(fresh_ps)
        except Exception as exc:
            # The mapping was NOT persisted: remove the orphan event
            # best-effort so a retry does not create a duplicate.
            # (Outside the lock — a network call, never under STATE_LOCK.)
            try:
                google_api("DELETE", "/calendars/primary/events/"
                           + urllib.parse.quote(eid, safe=""))
            except Exception:
                pass
            return 200, {"ok": False,
                         "error": "ذخیره‌ی پیوند «{}» ممکن نشد — رویداد ساخته‌شده پاک شد، دوباره تلاش کن: {}".format(e["title"], exc)}
        # Clear the orphaned flag so the status payload (and the corner
        # box) sees the box as connected, and persist the uid_map.
        try:
            with STATE_LOCK:
                fresh_prog = load_programme()
                pb = _programme_box(fresh_prog, bid)
                if pb is not None:
                    pb.pop("orphaned", None)
                if ical_uid:
                    f_uid_map = dict(fresh_prog.get("uid_map") or {})
                    f_uid_map[ical_uid] = bid
                    fresh_prog["uid_map"] = f_uid_map
                save_programme(fresh_prog)
        except Exception as exc:
            # The mapping IS persisted (event_map has it); only the
            # programme save failed. Report the error — the box is
            # linked and the next pull/push reconciles the flag.
            return 200, {"ok": False, "event_id": eid,
                         "error": "رویداد ساخته شد ولی ذخیره‌ی برنامه ممکن نشد: {}".format(exc)}
        with STATE_LOCK:
            box = _public_box(load_programme(), load_state(), bid)
        return 200, {"ok": True, "already": False, "event_id": eid,
                     "box": box}
    finally:
        _PUSH_IN_FLIGHT.discard(bid)


def _apply_map_diff(fresh, final, snap):
    """Apply a phase-B map diff onto a freshly loaded map (v1.11.24,
    QA BUG-019). Keys the phase-B run set or changed win; keys it
    removed are removed only when the fresh value still equals the
    phase-A snapshot — a concurrent writer's newer value always wins.
    (The only concurrent push_state writer during a push is
    note_app_edits, which touches app_edited_at + pending only; the
    pull can also pop last_pushed/event_map/app_edited_at entries.)"""
    for k, v in final.items():
        fresh[k] = v
    for k in list(fresh):
        if k in snap and k not in final and fresh[k] == snap[k]:
            del fresh[k]
    return fresh


def _apply_set_diff(fresh, final, snap):
    """Set version of _apply_map_diff: phase-B additions win;
    removals apply only to members the snapshot had (a member added
    by a concurrent run during phase B is never removed)."""
    fresh |= (final - snap)
    fresh -= (snap - final)
    return fresh


@_with_sync_lock
def push_to_google(manual=False):
    """Push app-side box changes to Google Calendar. Compares the effective
    boxes (programme + app edits + custom boxes) against last_pushed and
    only calls the API for what actually changed — and only when Google
    has not changed that box since the last pull: before PATCHing, the
    event's CURRENT values are read from Google, and a box Google moved
    first is skipped (the next pull then applies Google's version and
    drops the local edit, with a note). Deletions delete the Google event
    for every mapped box (v1.11.12 — user request: deleting a box in the
    app deletes its Google event too, not only events the app created).
    On any failure nothing is lost locally: the error is recorded in
    Persian and the push can be retried.
    v1.11.24 (QA BUG-019): three phases. The whole push used to run
    under STATE_LOCK, so a slow Google round-trip froze every state
    save (ticks, timer) for the entire push. Now: (A) a short locked
    snapshot of programme/state/push_state; (B) all Google calls with
    NO state lock held (SYNC_LOCK still serializes whole sync/push
    runs); (C) a short locked commit that applies only the DIFFS of
    phase B onto freshly re-loaded tracking — so an edit or a pull
    that landed during phase B is never overwritten."""
    cfg = load_oauth()
    if not (cfg.get("access_token") or "").strip() \
            and not (cfg.get("refresh_token") or "").strip():
        return {"ok": False, "error": "گوگل متصل نیست — اول «اتصال به گوگل» را بزن"}
    try:
        # ---- Phase A: snapshot (short, locked) ----
        # Snapshots (suffix _s) are the phase-A values; the plain names
        # are phase B's working copies. Only note_app_edits can write
        # push_state during phase B (STATE_LOCK only, app_edited_at +
        # pending only) — every other push_state/programme writer
        # (pull, push-one, reconnect) takes SYNC_LOCK and is blocked.
        with STATE_LOCK:
            prog = load_programme()
            state = load_state()
            ps = load_push_state()
            eff = effective_boxes(prog, state)
            deleted = set(state.get("deleted") or [])
            emap_s = dict(ps.get("event_map") or {})
            imap_s = dict(ps.get("ical_map") or {})
            created_s = set(ps.get("created_event_ids") or [])
            last_pushed_s = dict(ps.get("last_pushed") or {})
            app_edited_s = dict(ps.get("app_edited_at") or {})
            pending_s = set(ps.get("pending") or [])
            done_synced_s = dict(ps.get("done_synced") or {})
            uid_map_s = dict(prog.get("uid_map") or {})
            first, last = _programme_range()
            emap = dict(emap_s)
            imap = dict(imap_s)
            created_ids = set(created_s)
            last_pushed = dict(last_pushed_s)
            app_edited = dict(app_edited_s)
            pending = set(pending_s)
            done_synced = dict(done_synced_s)
            uid_map = dict(uid_map_s)
            # Prune tracking for boxes that no longer exist anywhere.
            pending &= (set(eff) | deleted)
            for bid in list(app_edited):
                if bid not in eff and bid not in deleted:
                    del app_edited[bid]

        # ---- Phase B: Google calls (SYNC_LOCK only, NO STATE_LOCK) ----
        created, updated, removed = 0, 0, 0
        errors = []
        prog_dirty = False

        def eff_sig(e):
            return {"title": e["title"], "date": e["date"],
                    "start": e["start"], "end": e["end"]}

        # --- deletions (v1.11.12): deleting a box in the app deletes its
        # Google event too — for EVERY mapped box, not only events the
        # app itself created (user request, 24 Nov 22:06). A box with no
        # event mapping still makes no API call. A delete failure keeps
        # the mapping (the `continue` below) so the next push retries.
        # v1.11.16 (audit §5 item 1.3): the pull records a link ONLY in
        # programme.uid_map, never in push_state.event_map — so a
        # pull-linked box was skipped by the old `bid not in emap`
        # gate and its Google event survived deletion. Resolve the
        # event id from uid_map / ical_map for those boxes instead of
        # skipping them.
        for bid in sorted(deleted):
            title = bid
            date = None
            raw = _programme_box(prog, bid)
            if raw is not None:
                ov = (state.get("edits") or {}).get(bid) or {}
                title = ov.get("title", raw.get("title")) or bid
                date = ov.get("date", raw.get("date"))
            else:
                cb = next((c for c in (state.get("custom_boxes") or [])
                           if c.get("id") == bid), None)
                title = (cb or {}).get("title") or bid
                date = (cb or {}).get("date")
            eid = emap.get(bid)
            uid = None
            if not eid:
                uid = _box_uid(prog, bid)
                if uid:
                    if imap.get(uid):
                        eid = imap[uid]
                    elif date:
                        eid = _resolve_event_id(imap, {"uid": uid, "date": date})
                    elif uid.endswith("@google.com"):
                        eid = uid[:-len("@google.com")]
            if not eid:
                if uid is None:
                    # No link of any kind: no Google event can exist
                    # for this box — never linked, never created, or
                    # already deleted and cleaned up (BUG-039), or the
                    # pull already dropped the link because the event
                    # is gone from the feed (orphan path). Nothing to
                    # delete and nothing to retry: drop the tracking
                    # silently, as before.
                    last_pushed.pop(bid, None)
                    app_edited.pop(bid, None)
                    pending.discard(bid)
                    done_synced.pop(bid, None)
                    continue
                # v1.11.27 (user-reported dashboard-delete bug, 25 Nov):
                # the box still HAS a pull link (uid_map), so a Google
                # event should exist — but its id resolves from nowhere
                # (not in ical_map, not in the day's refresh, and no
                # @google.com suffix to derive it from). The old code
                # dropped the tracking silently here, so the push still
                # reported ok: True with zero errors while the event
                # survived forever, with no signal anywhere. Record
                # the failure so last_push carries it (the Calendar tab
                # shows last_push.error and the pending count) and KEEP
                # all tracking: the bid stays in the phase-B pending
                # set, so the phase-C consumed() rule does not drop it
                # and the next auto-push retries the resolution.
                # Nothing is popped — the successful-DELETE branch
                # below still cleans up.
                errors.append(
                    "حذف «{}»: رویدادش در تقویم پیدا نشد — حذف دوباره تلاش می‌شود".format(title))
                continue
            try:
                google_api("DELETE", "/calendars/primary/events/"
                           + urllib.parse.quote(eid, safe=""))
                removed += 1
            except GoogleNotFound:
                removed += 1  # already gone on Google
            except Exception as exc:
                errors.append("حذف «{}»: {}".format(title, exc))
                continue
            created_ids.discard(eid)
            emap.pop(bid, None)
            last_pushed.pop(bid, None)
            app_edited.pop(bid, None)
            pending.discard(bid)
            done_synced.pop(bid, None)
            # v1.11.26 (QA BUG-039): the pull link must go regardless
            # of which map the event id came from. When eid came from
            # event_map, uid stayed None and the uid_map/imap entries
            # survived — the next push resolved the same dead event
            # again and counted another DELETE (404) as «removed».
            if uid is None:
                uid = _box_uid(prog, bid)
            if uid:
                # The event is gone: drop the pull link too, so a later
                # push never re-DELETEs a dead event (the merge would
                # drop it as an orphan anyway).
                uid_map.pop(uid, None)
                imap.pop(uid, None)
                prog_dirty = True

        # Live Google check (Google-wins rule): before PATCHing a box,
        # read the events' CURRENT values from Google. An app edit is
        # pushed only if Google has not changed that box since the last
        # pull. Fetched lazily — only when a real update is about to be
        # pushed — and only once per push run. If the live read fails,
        # updates are DEFERRED (kept pending for the next push) instead
        # of PATCHing blind on the last_pushed comparison.
        live = None  # None = not fetched yet, False = fetch failed

        def ensure_live():
            """Fetch the live event list once per push run (or False).
            Uses the phase-A programme range snapshot (BUG-019) — the
            range cannot change under the push anyway."""
            nonlocal live
            if live is None:
                try:
                    live = _list_google_events(
                        first.isoformat() + "T00:00:00+03:30",
                        (last + timedelta(days=1)).isoformat() + "T00:00:00+03:30")
                except Exception as exc:
                    print("Live Google check failed, pushing on last_pushed: {}".format(exc))
                    live = False
            return live

        def live_sig(uid):
            """Current Google {title, date, start, end} for a UID, or
            None if the event is not in the live list, or "unknown" if
            the live read failed."""
            lv = ensure_live()
            if not lv:
                return "unknown"
            ev = lv.get(uid)
            if not ev:
                return None
            return {"title": ev["title"], "date": ev["date"],
                    "start": ev["start"], "end": ev["end"]}

        def live_done(uid):
            """Current Google done flag for a UID (True/False), or None
            when the event is not in the live list or the live read
            failed. Used as the first-sync baseline for the done push."""
            lv = ensure_live()
            if not lv:
                return None
            ev = lv.get(uid)
            if not ev:
                return None
            return ev.get("done")

        def google_moved_first(bid, sig, uid):
            """True if Google changed this box after the last pull: the
            live event differs from BOTH last_pushed and the app's edit.
            No UID, an event missing from the live list, or a failed live
            read all mean 'cannot tell' -> False (push as before)."""
            if not uid:
                return False
            ls = live_sig(uid)
            if ls == "unknown" or ls is None:
                return False
            return ls != last_pushed.get(bid) and ls != sig

        # --- creates + updates ---
        for bid in sorted(eff):
            e = eff[bid]
            sig = eff_sig(e)
            done_local = bool((state.get("done") or {}).get(bid))
            if bid in emap:
                if last_pushed.get(bid) == sig:
                    pending.discard(bid)
                    continue
                eid = emap[bid]
                if e.get("uid") and live_sig(e.get("uid")) == "unknown":
                    # The live read failed: cannot tell whether Google
                    # moved this box first — defer the update (it stays
                    # pending) instead of PATCHing blind over Google.
                    errors.append("بررسی زنده‌ی تقویم ممکن نشد — ویرایش «{}» فرستاده نشد؛ در همگام‌سازی بعدی دوباره تلاش می‌شود".format(e["title"]))
                    continue
                if google_moved_first(bid, sig, e.get("uid")):
                    # Google changed this box after the last pull: do NOT
                    # overwrite it. The next pull applies Google's version
                    # and drops this local edit (with a note). Keep it
                    # pending so the push retries until the pull resolves it.
                    errors.append("«{}» در تقویم عوض شده بود — ویرایش برنامه فرستاده نشد؛ در همگام‌سازی بعدی نسخه‌ی تقویم اعمال می‌شود".format(e["title"]))
                    continue
                try:
                    google_api("PATCH", "/calendars/primary/events/"
                               + urllib.parse.quote(eid, safe=""),
                               _google_event_body(e, done=done_local))
                    updated += 1
                    done_synced[bid] = done_local
                except GoogleNotFound:
                    # Event vanished on Google: drop the mapping; the next
                    # pull re-adds the box if the event still exists.
                    emap.pop(bid, None)
                    last_pushed.pop(bid, None)
                    done_synced.pop(bid, None)
                    errors.append("رویداد «{}» در گوگل پیدا نشد — پیوندش برداشته شد".format(e["title"]))
                    continue
                except Exception as exc:
                    errors.append("به‌روز «{}»: {}".format(e["title"], exc))
                    continue
                last_pushed[bid] = sig
                app_edited.pop(bid, None)
                pending.discard(bid)
                continue
            if e["is_custom"]:
                # A box made in the app -> a brand-new Google event.
                try:
                    data = google_api("POST", "/calendars/primary/events",
                                      _google_event_body(e, done=done_local))
                except Exception as exc:
                    errors.append("ساخت «{}»: {}".format(e["title"], exc))
                    continue
                eid = str(data.get("id") or "")
                ical_uid = str(data.get("iCalUID") or "")
                if eid:
                    emap[bid] = eid
                    created_ids.add(eid)
                    if ical_uid:
                        imap[ical_uid] = eid
                        uid_map[ical_uid] = bid
                        prog_dirty = True
                    last_pushed[bid] = sig
                    done_synced[bid] = done_local
                    app_edited.pop(bid, None)
                    pending.discard(bid)
                    created += 1
                continue
            # A mapped programme box with no stored event id (e.g. mapped
            # before the OAuth connection): resolve it, then update.
            eid = _resolve_event_id(imap, e)
            if not eid:
                if not e.get("uid"):
                    # v1.11.23 (QA BUG-006): never linked to Google — there
                    # is nothing to push, and it is NOT an error. Every
                    # unlinked programme box used to append an error here,
                    # so `ok` was False on every push (316 phantom errors
                    # on a fresh seed) and a real push failure was
                    # indistinguishable from the noise.
                    continue
                errors.append("رویداد «{}» در گوگل پیدا نشد".format(e["title"]))
                continue
            emap[bid] = eid
            if last_pushed.get(bid) == sig:
                pending.discard(bid)
                continue
            if google_moved_first(bid, sig, e.get("uid")):
                errors.append("«{}» در تقویم عوض شده بود — ویرایش برنامه فرستاده نشد؛ در همگام‌سازی بعدی نسخه‌ی تقویم اعمال می‌شود".format(e["title"]))
                continue
            try:
                google_api("PATCH", "/calendars/primary/events/"
                           + urllib.parse.quote(eid, safe=""),
                           _google_event_body(e, done=done_local))
                updated += 1
                done_synced[bid] = done_local
            except GoogleNotFound:
                emap.pop(bid, None)
                last_pushed.pop(bid, None)
                done_synced.pop(bid, None)
                errors.append("رویداد «{}» در گوگل پیدا نشد — پیوندش برداشته شد".format(e["title"]))
                continue
            except Exception as exc:
                errors.append("به‌روز «{}»: {}".format(e["title"], exc))
                continue
            last_pushed[bid] = sig
            app_edited.pop(bid, None)
            pending.discard(bid)

        # --- done-status push (v1.11.7): a tick/untick is not a shape
        # change, so the loop above never PATCHes it. Boxes whose local
        # done differs from what Google last had get their
        # extendedProperties patched (no other field touched). A box never
        # synced before uses Google's live flag as the baseline — no flag
        # means not done, so an unticked box needs no PATCH at all.
        # Loop-safe: a successful PATCH records the value in done_synced,
        # so the next pull (Google == local) applies nothing and the next
        # push PATCHes nothing.
        done_updated = 0
        for bid in sorted(eff):
            e = eff[bid]
            eid = emap.get(bid)
            if not eid:
                continue
            done_local = bool((state.get("done") or {}).get(bid))
            synced = done_synced.get(bid)
            if synced is None:
                ld = live_done(e.get("uid")) if e.get("uid") else None
                synced = ld if ld is not None else False
            if synced == done_local:
                done_synced[bid] = done_local
                continue
            try:
                google_api("PATCH", "/calendars/primary/events/"
                           + urllib.parse.quote(eid, safe=""),
                           {"extendedProperties": {"private": {"studyflow.done": "1" if done_local else "0"}}})
                done_synced[bid] = done_local
                done_updated += 1
                pending.discard(bid)
            except GoogleNotFound:
                emap.pop(bid, None)
                last_pushed.pop(bid, None)
                done_synced.pop(bid, None)
                errors.append("رویداد «{}» در گوگل پیدا نشد — پیوندش برداشته شد".format(e["title"]))
                continue
            except Exception as exc:
                pending.add(bid)
                errors.append("به‌روز وضعیت «{}»: {}".format(e["title"], exc))
                continue

        summary = {"created": created, "updated": updated, "removed": removed,
                   "done_updated": done_updated,
                   "errors": errors[:10], "error_count": len(errors)}
        # ---- Phase C: commit the DIFFS (short, locked) ----
        # Re-load fresh and apply only what phase B changed, so an edit
        # (note_app_edits) or a pull that landed during phase B is
        # never overwritten. A phase-B removal applies only when the
        # fresh value still equals the phase-A snapshot — a concurrent
        # writer's newer value always wins.
        with STATE_LOCK:
            fresh_ps = load_push_state()
            fresh_ps["event_map"] = _apply_map_diff(
                dict(fresh_ps.get("event_map") or {}), emap, emap_s)
            fresh_ps["ical_map"] = _apply_map_diff(
                dict(fresh_ps.get("ical_map") or {}), imap, imap_s)
            fresh_ps["created_event_ids"] = sorted(_apply_set_diff(
                set(fresh_ps.get("created_event_ids") or {}),
                created_ids, created_s))
            fresh_ps["last_pushed"] = _apply_map_diff(
                dict(fresh_ps.get("last_pushed") or {}),
                last_pushed, last_pushed_s)
            fresh_ps["done_synced"] = _apply_map_diff(
                dict(fresh_ps.get("done_synced") or {}),
                done_synced, done_synced_s)
            f_app_edited = _apply_map_diff(
                dict(fresh_ps.get("app_edited_at") or {}),
                app_edited, app_edited_s)
            fresh_ps["app_edited_at"] = f_app_edited
            f_pending = set(fresh_ps.get("pending") or [])
            for bid in (pending_s - pending):
                # consumed() rule: drop only if no NEW edit landed
                # during phase B. A new edit sets a fresh app_edited_at
                # timestamp; the pull popping the entry (Google-wins)
                # also means the push is moot.
                if bid not in f_app_edited \
                        or f_app_edited[bid] == app_edited_s.get(bid):
                    f_pending.discard(bid)
            f_pending |= (pending - pending_s)
            fresh_ps["pending"] = sorted(f_pending)
            fresh_ps["last_push"] = {"ts": iso_now(), "ok": not errors,
                                     "summary": summary,
                                     "error": errors[0] if errors else None}
            save_push_state(fresh_ps)
            if prog_dirty:
                fresh_prog = load_programme()
                fresh_prog["uid_map"] = _apply_map_diff(
                    dict(fresh_prog.get("uid_map") or {}), uid_map, uid_map_s)
                save_programme(fresh_prog)
        return {"ok": not errors, "summary": summary}
    except Exception as exc:
        with STATE_LOCK:
            ps = load_push_state()
            ps["last_push"] = {"ts": iso_now(), "ok": False, "summary": None,
                               "error": str(exc)}
            save_push_state(ps)
        return {"ok": False, "error": str(exc)}


def note_app_edits(old_state, new_state):
    """After a state save: record which boxes changed (edit / custom box /
    delete / tick) with a timestamp, and queue a debounced auto-push.
    Ticks reach here too (a tick/untick queues a done-status push);
    test counts and real minutes never do — only box-shape changes and
    done changes do."""
    changed = set()
    old_edits = old_state.get("edits") or {}
    new_edits = new_state.get("edits") or {}
    for bid in set(old_edits) | set(new_edits):
        if old_edits.get(bid) != new_edits.get(bid):
            changed.add(bid)
    # Ticks (v1.11.7): a tick/untick is a done change — queue the box so
    # the debounced auto-push PATCHes its extendedProperties.
    old_done = old_state.get("done") or {}
    new_done = new_state.get("done") or {}
    for bid in set(old_done) | set(new_done):
        if bool(old_done.get(bid)) != bool(new_done.get(bid)):
            changed.add(bid)
    old_cb = {b["id"]: b for b in (old_state.get("custom_boxes") or []) if b.get("id")}
    new_cb = {b["id"]: b for b in (new_state.get("custom_boxes") or []) if b.get("id")}
    for bid in set(old_cb) | set(new_cb):
        if old_cb.get(bid) != new_cb.get(bid):
            changed.add(bid)
    changed |= (set(new_state.get("deleted") or []) - set(old_state.get("deleted") or []))
    if not changed:
        return
    with STATE_LOCK:
        ps = load_push_state()
        ea = dict(ps.get("app_edited_at") or {})
        now = time.time()
        for bid in changed:
            ea[bid] = now
        ps["app_edited_at"] = ea
        pend = set(ps.get("pending") or [])
        pend |= changed
        ps["pending"] = sorted(pend)
        save_push_state(ps)
    PUSH_SYNC.request()


class PushSync:
    """Debounced auto-push: runs ~15s after a state save that changed a box,
    so a burst of edits becomes one push. Same shape as the B2 CloudSync."""

    def __init__(self):
        self._event = threading.Event()
        self._immediate = threading.Event()

    def request(self, immediate=False):
        self._event.set()
        if immediate:
            self._immediate.set()

    def run(self):
        while True:
            self._event.wait(timeout=3600)
            self._event.clear()
            if self._immediate.is_set():
                self._immediate.clear()
            else:
                time.sleep(15)
            try:
                cfg = load_oauth()
                if not ((cfg.get("access_token") or "").strip()
                        or (cfg.get("refresh_token") or "").strip()):
                    continue
                # Nothing pending: the hourly wake is a no-op (pushing
                # with no changes only re-reads Google for nothing).
                if not (load_push_state().get("pending") or []):
                    continue
                get_sync_provider().push(manual=False)
            except Exception as exc:
                print("Calendar auto-push error: {}".format(exc))


PUSH_SYNC = PushSync()


# ---------- ICS fetch + sync runs ----------
def fetch_ics(url):
    # HTTPS only: the ICS URL carries the calendar's private token.
    if not str(url or "").strip().startswith("https://"):
        raise ValueError("آدرس ICS باید با https:// شروع شود")
    req = urllib.request.Request(
        url, headers={"User-Agent": "KonkurApp-CalendarSync/1.8"}, method="GET")
    # v1.11.24 (QA BUG-012): redirects are re-checked for https.
    with open_https_url(req, timeout=CALENDAR_FETCH_TIMEOUT) as resp:
        raw = resp.read(CALENDAR_MAX_BYTES + 1)
    if len(raw) > CALENDAR_MAX_BYTES:
        raise ValueError("فایل ICS خیلی بزرگ است")
    return raw.decode("utf-8", "replace")


def _record_sync_error(source_label, err, log=True):
    """Record a failed sync (fetch/parse/empty feed) in the calendar
    config (and, unless log=False, the sync log). No state is touched,
    so no lock is needed (v1.11.24, QA BUG-019)."""
    cfg = load_calendar_config()
    cfg["last_error"] = err
    save_calendar_config(cfg)
    if log:
        append_calendar_log(source_label, {"added": 0, "updated": 0, "removed": 0,
                                           "error": err}, [err])


@_with_sync_lock
def run_calendar_sync(source_label):
    """Fetch the configured ICS URL and merge it. On any failure the last
    good programme is kept untouched and the error is recorded.
    v1.11.24 (QA BUG-019): the ICS fetch (up to 25 s) used to run under
    STATE_LOCK, freezing every state save for the whole request.
    The fetch + parse now run with NO lock held; STATE_LOCK is taken
    only around the load-merge-save section. SYNC_LOCK still
    serializes whole sync/push runs against each other."""
    cfg = load_calendar_config()
    url = (cfg.get("ics_url") or "").strip()
    if not url:
        return {"ok": False, "error": "آدرس ICS تنظیم نشده است"}
    try:
        text = fetch_ics(url)  # network — NO lock held (BUG-019)
    except Exception as exc:
        err = "دریافت ICS ممکن نشد: {}".format(exc)
        _record_sync_error(source_label, err)
        return {"ok": False, "error": err}
    try:
        raw = parse_ics(text)
    except Exception as exc:
        err = "خواندن ICS ممکن نشد: {}".format(exc)
        # Same as before the split: a parse error is recorded in the
        # config only, with no log entry.
        _record_sync_error(source_label, err, log=False)
        return {"ok": False, "error": err}
    events, cancelled, counts = normalize_events(raw)
    if not events and not cancelled:
        err = "در فید هیچ رویداد درسی پیدا نشد — داده‌ی قبلی حفظ شد"
        _record_sync_error(source_label, err)
        return {"ok": False, "error": err}
    # Load-merge-save only — the one short locked section (BUG-019).
    try:
        with STATE_LOCK:
            summary = merge_calendar_events(events, cancelled, source_label, apply=True)
            summary["skipped"] = counts
    except ProgrammeCorruptError as exc:
        # v1.11.25 (QA BUG-024): a corrupt programme must fail the sync
        # LOUDLY (recorded in the sync log + config) instead of silently
        # merging into a substituted seed.
        err = str(exc)
        _record_sync_error(source_label, err)
        return {"ok": False, "error": err}
    # Two-way done-status sync (v1.11.7): pull the done flags Google
    # carries (extendedProperties) and apply them to the dashboard.
    # Best-effort — a failed done pull never fails the ICS sync itself.
    # v1.11.16 (audit §5 item 1.4): a failed done pull used to vanish
    # as a silent (0, 0) — the error is now recorded in the sync log
    # so the user sees it.
    try:
        done_applied, done_conflicts, done_error, done_skipped = sync_done_from_google()
        summary["done_applied"] = done_applied
        summary["done_conflicts"] = done_conflicts
        # v1.11.28 (QA BUG-041): boxes skipped because a local tick is
        # still pending are counted in the summary AND the sync log —
        # a stuck push used to be invisible ((0, 0) looked like «in
        # sync» while the tick never reached Google).
        summary["done_skipped_pending"] = done_skipped
        if done_skipped:
            append_calendar_log(
                source_label,
                {"added": 0, "updated": 0, "removed": 0,
                 "done_skipped_pending": done_skipped},
                ["{} باکس در انتظار push رد شد — تیک محلی حفظ شد".format(done_skipped)])
        if done_error:
            summary["done_pull_error"] = done_error
            append_calendar_log(source_label,
                                {"added": 0, "updated": 0, "removed": 0,
                                 "done_pull_error": done_error},
                                [done_error])
    except Exception as exc:
        print("Done-status pull failed: {}".format(exc))
        summary["done_applied"] = 0
        summary["done_conflicts"] = 0
        summary["done_skipped_pending"] = 0
        summary["done_pull_error"] = str(exc)
        append_calendar_log(source_label,
                            {"added": 0, "updated": 0, "removed": 0,
                             "done_pull_error": str(exc)},
                            [str(exc)])
    cfg = load_calendar_config()
    cfg["last_sync"] = iso_now()
    cfg["last_error"] = None
    cfg["last_summary"] = summary
    save_calendar_config(cfg)
    return {"ok": True, "summary": summary, "counts": counts}


def run_calendar_import(content, filename, source_label, apply):
    """Parse uploaded file content (ICS or JSON) and merge it. With
    apply=False this is the preview: nothing is written and nothing is
    logged. Returns (ok, payload)."""
    name = (filename or "").lower()
    text = content or ""
    try:
        if name.endswith(".json") or text.lstrip()[:1] in ("{", "["):
            raw = parse_calendar_json(text)
            fmt = "json"
        else:
            raw = parse_ics(text)
            fmt = "ics"
    except ValueError as exc:
        return False, {"error": str(exc)}
    except Exception as exc:
        return False, {"error": "خواندن فایل ممکن نشد: {}".format(exc)}
    events, cancelled, counts = normalize_events(raw)
    if not events and not cancelled:
        return False, {"error": "در فایل هیچ رویداد درسی پیدا نشد"}
    summary = merge_calendar_events(events, cancelled, source_label, apply=apply,
                                   remove_missing=False)
    summary["skipped"] = counts
    if apply:
        cfg = load_calendar_config()
        cfg["last_sync"] = iso_now()
        cfg["last_error"] = None
        cfg["last_summary"] = summary
        save_calendar_config(cfg)
    return True, {"format": fmt, "summary": summary, "counts": counts}


CAL_SYNC_STATE = {"last_attempt": 0.0}


# ---------- Sync provider abstraction (audit §5 item 3.6a) ----------
# The sync seam: everything the app does with a calendar goes through a
# provider object ({name, pull(source_label), push(manual)}). Google is
# the only provider today (ICS pull + OAuth push — the provider delegates
# to the exact functions below, it does not reimplement anything), but a
# second provider can register itself in SYNC_PROVIDERS without touching
# the Handler, the auto-sync loop or the push thread.
class SyncProvider:
    """Interface a calendar provider must satisfy."""
    name = "base"

    def pull(self, source_label):
        raise NotImplementedError

    def push(self, manual=False):
        raise NotImplementedError


class GoogleSyncProvider(SyncProvider):
    """Google Calendar: ICS feed for the pull, OAuth for the push."""
    name = "google"

    def pull(self, source_label):
        return run_calendar_sync(source_label)

    def push(self, manual=False):
        return push_to_google(manual=manual)


SYNC_PROVIDERS = {"google": GoogleSyncProvider()}


def get_sync_provider(name="google"):
    """The provider by name; KeyError for an unknown name."""
    return SYNC_PROVIDERS[name]


def calendar_sync_loop():
    """Background thread: auto-sync on the configured interval, plus one
    sync shortly after server start when a URL is configured."""
    time.sleep(5)
    while True:
        try:
            cfg = load_calendar_config()
            if cfg.get("enabled") and (cfg.get("ics_url") or "").strip():
                interval = max(5, int(cfg.get("interval_minutes") or 30)) * 60
                now = time.time()
                if now - CAL_SYNC_STATE["last_attempt"] >= interval:
                    CAL_SYNC_STATE["last_attempt"] = now
                    get_sync_provider().pull("auto")
        except Exception as exc:
            print("Calendar auto-sync error: {}".format(exc))
        time.sleep(60)


# v1.11.28 (QA BUG-048): at most 10 request-handler threads run at
# once — see Handler.handle(). One user's browser opens a handful of
# parallel connections; 10 leaves ample headroom while a flood can no
# longer grow threads without bound.
_REQUEST_SEMAPHORE = threading.BoundedSemaphore(10)


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=PUBLIC, **kwargs)

    def log_message(self, fmt, *args):
        pass  # keep the console quiet

    def version_string(self):
        # v1.11.28 (QA BUG-047): never advertise the Python version —
        # the default banner is "SimpleHTTP/0.6 Python/3.12.3".
        return "StudyFlow"

    def handle(self):
        # v1.11.28 (QA BUG-048): cap concurrent request threads at 10.
        # ThreadingHTTPServer spawns one thread per connection with no
        # limit; a flood of parallel requests used to grow threads
        # without bound. The semaphore is per-request only — the
        # PushSync thread, the auto-sync loop and the update thread are
        # separate threads and are unaffected. A request that cannot
        # get a slot within 30 s gets a 503 instead of queueing
        # forever.
        if not _REQUEST_SEMAPHORE.acquire(timeout=30):
            self.close_connection = True
            try:
                self._send_json(503, {"error": "سرور شلوغ است — دوباره تلاش کن"})
            except Exception:
                pass
            return
        try:
            self._handle_guarded()
        finally:
            _REQUEST_SEMAPHORE.release()

    def _handle_guarded(self):
        # v1.11.25 (QA BUG-024): a corrupt programme file (no backup)
        # raises ProgrammeCorruptError from load_programme() deep inside
        # a handler. CPython's BaseHTTPRequestHandler has NO handle_error
        # hook and handle_one_request() has no generic except (only
        # TimeoutError) — an earlier handle_error override here was dead
        # code: the exception reached the server, which only printed a
        # traceback and closed the socket, so the client saw a bare
        # "connection closed". Catch it HERE (handle() wraps the whole
        # request loop) and answer with a readable 500 instead, so the
        # UI shows what happened. Any OTHER exception still propagates
        # to the server's default handling (traceback on stderr).
        try:
            super().handle()
        except ProgrammeCorruptError as exc:
            self.close_connection = True
            try:
                self._send_json(500, {"error": str(exc)})
            except Exception:
                pass
        except _BadJsonBody as exc:
            # v1.11.26 (QA BUG-030): same pattern as ProgrammeCorruptError
            # above — answer with the body's own status/message instead
            # of closing the socket silently.
            self.close_connection = True
            try:
                self._send_json(exc.status, {"error": exc.message})
            except Exception:
                pass

    def end_headers(self):
        # v1.11.28 (QA BUG-047): basic security headers on EVERY
        # response (this runs after send_response/send_header, so it
        # covers static files, JSON and error pages alike). The CSP
        # keeps 'unsafe-inline' for scripts/styles because index.html
        # carries one small inline script (the mobile nav drawer) and
        # the app uses inline styles — everything else is 'self',
        # which is all this local single-page app loads.
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
            "connect-src 'self'; font-src 'self'; object-src 'none'; "
            "base-uri 'self'; frame-ancestors 'none'")
        # v1.11.4 — never let the browser cache app files: a stale
        # cached app.js after an update leaves buttons in fresh HTML
        # without handlers (and a stale i18n.js shows raw keys).
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def _send_json(self, status, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self):
        # v1.11.26 (QA BUG-030): the three failure modes are distinct
        # errors, not one {}. Every POST endpoint that reads a body
        # requires one (all 24 call sites do data.get(...) next), so
        # raising here is safe — no handler legitimately runs on an
        # empty body. A non-dict JSON value is also rejected: the old
        # code returned it as-is and the handler then crashed on .get.
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except Exception:
            raise _BadJsonBody(400, "طول بدنه نامعتبر است")
        if length <= 0:
            raise _BadJsonBody(400, "بدنه خالی")
        if length > 10 * 1024 * 1024:
            raise _BadJsonBody(413, "بدنه خیلی بزرگ است")
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw.decode("utf-8"))
        except Exception:
            raise _BadJsonBody(400, "JSON نامعتبر")
        if not isinstance(data, dict):
            raise _BadJsonBody(400, "JSON نامعتبر")
        return data

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path  # match routes without the query string
        if parsed.path == "/oauth/callback":
            self._handle_oauth_callback(parsed)
            return
        if path in ("/api/health", "/api/health/"):
            self._send_json(200, {"ok": True, "port": PORT})
            return
        if path in ("/api/state", "/api/state/"):
            self._send_json(200, load_state())
            return
        if path in ("/api/testbook", "/api/testbook/"):
            self._send_json(200, load_testbook())
            return
        if path in ("/api/gemini-key", "/api/gemini-key/"):
            # v1.11.28 (QA BUG-046): only a boolean leaves the server —
            # the old "masked" field leaked the first/last 4 chars of
            # the key to any caller of this endpoint.
            self._send_json(200, {"has_key": bool(read_key())})
            return
        if path in ("/api/gemini-model", "/api/gemini-model/"):
            self._send_json(200, {"model": read_model()})
            return
        if path in ("/api/gemini-models", "/api/gemini-models/"):
            # Diagnostic for the 404: list the models THIS key can actually use.
            key = read_key()
            if not key:
                self._send_json(400, {"error": "کلید API جمینای معتبر نیست"})
                return
            # v1.11.28 (QA BUG-048): the model list counts against the
            # same per-minute Gemini cap as generateContent calls.
            rate_err = check_gemini_rate_limit()
            if rate_err:
                self._send_json(429, {"error": rate_err})
                return
            # v1.11.28 (QA BUG-046): the key goes in the x-goog-api-key
            # header, never in the URL (?key= lands in logs/history).
            req = urllib.request.Request(
                GEMINI_API_BASE + "/models?pageSize=100",
                headers={"x-goog-api-key": key}, method="GET")
            try:
                # v1.11.24 (QA BUG-012): redirects are re-checked for https.
                with open_https_url(req, timeout=30) as resp:
                    result = json.loads(resp.read().decode("utf-8"))
            except urllib.error.HTTPError as exc:
                if exc.code in (400, 401, 403):
                    self._send_json(400, {"error": "کلید API جمینای معتبر نیست"})
                else:
                    self._send_json(502, {"error": "خطای سرور جمینای: HTTP " + str(exc.code)})
                return
            except Exception as exc:
                self._send_json(502, {"error": "ارتباط با جمینای برقرار نشد: " + str(exc)})
                return
            models = []
            for m in result.get("models", []) or []:
                name = str(m.get("name") or "")
                if name.startswith("models/"):
                    name = name[len("models/"):]
                methods = m.get("supportedGenerationMethods") or []
                if name and "generateContent" in methods:
                    # Full API metadata: the test panel shows the exact id,
                    # display name, version and context limits from Google.
                    models.append({
                        "id": name,
                        "displayName": str(m.get("displayName") or name),
                        "description": str(m.get("description") or ""),
                        "version": str(m.get("version") or ""),
                        "inputTokenLimit": m.get("inputTokenLimit"),
                        "outputTokenLimit": m.get("outputTokenLimit"),
                        "methods": methods,
                    })
            models.sort(key=lambda x: x["id"])
            self._send_json(200, {"models": models})
            return
        if path in ("/api/backup", "/api/backup/"):
            self._send_json(200, backup_status_payload())
            return
        if path in ("/api/backup/list", "/api/backup/list/"):
            versions = []
            for v in list_local_versions():
                versions.append(dict(v, verified=backup_entry_verified(v)))
            cloud = None
            cfg = load_b2_config()
            if cfg and cfg.get("enabled") and b2mod:
                try:
                    client = b2mod.B2Client(cfg)
                    manifest = client.get_json(CLOUD_MANIFEST_KEY) or {}
                    cloud = {"manifest": manifest}
                except Exception as exc:
                    cloud = {"error": str(exc)}
            self._send_json(200, {"versions": versions, "cloud": cloud})
            return
        if path in ("/api/backup/b2-config", "/api/backup/b2-config/"):
            self._send_json(200, masked_b2_config(load_b2_config()))
            return
        if path in ("/api/version", "/api/version/"):
            self._send_json(200, read_version())
            return
        if path in ("/api/update/status", "/api/update/status/"):
            self._send_json(200, {"version": read_version(),
                                  "backups": list_code_backups()})
            return
        if path in ("/api/update/auto", "/api/update/auto/"):
            cfg = load_update_config()
            self._send_json(200, {
                "config": {"manifest_url": cfg.get("manifest_url") or DEFAULT_MANIFEST_URL},
                "current": read_version(),
                "last_check": cfg.get("last_check"),
                "last_result": cfg.get("last_result"),
                "last_error": cfg.get("last_error"),
                "state": auto_update_status()})
            return
        if path in ("/api/update/auto-progress", "/api/update/auto-progress/"):
            self._send_json(200, auto_update_status())
            return
        if path in ("/data.json", "/data.json/"):
            try:
                prog, _ = read_json_file(CALENDAR_DATA_FILE)
                if isinstance(prog, dict) and isinstance(prog.get("boxes"), list):
                    # v1.11.9: attach the stored Google Event ID (uid) to
                    # each box, so the UI can show the REAL connection
                    # status (connected = has a uid and is not orphaned).
                    # uid_map is the only source of truth — never a
                    # title/date guess.
                    uid_by_box = {}
                    for u, bid in (prog.get("uid_map") or {}).items():
                        uid_by_box[bid] = u
                    boxes = []
                    for b in prog["boxes"]:
                        nb = dict(b)
                        nb["uid"] = uid_by_box.get(b.get("id"))
                        boxes.append(nb)
                    self._send_json(200, {"meta": prog.get("meta") or {},
                                          "boxes": boxes})
                    return
                with open(os.path.join(BASE, "data.json"), encoding="utf-8") as f:
                    data = json.load(f)
                self._send_json(200, data)
            except Exception as exc:
                self._send_json(500, {"error": str(exc)})
            return
        if path in ("/api/calendar/unlinked", "/api/calendar/unlinked/"):
            self._send_json(200, unlinked_calendar_payload())
            return
        if path in ("/api/calendar/status", "/api/calendar/status/"):
            self._send_json(200, calendar_status_payload())
            return
        if path in ("/api/calendar/config", "/api/calendar/config/"):
            self._send_json(200, masked_calendar_config(load_calendar_config()))
            return
        if path in ("/api/calendar/oauth/status", "/api/calendar/oauth/status/"):
            self._send_json(200, {"oauth": masked_oauth_status(),
                                  "push": push_status_payload()})
            return
        if path in ("/api/calendar/push-status", "/api/calendar/push-status/"):
            self._send_json(200, push_status_payload())
            return
        if path in ("/api/boxes", "/api/boxes/"):
            boxes = _public_boxes_list(load_programme(), load_state())
            self._send_json(200, {"boxes": boxes, "count": len(boxes)})
            return
        if path in ("/api/calendar/oauth/auth-url", "/api/calendar/oauth/auth-url/"):
            try:
                self._send_json(200, {"url": build_auth_url()})
            except Exception as exc:
                self._send_json(400, {"error": str(exc)})
            return
        super().do_GET()

    def _esc_html(self, s):
        return (str(s).replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace('"', "&quot;"))

    def _handle_oauth_callback(self, parsed):
        """Google redirects here after sign-in. Exchanges the code for
        tokens (server-side only) and shows a plain Persian result page."""
        qs = urllib.parse.parse_qs(parsed.query)
        code = (qs.get("code") or [""])[0]
        state = (qs.get("state") or [""])[0]
        err = (qs.get("error") or [""])[0]
        if err:
            ok, msg = False, "گوگل ورود را رد کرد: {}".format(err)
        elif not code:
            ok, msg = False, "کد ورود از گوگل نرسید — دوباره تلاش کن"
        else:
            try:
                cfg = exchange_code(code, state)
                email = cfg.get("account_email") or ""
                msg = "اتصال به گوگل برقرار شد" + (" ({})".format(email) if email else "") \
                    + " — می‌توانی این برگه را ببندی و به برنامه برگردی."
                ok = True
                threading.Thread(target=seed_push_state_after_connect, daemon=True).start()
            except Exception as exc:
                ok, msg = False, str(exc)
        heading = "اتصال برقرار شد" if ok else "اتصال ممکن نشد"
        page = ("<!DOCTYPE html><html lang=\"fa\" dir=\"rtl\"><head><meta charset=\"utf-8\">"
                "<title>StudyFlow — اتصال به گوگل</title>"
                "<style>body{font-family:tahoma,sans-serif;max-width:560px;margin:60px auto;"
                "padding:0 20px}h1{font-size:20px}p{line-height:1.9}</style></head><body>"
                "<h1>" + ("✅ " if ok else "⚠ ") + heading + "</h1><p>"
                + self._esc_html(msg) + "</p>"
                "<p><a href=\"/\">بازگشت به برنامه</a></p></body></html>")
        raw = page.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        # Match routes without the query string (a "?..." suffix used to
        # break every POST route that compared against self.path).
        path = urllib.parse.urlparse(self.path).path
        if path in ("/api/state", "/api/state/"):
            data = self._read_json()
            if not data:
                # Never let an empty/unreadable body wipe real data to defaults.
                self._send_json(400, {"error": "empty body"})
                return
            if not isinstance(data, dict):
                self._send_json(400, {"error": "bad body"})
                return
            # v1.11.23 (QA BUG-001): a known key with the wrong type must
            # be rejected WITHOUT saving — merge_state would drop it and
            # fall back to DEFAULT_STATE, silently wiping the stored
            # value (live repro: {"done": "bad-string"} wiped done to
            # {} with HTTP 200). Unknown keys stay log-and-drop (they
            # cannot wipe anything: sanitize removes them and the merge
            # below keeps the stored value).
            wrong_typed = state_wrong_typed_keys(data)
            if wrong_typed:
                print("POST /api/state wrong-typed keys: {}".format(wrong_typed))
                self._send_json(400, {"error": "نوع داده‌ی این فیلدها درست نیست: " + ", ".join(wrong_typed),
                                      "rejected": wrong_typed})
                return
            rejected = state_rejected_keys(data)
            if rejected:
                # The schema drops these on save (merge_state sanitizes);
                # log them so a client sending bad keys is visible.
                print("POST /api/state rejected keys: {}".format(rejected))
            # v1.11.23 (QA BUG-002): the client sends its sequence
            # number (X-State-Seq, added 1.11.17) — read it for the
            # save-order log. Ordering itself is handled by the
            # per-box deep merge below, not by rejecting stale saves.
            seq = self.headers.get("X-State-Seq")
            if seq:
                print("POST /api/state seq={}".format(seq))
            with STATE_LOCK:
                old_state = load_state()
                # Merge onto the CURRENT state: a partial body must
                # never wipe progress (done/tests/...) the client did
                # not send — and a stale tab must not wipe another
                # tab's newer per-box entries (merge_state_update
                # deep-merges the per-box dict keys; a stale tab's
                # null activeTimer never wipes a running timer).
                merged = merge_state_update(old_state, data)
                saved = save_state(merged)
                try:
                    note_app_edits(old_state, saved)
                except Exception as exc:
                    print("note_app_edits failed: {}".format(exc))
            self._send_json(200, saved)
            return
        if path in ("/api/boxes/create", "/api/boxes/create/"):
            data = self._read_json()
            status, payload = box_api_create(data or {})
            self._send_json(status, payload)
            return
        if path in ("/api/boxes/update", "/api/boxes/update/"):
            data = self._read_json()
            status, payload = box_api_update(data or {})
            self._send_json(status, payload)
            return
        if path in ("/api/boxes/delete", "/api/boxes/delete/"):
            data = self._read_json()
            status, payload = box_api_delete(data or {})
            self._send_json(status, payload)
            return
        if path in ("/api/boxes/reconnect", "/api/boxes/reconnect/"):
            data = self._read_json()
            status, payload = box_api_reconnect(data or {})
            self._send_json(status, payload)
            return
        if path in ("/api/calendar/tombstones/clear", "/api/calendar/tombstones/clear/"):
            # v1.11.29 (PI-04): no body needed — clears every stored tombstone.
            status, payload = clear_calendar_tombstones()
            self._send_json(status, payload)
            return
        if path in ("/api/boxes/push-one", "/api/boxes/push-one/"):
            data = self._read_json()
            status, payload = box_api_push_one(data or {})
            self._send_json(status, payload)
            return
        if path in ("/api/testbook", "/api/testbook/"):
            data = self._read_json()
            if not data:
                self._send_json(400, {"error": "empty body"})
                return
            if not valid_testbook(data):
                self._send_json(400, {"error": "testbook نامعتبر است"})
                return
            saved = save_testbook(data)
            self._send_json(200, saved)
            return
        if path in ("/api/gemini-key", "/api/gemini-key/"):
            data = self._read_json()
            key = str(data.get("key") or "").strip()
            if not key:
                self._send_json(400, {"error": "کلید خالی است"})
                return
            atomic_write(KEY_FILE, key.encode("utf-8"), mode=0o600)  # credential: owner only (1.10)
            # v1.11.28 (QA BUG-046): only a boolean — no masked form.
            self._send_json(200, {"has_key": True})
            return
        if path in ("/api/gemini-model", "/api/gemini-model/"):
            data = self._read_json()
            model = str(data.get("model") or "").strip()
            if not valid_model(model):
                self._send_json(400, {"error": "نام مدل معتبر نیست"})
                return
            atomic_write(MODEL_FILE, model.encode("utf-8"))
            self._send_json(200, {"model": model})
            return
        if path in ("/api/backup/now", "/api/backup/now/"):
            # v1.11.26 (QA BUG-031): snapshot under STATE_LOCK so the
            # three files are a consistent set — a concurrent save can
            # no longer slip between two snapshots.
            with STATE_LOCK:
                create_backup("state", force=True)
                create_backup("testbook", force=True)
                create_backup("programme", force=True)
            CLOUD_SYNC.request(immediate=True)
            self._send_json(200, backup_status_payload())
            return
        if path in ("/api/backup/restore", "/api/backup/restore/"):
            data = self._read_json()
            kind = data.get("kind")
            fname = data.get("file") or ""
            if kind not in ("state", "testbook", "programme", "push") or "/" in fname or "\\" in fname:
                self._send_json(400, {"error": "bad request"})
                return
            entry = None
            for v in list_local_versions(kind):
                if v.get("file") == fname:
                    entry = v
                    break
            if entry is None:
                self._send_json(404, {"error": "version not found"})
                return
            restored = verify_backup_entry(entry)
            if restored is None:
                self._send_json(400, {"error": "backup failed verification"})
                return
            # Audit §5 item 1.10: if the CURRENT file is corrupt, keep it
            # as <file>.corrupt-<ts> instead of silently overwriting it.
            target = {"state": STATE_FILE, "testbook": TESTBOOK_FILE,
                      "programme": CALENDAR_DATA_FILE,
                      "push": GOOGLE_PUSH_FILE}[kind]
            # v1.11.26 (QA BUG-031): the replace runs inside STATE_LOCK,
            # so a concurrent save cannot land mid-restore and be lost.
            # (STATE_LOCK is an RLock and _invalidate_push_tracking()
            # takes it too, so that nested acquisition is safe; the
            # cloud-sync thread never holds CLOUD_SYNC._lock while
            # taking STATE_LOCK, so the nested CLOUD_SYNC._lock below
            # cannot invert the lock order.)
            with STATE_LOCK:
                cur, _ = read_json_file(target)
                cur_ok = (cur is not None and
                          (valid_state(cur) if kind == "state" else
                           valid_testbook(cur) if kind == "testbook" else
                           isinstance(cur, dict) and isinstance(cur.get("boxes"), list)
                           if kind == "programme" else
                           isinstance(cur, dict)))
                if cur_ok:
                    # Snapshot the GOOD current file before replacing
                    # it, so a mistaken restore can be undone from
                    # backups/ (force=True: always a new version).
                    create_backup(kind, force=True)
                if os.path.exists(target) and not cur_ok:
                    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
                    corrupt_path = "{}.corrupt-{}".format(target, ts)
                    try:
                        shutil.copyfile(target, corrupt_path)
                        print("Preserved corrupt {} as {}".format(target, corrupt_path))
                    except Exception as exc:
                        print("Could not preserve corrupt file: {}".format(exc))
                if kind == "state":
                    atomic_write_json(STATE_FILE, restored)
                    with CLOUD_SYNC._lock:
                        CLOUD_SYNC.last_synced_sha["state"] = None
                    _invalidate_push_tracking()
                elif kind == "programme":
                    atomic_write_json(CALENDAR_DATA_FILE, restored)
                    with CLOUD_SYNC._lock:
                        CLOUD_SYNC.last_synced_sha["programme"] = None
                    _invalidate_push_tracking()
                elif kind == "push":
                    # Restoring the push bookkeeping itself — do NOT call
                    # _invalidate_push_tracking() here (that would wipe the
                    # bookkeeping we just restored). Push state is local-only
                    # (never cloud-synced), so no CLOUD_SYNC touch either.
                    atomic_write_json(GOOGLE_PUSH_FILE, restored)
                else:
                    atomic_write_json(TESTBOOK_FILE, restored)
                    with CLOUD_SYNC._lock:
                        CLOUD_SYNC.last_synced_sha["testbook"] = None
            self._send_json(200, {"ok": True, "restored": entry["file"]})
            return
        if path in ("/api/backup/resolve-conflict", "/api/backup/resolve-conflict/"):
            # Explicit user choice after a cloud conflict: upload the LOCAL
            # version as the newest cloud snapshot. The remote versioned
            # object is never deleted, so both versions stay in the cloud.
            data = self._read_json()
            kind = data.get("kind")
            # v1.11.26 (QA BUG-032): a programme conflict is resolvable
            # too — it was rejected by the allowlist even though the
            # cloud sync can produce one for any of the three kinds.
            if kind not in ("state", "testbook", "programme"):
                self._send_json(400, {"error": "bad request"})
                return
            with CLOUD_SYNC._lock:
                if CLOUD_SYNC.conflict and CLOUD_SYNC.conflict.get("kind") == kind:
                    CLOUD_SYNC.conflict = None
                CLOUD_SYNC.last_synced_sha[kind] = None
            # Force the manifest to accept ours next sync: temporarily clear
            # the remote-newer check by uploading now, directly.
            if b2mod:
                cfg = load_b2_config()
                if cfg and cfg.get("enabled"):
                    try:
                        client = b2mod.B2Client(cfg)
                        manifest = client.get_json(CLOUD_MANIFEST_KEY) or {}
                        path = (STATE_FILE if kind == "state" else
                                CALENDAR_DATA_FILE if kind == "programme" else
                                TESTBOOK_FILE)
                        with open(path, "rb") as f:
                            raw = f.read()
                        digest = sha256_bytes(raw)
                        ts = now_ts()
                        key = "{}-{}-{}.json".format(
                            kind, datetime.fromtimestamp(ts).strftime("%Y%m%d-%H%M%S"), digest[:8])
                        client.put_object(CLOUD_PREFIX + key, raw, "application/json")
                        manifest[kind] = {"key": CLOUD_PREFIX + key, "sha256": digest, "ts": ts}
                        manifest["updated_ts"] = ts
                        client.put_object(CLOUD_MANIFEST_KEY,
                                          json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8"),
                                          "application/json")
                        with CLOUD_SYNC._lock:
                            CLOUD_SYNC.last_synced_sha[kind] = digest
                            CLOUD_SYNC.last_sync = {"ts": now_ts(), "ts_iso": iso_now(),
                                                  "ok": True, "error": None}
                        self._send_json(200, {"ok": True, "uploaded": key})
                        return
                    except Exception as exc:
                        self._send_json(502, {"error": str(exc)})
                        return
            self._send_json(200, {"ok": True, "uploaded": None})
            return
        if path in ("/api/backup/restore-cloud", "/api/backup/restore-cloud/"):
            data = self._read_json()
            kind = data.get("kind")
            key = data.get("key") or ""
            if kind not in ("state", "testbook", "programme") or not key.startswith(CLOUD_PREFIX):
                self._send_json(400, {"error": "bad request"})
                return
            if not b2mod:
                self._send_json(500, {"error": "cloud module unavailable"})
                return
            cfg = load_b2_config()
            if not cfg or not cfg.get("enabled"):
                self._send_json(400, {"error": "cloud not configured"})
                return
            try:
                client = b2mod.B2Client(cfg)
                manifest = client.get_json(CLOUD_MANIFEST_KEY) or {}
                entry = manifest.get(kind) or {}
                if entry.get("key") != key:
                    self._send_json(404, {"error": "cloud version not found"})
                    return
                raw = client.get_object(key)
                if sha256_bytes(raw) != entry.get("sha256"):
                    self._send_json(400, {"error": "cloud version failed verification"})
                    return
                parsed = json.loads(raw.decode("utf-8"))
                if kind == "state" and not valid_state(parsed):
                    self._send_json(400, {"error": "cloud version failed verification"})
                    return
                if kind == "testbook" and not valid_testbook(parsed):
                    self._send_json(400, {"error": "cloud version failed verification"})
                    return
                if kind == "programme" and not (
                        isinstance(parsed, dict) and isinstance(parsed.get("boxes"), list)):
                    self._send_json(400, {"error": "cloud version failed verification"})
                    return
                if kind == "state":
                    atomic_write_json(STATE_FILE, parsed)
                    _invalidate_push_tracking()
                elif kind == "programme":
                    atomic_write_json(CALENDAR_DATA_FILE, parsed)
                    _invalidate_push_tracking()
                else:
                    atomic_write_json(TESTBOOK_FILE, parsed)
                with CLOUD_SYNC._lock:
                    CLOUD_SYNC.last_synced_sha[kind] = None
                    CLOUD_SYNC.conflict = None
                self._send_json(200, {"ok": True, "restored": key})
            except Exception as exc:
                self._send_json(502, {"error": str(exc)})
            return
        if path in ("/api/backup/b2-config", "/api/backup/b2-config/"):
            data = self._read_json()
            cfg = load_b2_config() or {}
            endpoint = str(data.get("endpoint") or cfg.get("endpoint") or
                           (b2mod.DEFAULT_ENDPOINT if b2mod else "")).strip()
            endpoint = re.sub(r"^https?://", "", endpoint).strip("/ ")
            key_id = str(data.get("key_id") or "").strip()
            app_key = str(data.get("application_key") or "").strip()
            bucket = str(data.get("bucket") or cfg.get("bucket") or "konkur-backup").strip()
            enabled = bool(data.get("enabled"))
            # Keep existing secrets when the form sends them back masked/empty.
            if not key_id and cfg.get("key_id"):
                key_id = cfg["key_id"]
            if not app_key and cfg.get("application_key"):
                app_key = cfg["application_key"]
            if enabled and (not key_id or not app_key):
                self._send_json(400, {"error": "key_id و application_key لازم است"})
                return
            new_cfg = {"endpoint": endpoint, "key_id": key_id,
                       "application_key": app_key, "bucket": bucket,
                       "enabled": enabled}
            save_b2_config(new_cfg)
            with CLOUD_SYNC._lock:
                CLOUD_SYNC.conflict = None
                CLOUD_SYNC.last_synced_sha = {"state": None, "testbook": None, "programme": None}
            if enabled:
                CLOUD_SYNC.request(immediate=True)
            self._send_json(200, masked_b2_config(new_cfg))
            return
        if path in ("/api/backup/b2-test", "/api/backup/b2-test/"):
            if not b2mod:
                self._send_json(500, {"error": "cloud module unavailable"})
                return
            cfg = load_b2_config()
            if not cfg or not cfg.get("key_id"):
                self._send_json(400, {"error": "B2 تنظیم نشده است"})
                return
            try:
                client = b2mod.B2Client(cfg)
                ok, err = client.test_connection()
                self._send_json(200, {"ok": ok, "error": err})
            except Exception as exc:
                self._send_json(200, {"ok": False, "error": str(exc)})
            return
        if path in ("/api/backup/b2-clear", "/api/backup/b2-clear/"):
            try:
                if os.path.exists(B2_CONFIG_FILE):
                    os.remove(B2_CONFIG_FILE)
            except Exception:
                pass
            with CLOUD_SYNC._lock:
                CLOUD_SYNC.conflict = None
                CLOUD_SYNC.last_synced_sha = {"state": None, "testbook": None, "programme": None}
            self._send_json(200, {"ok": True})
            return
        if path in ("/api/gemini", "/api/gemini/"):
            key = read_key()
            if not key:
                self._send_json(400, {"error": "کلید API جمینای معتبر نیست"})
                return
            data = self._read_json()
            prompt = str(data.get("prompt") or "").strip()
            if not prompt:
                self._send_json(400, {"error": "متن خالی است"})
                return
            r = _gemini_request(read_model(), prompt, timeout=60)
            if not r["ok"]:
                # Response shapes preserved exactly (the client checks for
                # "معتبر نیست" and "HTTP 404" in the error text).
                if r["kind"] == "auth":
                    self._send_json(400, {"error": "کلید API جمینای معتبر نیست"})
                elif r["kind"] == "network":
                    self._send_json(502, {"error": r["message"]})
                elif r["kind"] == "model" and r["code"] is None:
                    self._send_json(502, {"error": "جمینای پاسخی نداد"})
                elif r["code"]:
                    self._send_json(502, {"error": "خطای سرور جمینای: HTTP " + str(r["code"])})
                else:
                    self._send_json(502, {"error": r["message"]})
                return
            self._send_json(200, {"text": r["text"]})
            return
        if path in ("/api/gemini-test", "/api/gemini-test/"):
            # Live per-model test: one tiny, cheap request (max 8 output
            # tokens) to the named model with the stored key. Never changes
            # the default selected model. Returns latency + classified error.
            data = self._read_json()
            model = str(data.get("model") or "").strip()
            if not valid_model(model):
                self._send_json(400, {"error": "نام مدل معتبر نیست"})
                return
            t0 = time.time()
            r = _gemini_request(model, TEST_PROMPT, timeout=30,
                                max_tokens=TEST_MAX_TOKENS)
            latency_ms = int(round((time.time() - t0) * 1000))
            self._send_json(200, {
                "ok": r["ok"],
                "model": model,
                "latencyMs": latency_ms,
                "errorKind": r["kind"] or "",
                "errorMessage": "" if r["ok"] else r["message"],
            })
            return
        if path in ("/api/update/upload", "/api/update/upload/"):
            # Raw .zip bytes in the body (Content-Type: application/zip).
            try:
                length = int(self.headers.get("Content-Length") or 0)
            except Exception:
                length = 0
            if length <= 0 or length > MAX_UPDATE_ZIP_BYTES:
                self._send_json(400, {"error": "فایل zip خالی است یا خیلی بزرگ است"})
                return
            ensure_data_dir()
            os.makedirs(UPDATE_STAGING_DIR, exist_ok=True)
            staged = os.path.join(
                UPDATE_STAGING_DIR, staging_zip_name("update"))
            try:
                with open(staged, "wb") as f:
                    remaining = length
                    while remaining > 0:
                        chunk = self.rfile.read(min(65536, remaining))
                        if not chunk:
                            break
                        f.write(chunk)
                        remaining -= len(chunk)
            except Exception as exc:
                self._send_json(400, {"error": "دریافت فایل ممکن نشد: " + str(exc)})
                return
            version, backup, err = install_update_zip(staged)
            try:
                os.remove(staged)
            except Exception:
                pass
            if err:
                self._send_json(400, {"error": err})
                return
            self._send_json(200, {"ok": True, "version": version, "backup": backup})
            try:
                self.wfile.flush()
            except Exception:
                pass
            schedule_restart()
            return
        if path in ("/api/update/url", "/api/update/url/"):
            data = self._read_json()
            url = str(data.get("url") or "").strip()
            if not url.startswith("https://"):
                self._send_json(400, {"error": "لینک باید با https:// شروع شود"})
                return
            ensure_data_dir()
            os.makedirs(UPDATE_STAGING_DIR, exist_ok=True)
            staged = os.path.join(
                UPDATE_STAGING_DIR, staging_zip_name("update"))
            try:
                req = urllib.request.Request(url, method="GET",
                                             headers={"User-Agent": "KonkurApp-Updater"})
                # v1.11.24 (QA BUG-012): redirects are re-checked for https.
                with open_https_url(req, timeout=60) as resp:
                    total = 0
                    with open(staged, "wb") as f:
                        while True:
                            chunk = resp.read(65536)
                            if not chunk:
                                break
                            total += len(chunk)
                            if total > MAX_UPDATE_ZIP_BYTES:
                                raise ValueError("فایل zip خیلی بزرگ است")
                            f.write(chunk)
            except ValueError as exc:
                self._send_json(400, {"error": str(exc)})
                return
            except Exception as exc:
                self._send_json(502, {"error": "دانلود فایل ممکن نشد: " + str(exc)})
                return
            version, backup, err = install_update_zip(staged)
            try:
                os.remove(staged)
            except Exception:
                pass
            if err:
                self._send_json(400, {"error": err})
                return
            self._send_json(200, {"ok": True, "version": version, "backup": backup})
            try:
                self.wfile.flush()
            except Exception:
                pass
            schedule_restart()
            return
        if path in ("/api/update/rollback", "/api/update/rollback/"):
            data = self._read_json()
            backups = list_code_backups()
            name = str(data.get("backup") or "").strip()
            if not name:
                if not backups:
                    self._send_json(400, {"error": "نسخه‌ی قبلی برای بازگشت وجود ندارد"})
                    return
                name = backups[0]["name"]
            ok, err = restore_code_backup(name)
            if not ok:
                self._send_json(400, {"error": err})
                return
            restored = None
            for b in backups:
                if b["name"] == name:
                    restored = b
                    break
            self._send_json(200, {"ok": True, "version": {
                "version": (restored or {}).get("version", "dev"),
                "build_date": (restored or {}).get("build_date", "")},
                "backup": restored})
            try:
                self.wfile.flush()
            except Exception:
                pass
            schedule_restart()
            return
        if path in ("/api/update/check", "/api/update/check/"):
            result = run_update_check()
            self._send_json(200 if result.get("ok") else 502, result)
            return
        if path in ("/api/update/auto-config", "/api/update/auto-config/"):
            data = self._read_json()
            url = str(data.get("manifest_url") or "").strip()
            if not url:
                url = DEFAULT_MANIFEST_URL
            if not url.startswith("https://"):
                self._send_json(400, {"error": "آدرس مانیفست باید با https:// شروع شود"})
                return
            cfg = load_update_config()
            cfg["manifest_url"] = url
            cfg["last_check"] = None
            cfg["last_result"] = None
            cfg["last_error"] = None
            save_update_config(cfg)
            self._send_json(200, {"manifest_url": url})
            return
        if path in ("/api/update/install-auto", "/api/update/install-auto/"):
            # The manifest is re-fetched fresh here — the client never
            # supplies the zip URL or hash, so a stale or tampered claim
            # cannot steer the install.
            # v1.11.29 (PI-01): the check-and-set on AUTO_UPDATE_ACTIVE
            # was not atomic — two concurrent requests could both see
            # "not running" during the slow manifest fetch and both start
            # a download thread. The claim is taken atomically via
            # auto_update_try_claim() BEFORE the fetch; every failure
            # path below releases it again (the background thread's
            # finally releases it on the success path).
            if not auto_update_try_claim():
                self._send_json(409, {"error": "یک به‌روزرسانی در حال انجام است"})
                return
            result = run_update_check()
            if not result.get("ok"):
                auto_update_release()
                self._send_json(502, {"error": result.get("error") or "بررسی ممکن نشد"})
                return
            if result.get("blocked_min_version"):
                auto_update_release()
                self._send_json(400, {"error": "این نسخه به نسخه‌ی {} یا جدیدتر نیاز دارد؛ اول به‌صورت دستی به‌روز کن".format(result["blocked_min_version"])})
                return
            if not result.get("update_available"):
                auto_update_release()
                self._send_json(400, {"error": "به‌روز هستید"})
                return
            manifest = {"version": result["version"],
                        "zip_url": result["zip_url"],
                        "sha256": result["sha256"],
                        "notes": result.get("notes") or ""}
            _auto_update_set(phase="downloading", percent=0, downloaded=0,
                             total=None, version=manifest["version"], error=None)
            threading.Thread(target=download_and_install_auto,
                             args=(manifest,), daemon=True).start()
            self._send_json(200, {"ok": True, "started": True,
                                  "version": manifest["version"]})
            return
        if path in ("/api/calendar/config", "/api/calendar/config/"):
            data = self._read_json()
            cfg = load_calendar_config()
            url = str(data.get("ics_url") or "").strip()
            if url and not url.startswith("https://"):
                self._send_json(400, {"error": "آدرس ICS باید با https:// شروع شود"})
                return
            try:
                interval = int(data.get("interval_minutes") or cfg.get("interval_minutes") or 30)
            except Exception:
                interval = 30
            interval = max(5, min(1440, interval))
            enabled = bool(data.get("enabled")) if "enabled" in data else bool(cfg.get("enabled"))
            if url:
                cfg["ics_url"] = url
            elif "ics_url" in data:
                cfg["ics_url"] = ""
            cfg["interval_minutes"] = interval
            cfg["enabled"] = enabled and bool(cfg.get("ics_url"))
            save_calendar_config(cfg)
            self._send_json(200, masked_calendar_config(cfg))
            return
        if path in ("/api/calendar/oauth/credentials", "/api/calendar/oauth/credentials/"):
            data = self._read_json()
            cfg = load_oauth()
            cid = str(data.get("client_id") or "").strip()
            csec = str(data.get("client_secret") or "").strip()
            if cid:
                cfg["client_id"] = cid
            if csec:
                cfg["client_secret"] = csec
            if not (cfg.get("client_id") or "").strip():
                self._send_json(400, {"error": "Client ID خالی است"})
                return
            save_oauth(cfg)
            self._send_json(200, masked_oauth_status())
            return
        if path in ("/api/calendar/oauth/clear-credentials", "/api/calendar/oauth/clear-credentials/"):
            try:
                revoke_google_tokens()
            except Exception:
                pass
            try:
                if os.path.exists(GOOGLE_OAUTH_FILE):
                    os.remove(GOOGLE_OAUTH_FILE)
            except Exception:
                pass
            self._send_json(200, masked_oauth_status())
            return
        if path in ("/api/calendar/oauth/disconnect", "/api/calendar/oauth/disconnect/"):
            revoke_google_tokens()
            self._send_json(200, masked_oauth_status())
            return
        if path in ("/api/calendar/push", "/api/calendar/push/"):
            result = get_sync_provider().push(manual=True)
            self._send_json(200 if result.get("ok") else 502, result)
            return
        if path in ("/api/calendar/sync", "/api/calendar/sync/"):
            result = get_sync_provider().pull("manual")
            self._send_json(200 if result.get("ok") else 502, result)
            return
        if path in ("/api/calendar/import-preview", "/api/calendar/import-preview/"):
            data = self._read_json()
            content = str(data.get("content") or "")
            if not content.strip():
                self._send_json(400, {"error": "فایل خالی است"})
                return
            ok, payload = run_calendar_import(
                content, str(data.get("filename") or ""), "import-preview", apply=False)
            self._send_json(200 if ok else 400, payload)
            return
        if path in ("/api/calendar/import", "/api/calendar/import/"):
            data = self._read_json()
            content = str(data.get("content") or "")
            if not content.strip():
                self._send_json(400, {"error": "فایل خالی است"})
                return
            ok, payload = run_calendar_import(
                content, str(data.get("filename") or ""), "import", apply=True)
            self._send_json(200 if ok else 400, payload)
            return
        if path in ("/api/calendar/clear", "/api/calendar/clear/"):
            try:
                if os.path.exists(CALENDAR_CONFIG_FILE):
                    os.remove(CALENDAR_CONFIG_FILE)
            except Exception:
                pass
            self._send_json(200, {"ok": True})
            return
        self._send_json(404, {"error": "not found"})


# ---------- Credential hardening (audit §5 item 1.10) ----------
def harden_credential_files():
    """Tighten permissions on credential files written before 1.11.17
    (they were 0644): google_oauth.json, gemini_key.txt, b2_config.json.
    Best-effort — a missing file or a failed chmod is not fatal."""
    for path in (GOOGLE_OAUTH_FILE, KEY_FILE, B2_CONFIG_FILE):
        try:
            if os.path.exists(path):
                os.chmod(path, 0o600)
        except OSError:
            pass


if __name__ == "__main__":
    ensure_data_dir()
    migrate_legacy_files()
    harden_credential_files()
    sync_thread = threading.Thread(target=CLOUD_SYNC.run, daemon=True)
    sync_thread.start()
    cal_thread = threading.Thread(target=calendar_sync_loop, daemon=True)
    cal_thread.start()
    push_thread = threading.Thread(target=PUSH_SYNC.run, daemon=True)
    push_thread.start()
    upd_check_thread = threading.Thread(target=update_startup_check, daemon=True)
    upd_check_thread.start()
    # Retry the bind: after a self-update restart the old process may still
    # be releasing the port when the new one starts.
    server = None
    last_exc = None
    for attempt in range(12):
        try:
            server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
            break
        except OSError as exc:
            last_exc = exc
            time.sleep(1)
    if server is None:
        print("Could not bind port {}: {}".format(PORT, last_exc))
        raise SystemExit(1)
    print("Konkur local site running at http://localhost:8765")
    print("Data directory: {}".format(DATA_DIR))
    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
