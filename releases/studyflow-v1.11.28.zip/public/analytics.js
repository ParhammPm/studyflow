// Konkur local site — History & Performance Analysis ("تاریخچه و تحلیل عملکرد").
// READ-ONLY analytics: every number here is computed live from the app's real
// data (allBoxes() + state.done/state.tests + TESTBOOK + state.exams). Nothing
// in this file ever writes to state.json, testbook.json or data.json — the
// archive is a view, never a store. Where a metric has no real data behind it
// (e.g. ACTUAL study hours — boxes only carry scheduled start/end times),
// the UI says so and shows scheduled hours, clearly labelled, instead.
// v1.8.0: actual study time IS recorded now — per-box timer + a manual
// «دقیقه واقعی» entry, stored in state.actualMinutes (seconds) — so the
// charts show actual hours ALONGSIDE scheduled hours, never mixed.
// Charting is dependency-free inline SVG so the app still works offline.
"use strict";

/* ---------- UI prefs only (localStorage; never user data) ---------- */
const AN_KEY = "konkur-analytics-v1";
const AN_DEF = {
  year: 1405, month: "all", week: "all", from: "", to: "",
  subject: "all", type: "all", status: "all", exam: "all", book: "all", chapter: "all",
  cmpA: "aban", cmpB: "azar", cmpAFrom: "", cmpATo: "", cmpBFrom: "", cmpBTo: "",
  archMonth: "2026-11", archPage: 0, archQuery: "",
  heatYear: 1405, heatDay: null, subj: "حسابان", heatMode: "actual"
};
function anLoadPrefs() {
  try {
    const s = JSON.parse(localStorage.getItem(AN_KEY) || "{}");
    // v1.11.5: the old 3-way type filter had a "desc" (descriptive) option;
    // the new activity filter has study/homework/other instead, with no
    // single equivalent — a saved "desc" falls back to "all" (visible).
    if (s.type === "desc") s.type = "all";
    return Object.assign({}, AN_DEF, s);
  } catch (e) { return Object.assign({}, AN_DEF); }
}
let AN = anLoadPrefs();
function anSavePrefs() { try { localStorage.setItem(AN_KEY, JSON.stringify(AN)); } catch (e) {} }

/* ---------- Dates ---------- */
// Programme range (audit §5 item 1.7): state-driven, like app.js —
// programmeStart()/programmeEnd() live in app.js (loaded first).
// Falls back to the original Aban/Azar range if they are unavailable.
function anRangeStart() {
  return (typeof programmeStart === "function") ? programmeStart() : "2026-10-24";
}
function anRangeEnd() {
  return (typeof programmeEnd === "function") ? programmeEnd() : "2026-12-18";
}
function anJalali(iso) {
  const base = new Date(2026, 9, 23).getTime();
  const d = new Date(iso + "T12:00:00").getTime();
  const diff = Math.floor((d - base) / 86400000);
  if (diff < 0 || diff > 59) return null;
  if (diff < 30) return { year: 1405, month: 1, day: diff + 1 };
  return { year: 1405, month: 2, day: diff - 29 };
}
function anMonthKey(iso) {
  const j = anJalali(iso);
  // Out-of-range box (custom date outside Aban/Azar 1405): group by its
  // Gregorian calendar month instead of dropping it from month counts.
  if (!j) return iso.slice(0, 7);
  return j.month === 1 ? "2026-10" : "2026-11";
}
function anMonthSpan(key) {
  if (key === "2026-10") return { from: "2026-10-24", to: "2026-11-21" };
  if (key === "2026-11") return { from: "2026-11-22", to: "2026-12-18" };
  return null;
}
function anMonthLabel(key) {
  if (key === "2026-10") return t("anMonthAban");
  if (key === "2026-11") return t("anMonthAzar");
  return key;
}
function anWeekStart(iso) {
  const d = new Date(iso + "T12:00:00");
  const dow = (d.getDay() + 1) % 7; // Saturday = 0
  d.setDate(d.getDate() - dow);
  return isoOf(d);
}
function anWeekList() {
  // Saturday-start weeks spanning the whole (state-driven) programme
  // range, not just Aban/Azar.
  const out = [];
  let w = anWeekStart(anRangeStart());
  const last = addDays(anRangeEnd(), -6);
  while (w <= last) { out.push(w); w = addDays(w, 7); }
  return out;
}
function anRangeBounds() {
  if (AN.year !== 1405) return null; // no real data in any other year
  if (AN.from && AN.to && AN.from <= AN.to) return { from: AN.from, to: AN.to };
  // A half-filled custom range is open-ended, not ignored.
  if (AN.from) return { from: AN.from, to: anRangeEnd() };
  if (AN.to) return { from: anRangeStart(), to: AN.to };
  if (AN.month === "aban") return anMonthSpan("2026-10");
  if (AN.month === "azar") return anMonthSpan("2026-11");
  if (AN.week && AN.week !== "all") return { from: AN.week, to: addDays(AN.week, 6) };
  return { from: anRangeStart(), to: anRangeEnd() };
}
function anRangeLabel() {
  const r = anRangeBounds();
  if (!r) return String(AN.year);
  return gregToJalali(r.from).text + " — " + gregToJalali(r.to).text;
}

/* ---------- Box status & shared-ID linking ---------- */
// done = ticked; partial = not ticked but some tests completed; undone = rest.
function anBoxStatus(b) {
  if (isDone(b)) return "done";
  const tr = testOf(b);
  if ((tr.completed || 0) > 0) return "partial";
  return "undone";
}
function anBoxMinutes(b) {
  return minutesBetween(b.start || "00:00", b.end || "00:00");
}
// Box type (v1.8.0, kept): a box is a CLASS box when its title contains
// «کلاس» (live/online classes — data.json carries no class marker field, so
// the title rule is the rule; documented in the final report). Class wins over
// test: 41 of the 104 class boxes in the real programme are also is_test
// boxes, and they count as class. Otherwise test = is_test, descriptive
// = the rest. Counts in the real data: class 104, test 140, desc 74.
// v1.11.5: class-ness now comes from the shared boxIsClass() (app.js) — an
// explicit stored type ("class"/"normal") wins over the title rule, and
// the title rule still backfills old boxes without the field. This 3-way
// split is kept for the type donut / type counts; the FILTER uses the
// 5-way anActivityType() below.
function anBoxType(b) {
  if (boxIsClass(b)) return "class";
  return b.is_test ? "test" : "desc";
}
// 5-way activity type for the History/Analytics filter (v1.11.5, shared
// mapping — the History archive and every Analytics view use this one
// function, so the filter means the same thing everywhere):
//   class    — explicit type "class" or title contains «کلاس» (wins)
//   homework — title contains «تکلیف» / «تکالیف»
//   test     — is_test
//   study    — study keywords (مطالعه/مرور/دیدن/تماشا/ویدیو/پیش‌خوانی/
//              درسنامه/جزوه/تمرین/اتمام/خواندن/خلاصه/جبران/امتحان/آفلاین,
//              or the standalone word «درس»)
//   other    — everything else (e.g. the counselling session)
// Real counts: class 104, homework 18, test 125, study 69, other 2 = 318.
function anActivityType(b) {
  return boxActivityType(b);
}
function anActivityTypeLabel(b) {
  const ty = anActivityType(b);
  return ty === "class" ? t("anTypeClass") : ty === "homework" ? t("anTypeHomework") :
    ty === "test" ? t("anTypeTest") : ty === "study" ? t("anTypeStudy") : t("anTypeOther");
}
function anBoxTypeLabel(b) {
  return anActivityTypeLabel(b);
}
// Actual study minutes for a box: finished seconds (timer stops + manual
// entries) in state.actualMinutes, plus the live running/paused timer
// (timerLiveSecondsForBox lives in app.js; guarded for test harnesses).
function anActualMinutes(b) {
  let sec = ((typeof state !== "undefined" && state.actualMinutes) || {})[b.id] || 0;
  if (typeof timerLiveSecondsForBox === "function") sec += timerLiveSecondsForBox(b.id);
  return sec / 60;
}
// Useful study minutes for a box (v1.11.21): recorded independently of
// real time. Returns NULL when nothing was recorded — never 0 — so
// aggregates and efficiency can tell "no data" from "zero useful".
// (No live component: useful is only ever recorded, never ticking.)
function anUsefulMinutes(b) {
  const sec = ((typeof state !== "undefined" && state.usefulMinutes) || {})[b.id];
  if (!(sec > 0)) return null;
  return sec / 60;
}
// Efficiency of one box, or null when either side is missing.
function anBoxEfficiency(b) {
  const u = anUsefulMinutes(b);
  if (u == null) return null;
  const a = anActualMinutes(b);
  if (!(a > 0)) return null;
  return Math.min(100, u / a * 100);
}
// Exam -> book topics, through the same shared-ID chain the app already uses
// for budget progress pills: manual bookLinks first, computed keyword match
// as fallback (budgetTopicLinks). Boxes join through linkedTopicId().
function anExamTopicIds(ex) {
  const ids = new Set();
  (ex.budget || []).forEach(s => (s.chapters || []).forEach(ch => (ch.topics || []).forEach(tp => {
    const manual = topicLinks(tp).map(l => l.sectionId).filter(Boolean);
    if (manual.length) manual.forEach(id => ids.add(id));
    else budgetTopicLinks(s.subject, tp.name).forEach(id => ids.add(id));
  })));
  return ids;
}
function anBookTopicIds(bookId, chapterId) {
  const ids = new Set();
  const book = (TESTBOOK.books || []).find(b => b.id === bookId);
  if (!book) return ids;
  (book.chapters || []).forEach(ch => {
    if (chapterId && chapterId !== "all" && (ch.id || ch.title) !== chapterId) return;
    (ch.topics || []).forEach(tp => ids.add(tp.id));
  });
  return ids;
}
function anApplySharedFilters(list) {
  if (AN.subject !== "all") list = list.filter(b => b.subject === AN.subject);
  // v1.11.5: one 5-way activity filter (all/class/study/test/homework/
  // other) — the same mapping drives the History archive, KPIs, charts,
  // heatmap, subject dashboard, insights and period comparison.
  if (AN.type !== "all") list = list.filter(b => anActivityType(b) === AN.type);
  if (AN.status !== "all") list = list.filter(b => anBoxStatus(b) === AN.status);
  if (AN.exam !== "all") {
    const ex = findExam(AN.exam);
    if (!ex) return [];
    const ids = anExamTopicIds(ex);
    if (!ids.size) return [];
    list = list.filter(b => ids.has(linkedTopicId(b)));
  }
  if (AN.book !== "all") {
    const ids = anBookTopicIds(AN.book, AN.chapter);
    if (!ids.size) return [];
    list = list.filter(b => ids.has(linkedTopicId(b)));
  }
  return list;
}
// Boxes in the selected range + shared filters. Empty when the range has no
// real data (e.g. a year other than 1405).
function anFilteredBoxes() {
  const r = anRangeBounds();
  if (!r) return [];
  return anApplySharedFilters(allBoxes().filter(b => { const sd = boxStudyDay(b) || b.date; return sd >= r.from && sd <= r.to; }));
}
// Archive rows: the archive's own month + shared filters + search text.
// Grouped by STUDY day: a box starting before 03:30 belongs to the
// previous study day (and its Jalali month), not its calendar date.
function anArchiveBoxes() {
  let list = allBoxes().filter(b => anMonthKey(boxStudyDay(b) || b.date) === AN.archMonth);
  list = anApplySharedFilters(list);
  const q = (AN.archQuery || "").trim().toLowerCase();
  if (q) list = list.filter(b => ((b.title || "") + " " + (b.topic || "") + " " + (b.subject || "") + " " + (b.note || "")).toLowerCase().indexOf(q) >= 0);
  return list.sort(compareBoxOrder);
}

/* ---------- Aggregations (all from real boxes) ---------- */
function anAgg(list) {
  // Overdue = study day already ended (after 03:30 the next day) and the
  // box is not done. TODAY is the study day (see app.js study-day rule).
  let planned = 0, done = 0, partial = 0, undone = 0, overdue = 0, minutes = 0;
  let testsDone = 0, correct = 0, wrong = 0, unanswered = 0, actualMinutes = 0;
  let usefulMinutes = 0, usefulBoxes = 0;
  const typeCounts = { test: 0, desc: 0, class: 0 };
  const days = new Set();
  list.forEach(b => {
    planned++; days.add(boxStudyDay(b) || b.date);
    const st = anBoxStatus(b);
    if (st === "done") done++;
    else if (st === "partial") partial++;
    else undone++;
    if ((boxStudyDay(b) || b.date) < TODAY && st !== "done") overdue++;
    minutes += anBoxMinutes(b);
    actualMinutes += anActualMinutes(b);
    // Useful (v1.11.21): only boxes with a recorded useful count —
    // an unrecorded useful contributes nothing and is not a zero.
    const u = anUsefulMinutes(b);
    if (u != null) { usefulMinutes += u; usefulBoxes++; }
    typeCounts[anBoxType(b)]++;
    const tr = testOf(b);
    testsDone += tr.completed || 0;
    correct += tr.correct || 0;
    wrong += Math.max(0, (tr.completed || 0) - (tr.correct || 0));
    if ((b.tests_total || 0) > 0) unanswered += Math.max(0, b.tests_total - (tr.completed || 0));
  });
  return { planned, done, partial, undone, overdue, minutes, actualMinutes, usefulMinutes, usefulBoxes,
    efficiency: (usefulBoxes > 0 && actualMinutes > 0) ? Math.min(100, usefulMinutes / actualMinutes * 100) : null,
    typeCounts,
    testsDone, correct, wrong, unanswered,
    acc: testsDone ? (correct / testsDone) * 100 : null,
    real: planned ? (done / planned) * 100 : null, days: days.size };
}
function anDailySeries(list) {
  const map = {};
  list.forEach(b => {
    const sd = boxStudyDay(b) || b.date;
    const d = map[sd] = map[sd] || { date: sd, planned: 0, done: 0, minutes: 0, actual: 0, useful: 0, usefulBoxes: 0, tests: 0, correct: 0 };
    d.planned++; if (isDone(b)) d.done++;
    d.minutes += anBoxMinutes(b);
    d.actual += anActualMinutes(b);
    const u = anUsefulMinutes(b);
    if (u != null) { d.useful += u; d.usefulBoxes++; }
    const tr = testOf(b); d.tests += tr.completed || 0; d.correct += tr.correct || 0;
  });
  return Object.values(map).sort((a, b) => a.date.localeCompare(b.date));
}
function anWeeklySeries(list) {
  const map = {};
  list.forEach(b => {
    const w = anWeekStart(boxStudyDay(b) || b.date);
    const d = map[w] = map[w] || { date: w, planned: 0, done: 0, minutes: 0, actual: 0, useful: 0, usefulBoxes: 0, tests: 0, correct: 0 };
    d.planned++; if (isDone(b)) d.done++;
    d.minutes += anBoxMinutes(b);
    d.actual += anActualMinutes(b);
    const u = anUsefulMinutes(b);
    if (u != null) { d.useful += u; d.usefulBoxes++; }
    const tr = testOf(b); d.tests += tr.completed || 0; d.correct += tr.correct || 0;
  });
  return Object.values(map).sort((a, b) => a.date.localeCompare(b.date));
}
// Daily chart labels: bare Jalali day numbers repeat (1–30 in Aban AND
// in Azar), so label with the month too.
function anDayLabel(iso) {
  const j = anJalali(iso);
  if (!j) return iso.slice(5);
  return FA(j.day) + " " + t(j.month === 1 ? "monthAban" : "monthAzar");
}
function anPeriodAgg(from, to) {
  let list = allBoxes().filter(b => { const sd = boxStudyDay(b) || b.date; return sd >= from && sd <= to; });
  if (AN.subject !== "all") list = list.filter(b => b.subject === AN.subject);
  if (AN.type !== "all") list = list.filter(b => anActivityType(b) === AN.type);
  return anAgg(list);
}
function anPeriodBounds(key, fromKey, toKey) {
  if (key === "aban") return anMonthSpan("2026-10");
  if (key === "azar") return anMonthSpan("2026-11");
  if (key === "custom" && AN[fromKey] && AN[toKey] && AN[fromKey] <= AN[toKey]) return { from: AN[fromKey], to: AN[toKey] };
  return null;
}

// ---------- Lagging subjects vs programme pace (audit §5 item 2.4) ----------
// expected_done = total_boxes × elapsed%, where elapsed% is the share
// of the programme range (state fields, 1.7) that has passed. A subject
// lags when done/expected < 0.8; lagging subjects rank by shortfall in
// minutes. `done` counts boxes ticked on study days up to TODAY (anAgg
// on the past list — a future box can never be done yet, but an
// explicit tick on one must not flatter the pace either).
function programmeElapsedPct() {
  const start = Date.parse(programmeStart()), end = Date.parse(programmeEnd());
  if (!(end > start)) return 1;
  return Math.min(1, Math.max(0, (Date.parse(TODAY) - start) / (end - start)));
}
function laggingSubjects() {
  const elapsed = programmeElapsedPct();
  const bySubj = {};
  allBoxes().forEach(b => {
    const s = bySubj[b.subject] = bySubj[b.subject] || { total: 0, totalMinutes: 0 };
    s.total++;
    s.totalMinutes += minutesBetween(b.start || "00:00", b.end || "00:00");
  });
  const rows = [];
  Object.keys(bySubj).forEach(subj => {
    const pastList = allBoxes().filter(b => b.subject === subj && (boxStudyDay(b) || b.date) <= TODAY);
    const agg = anAgg(pastList);
    const expected = bySubj[subj].total * elapsed;
    if (expected < 1) return;
    const ratio = agg.done / expected;
    if (ratio >= 0.8) return;
    const doneMinutes = pastList.filter(isDone)
      .reduce((s, b) => s + minutesBetween(b.start || "00:00", b.end || "00:00"), 0);
    rows.push({ subject: subj, total: bySubj[subj].total, done: agg.done,
      expected: Math.round(expected * 10) / 10, ratio,
      shortBoxes: Math.round((expected - agg.done) * 10) / 10,
      shortMinutes: Math.max(0, Math.round(bySubj[subj].totalMinutes * elapsed - doneMinutes)) });
  });
  rows.sort((a, b) => b.shortMinutes - a.shortMinutes);
  return { elapsed, rows };
}
function lagRowsHtml(rows) {
  if (!rows.length) return '<p class="muted">' + t("lagNone") + '</p>';
  return rows.map(r => '<div class="trow topic lag-row"><span><span class="subj-dot ' + colorClass(r.subject) + '"></span>' +
    esc(subjName(r.subject)) + '</span><span>' +
    FA(r.done) + ' / ' + FA(Math.round(r.expected)) + ' ' + t("boxesWord") + ' · ' +
    t("lagShort") + ': ' + FA(Math.round(r.shortBoxes)) + ' ' + t("boxesWord") + ' · ' +
    sumDur(r.shortMinutes) + '</span></div>').join('');
}
function anRenderLagging() {
  const card = document.getElementById("anLagCard");
  if (!card) return;
  const { elapsed, rows } = laggingSubjects();
  card.innerHTML = '<h3>' + esc(t("lagTitle")) + ' <span class="muted">(' +
    t("lagElapsed", { n: FA(Math.round(elapsed * 100)) }) + ')</span></h3>' + lagRowsHtml(rows);
}

// ---------- Weak chapters by accuracy (audit §5 item 2.5) ----------
// Per chapter: accuracy = correct ÷ attempted, only where attempted
// >= 10; ranked by (1 − accuracy) × volume. A chapter that is 100%
// attempted at 40% accuracy surfaces here — the old volume-only
// "lagging topics" list never showed it. Counts come from topicStats,
// which after the item-18 fix no longer double-counts manual + box
// tests for the same section.
function weakChapters(book, limit) {
  const rows = [];
  (book.chapters || []).forEach(ch => {
    let solved = 0, correct = 0;
    const sectionIds = [];
    (ch.topics || []).forEach(tp => {
      const s = topicStats(tp);
      solved += s.solved; correct += s.correct;
      sectionIds.push(tp.id);
    });
    if (solved < 10) return;
    const acc = correct / solved;
    rows.push({ chapter: ch, solved, correct, acc, score: (1 - acc) * solved, sectionIds });
  });
  rows.sort((a, b) => b.score - a.score);
  return rows.slice(0, limit || 3);
}
// The nearest exam's budget topics that this chapter feeds: a budget
// topic feeds the chapter when any of its (computed or manual) links
// points at one of the chapter's sections.
function chapterBudgetTopics(chapter, ex) {
  const ids = new Set();
  (chapter.topics || []).forEach(tp => ids.add(tp.id));
  const names = [];
  if (!ex || !ex.budget) return names;
  ex.budget.forEach(s => (s.chapters || []).forEach(c => (c.topics || []).forEach(tp => {
    const links = budgetTopicLinks(s.subject, tp.name)
      .concat(topicLinks(tp).map(l => l.sectionId).filter(Boolean));
    if (links.some(id => ids.has(id))) names.push(s.subject + " — " + tp.name);
  })));
  return [...new Set(names)];
}

/* ---------- SVG chart helpers (dependency-free) ---------- */
// Visible legend row for SVG charts (audit §5 item 2.10): the values
// used to live only in hover tooltips, which do not exist on a phone.
function anChartLegend(items) {
  return '<div class="an-legend an-chart-legend">' + items.map(it =>
    '<span class="an-leg"><i class="an-swatch ' + it.cls + '"></i>' + esc(it.label) + '</span>').join('') + '</div>';
}
function anSvgOpen(w, h) { return '<svg viewBox="0 0 ' + w + ' ' + h + '" class="an-chart" role="img">'; }
// Grouped bars: planned (grey) vs done (accent) per bucket.
function anBarChart(rows) {
  const W = 560, H = 230, padL = 34, padB = 26, padT = 10;
  if (!rows.length) return '<p class="muted">' + t("anNoData") + '</p>';
  const max = Math.max(1, ...rows.map(r => r.planned));
  const iw = W - padL - 8, ih = H - padT - padB;
  const bw = Math.max(2, Math.min(12, (iw / rows.length) * 0.36));
  const step = Math.max(1, Math.ceil(rows.length / 12));
  let s = anSvgOpen(W, H);
  for (let g = 0; g <= 4; g++) {
    const y = padT + ih * g / 4, v = Math.round(max * (1 - g / 4));
    s += '<line x1="' + padL + '" y1="' + y + '" x2="' + (W - 8) + '" y2="' + y + '" class="an-grid"/>' +
      '<text x="' + (padL - 5) + '" y="' + (y + 4) + '" class="an-axis" text-anchor="end">' + FA(v) + '</text>';
  }
  rows.forEach((r, i) => {
    const x = padL + (i + 0.5) * iw / rows.length;
    const hp = r.planned / max * ih, hd = r.done / max * ih;
    s += '<rect x="' + (x - bw - 1).toFixed(1) + '" y="' + (padT + ih - hp).toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + Math.max(hp, r.planned ? 2 : 0).toFixed(1) + '" class="an-bar-p"><title>' + esc(r.label) + ' — ' + t("anPlanned") + ': ' + FA(r.planned) + '</title></rect>' +
      '<rect x="' + (x + 1).toFixed(1) + '" y="' + (padT + ih - hd).toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + Math.max(hd, r.done ? 2 : 0).toFixed(1) + '" class="an-bar-d"><title>' + esc(r.label) + ' — ' + t("anDone") + ': ' + FA(r.done) + '</title></rect>';
    // (2.10) value label above the done bar, on the labelled bars only.
    if (i % step === 0 && r.done) s += '<text x="' + (x + 1 + bw / 2).toFixed(1) + '" y="' + Math.max(padT + 2, padT + ih - hd - 4).toFixed(1) + '" class="an-val" text-anchor="middle">' + FA(r.done) + '</text>';
    if (i % step === 0) s += '<text x="' + x.toFixed(1) + '" y="' + (H - 8) + '" class="an-axis" text-anchor="middle">' + esc(r.label) + '</text>';
  });
  return anChartLegend([{ cls: "an-bar-p", label: t("anPlanned") }, { cls: "an-bar-d", label: t("anDone") }]) + s + '</svg>';
}
// Paired bars: scheduled (info) vs actual (accent) hours per day — the two
// series are drawn side by side and labelled, never mixed into one bar.
function anPairedBars(rows, opts) {
  // Two series side by side. Default: scheduled vs actual (the
  // original call site). v1.11.21 passes {aKey:"actual", bKey:"useful",
  // ...} for the actual-vs-useful chart — same shape, no new chart
  // code, and the legend always names both series.
  const o = opts || {};
  const aKey = o.aKey || "sched", bKey = o.bKey || "actual";
  const aLbl = o.aLabelKey ? t(o.aLabelKey) : t("anSchedLabel");
  const bLbl = o.bLabelKey ? t(o.bLabelKey) : t("anActualLabel");
  const aCls = o.aCls || "an-bar-h", bCls = o.bCls || "an-bar-d";
  const W = 560, H = 200, padL = 34, padB = 26, padT = 10;
  if (!rows.length) return '<p class="muted">' + t("anNoData") + '</p>';
  const max = Math.max(1, ...rows.map(r => Math.max(r[aKey] || 0, r[bKey] || 0)));
  const iw = W - padL - 8, ih = H - padT - padB;
  const bw = Math.max(2, Math.min(12, (iw / rows.length) * 0.36));
  const step = Math.max(1, Math.ceil(rows.length / 12));
  let s = anSvgOpen(W, H);
  for (let g = 0; g <= 4; g++) {
    const y = padT + ih * g / 4, v = Math.round(max * (1 - g / 4));
    s += '<line x1="' + padL + '" y1="' + y + '" x2="' + (W - 8) + '" y2="' + y + '" class="an-grid"/>' +
      '<text x="' + (padL - 5) + '" y="' + (y + 4) + '" class="an-axis" text-anchor="end">' + FA(v) + '</text>';
  }
  rows.forEach((r, i) => {
    const av = r[aKey] || 0, bv = r[bKey] || 0;
    const x = padL + (i + 0.5) * iw / rows.length;
    const ha = av / max * ih, hb = bv / max * ih;
    s += '<rect x="' + (x - bw - 1).toFixed(1) + '" y="' + (padT + ih - ha).toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + Math.max(ha, av ? 2 : 0).toFixed(1) + '" class="' + aCls + '"><title>' + esc(r.label) + ' — ' + aLbl + ': ' + fmtDuration(Math.round(av * 60)) + '</title></rect>' +
      '<rect x="' + (x + 1).toFixed(1) + '" y="' + (padT + ih - hb).toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + Math.max(hb, bv ? 2 : 0).toFixed(1) + '" class="' + bCls + '"><title>' + esc(r.label) + ' — ' + bLbl + ': ' + fmtDuration(Math.round(bv * 60)) + '</title></rect>';
    // (2.10) value label above the second bar, on the labelled bars only.
    if (i % step === 0 && bv) s += '<text x="' + (x + 1 + bw / 2).toFixed(1) + '" y="' + Math.max(padT + 2, padT + ih - hb - 4).toFixed(1) + '" class="an-val" text-anchor="middle">' + esc(fmtDuration(Math.round(bv * 60))) + '</text>';
    if (i % step === 0) s += '<text x="' + x.toFixed(1) + '" y="' + (H - 8) + '" class="an-axis" text-anchor="middle">' + esc(r.label) + '</text>';
  });
  return anChartLegend([{ cls: aCls, label: aLbl }, { cls: bCls, label: bLbl }]) + s + '</svg>';
}
// Single-value bars (e.g. realisation % or hours per bucket).
function anValueBars(rows, opts) {
  const W = 560, H = 200, padL = 34, padB = 26, padT = 10;
  if (!rows.length) return '<p class="muted">' + t("anNoData") + '</p>';
  const max = Math.max(1, ...(opts && opts.max != null ? [opts.max] : rows.map(r => r.value)));
  const iw = W - padL - 8, ih = H - padT - padB;
  const bw = Math.max(2, Math.min(30, (iw / rows.length) * 0.6));
  const step = Math.max(1, Math.ceil(rows.length / 12));
  let s = anSvgOpen(W, H);
  for (let g = 0; g <= 4; g++) {
    const y = padT + ih * g / 4, v = Math.round(max * (1 - g / 4));
    s += '<line x1="' + padL + '" y1="' + y + '" x2="' + (W - 8) + '" y2="' + y + '" class="an-grid"/>' +
      '<text x="' + (padL - 5) + '" y="' + (y + 4) + '" class="an-axis" text-anchor="end">' + FA(v) + (opts && opts.suffix ? opts.suffix : '') + '</text>';
  }
  rows.forEach((r, i) => {
    const x = padL + (i + 0.5) * iw / rows.length;
    const h = r.value / max * ih;
    s += '<rect x="' + (x - bw / 2).toFixed(1) + '" y="' + (padT + ih - h).toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + Math.max(h, r.value ? 2 : 0).toFixed(1) + '" class="' + (opts && opts.barCls ? opts.barCls : 'an-bar-d') + '"><title>' + esc(r.label) + ': ' + esc(r.title || FA(r.value)) + '</title></rect>';
    // (2.10) value label above the bar, on the labelled bars only.
    if (i % step === 0 && r.value) s += '<text x="' + x.toFixed(1) + '" y="' + Math.max(padT + 2, padT + ih - h - 4).toFixed(1) + '" class="an-val" text-anchor="middle">' + esc(r.title || FA(r.value)) + '</text>';
    if (i % step === 0) s += '<text x="' + x.toFixed(1) + '" y="' + (H - 8) + '" class="an-axis" text-anchor="middle">' + esc(r.label) + '</text>';
  });
  return s + '</svg>';
}
// Two-series line chart: [{label, values:[{label, value}], cls, dashed}]
function anLineChart(series) {
  const W = 560, H = 220, padL = 34, padB = 26, padT = 12;
  const n = Math.max(1, ...series.map(s => s.values.length));
  const allV = series.flatMap(s => s.values.map(v => v.value));
  const max = Math.max(1, ...allV);
  const iw = W - padL - 8, ih = H - padT - padB;
  const xAt = i => padL + (n === 1 ? iw / 2 : i * iw / (n - 1));
  const yAt = v => padT + ih - (v / max) * ih;
  let s = anSvgOpen(W, H);
  for (let g = 0; g <= 4; g++) {
    const y = padT + ih * g / 4, v = Math.round(max * (1 - g / 4));
    s += '<line x1="' + padL + '" y1="' + y + '" x2="' + (W - 8) + '" y2="' + y + '" class="an-grid"/>' +
      '<text x="' + (padL - 5) + '" y="' + (y + 4) + '" class="an-axis" text-anchor="end">' + FA(v) + '</text>';
  }
  series.forEach(sr => {
    if (!sr.values.length) return;
    const pts = sr.values.map((v, i) => xAt(i).toFixed(1) + ',' + yAt(v.value).toFixed(1)).join(' ');
    s += '<polyline points="' + pts + '" class="an-line ' + sr.cls + '"' + (sr.dashed ? ' stroke-dasharray="6 4"' : '') + '/>';
    sr.values.forEach((v, i) => {
      s += '<circle cx="' + xAt(i).toFixed(1) + '" cy="' + yAt(v.value).toFixed(1) + '" r="4" class="an-dot ' + sr.cls + '"><title>' + esc(v.label) + ' — ' + esc(sr.label) + ': ' + FA(v.value) + '</title></circle>';
      // (2.10) value label above each point — readable without hover.
      s += '<text x="' + xAt(i).toFixed(1) + '" y="' + Math.max(padT + 2, yAt(v.value) - 8).toFixed(1) + '" class="an-val" text-anchor="middle">' + FA(v.value) + '</text>';
    });
  });
  const labels = series.length && series[0].values.length ? series[0].values : (series[1] && series[1].values) || [];
  labels.forEach((v, i) => {
    s += '<text x="' + xAt(i).toFixed(1) + '" y="' + (H - 8) + '" class="an-axis" text-anchor="middle">' + esc(v.label) + '</text>';
  });
  // (2.10) visible legend — the line chart had none.
  return anChartLegend(series.filter(sr => sr.values.length).map(sr => ({ cls: sr.cls, label: sr.label }))) + s + '</svg>';
}
// Donut: parts [{label, value, cls}]; totalLabel shown in the middle.
// centerTotal (optional) overrides the centre number: the accuracy
// donut's parts sum to correct+wrong+unanswered, but its centre must
// show TESTS DONE (correct+wrong), not the sum including unanswered.
function anDonut(parts, totalLabel, centerTotal) {
  const total = parts.reduce((s, p) => s + p.value, 0);
  if (!total) return '<p class="muted">' + t("anNoData") + '</p>';
  const R = 70, C = 2 * Math.PI * R;
  let off = 0, circles = "";
  parts.forEach(p => {
    const frac = p.value / total;
    const dash = (frac * C).toFixed(1) + ' ' + (C - frac * C).toFixed(1);
    circles += '<circle cx="90" cy="90" r="' + R + '" class="an-donut-seg ' + p.cls + '" stroke-dasharray="' + dash + '" stroke-dashoffset="' + (-off).toFixed(1) + '"><title>' + esc(p.label) + ': ' + FA(p.value) + '</title></circle>';
    off += frac * C;
  });
  return '<div class="an-donut-wrap"><svg viewBox="0 0 180 180" class="an-donut">' + circles +
    '<text x="90" y="86" class="an-donut-total" text-anchor="middle">' + FA(centerTotal != null ? centerTotal : total) + '</text>' +
    '<text x="90" y="106" class="an-donut-cap" text-anchor="middle">' + esc(totalLabel || '') + '</text></svg>' +
    '<div class="an-legend">' + parts.map(p => '<span class="an-leg"><i class="an-swatch ' + p.cls + '"></i>' + esc(p.label) + ' · ' + FA(p.value) + '</span>').join('') + '</div></div>';
}
// Horizontal bars: rows [{label, pct, text}]
function anHBar(rows) {
  if (!rows.length) return '<p class="muted">' + t("anNoData") + '</p>';
  return rows.map(r =>
    '<div class="an-hbar"><span class="an-hbar-name">' + esc(r.label) + '</span>' +
    '<div class="an-hbar-track"><div class="an-hbar-fill' + (r.cls ? ' ' + esc(r.cls) : '') + '" style="width:' + Math.max(0, Math.min(100, r.pct)) + '%"></div></div>' +
    '<span class="an-hbar-val">' + esc(r.text) + '</span></div>').join('');
}
// Horizontal stacked bars: rows [{label, segs:[{value, cls, label}]}]
function anStackedBar(rows) {
  if (!rows.length) return '<p class="muted">' + t("anNoData") + '</p>';
  return rows.map(r => {
    const total = r.segs.reduce((s, g) => s + g.value, 0);
    const bars = total ? r.segs.filter(g => g.value > 0).map(g =>
      '<div class="an-stack-seg ' + g.cls + '" style="width:' + (g.value / total * 100).toFixed(1) + '%" title="' + esc(g.label) + ': ' + FA(g.value) + '"></div>').join('') : '';
    return '<div class="an-stack-row"><span class="an-hbar-name">' + esc(r.label) + '</span>' +
      '<div class="an-stack-track">' + (bars || '<span class="muted">' + t("anNoData") + '</span>') + '</div>' +
      '<span class="an-hbar-val">' + FA(total) + '</span></div>';
  }).join('') +
  '<div class="an-legend">' + (rows[0] ? rows[0].segs.map(g => '<span class="an-leg"><i class="an-swatch ' + g.cls + '"></i>' + esc(g.label) + '</span>').join('') : '') + '</div>';
}
function anCard(title, body, wide) {
  return '<div class="card an-card' + (wide ? ' an-wide' : '') + '"><h3>' + esc(title) + '</h3>' + body + '</div>';
}

/* ---------- Render: KPIs + charts ---------- */
function anRenderKpis(list, agg) {
  const el = document.getElementById("anKpis");
  if (!el) return;
  if (!list.length) {
    el.innerHTML = '<p class="muted an-nodata">' + t("anNoData") + '</p>';
    return;
  }
  el.innerHTML =
    statCard(t("anKpiPlanned"), FA(agg.planned), FA(agg.days) + " " + t("anKpiDays")) +
    statCard(t("anKpiDone"), FA(agg.done), FA(agg.partial) + " " + t("anPartial") + " · " + FA(agg.undone) + " " + t("anStatusUndone")) +
    statCard(t("anKpiReal"), agg.real == null ? "—" : FA_PCT(agg.real), anRangeLabel()) +
    statCard(t("anKpiHours"), fmtDuration(agg.minutes), t("anKpiHoursNote")) +
    statCard(t("anKpiActual"), fmtDuration(agg.actualMinutes), t("anKpiActualNote")) +
    // v1.11.21: useful hours + efficiency — an unrecorded useful is
    // «ثبت نشده», never 0, and efficiency hides without both values.
    statCard(t("anKpiUseful"), agg.usefulBoxes ? fmtDuration(agg.usefulMinutes) : t("tmUsefulNotRecorded"), t("anKpiUsefulNote")) +
    statCard(t("anKpiEfficiency"), agg.efficiency == null ? "—" : FA_PCT(agg.efficiency), t("anKpiEfficiencyNote")) +
    statCard(t("anKpiTests"), FA(agg.testsDone), FA(agg.correct) + " " + t("anCorrect")) +
    statCard(t("anKpiAcc"), agg.acc == null ? "—" : FA_PCT(agg.acc), FA(agg.wrong) + " " + t("anWrong") + " · " + FA(agg.unanswered) + " " + t("anUnanswered"));
}
function anRenderCharts(list, agg) {
  const wrap = document.getElementById("anCharts");
  if (!wrap) return;
  const daily = anDailySeries(list);
  const weekly = anWeeklySeries(list);
  const r = anRangeBounds();
  // Daily planned vs done (label = Jalali day + month; weekly when range is long).
  const dailyRows = daily.map(d => ({ label: anDayLabel(d.date), planned: d.planned, done: d.done }));
  // Weekly trend.
  const weekRows = weekly.map(w => ({ label: gregToJalali(w.date).text, planned: w.planned, done: w.done }));
  // Realisation % per week.
  const realRows = weekly.map(w => ({ label: gregToJalali(w.date).text, value: w.planned ? Math.round(w.done / w.planned * 100) : 0, title: FA_PCT(w.planned ? w.done / w.planned * 100 : 0) }));
  // Done / partial / undone per month.
  const months = ["2026-10", "2026-11"];
  const countRows = months.filter(m => list.some(b => anMonthKey(boxStudyDay(b) || b.date) === m)).map(m => {
    const mb = list.filter(b => anMonthKey(boxStudyDay(b) || b.date) === m);
    return { label: anMonthLabel(m), segs: [
      { value: mb.filter(b => anBoxStatus(b) === "done").length, cls: "an-c-done", label: t("anDone") },
      { value: mb.filter(b => anBoxStatus(b) === "partial").length, cls: "an-c-partial", label: t("anPartial") },
      { value: mb.filter(b => anBoxStatus(b) === "undone").length, cls: "an-c-undone", label: t("anStatusUndone") }
    ]};
  });
  // Box types: test / descriptive / class (3-way breakdown).
  const nTest = list.filter(b => anBoxType(b) === "test").length;
  const nClass = list.filter(b => anBoxType(b) === "class").length;
  const nDesc = list.length - nTest - nClass;
  // Subject comparison (all subjects in the filtered set, done% + accuracy).
  const bySubj = {};
  list.forEach(b => {
    const s = bySubj[b.subject] = bySubj[b.subject] || { planned: 0, done: 0, tests: 0, correct: 0, actual: 0, useful: 0, usefulBoxes: 0 };
    s.planned++; if (isDone(b)) s.done++;
    const tr = testOf(b); s.tests += tr.completed || 0; s.correct += tr.correct || 0;
    s.actual += anActualMinutes(b);
    const u = anUsefulMinutes(b);
    if (u != null) { s.useful += u; s.usefulBoxes++; }
  });
  const subjRows = Object.keys(bySubj).sort((a, b) => bySubj[b].planned - bySubj[a].planned).map(s => {
    const st = bySubj[s];
    // v1.11.21: per-subject efficiency only with enough data — at
    // least 3 boxes with recorded useful AND at least 60 real minutes
    // (the ≥10-style sufficiency gate); never from 1–2 samples.
    const eff = (st.usefulBoxes >= 3 && st.actual >= 60) ? Math.min(100, st.useful / st.actual * 100) : null;
    return { label: subjName(s),
      pct: st.planned ? st.done / st.planned * 100 : 0,
      text: FA(st.done) + "/" + FA(st.planned) + " · " + (st.tests ? FA_PCT(st.correct / st.tests * 100) : "—") +
        (eff == null ? "" : " · " + t("tmEfficiency") + " " + FA_PCT(eff)) };
  });
  // Accuracy: correct / wrong / unanswered (unanswered only from boxes with a total).
  const accParts = [
    { label: t("anCorrect"), value: agg.correct, cls: "an-c-done" },
    { label: t("anWrong"), value: agg.wrong, cls: "an-c-undone" },
    { label: t("anUnanswered"), value: agg.unanswered, cls: "an-c-partial" }
  ];
  // Scheduled hours per day.
  const hourRows = daily.map(d => ({ label: anDayLabel(d.date), value: Math.round(d.minutes / 60 * 10) / 10, title: fmtDuration(d.minutes) }));
  // Actual vs scheduled hours per day (paired bars, labelled separately).
  const actualRows = daily.map(d => ({ label: anDayLabel(d.date), sched: Math.round(d.minutes / 60 * 10) / 10, actual: Math.round(d.actual / 60 * 10) / 10 }));
  // v1.11.21: actual vs USEFUL hours per day — a 6h-real / 4h-useful
  // day shows the gap instead of hiding it behind one number.
  const usefulRows = daily.map(d => ({ label: anDayLabel(d.date), actual: Math.round(d.actual / 60 * 10) / 10, useful: Math.round(d.useful / 60 * 10) / 10 }));
  // Mock exams: held exams with a result. Taraz (~7411) and accuracy %
  // (~60) live on TWO separate charts: one shared axis squashed the
  // accuracy line flat. An exam held TODAY counts (<=, not <).
  const held = allExams().filter(e => e.result && e.date && e.date <= realTodayIso())
    .sort((a, b) => a.date.localeCompare(b.date));
  let examsBody = "";
  if (held.length >= 2) {
    // A missing taraz is skipped, never plotted as 0.
    const tarazPts = held.filter(e => e.result.taraz != null)
      .map(e => ({ label: gregToJalali(e.date).text, value: e.result.taraz }));
    // Accuracy is ONE definition everywhere (v1.11.16, audit §5 item
    // 1.6): correct ÷ attempted (correct + wrong). The old code divided
    // by the total including unanswered, so the same exam read 17.9%
    // here and 63% in the KPI.
    const accPts = held.map(e => {
      const r0 = e.result, att = (r0.correct || 0) + (r0.wrong || 0);
      return { label: gregToJalali(e.date).text, value: att ? Math.round((r0.correct || 0) / att * 100) : 0 };
    });
    // (2.10) the taraz line stays hidden until 2 results exist, with an
    // honest line saying when it appears — a single result is not a trend.
    examsBody = (tarazPts.length >= 2
        ? anLineChart([{ label: t("anTaraz"), values: tarazPts, cls: "an-ln-taraz" }])
        : '<p class="muted">' + t("anTarazSoon") + '</p>') +
      anLineChart([{ label: t("anExamAcc"), values: accPts, cls: "an-ln-acc" }]) +
      anExamTrendTable(held);
  } else if (held.length === 1) {
    examsBody = '<p class="muted">' + t("anTarazSoon") + '</p>' + anExamTrendTable(held);
  } else {
    examsBody = '<p class="muted">' + t("anNoData") + '</p>';
  }
  // (3.1) per-subject trend across the held exams, when entered.
  examsBody += anExamSubjectTrendTable(held);
  wrap.innerHTML =
    anCard(t("anChDaily"), anBarChart(dailyRows), true) +
    '<div class="an-grid2">' +
    anCard(t("anChWeekly"), anLineChart([
      { label: t("anPlanned"), values: weekRows.map(w => ({ label: w.label, value: w.planned })), cls: "an-ln-planned", dashed: true },
      { label: t("anDone"), values: weekRows.map(w => ({ label: w.label, value: w.done })), cls: "an-ln-done" }
    ])) +
    anCard(t("anChType"), anDonut([
      { label: t("anTypeTest"), value: nTest, cls: "an-c-test" },
      { label: t("anTypeDesc"), value: nDesc, cls: "an-c-desc" },
      { label: t("anTypeClass"), value: nClass, cls: "an-c-class" }
    ], t("anKpiPlanned"))) +
    anCard(t("anChReal"), anValueBars(realRows, { max: 100, suffix: LANG === "fa" ? "٪" : "%", barCls: "an-bar-d" })) +
    anCard(t("anChCounts"), anStackedBar(countRows)) +
    anCard(t("anChSubjects"), anHBar(subjRows)) +
    anCard(t("anChAcc"), anDonut(accParts, t("anKpiTests"), agg.testsDone) + '<p class="muted">' + t("anAccNote") + '</p>') +
    '</div>' +
    anCard(t("anChExams"), examsBody, true) +
    anCard(t("anChHours"), anValueBars(hourRows, { barCls: "an-bar-h" }) + '<p class="muted">' + t("anKpiHoursNote") + '</p>', true) +
    anCard(t("anChActualVsSched"), anPairedBars(actualRows) + '<p class="muted"><i class="an-swatch an-bar-h"></i> ' + t("anSchedLabel") + ' · <i class="an-swatch an-bar-d"></i> ' + t("anActualLabel") + '</p><p class="muted">' + t("anActualVsSchedNote") + '</p>', true) +
    // v1.11.21: actual vs useful, side by side, with the honest note
    // that more real time does not mean more useful time. The card
    // only renders its bars when some useful was recorded at all.
    anCard(t("anChActualVsUseful"), (agg.usefulBoxes
      ? anPairedBars(usefulRows, { aKey: "actual", bKey: "useful", aLabelKey: "anActualLabel", bLabelKey: "anUsefulLabel", aCls: "an-bar-d", bCls: "an-bar-h" })
      : '<p class="muted">' + t("tmUsefulNotRecorded") + '</p>') + '<p class="muted">' + t("anUsefulGapNote") + '</p>', true);
}

/* ---------- v1.11.22: Level 1–2 analysis sections ---------- */
// §0 data audit (recorded in the 1.11.22 report): every number below is
// computed ONLY from what is really stored — planned minutes
// (scheduled), done flags (CURRENT state, no tick date), actual/useful
// seconds (timer + manual entries only; useful exists only since
// 1.11.21 and is mostly unrecorded so far), test totals per box, dated
// testLog deltas (since 1.11.20), and the single held exam result (Maz
// stage 4). NOT computable, and therefore never shown: a true backlog
// trend over time (per-box tick dates are not stored — done is a
// current flag), and any "done ON that day" history. Every new
// indicator carries its own sufficiency gate and hides when it fails.

/* ---------- 2.2 Daily analysis (TODAY, study day) ---------- */
// v1.11.25 (QA BUG-023): actual/useful minutes are attributed by the
// SESSION's execution study day, not the box's study day — a timer run
// past midnight belongs to the day it ran on, not the day the box was
// planned for. Manual entries and old sessions without a start stamp
// fall back to the box's study day. Only anDayDetail uses these
// helpers; anAgg and the charts keep box-day attribution (deliberate
// scope boundary: changing the aggregate would move every trend).
function anSessionStudyDay(s) {
  if (!s || !s.start) return null;
  const d = new Date(s.start);
  if (isNaN(d.getTime())) return null;
  return studyDayOf(d);
}
// Session-attributed actual/useful for ONE study day, in minutes:
//   1) timer-session seconds whose START falls on this study day
//      (any box — a catch-up session run today counts today);
//   2) the remainder of each of THIS day's boxes (box total minus what
//      its sessions account for: manual entries + undated sessions +
//      useful recorded outside any session) stays on the box day.
// Returns { actual, useful, usefulBoxes }.
function anDayActualUseful(day) {
  let actualSec = 0, usefulSec = 0;
  const usefulBoxes = new Set();
  const byId = {};
  allBoxes().forEach(b => { byId[b.id] = b; });
  const sessByBox = {};
  (state.timerSessions || []).forEach(s => {
    if (!s || s.source !== "timer") return;
    const t = sessByBox[s.boxId] || (sessByBox[s.boxId] = { sec: 0, use: 0 });
    t.sec += (s.seconds || 0);
    t.use += (s.useful || 0);
    let sd = anSessionStudyDay(s);
    if (sd === null) {
      // No start stamp (old session): fall back to the box's study day.
      const b = byId[s.boxId];
      sd = b ? (boxStudyDay(b) || b.date) : null;
    }
    if (sd === day) {
      actualSec += (s.seconds || 0);
      if ((s.useful || 0) > 0) { usefulSec += s.useful; usefulBoxes.add(s.boxId); }
    }
  });
  allBoxes().forEach(b => {
    if ((boxStudyDay(b) || b.date) !== day) return;
    const t = sessByBox[b.id] || { sec: 0, use: 0 };
    // Box total minus session-accounted seconds = manual entries (+ the
    // live running timer, which has no session yet). Never negative.
    actualSec += Math.max(0, anActualMinutes(b) * 60 - t.sec);
    const u = anUsefulMinutes(b);
    if (u != null) {
      const remUseful = Math.max(0, u * 60 - t.use);
      usefulSec += remUseful;
      if (remUseful > 0) usefulBoxes.add(b.id);
    }
  });
  return { actual: actualSec / 60, useful: usefulSec / 60,
           usefulBoxes: usefulBoxes.size };
}
function anDayDetail(iso) {
  const list = allBoxes().filter(b => (boxStudyDay(b) || b.date) === iso);
  let planned = 0, done = 0, cls = 0, gen = 0, test = 0, study = 0, actual = 0, useful = 0, usefulBoxes = 0, tests = 0, correct = 0;
  list.forEach(b => {
    const mins = anBoxMinutes(b); planned += mins;
    if (isDone(b)) done++;
    const ty = boxActivityType(b);
    if (ty === "class") cls += mins;
    else if (ty === "test") test += mins;
    else if (GENERAL_SUBJECTS.has(b.subject)) gen += mins;
    // v1.11.24 (QA BUG-015): the "study" bucket was missing — plain
    // study boxes (not class/test/general) fell through every branch,
    // so their minutes were invisible in the daily analysis
    // (planned 615 vs cls 270 + gen 90 + test 90 = 450). Mirrors
    // daySummary's else branch.
    else study += mins;
    const tr = testOf(b); tests += tr.completed || 0; correct += tr.correct || 0;
  });
  // v1.11.25 (QA BUG-023): actual/useful are attributed by session
  // execution day (anDayActualUseful), not by box day — a session run
  // past midnight counts on the day it ran, and a catch-up session run
  // today counts today even when its box belongs to another day.
  const au = anDayActualUseful(iso);
  actual = au.actual; useful = au.useful; usefulBoxes = au.usefulBoxes;
  // Timer sessions of this day that carry a real clock span (1.11.21+).
  // v1.11.25 (QA BUG-023): listed by session START study day, not by
  // the box's day — the spans shown are the ones the actual/useful
  // totals above count. Undated sessions fall back to their box's day.
  const sessions = [];
  const byId = {};
  allBoxes().forEach(b => { byId[b.id] = b; });
  (state.timerSessions || []).forEach(s => {
    if (!s || s.source !== "timer" || !s.startHm || !s.endHm) return;
    const b = byId[s.boxId];
    if (!b) return;
    let sd = anSessionStudyDay(s);
    if (sd === null) sd = boxStudyDay(b) || b.date;
    if (sd === iso) sessions.push({ box: b, startHm: s.startHm, endHm: s.endHm, seconds: s.seconds || 0, useful: s.useful || null });
  });
  const overdueAll = allBoxes().filter(b => !isDone(b) && (boxStudyDay(b) || b.date) < TODAY).length;
  const eff = (usefulBoxes > 0 && actual > 0) ? Math.min(100, useful / actual * 100) : null;
  return { iso, boxes: list.length, done, undone: list.length - done, planned, cls, gen, test, study,
    actual, useful, usefulBoxes, eff, tests, correct, sessions,
    completion: list.length ? done / list.length * 100 : null,
    diff: actual - planned, overdueAll };
}
function anRenderDaily() {
  const card = document.getElementById("anDailyCard");
  if (!card) return;
  const d = anDayDetail(TODAY);
  const row = (label, val) => '<div class="day-sum-row"><span>' + label + '</span><b>' + val + '</b></div>';
  let verdict = "", vcls = "";
  if (d.boxes > 0) {
    if (d.usefulBoxes === 0) { verdict = t("anDailyVerdictNoUseful"); vcls = "st-pend"; }
    else if (d.eff != null && d.eff >= 85) { verdict = t("anDailyVerdictHigh"); vcls = "st-ok"; }
    else if (d.eff != null && d.eff < 70) { verdict = t("anDailyVerdictLow"); vcls = "st-warn"; }
  }
  let html = '<h3>' + esc(t("anDailyTitle")) + ' · ' + esc(anJalaliText(TODAY)) + '</h3>';
  if (!d.boxes) { html += '<p class="muted">' + t("sumNoProgram") + '</p>'; }
  else {
    html += '<div class="stat-grid">' +
      statCard(t("sumBoxes"), FA(d.done) + "/" + FA(d.boxes), d.completion == null ? "—" : FA_PCT(d.completion)) +
      statCard(t("anKpiHours"), fmtDuration(d.planned), t("anKpiHoursNote")) +
      statCard(t("anKpiActual"), d.actual > 0 ? fmtDuration(d.actual) : "—", t("anKpiActualNote")) +
      statCard(t("anKpiUseful"), d.usefulBoxes ? fmtDuration(d.useful) : t("tmUsefulNotRecorded"), t("anKpiUsefulNote")) +
      statCard(t("anKpiEfficiency"), d.eff == null ? "—" : FA_PCT(d.eff), t("anKpiEfficiencyNote")) +
      statCard(t("anKpiTests"), FA(d.tests), FA(d.correct) + " " + t("anCorrect")) +
      '</div><div class="day-sum-rows">' +
      row(t("sumClass"), fmtDuration(d.cls)) +
      row(t("sumGeneral"), fmtDuration(d.gen)) +
      row(t("sumTest"), fmtDuration(d.test)) +
      row(t("sumStudy"), fmtDuration(d.study)) +
      row(t("anDailyUndone"), FA(d.undone)) +
      row(t("anDailyOverdue"), FA(d.overdueAll)) +
      row(t("anDailyPlanVsActual"), (d.diff >= 0 ? "+" : "−") + fmtDuration(Math.abs(d.diff))) +
      '</div>';
    if (d.sessions.length) {
      html += '<h3>' + esc(t("anKpiActual")) + '</h3>' + d.sessions.slice(0, 5).map(s =>
        '<div class="day-sum-row"><span>' + esc(s.startHm) + ' → ' + esc(s.endHm) + ' · ' + esc(s.box.title) + '</span><b>' +
        fmtDuration(Math.round(s.seconds / 60)) + (s.useful ? ' · ' + t("anUsefulLabel") + ' ' + fmtDuration(Math.round(s.useful / 60)) : '') + '</b></div>').join('');
    }
    if (verdict) html += '<p><span class="st-pill ' + vcls + '">' + esc(verdict) + '</span></p>';
  }
  card.innerHTML = html;
}

/* ---------- 2.5 Planned vs Actual vs Useful (selected range) ---------- */
// Three bars per day (planned grey, actual accent, useful info) over the
// last 14 days of the range. When nothing useful was recorded anywhere
// in the range, the chart falls back to the planned-vs-actual pair and
// says so — a 0-height useful bar must never read as "0 useful studied".
function anTripleBars(rows) {
  const W = 560, H = 200, padL = 34, padB = 26, padT = 10;
  if (!rows.length) return '<p class="muted">' + t("anNoData") + '</p>';
  const max = Math.max(1, ...rows.map(r => Math.max(r.planned, r.actual, r.useful)));
  const iw = W - padL - 8, ih = H - padT - padB;
  const bw = Math.max(2, Math.min(9, (iw / rows.length) * 0.24));
  const step = Math.max(1, Math.ceil(rows.length / 12));
  let s = anSvgOpen(W, H);
  for (let g = 0; g <= 4; g++) {
    const y = padT + ih * g / 4, v = Math.round(max * (1 - g / 4));
    s += '<line x1="' + padL + '" y1="' + y + '" x2="' + (W - 8) + '" y2="' + y + '" class="an-grid"/>' +
      '<text x="' + (padL - 5) + '" y="' + (y + 4) + '" class="an-axis" text-anchor="end">' + FA(v) + '</text>';
  }
  rows.forEach((r, i) => {
    const x = padL + (i + 0.5) * iw / rows.length;
    const hp = r.planned / max * ih, ha = r.actual / max * ih, hu = r.useful / max * ih;
    const bar = (off, h, v, cls, lbl) => '<rect x="' + (x + off).toFixed(1) + '" y="' + (padT + ih - h).toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + Math.max(h, v ? 2 : 0).toFixed(1) + '" class="' + cls + '"><title>' + esc(r.label) + ' — ' + lbl + ': ' + fmtDuration(Math.round(v * 60)) + '</title></rect>';
    s += bar(-bw - 2, hp, r.planned, "an-bar-p", t("anPlanned")) +
         bar(0, ha, r.actual, "an-bar-d", t("anActualLabel")) +
         bar(bw + 2, hu, r.useful, "an-bar-h", t("anUsefulLabel"));
    if (i % step === 0) s += '<text x="' + x.toFixed(1) + '" y="' + (H - 8) + '" class="an-axis" text-anchor="middle">' + esc(r.label) + '</text>';
  });
  return anChartLegend([
    { cls: "an-bar-p", label: t("anPlanned") },
    { cls: "an-bar-d", label: t("anActualLabel") },
    { cls: "an-bar-h", label: t("anUsefulLabel") }]) + s + '</svg>';
}
function anRenderPvu() {
  const card = document.getElementById("anPvuCard");
  if (!card) return;
  const list = anFilteredBoxes();
  const agg = anAgg(list);
  const daily = anDailySeries(list).slice(-14);
  const rows = daily.map(d => ({ label: anDayLabel(d.date), planned: Math.round(d.minutes / 60 * 10) / 10, actual: Math.round(d.actual / 60 * 10) / 10, useful: Math.round(d.useful / 60 * 10) / 10 }));
  const row = (label, val) => '<div class="day-sum-row"><span>' + label + '</span><b>' + val + '</b></div>';
  let html = '<h3>' + esc(t("anPvuTitle")) + ' · ' + esc(anRangeLabel()) + '</h3>' +
    '<div class="day-sum-rows">' +
    row(t("anKpiHours"), fmtDuration(agg.minutes)) +
    row(t("anKpiActual"), fmtDuration(agg.actualMinutes)) +
    row(t("anKpiUseful"), agg.usefulBoxes ? fmtDuration(agg.usefulMinutes) : t("tmUsefulNotRecorded")) +
    row(t("anKpiEfficiency"), agg.efficiency == null ? "—" : FA_PCT(agg.efficiency)) +
    '</div>';
  if (!list.length) html += '<p class="muted">' + t("anNoData") + '</p>';
  else if (!agg.usefulBoxes) html += anPairedBars(daily.map(d => ({ label: anDayLabel(d.date), sched: Math.round(d.minutes / 60 * 10) / 10, actual: Math.round(d.actual / 60 * 10) / 10 }))) + '<p class="muted">' + t("tmUsefulNotRecorded") + '</p>';
  else html += anTripleBars(rows);
  html += '<p class="muted">' + t("anPvuNote") + '</p>';
  card.innerHTML = html;
}

/* ---------- 2.6 Study-quality indicators (gated, real data only) ---------- */
// Midpoint of the ELAPSED part of the current filter range — the split
// for first/second-half comparisons. Comparing full-range halves would
// count future (not-yet-due) boxes in the second half and make every
// completion trend look like a collapse; elapsed-only halves compare
// like with like. Null when nothing has elapsed yet.
function anElapsedMidIso() {
  const r = anRangeBounds();
  if (!r) return null;
  const to = TODAY < r.to ? TODAY : r.to;
  if (to < r.from) return null;
  const days = Math.round((Date.parse(to) - Date.parse(r.from)) / 86400000);
  return addDays(r.from, Math.floor(days / 2));
}
function anRenderQuality() {
  const card = document.getElementById("anQualityCard");
  if (!card) return;
  const list = anFilteredBoxes();
  const agg = anAgg(list);
  const items = [];
  // Completion rate — needs at least 5 planned boxes in the range.
  if (agg.planned >= 5 && agg.real != null) {
    items.push({ label: t("anQCompletion"), val: FA_PCT(agg.real),
      note: FA(agg.done) + "/" + FA(agg.planned) + " " + t("boxesWord"),
      cls: agg.real >= 80 ? "st-ok" : agg.real >= 50 ? "st-warn" : "st-err" });
  }
  // Efficiency — the 1.11.21 gate: ≥3 boxes with recorded useful AND ≥60 real minutes.
  // v1.11.24 (QA BUG-014): the gate used to exist only in the comment —
  // agg.efficiency was non-null with a single useful box, so a 100%
  // reading from one box was shown as a quality verdict. The gate is
  // now enforced here, mirroring the per-subject gate (≥3 useful
  // boxes, ≥60 real minutes).
  if (agg.efficiency != null && agg.usefulBoxes >= 3 && agg.actualMinutes >= 60) {
    items.push({ label: t("anQEfficiency"), val: FA_PCT(agg.efficiency),
      note: t("anUsefulLabel") + " " + fmtDuration(agg.usefulMinutes) + " / " + t("anActualLabel") + " " + fmtDuration(agg.actualMinutes),
      cls: agg.efficiency >= 85 ? "st-ok" : agg.efficiency >= 70 ? "st-warn" : "st-err" });
  }
  // Planned vs actual deviation — needs ≥60 recorded real minutes.
  if (agg.actualMinutes >= 60) {
    const dev = agg.actualMinutes - agg.minutes;
    items.push({ label: t("anQDeviation"), val: (dev >= 0 ? "+" : "−") + fmtDuration(Math.abs(dev)),
      note: t("anKpiActual") + " " + fmtDuration(agg.actualMinutes) + " · " + t("anKpiHours") + " " + fmtDuration(agg.minutes),
      cls: "st-info" });
  }
  // Backlog level — always computable: undone past boxes (current state).
  const overdueList = allBoxes().filter(b => !isDone(b) && (boxStudyDay(b) || b.date) < TODAY);
  if (overdueList.length) {
    const mins = overdueList.reduce((s, b) => s + anBoxMinutes(b), 0);
    const oldest = overdueList.map(b => boxStudyDay(b) || b.date).sort()[0];
    items.push({ label: t("anQBacklog"), val: FA(overdueList.length) + " " + t("boxesWord"),
      note: fmtDuration(mins) + (oldest ? " · " + t("anQOldest") + ": " + gregToJalali(oldest).text : ""),
      cls: "st-warn" });
  } else if (agg.planned >= 5) {
    items.push({ label: t("anQBacklog"), val: FA(0) + " " + t("boxesWord"), note: "", cls: "st-ok" });
  }
  const mid = anElapsedMidIso();
  if (mid) {
    const first = anAgg(list.filter(b => (boxStudyDay(b) || b.date) < mid));
    const second = anAgg(list.filter(b => { const sd = boxStudyDay(b) || b.date; return sd >= mid && sd <= TODAY; }));
    // Plan-execution trend — each half needs ≥5 planned boxes.
    if (first.planned >= 5 && second.planned >= 5 && first.real != null && second.real != null) {
      const d = second.real - first.real;
      items.push({ label: t("anQExecTrend"), val: (d >= 0 ? "+" : "") + FA_PCT(d),
        note: FA_PCT(first.real) + " → " + FA_PCT(second.real),
        cls: d >= 5 ? "st-ok" : d <= -5 ? "st-err" : "st-info" });
    }
    // Useful-time trend — each half needs ≥3 boxes with recorded useful.
    if (first.usefulBoxes >= 3 && second.usefulBoxes >= 3) {
      const d = second.usefulMinutes - first.usefulMinutes;
      items.push({ label: t("anQUsefulTrend"), val: (d >= 0 ? "+" : "−") + fmtDuration(Math.abs(d)),
        note: fmtDuration(first.usefulMinutes) + " → " + fmtDuration(second.usefulMinutes) + " · " + t(d >= 30 ? "anTrendRising" : d <= -30 ? "anTrendFalling" : "anTrendFlat"),
        cls: d >= 30 ? "st-ok" : d <= -30 ? "st-err" : "st-info" });
    }
  }
  // Subject balance — needs ≥2 subjects with ≥5 boxes each in the range.
  const bySubjMin = {};
  list.forEach(b => { bySubjMin[b.subject] = bySubjMin[b.subject] || { n: 0, mins: 0 }; bySubjMin[b.subject].n++; bySubjMin[b.subject].mins += anBoxMinutes(b); });
  const subjRows = Object.keys(bySubjMin).filter(s => bySubjMin[s].n >= 5)
    .sort((a, b) => bySubjMin[b].mins - bySubjMin[a].mins);
  if (subjRows.length >= 2 && agg.minutes > 0) {
    const top = subjRows[0], low = subjRows[subjRows.length - 1];
    items.push({ label: t("anQBalance"), val: subjName(top) + " " + FA_PCT(bySubjMin[top].mins / agg.minutes * 100),
      note: subjName(low) + " " + FA_PCT(bySubjMin[low].mins / agg.minutes * 100),
      cls: "st-info" });
  }
  // Study/test balance — needs ≥5 boxes; shares of study+homework vs test minutes.
  if (agg.planned >= 5) {
    let studyMin = 0, testMin = 0;
    list.forEach(b => {
      const ty = anActivityType(b);
      if (ty === "test") testMin += anBoxMinutes(b);
      else if (ty === "study" || ty === "homework") studyMin += anBoxMinutes(b);
    });
    if (studyMin + testMin > 0) {
      items.push({ label: t("anQStudyTest"), val: FA_PCT(testMin / (studyMin + testMin) * 100) + " " + t("anTypeTest"),
        note: t("anTypeTest") + " " + fmtDuration(testMin) + " · " + t("anTypeStudy") + " " + fmtDuration(studyMin),
        cls: "st-info" });
    }
  }
  let html = '<h3>' + esc(t("anQualityTitle")) + '</h3>';
  if (!items.length) html += '<p class="muted">' + t("anQNotEnough") + '</p>';
  else html += '<div class="an-q-grid">' + items.map(it =>
    '<div class="an-q-item"><div class="an-q-label">' + esc(it.label) + '</div>' +
    '<div class="an-q-val ' + it.cls + '">' + esc(it.val) + '</div>' +
    (it.note ? '<div class="an-q-note">' + esc(it.note) + '</div>' : '') + '</div>').join('') + '</div>';
  card.innerHTML = html;
}

/* ---------- 2.3 Weekly analysis (Saturday-start week of TODAY) ---------- */
function anRenderWeek() {
  const card = document.getElementById("anWeekCard");
  if (!card) return;
  const ws = anWeekStart(TODAY), we = addDays(ws, 6);
  const weekBoxes = allBoxes().filter(b => { const sd = boxStudyDay(b) || b.date; return sd >= ws && sd <= we; });
  const agg = anAgg(weekBoxes);
  const dayRows = [];
  for (let i = 0; i < 7; i++) {
    const d = addDays(ws, i);
    const a = anAgg(weekBoxes.filter(b => (boxStudyDay(b) || b.date) === d));
    dayRows.push({ date: d, planned: a.planned, done: a.done, actual: a.actualMinutes, useful: a.usefulMinutes, usefulBoxes: a.usefulBoxes, undone: a.undone });
  }
  const withBoxes = dayRows.filter(d => d.planned > 0);
  const best = withBoxes.length ? withBoxes.slice().sort((a, b) => (b.done / b.planned) - (a.done / a.planned))[0] : null;
  const mostReal = dayRows.filter(d => d.actual > 0).sort((a, b) => b.actual - a.actual)[0] || null;
  const mostUseful = dayRows.filter(d => d.useful > 0).sort((a, b) => b.useful - a.useful)[0] || null;
  const mostBacklog = dayRows.filter(d => d.date < TODAY && d.undone > 0).sort((a, b) => b.undone - a.undone)[0] || null;
  const overdueWeek = dayRows.filter(d => d.date < TODAY).reduce((s, d) => s + d.undone, 0);
  // Improved / worsened: first 3 days vs last 4 days of the week
  // (completion); each side needs ≥2 days with boxes and ≥3 boxes.
  // v1.11.26 (QA BUG-035): the second side used to be slice(4, 7),
  // which silently dropped Tuesday from the verdict entirely.
  const sideAgg = (rows) => {
    const p = rows.reduce((s, d) => s + d.planned, 0), dn = rows.reduce((s, d) => s + d.done, 0);
    return { p, dn, days: rows.filter(d => d.planned > 0).length, rate: p ? dn / p * 100 : null };
  };
  const fA = sideAgg(dayRows.slice(0, 3)), lA = sideAgg(dayRows.slice(3, 7));
  let weekVerdict = null;
  if (fA.rate != null && lA.rate != null && fA.days >= 2 && lA.days >= 2 && fA.p >= 3 && lA.p >= 3) {
    const dd = lA.rate - fA.rate;
    weekVerdict = { key: dd >= 5 ? "anWeekImproved" : dd <= -5 ? "anWeekWorsened" : "anWeekStable", cls: dd >= 5 ? "st-ok" : dd <= -5 ? "st-err" : "st-info" };
  }
  const bySubj = {};
  weekBoxes.forEach(b => { const s = bySubj[b.subject] = bySubj[b.subject] || { planned: 0, done: 0, actual: 0 }; s.planned++; if (isDone(b)) s.done++; s.actual += anActualMinutes(b); });
  const topSubj = Object.keys(bySubj).sort((a, b) => bySubj[b].actual - bySubj[a].actual).slice(0, 3);
  const row = (label, val) => '<div class="day-sum-row"><span>' + label + '</span><b>' + val + '</b></div>';
  let html = '<h3>' + esc(t("anWeekTitle")) + ' · ' + esc(anJalaliText(ws) + " — " + anJalaliText(we)) + '</h3>';
  if (!weekBoxes.length) { html += '<p class="muted">' + t("wrEmpty") + '</p>'; }
  else {
    html += '<div class="stat-grid">' +
      statCard(t("anKpiHours"), fmtDuration(agg.minutes), t("anKpiHoursNote")) +
      statCard(t("anKpiActual"), fmtDuration(agg.actualMinutes), t("anKpiActualNote")) +
      statCard(t("anKpiUseful"), agg.usefulBoxes ? fmtDuration(agg.usefulMinutes) : t("tmUsefulNotRecorded"), t("anKpiUsefulNote")) +
      statCard(t("anKpiEfficiency"), agg.efficiency == null ? "—" : FA_PCT(agg.efficiency), t("anKpiEfficiencyNote")) +
      statCard(t("anKpiDone"), FA(agg.done) + "/" + FA(agg.planned), agg.real == null ? "—" : FA_PCT(agg.real)) +
      statCard(t("anKpiTests"), FA(agg.testsDone), FA(agg.correct) + " " + t("anCorrect")) +
      '</div><div class="day-sum-rows">' +
      row(t("anWeekBest"), best ? gregToJalali(best.date).text + " · " + FA_PCT(best.done / best.planned * 100) : "—") +
      row(t("anWeekMostReal"), mostReal ? gregToJalali(mostReal.date).text + " · " + fmtDuration(mostReal.actual) : "—") +
      row(t("anWeekMostUseful"), mostUseful ? gregToJalali(mostUseful.date).text + " · " + fmtDuration(mostUseful.useful) : "—") +
      row(t("anWeekMostBacklog"), mostBacklog ? gregToJalali(mostBacklog.date).text + " · " + FA(mostBacklog.undone) + " " + t("boxesWord") : "—") +
      row(t("anQBacklog"), FA(overdueWeek) + " " + t("boxesWord")) +
      '</div>';
    html += '<table><tr><th>' + t("anThDate") + '</th><th>' + t("anKpiPlanned") + '</th><th>' + t("anKpiReal") + '</th><th>' + t("anKpiActual") + '</th><th>' + t("anKpiUseful") + '</th></tr>' +
      dayRows.map(d => '<tr><td>' + esc(gregToJalali(d.date).text) + '</td><td>' + FA(d.done) + "/" + FA(d.planned) + '</td><td>' + (d.planned ? FA_PCT(d.done / d.planned * 100) : "—") + '</td><td>' + (d.actual > 0 ? fmtDuration(d.actual) : "—") + '</td><td>' + (d.usefulBoxes ? fmtDuration(d.useful) : "—") + '</td></tr>').join('') + '</table>';
    if (topSubj.length) html += '<p class="muted">' + topSubj.map(s => esc(subjName(s)) + " · " + fmtDuration(bySubj[s].actual) + " · " + FA(bySubj[s].done) + "/" + FA(bySubj[s].planned)).join(" · ") + '</p>';
    if (weekVerdict) html += '<p><span class="st-pill ' + weekVerdict.cls + '">' + esc(t(weekVerdict.key)) + '</span></p>';
  }
  card.innerHTML = html;
}

/* ---------- 2.7 Trends: last 7 / 14 / 30 days ---------- */
function anTrendWord(d, threshold) {
  if (d == null) return null;
  return d >= threshold ? "anTrendRising" : d <= -threshold ? "anTrendFalling" : "anTrendFlat";
}
function anTrendWindow(days) {
  const to = TODAY, from = addDays(TODAY, -(days - 1));
  const list = anFilteredBoxes().filter(b => { const sd = boxStudyDay(b) || b.date; return sd >= from && sd <= to; });
  const daily = anDailySeries(list);
  const half = Math.floor(days / 2);
  const cut = addDays(from, half);
  const f = anAgg(list.filter(b => (boxStudyDay(b) || b.date) < cut));
  const s = anAgg(list.filter(b => (boxStudyDay(b) || b.date) >= cut));
  return { days, from, to, daysWithBoxes: daily.length, daily,
    completion: (f.planned >= 5 && s.planned >= 5 && f.real != null && s.real != null) ? { d: s.real - f.real, from: f.real, to: s.real } : null,
    actual: (f.actualMinutes > 0 && s.actualMinutes > 0) ? { d: s.actualMinutes - f.actualMinutes, from: f.actualMinutes, to: s.actualMinutes } : null,
    useful: (f.usefulBoxes >= 3 && s.usefulBoxes >= 3) ? { d: s.usefulMinutes - f.usefulMinutes, from: f.usefulMinutes, to: s.usefulMinutes } : null };
}
function anRenderTrends() {
  const card = document.getElementById("anTrendCard");
  if (!card) return;
  const windows = [7, 14, 30].map(anTrendWindow);
  let html = "";
  windows.forEach(w => {
    html += '<h3>' + esc(t("anTrend" + w.days)) + '</h3>';
    if (w.daysWithBoxes < 3) { html += '<p class="muted">' + t("anQNotEnough") + '</p>'; return; }
    const pctRow = (label, tr) => {
      if (!tr) return '<div class="day-sum-row"><span>' + label + '</span><b>—</b></div>';
      const word = anTrendWord(tr.d, 5);
      return '<div class="day-sum-row"><span>' + label + '</span><b>' + FA_PCT(tr.from) + ' → ' + FA_PCT(tr.to) + ' · ' + t(word) + '</b></div>';
    };
    const minRow = (label, tr) => {
      if (!tr) return '<div class="day-sum-row"><span>' + label + '</span><b>—</b></div>';
      const word = anTrendWord(tr.d, 30);
      return '<div class="day-sum-row"><span>' + label + '</span><b>' + fmtDuration(tr.from) + ' → ' + fmtDuration(tr.to) + ' · ' + t(word) + '</b></div>';
    };
    html += '<div class="day-sum-rows">' +
      pctRow(t("anQCompletion"), w.completion) +
      minRow(t("anKpiActual"), w.actual) +
      minRow(t("anQUsefulTrend"), w.useful) +
      '</div>';
  });
  // 30-day completion line: days WITH boxes only (a day with no boxes
  // is skipped, never plotted as 0); needs ≥5 such days.
  const w30 = windows[2];
  const compPts = w30.daily.filter(d => d.planned > 0).map(d => ({ label: anDayLabel(d.date), value: Math.round(d.done / d.planned * 100) }));
  if (compPts.length >= 5) html += anLineChart([{ label: t("anQCompletion"), values: compPts, cls: "an-ln-done" }]);
  card.innerHTML = html;
}

/* ---------- 2.4 Per-subject comparison table ---------- */
function anRenderSubjCompare() {
  const card = document.getElementById("anSubjCmpCard");
  if (!card) return;
  const list = anFilteredBoxes();
  const bySubj = {};
  list.forEach(b => {
    const s = bySubj[b.subject] = bySubj[b.subject] || { planned: 0, done: 0, actual: 0, useful: 0, usefulBoxes: 0, tests: 0, correct: 0, backlog: 0 };
    s.planned++; if (isDone(b)) s.done++;
    s.actual += anActualMinutes(b);
    const u = anUsefulMinutes(b); if (u != null) { s.useful += u; s.usefulBoxes++; }
    const tr = testOf(b); s.tests += tr.completed || 0; s.correct += tr.correct || 0;
    if (!isDone(b) && (boxStudyDay(b) || b.date) < TODAY) s.backlog++;
  });
  const mid = anElapsedMidIso();
  let html = '<h3>' + esc(t("anSubjCompareTitle")) + '</h3>';
  if (!list.length) { html += '<p class="muted">' + t("anNoData") + '</p>'; }
  else {
    const rows = Object.keys(bySubj).sort((a, b) => bySubj[b].planned - bySubj[a].planned).map(s => {
      const st = bySubj[s];
      const eff = (st.usefulBoxes >= 3 && st.actual >= 60) ? Math.min(100, st.useful / st.actual * 100) : null;
      let trend = null;
      if (mid) {
        const f = list.filter(b => b.subject === s && (boxStudyDay(b) || b.date) < mid);
        const g = list.filter(b => { const sd = boxStudyDay(b) || b.date; return b.subject === s && sd >= mid && sd <= TODAY; });
        if (f.length >= 5 && g.length >= 5) {
          const fr = f.filter(isDone).length / f.length * 100, gr = g.filter(isDone).length / g.length * 100;
          const word = anTrendWord(gr - fr, 5);
          trend = (gr - fr >= 0 ? "+" : "") + FA_PCT(gr - fr) + " · " + t(word);
        }
      }
      return { s, st, eff, trend };
    });
    html += '<div class="an-table-wrap"><table><tr><th>' + t("anThSubject") + '</th><th>' + t("anKpiPlanned") + '</th><th>' + t("anKpiActual") + '</th><th>' + t("anKpiUseful") + '</th><th>' + t("anKpiEfficiency") + '</th><th>' + t("anKpiTests") + '</th><th>' + t("anSubjAcc") + '</th><th>' + t("anSubjBacklog") + '</th><th>' + t("anSubjCmpTrend") + '</th></tr>' +
      rows.map(r => '<tr><td>' + esc(subjName(r.s)) + '</td><td>' + FA(r.st.done) + "/" + FA(r.st.planned) + '</td><td>' + (r.st.actual > 0 ? fmtDuration(r.st.actual) : "—") + '</td><td>' + (r.st.usefulBoxes ? fmtDuration(r.st.useful) : "—") + '</td><td>' + (r.eff == null ? "—" : FA_PCT(r.eff)) + '</td><td>' + FA(r.st.tests) + '</td><td>' + (r.st.tests ? FA_PCT(r.st.correct / r.st.tests * 100) : "—") + '</td><td>' + FA(r.st.backlog) + '</td><td>' + (r.trend || t("anSubjNoTrend")) + '</td></tr>').join('') + '</table></div>';
  }
  card.innerHTML = html;
}
function anExamTrendTable(held) {
  // One accuracy definition (v1.11.16, audit §5 item 1.6): accuracy =
  // correct ÷ attempted, and coverage = attempted ÷ total, shown as a
  // separate labelled column — the old table showed correct ÷ total,
  // which contradicted the KPI (17.9% vs 63% for the same exam).
  let html = '<table><tr><th>' + t("anThExam") + '</th><th>' + t("anThDate") + '</th><th>' + t("anTaraz") + '</th><th>' + t("anExamAcc") + '</th><th>' + t("anThCoverage") + '</th><th>' + t("anCorrect") + ' / ' + t("anWrong") + ' / ' + t("anUnanswered") + '</th></tr>';
  held.forEach(e => {
    const r0 = e.result, att = (r0.correct || 0) + (r0.wrong || 0),
      tot = att + (r0.unanswered || 0);
    html += '<tr><td>' + esc(examDisplayName(e)) + '</td><td>' + esc(gregToJalali(e.date).text) + '</td><td>' +
      (r0.taraz != null ? FA(r0.taraz) : "—") + '</td><td>' + (att ? FA_PCT((r0.correct || 0) / att * 100) : "—") + '</td><td>' +
      (tot ? FA_PCT(att / tot * 100) : "—") + '</td><td>' +
      FA(r0.correct || 0) + ' / ' + FA(r0.wrong || 0) + ' / ' + FA(r0.unanswered || 0) + '</td></tr>';
  });
  return html + '</table><p class="muted">' + t("anAccDefNote") + '</p>';
}

/* ---------- Per-subject exam trend (audit §5 item 3.1) ---------- */
// One row per subject, one column per held exam with a per-subject
// result, plus an overall accuracy column. Exams without per-subject
// results simply have no column — the table only appears once at least
// one exam carries result.subjects.
function anExamSubjectTrendTable(held) {
  const withSubj = held.filter(e => e.result && e.result.subjects && Object.keys(e.result.subjects).length);
  if (!withSubj.length) return "";
  const subjects = [...new Set(withSubj.flatMap(e => Object.keys(e.result.subjects)))];
  const agg = {};
  subjects.forEach(s => { agg[s] = { c: 0, att: 0 }; });
  withSubj.forEach(e => {
    Object.keys(e.result.subjects).forEach(s => {
      const v = e.result.subjects[s] || {};
      agg[s].c += v.correct || 0;
      agg[s].att += (v.correct || 0) + (v.wrong || 0);
    });
  });
  const weakest = subjects.filter(s => agg[s].att >= 10)
    .sort((a, b) => (agg[a].c / agg[a].att) - (agg[b].c / agg[b].att))[0] || null;
  let html = '<h3>' + esc(t("anSubjTrendTitle")) + '</h3><table><tr><th>' + t("anThSubject") + '</th>' +
    withSubj.map(e => '<th>' + esc(examDisplayName(e)) + '</th>').join('') + '<th>' + t("exAccuracy") + '</th></tr>';
  subjects.forEach(s => {
    html += '<tr><td>' + esc(subjName(s)) + '</td>' + withSubj.map(e => {
      const v = e.result.subjects[s];
      if (!v) return '<td>—</td>';
      const att = (v.correct || 0) + (v.wrong || 0);
      return '<td>' + (att ? FA_PCT((v.correct || 0) / att * 100) : "—") + '</td>';
    }).join('') + '<td>' + (agg[s].att ? FA_PCT(agg[s].c / agg[s].att * 100) : "—") + '</td></tr>';
  });
  html += '</table>';
  if (weakest) html += '<p class="muted">' + t("anSubjTrendWeakest") + ': <b>' + esc(subjName(weakest)) + '</b> · ' + FA_PCT(agg[weakest].c / agg[weakest].att * 100) + '</p>';
  return html;
}

/* ---------- Render: heatmap ---------- */
function anHeatLevel(doneCount) {
  if (!doneCount) return 0;
  if (doneCount <= 1) return 1;
  if (doneCount <= 3) return 2;
  if (doneCount <= 5) return 3;
  return 4;
}
function anHeatLevelActual(mins) {
  if (!mins) return 0;
  if (mins <= 30) return 1;
  if (mins <= 90) return 2;
  if (mins <= 180) return 3;
  return 4;
}
function anRenderHeatmap(list) {
  const wrap = document.getElementById("anHeatmap");
  const dayEl = document.getElementById("anHeatDay");
  if (!wrap) return;
  // Year buttons.
  const yb = document.getElementById("anHeatYears");
  if (yb) {
    yb.innerHTML = [1404, 1405, 1406].map(y =>
      '<button class="btn' + (AN.heatYear === y ? ' btn-lime' : '') + '" data-hy="' + y + '">' + FA(y) + '</button>').join('');
    yb.querySelectorAll("button").forEach(b => b.addEventListener("click", () => {
      AN.heatYear = parseInt(b.dataset.hy, 10); AN.year = AN.heatYear; AN.heatDay = null; anSavePrefs(); renderAnalytics();
    }));
  }
  if (AN.heatYear !== 1405) {
    wrap.innerHTML = '<p class="muted">' + t("anHeatNoData") + '</p>';
    if (dayEl) dayEl.innerHTML = "";
    return;
  }
  // Mode toggle: done boxes, actual minutes, or useful minutes that
  // day. Default is real minutes (2.10): the colour should mean time
  // studied, not boxes. v1.11.21 adds the useful mode.
  const modeEl = document.getElementById("anHeatModes");
  if (modeEl) {
    modeEl.innerHTML = [["done", t("anHeatModeDone")], ["actual", t("anHeatModeActual")], ["useful", t("anHeatModeUseful")]].map(([v, l]) =>
      '<button class="btn' + (AN.heatMode === v ? ' btn-lime' : '') + '" data-hm="' + v + '">' + esc(l) + '</button>').join('');
    modeEl.querySelectorAll("button").forEach(b => b.addEventListener("click", () => {
      AN.heatMode = b.dataset.hm; anSavePrefs(); renderAnalytics();
    }));
  }
  // (2.10) the note says what the colour means IN THE CURRENT MODE —
  // the static text only described the done-boxes mode.
  const noteEl = document.getElementById("anHeatNote");
  if (noteEl) noteEl.textContent = AN.heatMode === "actual" ? t("anHeatNoteActual") : AN.heatMode === "useful" ? t("anHeatNoteUseful") : t("anHeatNote");
  // 8 Saturday-start weeks, 2026-10-24 .. 2026-12-18. Cells are STUDY days.
  const byDate = {};
  if (AN.heatMode === "actual") {
    list.forEach(b => { const sd = boxStudyDay(b) || b.date; byDate[sd] = (byDate[sd] || 0) + anActualMinutes(b); });
  } else if (AN.heatMode === "useful") {
    // Useful: unrecorded boxes contribute nothing (null → 0 here is a
    // sum over recorded values, not a fabricated per-box value).
    list.forEach(b => { const sd = boxStudyDay(b) || b.date; byDate[sd] = (byDate[sd] || 0) + (anUsefulMinutes(b) || 0); });
  } else {
    list.forEach(b => { if (isDone(b)) { const sd = boxStudyDay(b) || b.date; byDate[sd] = (byDate[sd] || 0) + 1; } });
  }
  const weeks = anWeekList();
  let html = '<div class="an-heat">';
  for (let row = 0; row < 7; row++) {
    html += '<div class="an-heat-row">';
    weeks.forEach(ws => {
      const d = addDays(ws, row);
      if (d > anRangeEnd() || d < anRangeStart()) { html += '<span class="an-heat-cell an-heat-out"></span>'; return; }
      const n = byDate[d] || 0;
      const j = anJalali(d);
      const lv = AN.heatMode === "done" ? anHeatLevel(n) : anHeatLevelActual(n);
      const tip = AN.heatMode === "actual"
        ? gregToJalali(d).text + ' · ' + t("anActualLabel") + ': ' + fmtDuration(Math.round(n))
        : AN.heatMode === "useful"
          ? gregToJalali(d).text + ' · ' + t("anUsefulLabel") + ': ' + fmtDuration(Math.round(n))
          : gregToJalali(d).text + ' · ' + t("anDone") + ': ' + FA(n);
      html += '<button class="an-heat-cell an-heat-lv' + lv + (AN.heatDay === d ? ' an-heat-sel' : '') + '" data-day="' + esc(d) + '" title="' +
        esc(tip) + '">' + FA(j ? j.day : "") + '</button>';
    });
    html += '</div>';
  }
  html += '</div>';
  wrap.innerHTML = html;
  wrap.querySelectorAll(".an-heat-cell[data-day]").forEach(c => c.addEventListener("click", () => {
    AN.heatDay = c.dataset.day; anSavePrefs(); renderAnalytics();
  }));
  // Day detail: the SAME filtered list the heatmap was built from —
  // the old code re-read allBoxes() with only the shared filters, so
  // the detail showed boxes the heatmap (range filter) said were 0.
  if (dayEl) {
    if (!AN.heatDay) { dayEl.innerHTML = ""; return; }
    const dayBoxes = list.filter(b => (boxStudyDay(b) || b.date) === AN.heatDay)
      .sort(compareBoxOrder);
    let h = '<h3>' + esc(t("anHeatDay", { d: gregToJalali(AN.heatDay).text })) + '</h3>';
    if (!dayBoxes.length) {
      h += '<p class="muted">' + t("anHeatEmpty") + '</p>';
    } else {
      h += dayBoxes.map(b => {
        const tr = testOf(b);
        const u = anUsefulMinutes(b);
        return '<div class="trow topic" style="display:flex;justify-content:space-between;gap:8px"><span>' + esc(b.start) + ' – ' + esc(b.end) + ' · ' + esc(b.title) + ' · ' + esc(subjName(b.subject)) + '</span><span>' +
          (isDone(b) ? '✓ ' : '') + (anBoxType(b) === "test" ? FA(tr.completed || 0) + '/' + FA(b.tests_total || 0) : anBoxTypeLabel(b)) + ' · ' + (hasActualMinutes(b) ? fmtDuration(Math.round(anActualMinutes(b))) : "—") + (u == null ? "" : ' · ' + t("anUsefulLabel") + ' ' + fmtDuration(Math.round(u))) + '</span></div>';
      }).join('');
    }
    h += '<p><button class="btn" id="anHeatOpenDay">' + t("anOpenDay") + '</button></p>';
    dayEl.innerHTML = h;
    const ob = document.getElementById("anHeatOpenDay");
    if (ob) ob.addEventListener("click", () => navigate({ tab: "program", day: AN.heatDay }));
  }
}

/* ---------- Render: per-subject dashboards ---------- */
function anSubjectList() {
  return [...new Set(allBoxes().map(b => b.subject))].sort();
}
function anRenderSubject(list) {
  const chips = document.getElementById("anSubjChips");
  const body = document.getElementById("anSubjBody");
  if (!chips || !body) return;
  const subjects = anSubjectList();
  if (!subjects.includes(AN.subj)) AN.subj = subjects[0] || "حسابان";
  chips.innerHTML = subjects.map(s =>
    '<button class="btn' + (AN.subj === s ? ' btn-lime' : '') + '" data-subj="' + esc(s) + '"><span class="subj-dot ' + colorClass(s) + '"></span>' + esc(subjName(s)) + '</button>').join('');
  chips.querySelectorAll("button").forEach(b => b.addEventListener("click", () => {
    AN.subj = b.dataset.subj; anSavePrefs(); renderAnalytics();
  }));
  const subj = AN.subj;
  // The filtered list (range/type/status/...) — the chips above still
  // come from allBoxes(), but the numbers below respect the filters.
  const boxes = list.filter(b => b.subject === subj);
  const agg = anAgg(boxes);
  // This month (month of TODAY) vs previous month.
  const curKey = anMonthKey(TODAY);
  const prevKey = curKey === "2026-11" ? "2026-10" : null;
  const curAgg = curKey ? anAgg(boxes.filter(b => anMonthKey(boxStudyDay(b) || b.date) === curKey)) : null;
  const prevAgg = prevKey ? anAgg(boxes.filter(b => anMonthKey(boxStudyDay(b) || b.date) === prevKey)) : null;
  // Chapter progress from the test book (mapped subjects only).
  const bookId = bookOfSubject(subj);
  const book = bookId ? (TESTBOOK.books || []).find(b => b.id === bookId) : null;
  let chHtml = "";
  if (book) {
    const rows = [];
    (book.chapters || []).forEach(ch => {
      let solved = 0, total = 0;
      (ch.topics || []).forEach(tp => { const s = topicStats(tp); solved += s.solved; total += s.total; });
      rows.push({ label: chapterTitle(ch), pct: total ? solved / total * 100 : 0, cls: colorClass(subj),
        text: FA(solved) + "/" + FA(total) + (total ? " · " + FA_PCT(solved / total * 100) : "") });
    });
    chHtml = '<h3>' + esc(t("anSubjChapters")) + ' — ' + esc(bookName(book)) + '</h3>' + anHBar(rows);
  } else {
    chHtml = '<p class="muted">' + t("anSubjNoBook") + '</p>';
  }
  // Lagging topics: book topics with the most remaining tests (mapped subjects),
  // otherwise box topics with the most undone boxes.
  let lagHtml = "";
  if (book) {
    const lag = [];
    (book.chapters || []).forEach(ch => (ch.topics || []).forEach(tp => {
      const s = topicStats(tp);
      if (s.total > 0 && s.remaining > 0) lag.push({ label: chapterTitle(ch) + " — " + topicTitle(tp), rem: s.remaining, acc: s.acc });
    }));
    lag.sort((a, b) => b.rem - a.rem);
    lagHtml = lag.length
      ? lag.slice(0, 5).map(l => '<div class="trow topic" style="display:flex;justify-content:space-between;gap:8px"><span>' + esc(l.label) + '</span><span>' + FA(l.rem) + ' ' + t("anRemaining") + ' · ' + (l.acc == null ? "—" : FA_PCT(l.acc)) + '</span></div>').join('')
      : '<p class="muted">' + t("anNoData") + '</p>';
  } else {
    const byTopic = {};
    boxes.filter(b => !isDone(b)).forEach(b => { byTopic[b.topic || b.title] = (byTopic[b.topic || b.title] || 0) + 1; });
    const top = Object.keys(byTopic).sort((a, b) => byTopic[b] - byTopic[a]).slice(0, 5);
    lagHtml = top.length
      ? top.map(tp => '<div class="trow topic" style="display:flex;justify-content:space-between"><span>' + esc(tp) + '</span><span>' + FA(byTopic[tp]) + ' ' + t("anKpiPlanned") + '</span></div>').join('')
      : '<p class="muted">' + t("anNoData") + '</p>';
  }
  // Weak chapters by accuracy (audit §5 item 2.5): the chapters that
  // need re-reading, not just finishing — with the nearest exam's
  // budget topics they feed.
  let weakChHtml = "";
  if (book) {
    const weak = weakChapters(book, 3);
    const near = nearestExam();
    weakChHtml = weak.length
      ? weak.map(w => {
          const feeds = chapterBudgetTopics(w.chapter, near);
          const feedTxt = feeds.length
            ? ' · ' + esc(feeds.slice(0, 2).join("، ")) + (feeds.length > 2 ? ' +' + FA(feeds.length - 2) : '')
            : '';
          return '<div class="trow topic weak-row"><span>' + esc(chapterTitle(w.chapter)) + '</span><span>' +
            FA_PCT(w.acc * 100) + ' · ' + FA(w.correct) + '/' + FA(w.solved) + ' ' + t("testsWord") +
            feedTxt + '</span></div>';
        }).join('')
      : '<p class="muted">' + t("anWeakNone") + '</p>';
  } else {
    weakChHtml = '<p class="muted">' + t("anSubjNoBook") + '</p>';
  }
  // Accuracy trend per chapter (audit §5 item 3.2): first vs last dated
  // accuracy, only for chapters with at least two dated points. Old
  // totals have no dates, so a chapter with no dated entries has no
  // trend yet — the empty state says so instead of inventing one.
  let trendHtml = "";
  if (book) {
    const rows = [];
    (book.chapters || []).forEach(ch => {
      const tr = chapterTrendLabel(ch);
      if (tr) rows.push({ chapter: ch, tr });
    });
    trendHtml = rows.length
      ? rows.map(r => '<div class="trow topic"><span>' + esc(chapterTitle(r.chapter)) + '</span><span>' +
          esc(t("tlFirst")) + ' ' + FA_PCT(r.tr.first * 100) + ' · ' + esc(t("tlLast")) + ' ' + FA_PCT(r.tr.last * 100) +
          ' · ' + esc(t(r.tr.dir === "improving" ? "tlImproving" : r.tr.dir === "declining" ? "tlDeclining" : "tlStable")) + '</span></div>').join('')
      : '<p class="muted">' + t("tlEmpty") + '</p>';
  } else {
    trendHtml = '<p class="muted">' + t("anSubjNoBook") + '</p>';
  }
  const cmpRow = (label, cur, prev, fmt) =>
    '<tr><td>' + esc(label) + '</td><td>' + fmt(cur) + '</td><td>' + fmt(prev) + '</td></tr>';
  body.innerHTML =
    '<div class="stat-grid">' +
    statCard(t("anSubjBoxes"), FA(agg.done) + "/" + FA(agg.planned), agg.real == null ? "—" : FA_PCT(agg.real)) +
    statCard(t("anSubjTests"), FA(agg.testsDone), FA(agg.correct) + " " + t("anCorrect")) +
    statCard(t("anSubjAcc"), agg.acc == null ? "—" : FA_PCT(agg.acc), FA(agg.wrong) + " " + t("anWrong")) +
    statCard(t("anKpiHours"), fmtDuration(agg.minutes), t("anKpiHoursNote")) +
    statCard(t("anKpiActual"), fmtDuration(agg.actualMinutes), t("anKpiActualNote")) +
    // v1.11.21: useful + efficiency for this subject — same honesty
    // rules as the main KPIs (unrecorded = «ثبت نشده», no fake %).
    statCard(t("anKpiUseful"), agg.usefulBoxes ? fmtDuration(agg.usefulMinutes) : t("tmUsefulNotRecorded"), t("anKpiUsefulNote")) +
    statCard(t("anKpiEfficiency"), agg.efficiency == null ? "—" : FA_PCT(agg.efficiency), t("anKpiEfficiencyNote")) +
    statCard(t("anSubjTypes"), FA(agg.typeCounts.class), t("anTypeTest") + ": " + FA(agg.typeCounts.test) + " · " + t("anTypeDesc") + ": " + FA(agg.typeCounts.desc)) +
    '</div>' +
    '<div class="card an-card"><h3>' + esc(t("anSubjCompare")) + '</h3>' +
    (curAgg && prevAgg
      ? '<table><tr><th>' + t("anCmpMetric") + '</th><th>' + t("anCurMonth") + ' (' + anMonthLabel(curKey) + ')</th><th>' + t("anPrevMonth") + ' (' + anMonthLabel(prevKey) + ')</th></tr>' +
        cmpRow(t("anKpiPlanned"), curAgg.planned, prevAgg.planned, v => FA(v)) +
        cmpRow(t("anKpiDone"), curAgg.done, prevAgg.done, v => FA(v)) +
        cmpRow(t("anKpiReal"), curAgg.real, prevAgg.real, v => v == null ? "—" : FA_PCT(v)) +
        cmpRow(t("anKpiTests"), curAgg.testsDone, prevAgg.testsDone, v => FA(v)) +
        cmpRow(t("anSubjAcc"), curAgg.acc, prevAgg.acc, v => v == null ? "—" : FA_PCT(v)) +
        cmpRow(t("anKpiActual"), curAgg.actualMinutes, prevAgg.actualMinutes, v => fmtDuration(v)) +
        // v1.11.21: useful + efficiency, same months — a month with no
        // recorded useful shows "—", never a 0 presented as studied.
        '<tr><td>' + esc(t("anKpiUseful")) + '</td><td>' + (curAgg.usefulBoxes ? fmtDuration(curAgg.usefulMinutes) : "—") + '</td><td>' + (prevAgg.usefulBoxes ? fmtDuration(prevAgg.usefulMinutes) : "—") + '</td></tr>' +
        cmpRow(t("anKpiEfficiency"), curAgg.efficiency, prevAgg.efficiency, v => v == null ? "—" : FA_PCT(v)) +
        cmpRow(t("anTypeTest"), curAgg.typeCounts.test, prevAgg.typeCounts.test, v => FA(v)) +
        cmpRow(t("anTypeDesc"), curAgg.typeCounts.desc, prevAgg.typeCounts.desc, v => FA(v)) +
        cmpRow(t("anTypeClass"), curAgg.typeCounts.class, prevAgg.typeCounts.class, v => FA(v)) +
        '</table>'
      : '<p class="muted">' + t("anNotEnough") + '</p>') +
    '</div>' +
    '<div class="card an-card">' + chHtml + '</div>' +
    '<div class="card an-card"><h3>' + esc(t("anWeakChapters")) + '</h3>' + weakChHtml + '</div>' +
    '<div class="card an-card"><h3>' + esc(t("tlTrendTitle")) + '</h3>' + trendHtml + '</div>' +
    '<div class="card an-card"><h3>' + esc(t("anSubjLagging")) + '</h3>' + lagHtml + '</div>';
}

/* ---------- Render: period comparison ---------- */
function anRenderCompare() {
  const card = document.getElementById("anCmpCard");
  if (!card) return;
  const optB = ['aban', 'azar', 'custom'].map(v =>
    '<option value="' + v + '"' + (AN.cmpB === v ? " selected" : "") + '>' + t(v === "aban" ? "anMonthAban" : v === "azar" ? "anMonthAzar" : "anRangeCustom") + '</option>').join('');
  const optA = ['aban', 'azar', 'custom'].map(v =>
    '<option value="' + v + '"' + (AN.cmpA === v ? " selected" : "") + '>' + t(v === "aban" ? "anMonthAban" : v === "azar" ? "anMonthAzar" : "anRangeCustom") + '</option>').join('');
  card.innerHTML =
    '<div class="form-row">' +
    '<label><span>' + t("anCmpA") + '</span><select id="anCmpASel">' + optA + '</select></label>' +
    '<label><span>' + t("anFrom") + '</span><input type="date" id="anCmpAFrom" min="2026-10-24" max="2026-12-18" value="' + esc(AN.cmpAFrom || "") + '"' + (AN.cmpA === "custom" ? "" : " disabled") + '></label>' +
    '<label><span>' + t("anTo") + '</span><input type="date" id="anCmpATo" min="2026-10-24" max="2026-12-18" value="' + esc(AN.cmpATo || "") + '"' + (AN.cmpA === "custom" ? "" : " disabled") + '></label>' +
    '</div>' +
    '<div class="form-row">' +
    '<label><span>' + t("anCmpB") + '</span><select id="anCmpBSel">' + optB + '</select></label>' +
    '<label><span>' + t("anFrom") + '</span><input type="date" id="anCmpBFrom" min="2026-10-24" max="2026-12-18" value="' + esc(AN.cmpBFrom || "") + '"' + (AN.cmpB === "custom" ? "" : " disabled") + '></label>' +
    '<label><span>' + t("anTo") + '</span><input type="date" id="anCmpBTo" min="2026-10-24" max="2026-12-18" value="' + esc(AN.cmpBTo || "") + '"' + (AN.cmpB === "custom" ? "" : " disabled") + '></label>' +
    '</div>' +
    '<p class="muted">' + t("anCmpNote") + '</p><div id="anCmpBody"></div>';
  const body = document.getElementById("anCmpBody");
  const bA = anPeriodBounds(AN.cmpA, "cmpAFrom", "cmpATo");
  const bB = anPeriodBounds(AN.cmpB, "cmpBFrom", "cmpBTo");
  if (!bA || !bB) { body.innerHTML = '<p class="muted">' + t("anNotEnough") + '</p>'; }
  else {
    const a = anPeriodAgg(bA.from, bA.to), b = anPeriodAgg(bB.from, bB.to);
    const rowN = (label, va, vb) => '<tr><td>' + esc(label) + '</td><td>' + FA(va) + '</td><td>' + FA(vb) + '</td><td>' + (vb - va >= 0 ? "+" : "") + FA(vb - va) + '</td></tr>';
    const rowP = (label, va, vb) => {
      const d = (va == null || vb == null) ? null : vb - va;
      return '<tr><td>' + esc(label) + '</td><td>' + (va == null ? "—" : FA_PCT(va)) + '</td><td>' + (vb == null ? "—" : FA_PCT(vb)) + '</td><td>' + (d == null ? "—" : (d >= 0 ? "+" : "") + FA_PCT(d)) + '</td></tr>';
    };
    const rowD = (label, va, vb) => '<tr><td>' + esc(label) + '</td><td>' + fmtDuration(va) + '</td><td>' + fmtDuration(vb) + '</td><td>' + (vb - va >= 0 ? "+" : "−") + fmtDuration(Math.abs(vb - va)) + '</td></tr>';
    // v1.11.21: a period with no recorded useful shows "—" for that
    // period (and no delta), never a 0 presented as studied.
    const rowU = (label, va, vb, ha, hb) => '<tr><td>' + esc(label) + '</td><td>' + (ha ? fmtDuration(va) : "—") + '</td><td>' + (hb ? fmtDuration(vb) : "—") + '</td><td>' + ((ha && hb) ? (vb - va >= 0 ? "+" : "−") + fmtDuration(Math.abs(vb - va)) : "—") + '</td></tr>';
    body.innerHTML = '<table><tr><th>' + t("anCmpMetric") + '</th><th>' + esc(gregToJalali(bA.from).text + " — " + gregToJalali(bA.to).text) + '</th><th>' + esc(gregToJalali(bB.from).text + " — " + gregToJalali(bB.to).text) + '</th><th>' + t("anCmpDelta") + '</th></tr>' +
      rowN(t("anKpiPlanned"), a.planned, b.planned) +
      rowN(t("anKpiDone"), a.done, b.done) +
      rowN(t("anPartial"), a.partial, b.partial) +
      rowN(t("anStatusUndone"), a.undone, b.undone) +
      rowP(t("anKpiReal"), a.real, b.real) +
      rowD(t("anKpiHours"), a.minutes, b.minutes) +
      rowN(t("anKpiTests"), a.testsDone, b.testsDone) +
      rowN(t("anCorrect"), a.correct, b.correct) +
      rowP(t("anSubjAcc"), a.acc, b.acc) +
      rowN(t("anTypeTest"), a.typeCounts.test, b.typeCounts.test) +
      rowN(t("anTypeDesc"), a.typeCounts.desc, b.typeCounts.desc) +
      rowN(t("anTypeClass"), a.typeCounts.class, b.typeCounts.class) +
      rowD(t("anKpiActual"), a.actualMinutes, b.actualMinutes) +
      // v1.11.21: useful + efficiency across the two periods.
      rowU(t("anKpiUseful"), a.usefulMinutes, b.usefulMinutes, a.usefulBoxes, b.usefulBoxes) +
      rowP(t("anKpiEfficiency"), a.efficiency, b.efficiency) +
      '</table>';
  }
  document.getElementById("anCmpASel").addEventListener("change", e => { AN.cmpA = e.target.value; anSavePrefs(); renderAnalytics(); });
  document.getElementById("anCmpBSel").addEventListener("change", e => { AN.cmpB = e.target.value; anSavePrefs(); renderAnalytics(); });
  [["anCmpAFrom", "cmpAFrom"], ["anCmpATo", "cmpATo"], ["anCmpBFrom", "cmpBFrom"], ["anCmpBTo", "cmpBTo"]].forEach(([id, key]) => {
    const el = document.getElementById(id);
    if (el) el.addEventListener("change", e => { AN[key] = e.target.value; anSavePrefs(); renderAnalytics(); });
  });
}

/* ---------- Render: smart report (real data only) ---------- */
// Insights are computed from the FILTERED list (range/subject/type/...),
// not the whole programme — except the book-review and nearest-exam
// rows, which are inherently whole-programme (book stats / exam budget).
function anRenderInsights(list) {
  const wrap = document.getElementById("anInsights");
  if (!wrap) return;
  const boxes = list;
  // "Fully-done day" inside the filtered list: all FILTERED boxes of
  // that day done (the global isDayDone() would count unfiltered boxes).
  const dayDoneInList = d => {
    const dayBoxes = boxes.filter(b => (boxStudyDay(b) || b.date) === d);
    return dayBoxes.length > 0 && dayBoxes.every(isDone);
  };
  const doneCount = boxes.filter(isDone).length;
  const testsDone = boxes.reduce((s, b) => s + (testOf(b).completed || 0), 0);
  if (!doneCount && !testsDone) {
    wrap.innerHTML = '<div class="card an-card"><p class="muted">' + t("anSmartEmpty") + '</p></div>';
    return;
  }
  const insights = [];
  const today = TODAY; // study day (03:30 boundary): "past" ends at 03:30
  // Trend: first half vs second half of the ELAPSED programme (done%).
  // The second half is capped at TODAY — counting future boxes would
  // make the trend look like a collapse (same fix as anElapsedMidIso).
  const all = boxes;
  const mid = anElapsedMidIso();
  const first = mid ? anAgg(all.filter(b => (boxStudyDay(b) || b.date) < mid)) : anAgg([]);
  const second = mid ? anAgg(all.filter(b => { const sd = boxStudyDay(b) || b.date; return sd >= mid && sd <= TODAY; })) : anAgg([]);
  if (first.planned >= 5 && second.planned >= 5 && first.real != null && second.real != null) {
    const d = second.real - first.real;
    insights.push({ title: t("anInsightTrend"),
      text: FA_PCT(first.real) + " → " + FA_PCT(second.real) + " (" + (d >= 0 ? "+" : "") + FA_PCT(d) + ")" });
  }
  // v1.11.21: efficiency trend (first half vs second half) — only
  // when BOTH halves have recorded useful time; and the real-vs-useful
  // gap, when useful is recorded but below real. More real time does
  // not necessarily mean more useful time.
  if (first.efficiency != null && second.efficiency != null) {
    const d = second.efficiency - first.efficiency;
    insights.push({ title: t("anInsightUseful"),
      text: FA_PCT(first.efficiency) + " → " + FA_PCT(second.efficiency) + " (" + (d >= 0 ? "+" : "") + FA_PCT(d) + ")" });
  }
  const allAgg = anAgg(all);
  if (allAgg.efficiency != null && allAgg.efficiency < 100) {
    insights.push({ title: t("anInsightUsefulGap"),
      text: t("anActualLabel") + ": " + fmtDuration(allAgg.actualMinutes) + " · " + t("anUsefulLabel") + ": " + fmtDuration(allAgg.usefulMinutes) + " · " + FA_PCT(allAgg.efficiency) });
  }
  // Class share: how much of the programme is live classes (3-way type).
  const nClassAll = boxes.filter(b => anBoxType(b) === "class").length;
  if (nClassAll) {
    const classDone = boxes.filter(b => anBoxType(b) === "class" && isDone(b)).length;
    insights.push({ title: t("anInsightClass"),
      text: FA(nClassAll) + " / " + FA(boxes.length) + " · " + t("anDone") + ": " + FA(classDone) });
  }
  // Best weekday (min 3 days with boxes).
  const byWd = {};
  anDailySeries(boxes).forEach(d => {
    const wd = weekdayFa(d.date);
    const s = byWd[wd] = byWd[wd] || { planned: 0, done: 0, days: 0 };
    s.planned += d.planned; s.done += d.done; s.days++;
  });
  const wdBest = Object.keys(byWd).filter(w => byWd[w].days >= 3 && byWd[w].planned > 0)
    .sort((a, b) => (byWd[b].done / byWd[b].planned) - (byWd[a].done / byWd[a].planned))[0];
  if (wdBest) insights.push({ title: t("anInsightWeekday"),
    text: wdBest + " · " + FA_PCT(byWd[wdBest].done / byWd[wdBest].planned * 100) });
  // Weakest subject by accuracy (min 20 completed tests).
  const bySubj = {};
  boxes.forEach(b => {
    const s = bySubj[b.subject] = bySubj[b.subject] || { tests: 0, correct: 0 };
    const tr = testOf(b); s.tests += tr.completed || 0; s.correct += tr.correct || 0;
  });
  const weak = Object.keys(bySubj).filter(s => bySubj[s].tests >= 20)
    .sort((a, b) => (bySubj[a].correct / bySubj[a].tests) - (bySubj[b].correct / bySubj[b].tests))[0];
  if (weak) insights.push({ title: t("anInsightWeak"),
    text: subjName(weak) + " · " + FA_PCT(bySubj[weak].correct / bySubj[weak].tests * 100) + " (" + FA(bySubj[weak].tests) + " " + t("anKpiTests") + ")" });
  // v1.11.22: most study time subject THIS WEEK (by recorded actual
  // minutes; needs ≥60 recorded real minutes in the week).
  const ws = anWeekStart(TODAY);
  const weekList = boxes.filter(b => { const sd = boxStudyDay(b) || b.date; return sd >= ws && sd <= addDays(ws, 6); });
  const weekActual = weekList.reduce((s, b) => s + anActualMinutes(b), 0);
  if (weekActual >= 60) {
    const byS = {};
    weekList.forEach(b => { byS[b.subject] = (byS[b.subject] || 0) + anActualMinutes(b); });
    const top = Object.keys(byS).sort((a, b) => byS[b] - byS[a])[0];
    if (top && byS[top] > 0) insights.push({ title: t("anInsMostTime"),
      text: subjName(top) + " · " + fmtDuration(byS[top]) });
  }
  // v1.11.22: real time rose but useful stayed flat (first vs second
  // half of the programme; both halves need recorded useful time).
  if (first.efficiency != null && second.efficiency != null && first.actualMinutes > 0 && second.actualMinutes > 0) {
    const realDelta = (second.actualMinutes - first.actualMinutes) / first.actualMinutes;
    const effDelta = second.efficiency - first.efficiency;
    if (realDelta >= 0.10 && Math.abs(effDelta) < 5) insights.push({ title: t("anInsRealFlat"),
      text: t("anActualLabel") + ": " + fmtDuration(first.actualMinutes) + " → " + fmtDuration(second.actualMinutes) + " · " + t("anKpiEfficiency") + ": " + FA_PCT(first.efficiency) + " → " + FA_PCT(second.efficiency) });
  }
  // v1.11.22: the past study day that created the most backlog (most
  // boxes still undone from that day — current state, grouped by day).
  const byDay = {};
  boxes.filter(b => !isDone(b) && (boxStudyDay(b) || b.date) < TODAY).forEach(b => {
    const sd = boxStudyDay(b) || b.date; byDay[sd] = (byDay[sd] || 0) + 1;
  });
  const worstDay = Object.keys(byDay).sort((a, b) => byDay[b] - byDay[a])[0];
  if (worstDay) insights.push({ title: t("anInsBacklogDay"),
    text: gregToJalali(worstDay).text + " · " + FA(byDay[worstDay]) + " " + t("boxesWord") });
  // Longest streak of fully-done days (inside the filtered list).
  const dates = [...new Set(boxes.map(b => boxStudyDay(b) || b.date))].sort();
  let best = 0, cur = 0, prev = null;
  dates.forEach(d => {
    if (dayDoneInList(d) && (!prev || addDays(prev, 1) === d)) cur++;
    else if (dayDoneInList(d)) cur = 1;
    else cur = 0;
    best = Math.max(best, cur); prev = d;
  });
  if (best > 0) insights.push({ title: t("anInsightStreak"), text: FA(best) + " " + t("anKpiDays") });
  // Days with no activity in the past (within range, before today).
  // v1.11.26 (QA BUG-034): a day counts as active when it has recorded
  // real minutes too — a timer-only day (no tick, no tests) is a study
  // day, not an idle one.
  const pastDays = [];
  let d = anRangeStart();
  while (d < today && d <= anRangeEnd()) { pastDays.push(d); d = addDays(d, 1); }
  const idle = pastDays.filter(dt => !boxes.some(b => (boxStudyDay(b) || b.date) === dt && (isDone(b) || (testOf(b).completed || 0) > 0 || anActualMinutes(b) > 0)));
  if (pastDays.length) insights.push({ title: t("anInsightIdle"),
    text: FA(idle.length) + " / " + FA(pastDays.length) });
  // Topics needing review: book topics with the most remaining tests.
  const lag = [];
  (TESTBOOK.books || []).forEach(book => (book.chapters || []).forEach(ch => (ch.topics || []).forEach(tp => {
    const s = topicStats(tp);
    if (s.total > 0 && s.remaining > 0) lag.push({ label: bookName(book) + " — " + chapterTitle(ch) + " — " + topicTitle(tp), rem: s.remaining });
  })));
  lag.sort((a, b) => b.rem - a.rem);
  if (lag.length) insights.push({ title: t("anInsightReview"),
    text: lag.slice(0, 3).map(l => l.label + " (" + FA(l.rem) + ")").join(" · ") });
  // Nearest upcoming exam readiness.
  const u = upcomingExams(36500);
  if (u.length) {
    const r0 = examReadiness(u[0]);
    if (r0) insights.push({ title: t("anInsightExam"),
      text: examDisplayName(u[0]) + " · " + FA_PCT(r0.pct) + " (" + FA(r0.done) + "/" + FA(r0.total) + ")" });
  }
  // Study discipline: fully-done days / past days with boxes (filtered).
  const pastWithBoxes = pastDays.filter(dt => boxes.some(b => (boxStudyDay(b) || b.date) === dt));
  const fullDays = pastWithBoxes.filter(dt => dayDoneInList(dt)).length;
  if (pastWithBoxes.length) insights.push({ title: t("anInsightDisc"),
    text: FA(fullDays) + "/" + FA(pastWithBoxes.length) + " · " + FA_PCT(pastWithBoxes.length ? fullDays / pastWithBoxes.length * 100 : 0) });
  wrap.innerHTML = insights.length
    ? '<div class="an-insights">' + insights.map(i =>
      // v1.11.23 (QA BUG-027): esc() the TEXT too, not just the title —
      // a subject name from an ICS title reached innerHTML raw here
      // (stored XSS). The two texts that used to esc() inline (review
      // labels, exam name) no longer do — one escape at this sink.
      '<div class="card an-insight"><b>' + esc(i.title) + '</b><p>' + esc(i.text) + '</p></div>').join('') + '</div>'
    : '<div class="card an-card"><p class="muted">' + t("anSmartEmpty") + '</p></div>';
}

/* ---------- Weekly report (audit §5 item 2.7) ---------- */
// One page, a composition of existing data only: this week's real vs
// planned hours, accuracy + weakest chapter (2.5), lagging subjects
// (2.4), next-exam readiness + forecast (2.3), idle days, next week's
// load. No new capture, no new maths — every number is already computed
// somewhere else in the app. The range label uses jalaliParts (full
// Jalali arithmetic), not the Aban/Azar-only gregToJalali.
function anJalaliText(iso) {
  const p = jalaliParts(iso);
  const faNum = (n) => String(n).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[+d]);
  return LANG === "fa"
    ? faNum(p.jd) + " " + t(jalaliMonthKey(p.jm)) + " " + faNum(p.jy)
    : t(jalaliMonthKey(p.jm)) + " " + p.jd + ", " + p.jy;
}
function anRenderWeeklyReport() {
  const wrap = document.getElementById("anWeeklyReport");
  if (!wrap) return;
  const ws = anWeekStart(TODAY), we = addDays(ws, 6);
  const weekBoxes = allBoxes().filter(b => {
    const sd = boxStudyDay(b) || b.date;
    return sd >= ws && sd <= we;
  });
  const agg = anAgg(weekBoxes);
  const testsDone = weekBoxes.reduce((s, b) => s + (testOf(b).completed || 0), 0);
  if (!weekBoxes.length && !testsDone) {
    wrap.innerHTML = '<div class="card an-card"><p class="muted">' + t("wrEmpty") + '</p></div>';
    return;
  }
  // Weakest chapter across all books (2.5 logic, worst score wins).
  let weak = null;
  (TESTBOOK.books || []).forEach(book => {
    const w = weakChapters(book, 1)[0];
    if (w && (!weak || w.score > weak.score)) weak = { ch: w };
  });
  const lag = laggingSubjects().rows.slice(0, 3);
  // Idle days: past days of this week with no done box, no tests and
  // no recorded real minutes (v1.11.26, QA BUG-034 — same fix as the
  // insights idle filter above: a timer-only day is active).
  const pastDays = [];
  let d = ws;
  while (d <= we && d < TODAY) { pastDays.push(d); d = addDays(d, 1); }
  const idle = pastDays.filter(dt => !weekBoxes.some(b => (boxStudyDay(b) || b.date) === dt && (isDone(b) || (testOf(b).completed || 0) > 0 || anActualMinutes(b) > 0)));
  // Next week's load.
  const nws = addDays(ws, 7), nwe = addDays(ws, 13);
  const nextWeek = allBoxes().filter(b => {
    const sd = boxStudyDay(b) || b.date;
    return sd >= nws && sd <= nwe;
  });
  const nextMinutes = nextWeek.reduce((s, b) => s + anBoxMinutes(b), 0);
  const near = nearestExam();
  const row = (label, val) => '<div class="day-sum-row"><span>' + label + '</span><b>' + val + '</b></div>';
  let html = '<div class="card an-card"><h3>' + esc(t("wrTitle")) + ' · ' + esc(anJalaliText(ws) + " — " + anJalaliText(we)) + '</h3><div class="day-sum-rows">' +
    row(t("wrPlanned"), fmtDuration(agg.minutes)) +
    row(t("wrActual"), fmtDuration(agg.actualMinutes)) +
    // v1.11.21: useful + efficiency next to real; unrecorded useful
    // is «ثبت نشده», and the note states the real-vs-useful truth
    // whenever a gap exists (more real time ≠ more useful time).
    row(t("wrUseful"), agg.usefulBoxes ? fmtDuration(agg.usefulMinutes) : t("tmUsefulNotRecorded")) +
    row(t("wrEfficiency"), agg.efficiency == null ? "—" : FA_PCT(agg.efficiency)) +
    row(t("wrAcc"), agg.acc == null ? "—" : FA_PCT(agg.acc) + " (" + FA(agg.testsDone) + " " + t("testsWord") + ")") +
    row(t("wrIdleDays"), FA(idle.length) + " / " + FA(pastDays.length)) +
    row(t("wrNextWeek"), FA(nextWeek.length) + " " + t("boxesWord") + " · " + fmtDuration(nextMinutes)) +
    '</div>';
  if (agg.efficiency != null && agg.efficiency < 100) {
    html += '<p class="muted">' + esc(t("wrRealVsUsefulNote")) + '</p>';
  }
  if (weak) {
    html += '<p>' + esc(t("wrWeakestChapter")) + ': <b>' + esc(chapterTitle(weak.ch.chapter)) + '</b> · ' +
      FA_PCT(weak.ch.acc * 100) + ' (' + FA(weak.ch.correct) + '/' + FA(weak.ch.solved) + ')</p>';
  }
  if (lag.length) {
    html += '<p>' + esc(t("lagTitle")) + ': ' + lag.map(r => esc(subjName(r.subject)) + " (" + FA(Math.round(r.shortBoxes)) + " " + t("boxesWord") + ")").join(" · ") + '</p>';
  }
  if (near) html += '<div class="wr-exam">' + examForecastHtml(near) + '</div>';
  wrap.innerHTML = html + '</div>';
}

/* ---------- Render: archive (paginated, searchable, read-only) ---------- */
const AN_PAGE_SIZE = 25;
function anRenderArchive() {
  const tbl = document.getElementById("anArchTable");
  const totalEl = document.getElementById("anArchTotal");
  const pageEl = document.getElementById("anArchPageInfo");
  const monthLbl = document.getElementById("anArchMonthLabel");
  if (!tbl) return;
  const rows = anArchiveBoxes();
  const pages = Math.max(1, Math.ceil(rows.length / AN_PAGE_SIZE));
  if (AN.archPage >= pages) AN.archPage = pages - 1;
  if (AN.archPage < 0) AN.archPage = 0;
  if (monthLbl) monthLbl.textContent = anMonthLabel(AN.archMonth);
  if (totalEl) totalEl.textContent = t("anArchTotal", { n: FA(rows.length) });
  if (pageEl) pageEl.textContent = t("anArchPage", { p: FA(AN.archPage + 1), n: FA(pages) });
  const prevPg = document.getElementById("anArchPrevPg");
  const nextPg = document.getElementById("anArchNextPg");
  if (prevPg) prevPg.disabled = AN.archPage <= 0;
  if (nextPg) nextPg.disabled = AN.archPage >= pages - 1;
  if (!rows.length) { tbl.innerHTML = '<p class="muted">' + t("anArchEmpty") + '</p>'; return; }
  const page = rows.slice(AN.archPage * AN_PAGE_SIZE, (AN.archPage + 1) * AN_PAGE_SIZE);
  let html = '<table><tr><th>' + t("calColTitle") + '</th><th>' + t("anThDate") + '</th><th>' + t("anThTime") + '</th><th>' + t("anThSubject") + '</th><th>' + t("anThTitle") + '</th><th>' + t("anThType") + '</th><th>' + t("anThStatus") + '</th><th>' + t("anThTests") + '</th><th>' + t("anThAcc") + '</th><th>' + t("anThActual") + '</th><th></th></tr>';
  page.forEach(b => {
    const tr = testOf(b);
    const st = anBoxStatus(b);
    const acc = (tr.completed || 0) ? FA_PCT((tr.correct || 0) / tr.completed * 100) : "—";
    const sd = boxStudyDay(b) || b.date;
    const tp = boxTopicShown(b);
    html += '<tr data-box="' + esc(b.id) + '"><td>' + connStatusBoxHtml(b) + calAddToCalBtnHtml(b) + '</td><td>' + esc(gregToJalali(sd).text) + '</td><td>' + esc(b.start) + '–' + esc(b.end) + '</td><td>' + esc(subjName(b.subject)) + '</td><td>' + esc(b.title) + (tp ? '<br><span class="muted">' + esc(tp) + '</span>' : '') + '</td><td>' + anBoxTypeLabel(b) + '</td><td>' + t(st === "done" ? "anStatusDone" : st === "partial" ? "anStatusPartial" : "anStatusUndone") + '</td><td>' + FA(tr.completed || 0) + '/' + FA(b.tests_total || 0) + '</td><td>' + acc + '</td><td>' + actualVsHtml(b) + '</td>' +
      '<td><button class="btn an-arch-det" data-box="' + esc(b.id) + '">' + t("anArchDetail") + '</button></td></tr>' +
      '<tr class="an-arch-detail-row" data-for="' + esc(b.id) + '" hidden><td colspan="11"></td></tr>';
  });
  tbl.innerHTML = html + '</table>';
  tbl.querySelectorAll(".an-arch-det").forEach(btn => btn.addEventListener("click", () => {
    const b = allBoxes().find(x => x.id === btn.dataset.box);
    if (!b) return;
    // v1.11.28 (QA BUG-044): the old code built a selector from the
    // raw box id — a tampered id could break out of the attribute
    // and inject a selector. Match by dataset instead.
    const row = Array.from(tbl.querySelectorAll(".an-arch-detail-row"))
      .find(r => r.dataset.for === b.id);
    if (!row) return;
    if (!row.hidden) { row.hidden = true; return; }
    const link = linkedTopicId(b);
    const linkInfo = link && topicById(link);
    const tr = testOf(b);
    row.querySelector("td").innerHTML =
      '<div class="an-detail"><span><b>' + t("anArchNote") + ':</b> ' + esc(b.note || "—") + '</span>' +
      '<span><b>' + t("anArchBookTopic") + ':</b> ' + (linkInfo ? esc(topicTitle(linkInfo.topic)) : "—") + '</span>' +
      '<span><b>' + t("anArchMinutes") + ':</b> ' + fmtDuration(anBoxMinutes(b)) + '</span>' +
      '<span><b>' + t("anActualLabel") + ':</b> ' + (hasActualMinutes(b) ? fmtDuration(Math.round(anActualMinutes(b))) : "—") + '</span>' +
      // v1.11.21: useful (never 0 when unrecorded) + the last timer
      // session's real clock span, when this version recorded one.
      '<span><b>' + t("anUsefulLabel") + ':</b> ' + (anUsefulMinutes(b) == null ? t("tmUsefulNotRecorded") : fmtDuration(Math.round(anUsefulMinutes(b)))) + '</span>' +
      '<span><b>' + t("tmEfficiency") + ':</b> ' + (anBoxEfficiency(b) == null ? "—" : FA_PCT(anBoxEfficiency(b))) + '</span>' +
      '<span>' + sessionClockHtml(b) + '</span>' +
      '<span><b>' + t("anCorrect") + ':</b> ' + FA(tr.correct || 0) + ' · <b>' + t("anWrong") + ':</b> ' + FA(Math.max(0, (tr.completed || 0) - (tr.correct || 0))) + '</span>' +
      ' <button class="btn an-arch-edit" data-box="' + esc(b.id) + '">' + t("editBtn") + '</button>' + boxMenuBtnHtml() + '</div>';
    row.hidden = false;
    row.querySelector(".an-arch-edit").addEventListener("click", () => openEditBox(b));
    const archMenuBtn = row.querySelector(".menu-btn");
    if (archMenuBtn) wireBoxMenuBtn(archMenuBtn, b);
  }));
}

/* ---------- Review past (v1.11.7): undone past work + items hidden from
   the backlog — a VIEW over the same data, never a separate store.
   Undone past boxes keep their title, original date, time, subject and
   undone status even when Google no longer has the event (orphaned).
   Done items hidden from the backlog stay visible here with a restore
   button. The Analytics filters do not apply here: this is the whole
   past, not a filtered slice. */
function anRenderReviewPast() {
  const card = document.getElementById("anReviewPastCard");
  if (!card) return;
  const hidden = state.backlogHidden || {};
  const byDate = compareBoxOrder;
  const undonePast = allBoxes()
    .filter(b => !isDone(b) && (boxStudyDay(b) || b.date) < TODAY)
    .sort(byDate);
  const hiddenDone = allBoxes()
    .filter(b => isDone(b) && (boxStudyDay(b) || b.date) < TODAY && hidden[b.id])
    .sort(byDate);
  let html = '<h3>' + t("anReviewPastUndone") + '</h3>';
  if (!undonePast.length) {
    html += '<p class="muted">' + t("anReviewPastEmpty") + '</p>';
  } else {
    html += '<table><tr><th>' + t("calColTitle") + '</th><th>' + t("anThDate") + '</th><th>' + t("anThTime") + '</th><th>' + t("anThSubject") + '</th><th>' + t("anThTitle") + '</th><th>' + t("anThStatus") + '</th><th></th></tr>';
    undonePast.forEach(b => {
      const sd = boxStudyDay(b) || b.date;
      html += '<tr data-box="' + esc(b.id) + '"><td>' + connStatusBoxHtml(b) + calAddToCalBtnHtml(b) + '</td><td>' + esc(gregToJalali(sd).text) + '</td><td>' + esc(b.start) + '–' + esc(b.end) + '</td><td>' + esc(subjName(b.subject)) + '</td><td>' + esc(b.title) + (b.orphaned ? '<br><span class="muted">' + t("orphanedNote") + '</span>' : '') + '</td><td>' + t("anStatusUndone") + '</td>' +
        '<td><input type="checkbox" class="an-rp-done" data-box="' + esc(b.id) + '" aria-label="' + t("fDone") + '"> <button class="btn an-rp-edit" data-box="' + esc(b.id) + '">' + t("editBtn") + '</button> ' + boxMenuBtnHtml().replace('class="menu-btn"', 'class="menu-btn an-rp-menu" data-box="' + esc(b.id) + '"') + '</td></tr>';
    });
    html += '</table>';
  }
  html += '<h3>' + t("anReviewPastHidden") + '</h3>';
  if (!hiddenDone.length) {
    html += '<p class="muted">' + t("anReviewPastHiddenEmpty") + '</p>';
  } else {
    html += '<table><tr><th>' + t("calColTitle") + '</th><th>' + t("anThDate") + '</th><th>' + t("anThTime") + '</th><th>' + t("anThSubject") + '</th><th>' + t("anThTitle") + '</th><th></th></tr>';
    hiddenDone.forEach(b => {
      const sd = boxStudyDay(b) || b.date;
      html += '<tr><td>' + connStatusBoxHtml(b) + calAddToCalBtnHtml(b) + '</td><td>' + esc(gregToJalali(sd).text) + '</td><td>' + esc(b.start) + '–' + esc(b.end) + '</td><td>' + esc(subjName(b.subject)) + '</td><td>' + esc(b.title) + '</td>' +
        '<td><button class="btn an-rp-restore" data-box="' + esc(b.id) + '">' + t("anRestoreBacklog") + '</button> ' + boxMenuBtnHtml().replace('class="menu-btn"', 'class="menu-btn an-rp-menu" data-box="' + esc(b.id) + '"') + '</td></tr>';
    });
    html += '</table>';
  }
  card.innerHTML = html;
  card.querySelectorAll(".an-rp-done").forEach(cb => cb.addEventListener("change", (e) => {
    const id = e.target.dataset.box;
    if (e.target.checked) state.done[id] = true; else delete state.done[id];
    saveState(); renderAll();
  }));
  card.querySelectorAll(".an-rp-edit").forEach(btn => btn.addEventListener("click", () => {
    const b = allBoxes().find(x => x.id === btn.dataset.box);
    if (b) openEditBox(b);
  }));
  card.querySelectorAll(".an-rp-restore").forEach(btn => btn.addEventListener("click", () => {
    if (state.backlogHidden) delete state.backlogHidden[btn.dataset.box];
    saveState(); renderAll();
  }));
  // v1.11.9: the same three-dot menu as the dashboard cards.
  card.querySelectorAll(".an-rp-menu").forEach(btn => {
    const b = allBoxes().find(x => x.id === btn.dataset.box);
    if (b) wireBoxMenuBtn(btn, b);
  });
}

/* ---------- Export: CSV + print ---------- */
function anCsvText(list) {
  const head = ["date", "jalali", "start", "end", "subject", "topic", "title", "type", "status", "completed", "correct", "total", "minutes", "actualMinutes", "usefulMinutes"];
  const q = v => '"' + String(v == null ? "" : v).replace(/"/g, '""') + '"';
  const lines = [head.join(",")];
  list.forEach(b => {
    const tr = testOf(b);
    const sd = boxStudyDay(b) || b.date;
    const st = anBoxStatus(b);
    const u = anUsefulMinutes(b);
    lines.push([sd, gregToJalali(sd).text, b.start, b.end, b.subject, b.topic || "", b.title || "",
      anBoxTypeLabel(b), t(st === "done" ? "anStatusDone" : st === "partial" ? "anStatusPartial" : "anStatusUndone"), tr.completed || 0, tr.correct || 0, b.tests_total || 0, anBoxMinutes(b), Math.round(anActualMinutes(b) * 10) / 10, u == null ? "" : Math.round(u * 10) / 10].map(q).join(","));
  });
  return "\uFEFF" + lines.join("\n");
}
function anDownloadCsv() {
  const list = anFilteredBoxes().sort(compareBoxOrder);
  const r = anRangeBounds();
  const name = "analytics-" + (r ? r.from : "nodata") + "_" + (r ? r.to : "") + ".csv";
  const blob = new Blob([anCsvText(list)], { type: "text/csv;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
}

/* ---------- Filter bar ---------- */
function anFillSelect(sel, options, value) {
  if (!sel) return;
  sel.innerHTML = options.map(o => '<option value="' + esc(o[0]) + '"' + (String(o[0]) === String(value) ? " selected" : "") + '>' + esc(o[1]) + '</option>').join('');
  // Assign only when the value exists among the options: assigning an
  // unmatched value leaves the select blank. Fall back to the first.
  if (options.some(o => String(o[0]) === String(value))) sel.value = value;
  else if (options.length) sel.value = options[0][0];
}
function anBuildFilters() {
  anFillSelect(document.getElementById("anYear"), [1404, 1405, 1406].map(y => [y, LANG === "fa" ? { 1404: "۱۴۰۴", 1405: "۱۴۰۵", 1406: "۱۴۰۶" }[y] : String(y)]), AN.year);
  anFillSelect(document.getElementById("anMonth"), [["all", t("anMonthAll")], ["aban", t("anMonthAban")], ["azar", t("anMonthAzar")]], AN.month);
  anFillSelect(document.getElementById("anWeek"), [["all", t("anWeekAll")]].concat(anWeekList().map(w => [w, gregToJalali(w).text])), AN.week);
  const fromEl = document.getElementById("anFrom"), toEl = document.getElementById("anTo");
  if (fromEl) fromEl.value = AN.from || "";
  if (toEl) toEl.value = AN.to || "";
  const subjects = [["all", t("anAllSubjects")]].concat(anSubjectList().map(s => [s, subjName(s)]));
  anFillSelect(document.getElementById("anSubject"), subjects, AN.subject);
  // v1.11.5: activity-type filter — همه / کلاس / مطالعه / تست / تکلیف / سایر
  // (user order). The old "desc" option is gone; a saved "desc" pref is
  // normalised to "all" in anLoadPrefs.
  anFillSelect(document.getElementById("anType"), [["all", t("anTypeAll")], ["class", t("anTypeClass")], ["study", t("anTypeStudy")], ["test", t("anTypeTest")], ["homework", t("anTypeHomework")], ["other", t("anTypeOther")]], AN.type);
  anFillSelect(document.getElementById("anStatus"), [["all", t("anStatusAll")], ["done", t("anStatusDone")], ["partial", t("anStatusPartial")], ["undone", t("anStatusUndone")]], AN.status);
  const exams = [["all", t("anExamAll")]].concat(allExams().map(e => [e.id, examDisplayName(e)]));
  anFillSelect(document.getElementById("anExam"), exams, AN.exam);
  const books = [["all", t("anBookAll")]].concat((TESTBOOK.books || []).map(b => [b.id, bookName(b)]));
  anFillSelect(document.getElementById("anBook"), books, AN.book);
  const chOpts = [["all", t("anChapterAll")]];
  if (AN.book !== "all") {
    const book = (TESTBOOK.books || []).find(b => b.id === AN.book);
    if (book) (book.chapters || []).forEach(ch => chOpts.push([ch.id || ch.title, chapterTitle(ch)]));
  }
  anFillSelect(document.getElementById("anChapter"), chOpts, AN.chapter);
  const note = document.getElementById("anRangeNote");
  if (note) note.textContent = t("anKpiPlanned") + ": " + anRangeLabel();
}
function anWireFilters() {
  const bind = (id, key, parse) => {
    const el = document.getElementById(id);
    if (!el || el.dataset.anWired) return;
    el.dataset.anWired = "1";
    el.addEventListener("change", () => {
      AN[key] = parse ? parse(el.value) : el.value;
      if (key === "month" || key === "week") { AN.from = ""; AN.to = ""; }
      if (key === "from" || key === "to") { AN.month = "all"; AN.week = "all"; }
      if (key === "book") AN.chapter = "all";
      if (key === "year") { AN.month = "all"; AN.week = "all"; AN.heatYear = AN.year; }
      anSavePrefs(); renderAnalytics();
    });
  };
  bind("anYear", "year", v => parseInt(v, 10) || 1405);
  bind("anMonth", "month");
  bind("anWeek", "week");
  bind("anFrom", "from");
  bind("anTo", "to");
  bind("anSubject", "subject");
  bind("anType", "type");
  bind("anStatus", "status");
  bind("anExam", "exam");
  bind("anBook", "book");
  bind("anChapter", "chapter");
  const clear = document.getElementById("anClearBtn");
  if (clear && !clear.dataset.anWired) {
    clear.dataset.anWired = "1";
    clear.addEventListener("click", () => {
      const keep = { archMonth: AN.archMonth, archPage: AN.archPage, archQuery: AN.archQuery, subj: AN.subj };
      AN = Object.assign({}, AN_DEF, keep);
      anSavePrefs(); renderAnalytics();
    });
  }
  const csv = document.getElementById("anCsvBtn");
  if (csv && !csv.dataset.anWired) {
    csv.dataset.anWired = "1";
    csv.addEventListener("click", anDownloadCsv);
  }
  const pr = document.getElementById("anPrintBtn");
  if (pr && !pr.dataset.anWired) {
    pr.dataset.anWired = "1";
    pr.addEventListener("click", () => window.print());
  }
  const ap = document.getElementById("anArchPrev");
  if (ap && !ap.dataset.anWired) {
    ap.dataset.anWired = "1";
    ap.addEventListener("click", () => {
      // Real prev/next over the archive months, clamped at the ends.
      const months = ["2026-10", "2026-11"];
      const i = Math.max(0, months.indexOf(AN.archMonth) - 1);
      AN.archMonth = months[i]; AN.archPage = 0; anSavePrefs(); renderAnalytics();
    });
  }
  const an = document.getElementById("anArchNext");
  if (an && !an.dataset.anWired) {
    an.dataset.anWired = "1";
    an.addEventListener("click", () => {
      const months = ["2026-10", "2026-11"];
      const i = Math.min(months.length - 1, months.indexOf(AN.archMonth) + 1);
      AN.archMonth = months[i]; AN.archPage = 0; anSavePrefs(); renderAnalytics();
    });
  }
  const pp = document.getElementById("anArchPrevPg");
  if (pp && !pp.dataset.anWired) {
    pp.dataset.anWired = "1";
    pp.addEventListener("click", () => { AN.archPage = Math.max(0, AN.archPage - 1); anSavePrefs(); renderAnalytics(); });
  }
  const np = document.getElementById("anArchNextPg");
  if (np && !np.dataset.anWired) {
    np.dataset.anWired = "1";
    np.addEventListener("click", () => { AN.archPage++; anSavePrefs(); renderAnalytics(); });
  }
  const sq = document.getElementById("anArchSearch");
  if (sq && !sq.dataset.anWired) {
    sq.dataset.anWired = "1";
    let timer = null;
    sq.addEventListener("input", () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        AN.archQuery = sq.value; AN.archPage = 0; anSavePrefs();
        anRenderArchive(); // re-render only the table, so typing never loses focus
      }, 250);
    });
  }
}

/* ---------- Entry point (called from renderAll, guarded) ---------- */
function renderAnalytics() {
  if (!document.getElementById("tab-analytics")) return;
  anWireFilters();
  anBuildFilters();
  const list = anFilteredBoxes();
  const agg = anAgg(list);
  anRenderKpis(list, agg);
  anRenderDaily();
  anRenderPvu();
  anRenderCharts(list, agg);
  anRenderQuality();
  anRenderWeek();
  anRenderTrends();
  anRenderHeatmap(list);
  anRenderSubject(list);
  anRenderSubjCompare();
  anRenderLagging();
  anRenderCompare();
  anRenderInsights(list);
  anRenderWeeklyReport();
  anRenderArchive();
  anRenderReviewPast();
}
// NOTE: no eager call here — loadAll() is still fetching when this script
// parses (state.exams is null until ensureExams runs). The first render
// comes from renderAll() after the data loads, and every render after that.
