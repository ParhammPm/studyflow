// Konkur local site — frontend logic.
// Data: data.json (318 real boxes). Test books: /api/testbook (v2: the four
// REAL books from the user's own TOCs — شیمی بتمن، حسابان IQ، فیزیک الگو،
// گسسته IQ — plus TESTBOOK.legacy for old topics with no new counterpart).
// State: /api/state on the local server (ticks, test counts, edits, subjects,
// theme, daysDone, topicLinks) saved to state.json on disk — in the DATA
// directory outside the app folder (%APPDATA%\KonkurApp on Windows), with
// automatic versioned backups + optional B2 cloud sync (see server.py).
// ONE source of truth: book topic numbers are COMPUTED at render time from
// state.tests (daily boxes) + testbook manual_solved. Nothing is stored twice.
// Exam-topic -> book-section links are MANUAL only: topic.bookLinks inside
// state.exams, set by the user in the exam budget view, never guessed.
"use strict";

const FA = (n) => fmtNum(n);
const FA_PCT = (x) => fmtPct(x);

// Jalali: 1 Aban 1405 = 2026-10-23 (Friday); 1 Azar 1405 = 2026-11-22 (Sunday).
// Aban and Azar have 30 days each.
function gregToJalali(dateStr) { return jalaliText(dateStr); }
function weekdayFa(dateStr) { return weekdayName(dateStr); }
function isoOf(d) {
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}
function addDays(iso, n) {
  const d = new Date(iso + "T12:00:00"); d.setDate(d.getDate() + n); return isoOf(d);
}
// ---------- Study day (v1.9.0) ----------
// A study day runs 03:30:00 -> 03:29:59 the next day, Asia/Tehran.
// EVERY date-dependent part of the app goes through these helpers —
// nothing computes "today" or a day bucket on its own. (The one
// deliberate exception is the exam countdown: exams are calendar events
// with a clock time, so they count down from the real calendar date —
// see realTodayIso() below. No system clock or timezone is changed;
// this is application logic only, via Intl with timeZone Asia/Tehran.)
const STUDY_DAY_START_MIN = 3 * 60 + 30; // 03:30
function tehranParts(d) {
  const fmt = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Tehran", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" });
  const p = {};
  fmt.formatToParts(d).forEach(x => { p[x.type] = x.value; });
  return { iso: p.year + "-" + p.month + "-" + p.day, hh: +p.hour, mm: +p.minute };
}
// Study day of a timestamp: its Tehran calendar date when the time is
// >= 03:30, else the previous Tehran calendar date. Verified against the
// user's examples: 24 Aban 03:29 -> 23 Aban; 24 Aban 03:30 -> 24 Aban;
// 25 Aban 02:00 / 03:29 -> 24 Aban; 25 Aban 03:30 -> 25 Aban.
function studyDayOf(d) {
  const dt = d instanceof Date ? d : new Date(d);
  const p = tehranParts(dt);
  return (p.hh * 60 + p.mm) >= STUDY_DAY_START_MIN ? p.iso : addDays(p.iso, -1);
}
function timeToMinutes(t) {
  const parts = String(t || "00:00").split(":");
  return (parseInt(parts[0], 10) || 0) * 60 + (parseInt(parts[1], 10) || 0);
}
// Study day of a box: boxes carry a stored calendar date + start time.
// A box starting at/after 03:30 belongs to its calendar date; a box
// starting before 03:30 (e.g. 25 Aban 00:30) belongs to the day before
// (study day 24 Aban) — so it renders in that study day's view.
function boxStudyDay(b) {
  if (!b || !b.date) return null;
  return timeToMinutes(b.start) >= STUDY_DAY_START_MIN ? b.date : addDays(b.date, -1);
}
// A timer/manual session is attributed to the study day its START falls
// in — even when the session crosses 03:30 (documented rule; actual
// minutes themselves are stored per box, so charts bucket by the box).
function timerSessionStudyDay(s) {
  if (!s || !s.start) return null;
  return studyDayOf(new Date(s.start));
}
// "Today" is the STUDY day, clamped to the program range
// 2026-10-24..2026-12-18 (the programme only spans those dates).
function todayIso() {
  const s = studyDayOf(new Date());
  if (s < "2026-10-24") return "2026-10-24";
  if (s > "2026-12-18") return "2026-12-18";
  return s;
}
const TODAY = todayIso();
const TOMORROW = addDays(TODAY, 1);
function minutesBetween(start, end) {
  const [sh, sm] = start.split(":").map(Number);
  const [eh, em] = end.split(":").map(Number);
  return Math.max(0, (eh * 60 + em) - (sh * 60 + sm));
}
function fmtDuration(mins) {
  if (LANG === "en") return fmtDurationEn(mins);
  const h = Math.floor(mins / 60), m = mins % 60;
  if (h === 0) return m + " دقیقه";
  if (m === 0) return h + " ساعت";
  return h + " ساعت و " + m + " دقیقه";
}
function fmtDurationEn(mins) {
  const h = Math.floor(mins / 60), m = mins % 60;
  if (h === 0) return m + "m";
  if (m === 0) return h + "h";
  return h + "h " + m + "m";
}
// Fixed per-subject colours (Design System v1.9.0): the same subject
// always gets the same colour on every surface — box side bars, book
// cards/chips, subject cards, Overview bars, analytics chips and chart
// fills. Unknown subjects fall back to the neutral "other" colour.
const SUBJECT_CLASS = {
  "حسابان": "subj-math", "ریاضی": "subj-math", "ریاضیات": "subj-math",
  "فیزیک": "subj-physics",
  "شیمی": "subj-chemistry",
  "هندسه": "subj-geometry",
  "گسسته": "subj-discrete",
  "ادبیات": "subj-literature", "فارسی": "subj-literature",
  "عربی": "subj-arabic",
  "دینی": "subj-dini",
  "زبان": "subj-english", "زبان انگلیسی": "subj-english",
};
function colorClass(subject) {
  return SUBJECT_CLASS[subject] || "subj-other";
}
function esc(s) {
  return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

let DATA = { meta: {}, boxes: [] };
let TESTBOOK = { books: [] };
let EXAMS = { exams: [] };
let state = { done: {}, tests: {}, tests_total: {}, subjects: [], theme: "dark", lang: "fa",
              custom_boxes: [], deleted: [], edits: {}, daysDone: {}, topicLinks: {},
              examResults: {},
              exams: null, examsRemoved: [],
              assignments: null, assignmentsRemoved: [],
              boxBookLinks: {},
              actualMinutes: {}, timerSessions: [], activeTimer: null };
let selectedDay = TODAY;
let openBookId = null;
let saveTimer = null;
let tbTimer = null;

// ---------- Language (i18n): FA / EN, RTL / LTR, persisted ----------
// Static texts are marked with data-i18n / data-i18n-ph in index.html.
// Dynamic strings are rendered through t() everywhere below.
function applyStaticI18n() {
  document.getElementById("pageTitle").textContent = t("appTitle");
  document.getElementById("savedPill").textContent = t("savedAuto");
  document.getElementById("resetBtn").textContent = t("resetAll");
  document.getElementById("resetBtn").title = t("resetAll");
  document.getElementById("statsBtn").title = t("statsTitle");
  document.getElementById("themeBtn").title = t("themeTitle");
  document.getElementById("langBtn").title = t("langTitle");
  document.getElementById("langBtn").innerHTML =
    '<span class="' + (LANG === "fa" ? "on" : "off") + '">FA</span> | <span class="' +
    (LANG === "en" ? "on" : "off") + '">EN</span>';
  document.querySelectorAll("[data-i18n]").forEach(el => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll("[data-i18n-ph]").forEach(el => { el.placeholder = t(el.dataset.i18nPh); });
  document.getElementById("keyStatus").textContent = t("keyStatusChecking");
  const bkPill = document.getElementById("backupPill");
  if (bkPill && !bkPill.dataset.live) bkPill.textContent = t("bkPillLocal");
  refreshAsgFormLabels();
  if (typeof refreshKeyStatus === "function") refreshKeyStatus();
  if (typeof refreshGeminiModel === "function") refreshGeminiModel();
  if (typeof refreshGmTestPanel === "function") refreshGmTestPanel();
}
function applyLang(lang, save) {
  const l = setLang(lang);
  state.lang = l;
  try { localStorage.setItem("konkur-lang", l); } catch (e) {}
  applyStaticI18n();
  if (save) saveState();
  renderAll();
}
function toggleLang() { applyLang(LANG === "fa" ? "en" : "fa", true); }
document.getElementById("langBtn").addEventListener("click", toggleLang);
// Re-label the assignment-form selects after a language switch. Values stay
// Persian (they are data keys); only the visible option text translates.
function refreshAsgFormLabels() {
  const subjSel = document.getElementById("asgSubject");
  if (subjSel && subjSel.options.length) {
    Array.from(subjSel.options).forEach(o => { o.textContent = subjName(o.value); });
  }
  if (typeof asgFillCascade === "function") asgFillCascade();
}

// ---------- Test-book mapping (daily box -> book topic) ----------
// Leaves are the real TOC sections (مبحث / بخش / پنجره). Legacy entries are
// old v1 topics with no counterpart in the new books (e.g. فیزیک دهم/یازدهم):
// they live in TESTBOOK.legacy so their solved counts are never lost.
function topicById(id) {
  for (const book of TESTBOOK.books || []) {
    for (const ch of book.chapters || []) {
      for (const t of ch.topics || []) {
        if (t.id === id) return { book, chapter: ch, topic: t, legacy: false };
      }
    }
  }
  const lg = (TESTBOOK.legacy || {})[id];
  if (lg) {
    const book = (TESTBOOK.books || []).find(b => b.id === lg.bookId) || null;
    return { book, chapter: null, topic: lg, legacy: true };
  }
  return null;
}
// Daily box -> first leaf of the matching section (درس / فصل). Order matters:
// ترمودینامیک is checked before دینامیک, pH/اسید before the generic فصل rules.
// Returns a leaf id, a legacy id (فیزیک دهم/یازدهم has no book here), or null.
function autoTopicId(b) {
  const text = (b.subject || "") + " " + (b.title || "") + " " + (b.topic || "");
  const has = (re) => re.test(text);
  if (b.subject === "شیمی" || has(/شیمی/)) {
    if (has(/pH|اسید|باز|خورندگی/)) return "chem-c7-s3";
    if (has(/برقکافت|آبکاری|الکترون|گالوانی|سلول سوختی|الکتروشیمی/)) return "chem-c8-s1";
    if (has(/فصل ۳.*آب|آب، آهنگ|فصل ۳ دهم/)) return "chem-c3-s1";
    if (has(/فصل ۱.*دهم|کیهان/)) return "chem-c1-s1";
    if (has(/فصل ۲.*دهم|ردپای گاز/)) return "chem-c2-s1";
    if (has(/فصل ۳.*دوازدهم|جلوه‌ای از هنر/)) return "chem-c9-s1";
    if (has(/فصل ۴.*دوازدهم|آینده/)) return "chem-c10-s1";
    if (has(/فصل ۱.*یازدهم|قدر هدایای/)) return "chem-c4-s1";
    if (has(/فصل ۲.*یازدهم|غذای سالم/)) return "chem-c5-s1";
    if (has(/فصل ۳.*یازدهم|پوشاک/)) return "chem-c6-s1";
    if (has(/فصل ۱/)) return "chem-c7-s1";
    if (has(/فصل ۲/)) return "chem-c8-s1";
    if (has(/فصل ۳/)) return "chem-c9-s1";
    if (has(/فصل ۴/)) return "chem-c10-s1";
    return null;
  }
  if (b.subject === "حسابان" || has(/حسابان/)) {
    if (has(/مشتق/)) return "calc-c8-l80";
    if (has(/مثلثات/)) return "calc-c6-l51";
    if (has(/حدهای نامتناهی|حد در بی‌نهایت/)) return "calc-c7-l72";
    if (has(/حد/)) return "calc-c7-l67";
    if (has(/معادلات گویا|رادیکالی/)) return "calc-c3-l24";
    if (has(/نمایی|لگاریتم/)) return "calc-c5-l38";
    if (has(/الگو|دنباله/)) return "calc-c10-l104";
    if (has(/توان گویا/)) return "calc-c11-l110";
    if (has(/تابع/)) return "calc-c1-l1";
    return null;
  }
  if (b.subject === "فیزیک" || has(/فیزیک/)) {
    if (has(/ترمودینامیک/)) return "legacy-phys-thermo"; // before دینامیک: ترمودینامیک contains دینامیک
    if (has(/دینامیک|حرکت دایره‌ای/)) return "phys-c2-w1";
    if (has(/برهم‌کنش‌های موج/)) return "phys-c4-w1";
    if (has(/شتاب ثابت|سقوط آزاد|حرکت‌شناسی|حرکت بر خط|جمع‌بندی حرکت/)) return "phys-c1-w1";
    if (has(/دما و گرما|گرما/)) return "legacy-phys-heat";
    if (has(/الکتریسیته ساکن/)) return "legacy-phys-static";
    if (has(/جریان الکتریکی|مدار/)) return "legacy-phys-circuit";
    if (has(/مغناطیس/)) return "legacy-phys-magnet";
    if (has(/القا/)) return "legacy-phys-induction";
    if (has(/نوسان|موج/)) return "phys-c3-w1";
    if (has(/اتمی/)) return "phys-c5-w1";
    if (has(/هسته‌ای/)) return "phys-c6-w1";
    if (has(/فشار|ویژگی.*مواد/)) return "legacy-phys-materials";
    if (has(/کار و انرژی|کار، انرژی/)) return "legacy-phys-work";
    return null;
  }
  if (b.subject === "گسسته" || has(/گسسته/)) {
    if (has(/نظریه اعداد/)) return "disc-c1-s1";
    if (has(/گراف/)) return "disc-c2-s1";
    if (has(/ترکیبیات|شمارش/)) return "disc-c3-s1";
    return null; // احتمال / آمار live in pending chapters 4–8 (no sections yet)
  }
  return null;
}
function linkedTopicId(b) {
  const override = (state.topicLinks || {})[b.id];
  if (override === "none") return null;
  if (override) return override;
  return autoTopicId(b);
}
function topicSolved(topicId) {
  const found = topicById(topicId);
  let solved = found ? (found.topic.manual_solved || 0) : 0;
  allBoxes().forEach(b => {
    if (linkedTopicId(b) === topicId) solved += (testOf(b).completed || 0);
  });
  return solved;
}
function topicCorrect(topicId) {
  const found = topicById(topicId);
  let correct = found ? (found.topic.manual_correct || 0) : 0;
  allBoxes().forEach(b => {
    if (linkedTopicId(b) === topicId) correct += (testOf(b).correct || 0);
  });
  return correct;
}
function topicWrong(topicId) {
  const found = topicById(topicId);
  let wrong = found ? (found.topic.manual_wrong || 0) : 0;
  allBoxes().forEach(b => {
    if (linkedTopicId(b) === topicId) {
      const tr = testOf(b);
      wrong += Math.max(0, (tr.completed || 0) - (tr.correct || 0));
    }
  });
  return wrong;
}
function topicStats(topic) {
  const solved = topicSolved(topic.id);
  const total = topic.tests_total || 0;
  const correct = topicCorrect(topic.id);
  const wrong = topicWrong(topic.id);
  return { solved, total, correct, wrong,
           unanswered: total ? Math.max(0, total - correct - wrong) : null,
           remaining: total ? Math.max(0, total - solved) : null,
           pct: total ? Math.min(100, Math.round(solved / total * 100)) : null,
           acc: solved ? Math.round(correct / solved * 100) : null };
}
function bookStats(book) {
  let solved = 0, total = 0;
  (book.chapters || []).forEach(ch => (ch.topics || []).forEach(t => {
    const s = topicStats(t); solved += s.solved; total += s.total;
  }));
  // Legacy topics of this book (old v1 topics with no new chapter) count too.
  Object.values(TESTBOOK.legacy || {}).forEach(lg => {
    if (lg.bookId !== book.id) return;
    const s = topicStats(lg); solved += s.solved; total += s.total;
  });
  return { solved, total, remaining: total ? Math.max(0, total - solved) : null,
           pct: total ? Math.min(100, Math.round(solved / total * 100)) : null };
}

// ---------- Boxes / state ----------
function allBoxes() {
  const deleted = new Set(state.deleted || []);
  const list = DATA.boxes.filter(b => !deleted.has(b.id)).map(b => {
    const edit = (state.edits || {})[b.id] || {};
    return Object.assign({}, b, edit, {
      tests_total: (state.tests_total && state.tests_total[b.id] != null)
        ? state.tests_total[b.id] : b.tests_total
    });
  });
  return list.concat(state.custom_boxes || []);
}
function isDone(b) { return !!state.done[b.id]; }
// Single shared counter: setting a box's completed/correct tests here is the
// ONLY place the number is stored. Assignments and book topics only READ it.
function setBoxTests(boxId, field, val) {
  const cur = (state.tests || {})[boxId] || { completed: 0, correct: 0 };
  cur[field] = Math.max(0, parseInt(val, 10) || 0);
  if (cur.correct > cur.completed) cur.correct = cur.completed;
  state.tests[boxId] = cur;
  saveState(); renderAll();
}
function testOf(b) { return (state.tests || {})[b.id] || { completed: 0, correct: 0 }; }
function accuracy(b) {
  const tr = testOf(b);
  if (!tr.completed) return null;
  return (tr.correct / tr.completed) * 100;
}
function isDayDone(date) {
  if ((state.daysDone || {})[date]) return true;
  const boxes = allBoxes().filter(b => boxStudyDay(b) === date);
  return boxes.length > 0 && boxes.every(isDone);
}
function setDayDone(date, val) {
  state.daysDone = state.daysDone || {};
  if (val) state.daysDone[date] = true; else delete state.daysDone[date];
  saveState(); renderAll();
}

// ---------- Test-book v1 -> v2 migration (one-time, on first load) ----------
// v1 had 3 books with syllabus-derived chapter-level topics; v2 has the four
// real books with leaf sections. Non-zero counts are carried over:
// chapter-level calc/chem counts -> the first leaf of the matching section,
// فیزیک دهم/یازدهم topics (no book here) -> TESTBOOK.legacy so nothing is lost.
// The v2 seed lives in public/testbook-seed.json; after migration the v2
// file is saved back to testbook.json immediately.
const V1_LEAF_MAP = {
  "calc-function": "calc-c1-l1", "calc-trig": "calc-c6-l51",
  "calc-limit": "calc-c7-l67", "calc-limit12": "calc-c7-l72",
  "calc-equation": "calc-c3-l24", "calc-exp": "calc-c5-l38",
  "calc-sequence": "calc-c10-l104", "calc-power": "calc-c11-l110",
  "calc-derivative": "calc-c8-l80",
  "chem1-ch1": "chem-c1-s1", "chem1-ch2": "chem-c2-s1", "chem1-ch3": "chem-c3-s1",
  "chem2-ch1": "chem-c4-s1", "chem2-ch2": "chem-c5-s1", "chem2-ch3": "chem-c6-s1",
  "chem3-ch1": "chem-c7-s1", "chem3-ch2": "chem-c8-s1",
  "chem3-ch3": "chem-c9-s1", "chem3-ch4": "chem-c10-s1"
};
const V1_LEGACY = {
  "phys-thermo": "ترمودینامیک (دهم)", "phys-heat": "دما و گرما (دهم)",
  "phys-static": "الکتریسیته ساکن (یازدهم)", "phys-circuit": "مدار و جریان الکتریکی (یازدهم)",
  "phys-magnet": "مغناطیس (یازدهم)", "phys-induction": "القای الکترومغناطیسی (یازدهم)",
  "phys-materials": "فشار و ویژگی‌های مواد (دهم)", "phys-work": "کار و انرژی (دهم)",
  "phys-measure": "اندازه‌گیری (دهم)"
};
function migrateTestbookV1(old, seed) {
  const out = JSON.parse(JSON.stringify(seed));
  out.legacy = out.legacy || {};
  const leafById = {};
  (out.books || []).forEach(b => (b.chapters || []).forEach(ch =>
    (ch.topics || []).forEach(tp => { leafById[tp.id] = tp; })));
  (old.books || []).forEach(b => (b.chapters || []).forEach(ch =>
    (ch.topics || []).forEach(tp => {
      const counts = {
        tests_total: tp.tests_total || 0, manual_solved: tp.manual_solved || 0,
        manual_correct: tp.manual_correct || 0, manual_wrong: tp.manual_wrong || 0
      };
      if (!counts.tests_total && !counts.manual_solved && !counts.manual_correct && !counts.manual_wrong) return;
      const leafId = V1_LEAF_MAP[tp.id];
      if (leafId && leafById[leafId]) {
        const leaf = leafById[leafId];
        leaf.tests_total += counts.tests_total;
        leaf.manual_solved += counts.manual_solved;
        leaf.manual_correct += counts.manual_correct;
        leaf.manual_wrong += counts.manual_wrong;
        return;
      }
      const lid = "legacy-" + String(tp.id || "").replace(/^legacy-/, "");
      out.legacy[lid] = {
        id: lid, bookId: b.id || "", title: V1_LEGACY[tp.id] || tp.title || tp.id,
        tests_total: counts.tests_total, manual_solved: counts.manual_solved,
        manual_correct: counts.manual_correct, manual_wrong: counts.manual_wrong,
        mastery: "", status: "", note: ""
      };
    })));
  return out;
}

async function loadAll() {
  const [dRes, sRes, tRes, eRes] = await Promise.all([
    fetch("data.json"), fetch("/api/state"), fetch("/api/testbook"), fetch("exams.json")
  ]);
  DATA = await dRes.json();
  if (sRes.ok) state = Object.assign(state, await sRes.json());
  state.daysDone = state.daysDone || {};
  state.topicLinks = state.topicLinks || {};
  state.examResults = state.examResults || {};
  if (tRes.ok) {
    const tb = await tRes.json();
    if (!tb.version || tb.version < 2) {
      // A v1 testbook.json is on disk (the user's own counts): migrate it
      // against the v2 seed and save the migrated file back at once.
      try {
        const seedRes = await fetch("testbook-seed.json");
        if (seedRes.ok) {
          TESTBOOK = migrateTestbookV1(tb, await seedRes.json());
          saveTestbook();
        } else TESTBOOK = tb;
      } catch (e) { TESTBOOK = tb; }
    } else TESTBOOK = tb;
  }
  if (eRes.ok) EXAMS = await eRes.json();
  ensureExams();
  if (normalizeExamLinks() | normalizeBoxBookLinks() | normalizeAssignmentLinks()) saveState(); // persist a legacy-link migration at once
  // MIGRATION (one-time): assignments did not exist before. Derive them from the
  // existing daily test boxes — one assignment per test box, keyed by the SAME
  // box id. No counts are copied: done/tests live only in state.done/state.tests.
  if (!Array.isArray(state.assignments)) {
    state.assignments = DATA.boxes.filter(b => b.is_test).map(b => ({
      id: "asg-" + b.id, boxId: b.id, type: "test"
    }));
    state.assignmentsRemoved = state.assignmentsRemoved || [];
    saveState();
  }
  state.assignmentsRemoved = state.assignmentsRemoved || [];
  document.documentElement.setAttribute("data-theme", state.theme || "dark");
  const savedLang = state.lang || (() => { try { return localStorage.getItem("konkur-lang"); } catch (e) { return null; } })() || "fa";
  applyLang(savedLang);
  refreshKeyStatus();
  refreshGeminiModel();
  refreshBackupStatus();
  setInterval(() => { refreshBackupStatus(); renderCalendarPanel(); }, 60000);
  asgInitForm();
  initRouting();
}
function saveState() {
  const pill = document.getElementById("savedPill");
  pill.textContent = t("saving");
  clearTimeout(saveTimer);
  saveTimer = setTimeout(async () => {
    try {
      const res = await fetch("/api/state", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(state)
      });
      pill.textContent = res.ok ? t("savedAuto") : t("saveFailed");
      if (res.ok) refreshBackupStatus();
    } catch (e) { pill.textContent = t("saveFailedServer"); }
  }, 400);
}
function saveTestbook() {
  const pill = document.getElementById("savedPill");
  pill.textContent = t("saving");
  clearTimeout(tbTimer);
  tbTimer = setTimeout(async () => {
    try {
      const res = await fetch("/api/testbook", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(TESTBOOK)
      });
      pill.textContent = res.ok ? t("savedAuto") : t("saveFailed");
      if (res.ok) refreshBackupStatus();
    } catch (e) { pill.textContent = t("saveFailedServer"); }
  }, 400);
}

// ---------- Real study time (v1.8.0): per-box timer ----------
// state.actualMinutes[boxId] = finished SECONDS (timer stops + manual
// entries). state.timerSessions = the session records behind that total.
// state.activeTimer = {boxId, startedAt (ms epoch, current running
// stretch), accumulated (seconds banked in this session from pauses),
// sessionStartedAt (ms epoch), status: "running"|"paused"} — stored in
// state.json on the server, so a server restart resumes it honestly from
// its stored start (the chip tooltip says so; nothing is silently closed).
function timerLiveSecondsForBox(boxId) {
  const at = state.activeTimer;
  if (!at || at.boxId !== boxId) return 0;
  if (at.status === "paused") return at.accumulated || 0;
  return (at.accumulated || 0) + Math.max(0, Math.floor((Date.now() - (at.startedAt || Date.now())) / 1000));
}
function timerTotalSeconds(boxId) {
  return ((state.actualMinutes || {})[boxId] || 0) + timerLiveSecondsForBox(boxId);
}
// ---- Actual vs scheduled time on every box (v1.9.0) ----
// Never invents a value: a box with no recorded time shows an honest
// empty state ("—"), not 0 presented as studied. The live timer counts
// while it runs; stopping the timer or saving a manual value re-renders
// the box in place (renderAll, no page reload).
function hasActualMinutes(b) {
  if (!b) return false;
  if (((state.actualMinutes || {})[b.id] || 0) > 0) return true;
  return !!(state.activeTimer && state.activeTimer.boxId === b.id);
}
function actualVsHtml(b) {
  const sched = minutesBetween(b.start || "00:00", b.end || "00:00");
  const actual = Math.round(timerTotalSeconds(b.id) / 60);
  const has = hasActualMinutes(b);
  const cls = !has ? "tm-vs--none" : (actual >= sched ? "tm-vs--ok" : "tm-vs--low");
  return '<span class="tm-vs ' + cls + '">' + t("tmActualVs", { a: has ? fmtDuration(actual) : "—", s: fmtDuration(sched) }) + '</span>';
}
function timerStopCurrent() {
  const at = state.activeTimer;
  if (!at) return;
  const secs = timerLiveSecondsForBox(at.boxId);
  if (secs > 0) {
    state.actualMinutes = state.actualMinutes || {};
    state.actualMinutes[at.boxId] = (state.actualMinutes[at.boxId] || 0) + secs;
    state.timerSessions = state.timerSessions || [];
    state.timerSessions.push({ boxId: at.boxId, start: at.sessionStartedAt ? new Date(at.sessionStartedAt).toISOString() : null, end: new Date().toISOString(), seconds: secs, source: "timer" });
    if (state.timerSessions.length > 500) state.timerSessions = state.timerSessions.slice(-500);
  }
  state.activeTimer = null;
}
function timerStart(boxId) {
  if (state.activeTimer && state.activeTimer.boxId === boxId && state.activeTimer.status === "running") return;
  if (state.activeTimer) timerStopCurrent(); // one timer at a time: fold the old one in
  const now = Date.now();
  state.activeTimer = { boxId, startedAt: now, accumulated: 0, sessionStartedAt: now, status: "running" };
  saveState(); renderAll();
}
function timerPause() {
  const at = state.activeTimer;
  if (!at || at.status !== "running") return;
  at.accumulated = timerLiveSecondsForBox(at.boxId);
  at.startedAt = null; at.status = "paused";
  saveState(); renderAll();
}
function timerResume() {
  const at = state.activeTimer;
  if (!at || at.status !== "paused") return;
  at.startedAt = Date.now(); at.status = "running";
  saveState(); renderAll();
}
function timerStop() { if (!state.activeTimer) return; timerStopCurrent(); saveState(); renderAll(); }
function timerAddManual(boxId, mins) {
  mins = Math.max(0, Math.round(parseFloat(mins) || 0));
  if (!mins) return;
  state.actualMinutes = state.actualMinutes || {};
  state.actualMinutes[boxId] = (state.actualMinutes[boxId] || 0) + mins * 60;
  state.timerSessions = state.timerSessions || [];
  state.timerSessions.push({ boxId, start: new Date().toISOString(), end: new Date().toISOString(), seconds: mins * 60, source: "manual" });
  if (state.timerSessions.length > 500) state.timerSessions = state.timerSessions.slice(-500);
  saveState(); renderAll();
}
function fmtClock(totalSecs) {
  const mm = Math.floor(totalSecs / 60), ss = totalSecs % 60;
  return String(mm).padStart(2, "0") + ":" + String(ss).padStart(2, "0");
}
// Topbar chip + visible per-box live counters, updated every second
// WITHOUT a full re-render (which would steal input focus).
function updateTimerDisplays() {
  const chip = document.getElementById("timerChip");
  const at = state.activeTimer;
  if (chip) {
    if (!at) { chip.hidden = true; }
    else {
      chip.hidden = false;
      const b = allBoxes().find(x => x.id === at.boxId);
      const el = document.getElementById("timerChipText");
      if (el) el.textContent = (at.status === "paused" ? t("tmPaused") + " · " : "") + (b ? b.title : at.boxId) + " · " + fmtClock(timerLiveSecondsForBox(at.boxId));
      chip.title = t("tmResumedNote");
    }
  }
  document.querySelectorAll("[data-tm-live]").forEach(el => {
    el.textContent = fmtClock(timerLiveSecondsForBox(el.dataset.tmLive));
  });
}
setInterval(updateTimerDisplays, 1000);
document.getElementById("timerChipStop").addEventListener("click", () => timerStop());

function renderAll() {
  renderSummary(); renderDashboard(); renderCalendar(); renderRemaining();
  renderOverview(); renderSubjectStats(); renderAssignments(); renderTestbookTab();
  renderExams();
  if (typeof renderAnalytics === "function") renderAnalytics(); // analytics.js (loaded after app.js)
  if (currentTab === "backup") renderBackup();
  if (openBookId) renderBookView(openBookId);
}

// ---- Summary ----
function renderSummary() {
  const boxes = allBoxes();
  const done = boxes.filter(isDone).length;
  const tests = boxes.reduce((s, b) => s + (testOf(b).completed || 0), 0);
  document.getElementById("summaryLine").innerHTML =
    t("summaryLine", { done: FA(done), total: FA(boxes.length), tests: FA(tests) });
}

// ---- Day tick control (shared by dashboard + calendar) ----
function dayTickEl(date) {
  const done = isDayDone(date);
  const wrap = document.createElement("label");
  wrap.className = "day-tick" + (done ? " on" : "");
  wrap.innerHTML = '<input type="checkbox" ' + (done ? "checked" : "") + '> ' +
    '<span>' + (done ? t("dayCompleteDone") : t("dayComplete")) + "</span>";
  wrap.querySelector("input").addEventListener("change", (e) => {
    e.stopPropagation();
    setDayDone(date, e.target.checked);
  });
  return wrap;
}

// ---- Part card (screenshot style) ----
function partCard(b, idx) {
  const tr = testOf(b);
  const acc = accuracy(b);
  const link = linkedTopicId(b);
  const linkInfo = link && topicById(link);
  const div = document.createElement("div");
  div.className = "part " + colorClass(b.subject) + (isDone(b) ? " done" : "");
  div.innerHTML =
    '<div class="part-top">' +
      '<input type="checkbox" ' + (isDone(b) ? "checked" : "") + ' aria-label="' + t("fDone") + '">' +
      '<div style="flex:1"><div class="part-title">' + t("partWord") + FA(idx + 1) + ' — ' + esc(b.title) + '</div>' +
      '<div class="part-time">' + esc(b.start) + ' – ' + esc(b.end) + ' · ' + esc(subjName(b.subject)) +
      (linkInfo ? ' · ' + esc(topicTitle(linkInfo.topic)) : "") + '</div></div>' +
    '</div>' +
    '<div class="tests-label">' + t("testsPractice") + '</div>' +
    '<div class="tests-row">' +
      '<label>' + t("completedLbl") + '<input type="number" min="0" class="t-completed" value="' + tr.completed + '"></label>' +
      '<label>' + t("correctLbl") + '<input type="number" min="0" class="t-correct" value="' + tr.correct + '"></label>' +
      '<label>' + t("totalTestsInput") + '<input type="number" min="0" class="t-total" value="' + (b.tests_total || 0) + '" title="' + t("totalTestsHint") + '"></label>' +
    '</div>' +
    '<div class="acc-line"><span>' + t("testsLine", { c: FA(tr.completed), r: FA(tr.correct) }) + '</span>' +
    '<span class="pct">' + (acc == null ? "—" : FA_PCT(acc)) + '</span></div>' +
    '<div class="progress"><div style="width:' + (acc == null ? 0 : acc) + '%"></div></div>' +
    '<div class="timer-row">' +
      '<span class="tm-actual">' + actualVsHtml(b) +
      (state.activeTimer && state.activeTimer.boxId === b.id ? ' · <span class="tm-live" data-tm-live="' + b.id + '">' + fmtClock(timerLiveSecondsForBox(b.id)) + '</span>' : '') + '</span>' +
      (state.activeTimer && state.activeTimer.boxId === b.id
        ? (state.activeTimer.status === "running"
          ? '<button class="btn tm-pause">' + t("tmPause") + '</button><button class="btn tm-stop">' + t("tmStop") + '</button>'
          : '<button class="btn tm-resume">' + t("tmResume") + '</button><button class="btn tm-stop">' + t("tmStop") + '</button>')
        : '<button class="btn btn-lime tm-start">' + t("tmStart") + '</button>') +
      '<label class="tm-manual">' + t("tmManualLabel") + ' <input type="number" min="0" class="tm-mins" placeholder="0"></label>' +
      '<button class="btn tm-add">' + t("tmAddBtn") + '</button>' +
    '</div>' +
    genericLinkRowHtml(boxBookLinks(b.id), "box:" + b.id) +
    '<div class="part-actions">' +
      '<button class="edit-btn">' + t("editBtn") + '</button>' +
      '<button class="del-btn">' + t("delBtn") + '</button>' +
    '</div>';
  div.querySelector('input[type="checkbox"]').addEventListener("change", (e) => {
    state.done[b.id] = e.target.checked;
    if (!e.target.checked) delete state.done[b.id];
    saveState(); renderAll();
  });
  const setTest = (field, val) => setBoxTests(b.id, field, val);
  div.querySelector(".t-completed").addEventListener("change", (e) => setTest("completed", e.target.value));
  div.querySelector(".t-correct").addEventListener("change", (e) => setTest("correct", e.target.value));
  div.querySelector(".t-total").addEventListener("change", (e) => {
    state.tests_total[b.id] = Math.max(0, parseInt(e.target.value, 10) || 0);
    saveState(); renderAll();
  });
  const tmStartBtn = div.querySelector(".tm-start");
  if (tmStartBtn) tmStartBtn.addEventListener("click", () => timerStart(b.id));
  const tmPauseBtn = div.querySelector(".tm-pause");
  if (tmPauseBtn) tmPauseBtn.addEventListener("click", timerPause);
  const tmResumeBtn = div.querySelector(".tm-resume");
  if (tmResumeBtn) tmResumeBtn.addEventListener("click", timerResume);
  const tmStopBtn = div.querySelector(".tm-stop");
  if (tmStopBtn) tmStopBtn.addEventListener("click", timerStop);
  div.querySelector(".tm-add").addEventListener("click", () => {
    const inp = div.querySelector(".tm-mins");
    timerAddManual(b.id, inp ? inp.value : 0);
  });
  wireOwnerLinkRow(div, "box:" + b.id,
    () => boxBookLinks(b.id),
    (entries) => {
      state.boxBookLinks = state.boxBookLinks || {};
      if (entries.length) state.boxBookLinks[b.id] = entries;
      else delete state.boxBookLinks[b.id];
    });
  div.querySelector(".edit-btn").addEventListener("click", () => openEditBox(b));
  div.querySelector(".del-btn").addEventListener("click", () => {
    if (!confirm(t("delBoxConfirm"))) return;
    if (b.id.startsWith("custom-")) {
      state.custom_boxes = (state.custom_boxes || []).filter(x => x.id !== b.id);
    } else {
      state.deleted = (state.deleted || []).concat([b.id]);
    }
    if (state.boxBookLinks) delete state.boxBookLinks[b.id];
    if (Array.isArray(state.assignments)) {
      state.assignments = state.assignments.filter(a => a.boxId !== b.id);
    }
    saveState(); renderAll();
  });
  return div;
}

// ---- Edit modal (box: title, subject, topic link, date, times, tests, note, done) ----
let editingBoxId = null;
function topicSelectOptions(selected) {
  let html = '<option value="auto"' + (selected === "auto" || !selected ? " selected" : "") + '>' + t("fAuto") + '</option>' +
    '<option value="none"' + (selected === "none" ? " selected" : "") + '>' + t("fNoLink") + '</option>';
  (TESTBOOK.books || []).forEach(book => {
    html += '<optgroup label="' + esc(bookName(book)) + '">';
    (book.chapters || []).forEach(ch => (ch.topics || []).forEach(tp => {
      html += '<option value="' + tp.id + '"' + (selected === tp.id ? " selected" : "") + '>' +
        esc(chapterTitle(ch) + " — " + topicTitle(tp)) + "</option>";
    }));
    html += "</optgroup>";
  });
  return html;
}
function fillEditBox(b) {
  editingBoxId = b.id;
  document.getElementById("editModalTitle").textContent = t("edTitle");
  document.getElementById("efTitle").value = b.title || "";
  document.getElementById("efSubject").value = b.subject || "";
  document.getElementById("efTopic").innerHTML = topicSelectOptions(
    (state.topicLinks || {})[b.id] || "auto");
  document.getElementById("efDate").value = b.date || "";
  document.getElementById("efStart").value = b.start || "09:00";
  document.getElementById("efEnd").value = b.end || "10:30";
  document.getElementById("efTotal").value = b.tests_total || 0;
  const tr = testOf(b);
  document.getElementById("efCompleted").value = tr.completed || 0;
  document.getElementById("efCorrect").value = tr.correct || 0;
  document.getElementById("efNote").value = b.note || "";
  document.getElementById("efActual").value = Math.round(((state.actualMinutes || {})[b.id] || 0) / 60);
  document.getElementById("efActualLine").innerHTML = actualVsHtml(b);
  document.getElementById("efDone").checked = isDone(b);
  const subjects = [...new Set(allBoxes().map(x => x.subject))].sort();
  document.getElementById("subjectList").innerHTML =
    subjects.map(s => "<option value=\"" + esc(s) + "\">").join("");
  document.getElementById("editModal").classList.add("open");
  renderModalLinkRow(b);
}
// Book links inside the box edit modal: the same multi-select picker as
// exam topics. Saving writes immediately (like the exam editor); the
// modal's own Save never touches links. Re-renders only this block so
// the modal stays open with its form values intact.
function renderModalLinkRow(b) {
  const wrap = document.getElementById("efLinks");
  if (!wrap || !b) return;
  const key = "box:" + b.id;
  wrap.innerHTML = genericLinkRowHtml(boxBookLinks(b.id), key);
  wireOwnerLinkRow(wrap, key,
    () => boxBookLinks(b.id),
    (entries) => {
      state.boxBookLinks = state.boxBookLinks || {};
      if (entries.length) state.boxBookLinks[b.id] = entries;
      else delete state.boxBookLinks[b.id];
    },
    () => renderModalLinkRow(b),
    () => renderModalLinkRow(b));
}
// User-initiated open: fill the form AND push a history entry (Back closes it).
function openEditBox(b) { fillEditBox(b); pushModalRoute({ kind: "edit", boxId: b.id }); }
function hideEditModalUI() {
  document.getElementById("editModal").classList.remove("open");
  editingBoxId = null;
  // An open box-link editor must not leak into the part card behind it.
  if (linkEditingKey && linkEditingKey.indexOf("box:") === 0) { linkEditingKey = null; linkDraft = null; }
}
function closeEditModal() {
  hideEditModalUI();
  closeModalHistory();
}
document.getElementById("editClose").addEventListener("click", closeEditModal);
document.getElementById("efCancel").addEventListener("click", closeEditModal);
document.getElementById("editModal").addEventListener("click", (e) => {
  if (e.target.id === "editModal") closeEditModal();
});
document.getElementById("efSave").addEventListener("click", () => {
  const id = editingBoxId;
  if (!id) return;
  const b = allBoxes().find(x => x.id === id);
  if (!b) return;
  const title = document.getElementById("efTitle").value.trim() || b.title;
  const subject = document.getElementById("efSubject").value.trim() || b.subject;
  const date = document.getElementById("efDate").value || b.date;
  const start = document.getElementById("efStart").value || b.start;
  const end = document.getElementById("efEnd").value || b.end;
  const note = document.getElementById("efNote").value;
  const total = Math.max(0, parseInt(document.getElementById("efTotal").value, 10) || 0);
  const completed = Math.max(0, parseInt(document.getElementById("efCompleted").value, 10) || 0);
  const correct = Math.min(completed, Math.max(0, parseInt(document.getElementById("efCorrect").value, 10) || 0));
  const done = document.getElementById("efDone").checked;
  const link = document.getElementById("efTopic").value;
  const actualMins = Math.max(0, parseInt(document.getElementById("efActual").value, 10) || 0);
  state.actualMinutes = state.actualMinutes || {};
  state.actualMinutes[id] = actualMins * 60;
  if (id.startsWith("custom-")) {
    const cb = (state.custom_boxes || []).find(x => x.id === id);
    Object.assign(cb, { title, subject, topic: title, date, start, end, note, tests_total: total });
  } else {
    state.edits[id] = Object.assign({}, state.edits[id], { title, subject, date, start, end, note });
    state.tests_total[id] = total;
  }
  state.tests[id] = { completed, correct };
  if (done) state.done[id] = true; else delete state.done[id];
  state.topicLinks = state.topicLinks || {};
  if (link === "auto") delete state.topicLinks[id]; else state.topicLinks[id] = link;
  saveState(); hideEditModalUI(); dismissModalEntry(); renderAll();
});

// ---- Dashboard ----
function statCard(label, value, sub) {
  return '<div class="stat-card"><div class="sc-label">' + label + '</div>' +
    '<div class="sc-value">' + value + '</div><div class="sc-sub">' + (sub || "") + "</div></div>";
}
// ---- Dashboard: at-a-glance ONLY ----
// Today only: Jalali date, today's boxes + day tick, today's tests, a small
// done-past-days badge, and quick navigation. All heavy stats (overall %,
// per-subject bars, week strip, full day-by-day program, book summary)
// live in the Overview view (renderOverview) now.
function renderDashboard() {
  const boxes = allBoxes();
  const todayList = boxes.filter(b => boxStudyDay(b) === TODAY).slice().sort((a, b) => a.start.localeCompare(b.start));
  document.getElementById("dashDateLine").textContent =
    weekdayFa(TODAY) + " " + gregToJalali(TODAY).text;
  const testsToday = todayList.reduce((s, b) => s + (testOf(b).completed || 0), 0);
  const correctToday = todayList.reduce((s, b) => s + (testOf(b).correct || 0), 0);
  document.getElementById("dashTodayTests").textContent =
    t("dashTestsToday", { done: FA(testsToday), correct: FA(correctToday) });
  const todayActualSecs = todayList.reduce((s, b) => s + timerTotalSeconds(b.id), 0);
  const taEl = document.getElementById("dashTodayActual");
  if (taEl) taEl.textContent = t("dashActualToday", { t: fmtDuration(Math.round(todayActualSecs / 60)) });
  const sdNote = document.getElementById("dashStudyDayNote");
  if (sdNote) sdNote.textContent = t("studyDayNote");
  // Backlog rule (user-confirmed): undone past boxes are NOT backlogs — they are
  // already scheduled in the current programme through 27 Azar. The
  // "remaining" section therefore lists only parts actually DONE on past days.
  const donePastCount = boxes.filter(b => isDone(b) && boxStudyDay(b) < TODAY).length;
  const ob = document.getElementById("dashOverdueBtn");
  ob.textContent = donePastCount
    ? t("dashOverdueLink", { n: FA(donePastCount) })
    : t("dashOverdueNone");
  ob.onclick = () => navigate({ tab: "remaining" });
  // Quick navigation chips to every other view.
  const nav = document.getElementById("dashQuickNav");
  nav.innerHTML = "";
  [["program", "tabProgram"], ["assignments", "tabAssignments"], ["testbook", "tabTestbook"],
   ["remaining", "tabOverdue"], ["exams", "tabExams"], ["gemini", "tabGemini"], ["overview", "tabOverview"]].forEach(([tab, key]) => {
    const btn = document.createElement("button");
    btn.className = "btn";
    btn.textContent = t(key);
    btn.addEventListener("click", () => navigate({ tab }));
    nav.appendChild(btn);
  });
  // Today only — no tomorrow, no full program, no stats.
  const el = document.getElementById("todayBoxes");
  el.innerHTML = "";
  if (!todayList.length) { el.innerHTML = '<p class="muted">' + t("noBoxDay") + '</p>'; return; }
  el.appendChild(dayTickEl(TODAY));
  todayList.forEach((b, i) => el.appendChild(partCard(b, i)));
}

// ---- Book view ----
// One line of section metadata: درس group + start pages. Book data is
// never translated — page numbers and titles show as stored.
function topicMetaText(tp) {
  const parts = [];
  if (tp.group) parts.push(tp.group);
  if (tp.page) parts.push(t("metaPage", { n: FA(tp.page) }));
  if (tp.pages) parts.push(tp.pages);
  if (tp.textbookPages) parts.push(t("metaTextbook", { r: tp.textbookPages }));
  if (tp.lessonPage) parts.push(t("metaLesson", { n: FA(tp.lessonPage) }));
  if (tp.questionsPage) parts.push(t("metaQuestions", { n: FA(tp.questionsPage) }));
  if (tp.kind) parts.push(t({ exam: "kindExam", interactive: "kindInteractive", review: "kindReview", appendix: "kindAppendix", answers: "kindAnswers" }[tp.kind] || "kindExam"));
  return parts.join(" · ");
}
function masteryOptions(cur) {
  return [["", "masteryNone"], ["weak", "masteryWeak"], ["mid", "masteryMid"], ["good", "masteryGood"], ["strong", "masteryStrong"]]
    .map(([v, k]) => '<option value="' + v + '"' + (cur === v ? " selected" : "") + '>' + t(k) + '</option>').join("");
}
function statusOptions(cur) {
  return [["", "statusNone"], ["not", "statusNot"], ["studying", "statusStudying"], ["done", "statusDone"]]
    .map(([v, k]) => '<option value="' + v + '"' + (cur === v ? " selected" : "") + '>' + t(k) + '</option>').join("");
}
// Everything manually linked to this book section — the reverse view of
// all three link kinds: exam topics (topic.bookLinks), assignments
// (assignment.bookLinks) and study boxes (state.boxBookLinks). All sides
// read the same shared records, so a link shows up here and at its owner.
function reverseBookLinks(sectionId) {
  const out = [];
  allExams().forEach(ex => (ex.budget || []).forEach(s => (s.chapters || []).forEach(ch =>
    (ch.topics || []).forEach(tp => {
      if (topicLinks(tp).some(l => l.sectionId === sectionId))
        out.push({ kind: "exam", examId: ex.id, examName: examGroupLabel(ex) + " — " + examDisplayName(ex), topicName: tp.name });
    }))));
  (state.assignments || []).forEach(a => {
    if (!assignmentBookLinks(a).some(l => l.sectionId === sectionId)) return;
    const box = allBoxes().find(b => b.id === a.boxId);
    if (box) out.push({ kind: "assignment", assignmentId: a.id, boxId: box.id, boxTitle: box.title, boxDate: boxStudyDay(box) || box.date });
  });
  Object.keys(state.boxBookLinks || {}).forEach(boxId => {
    if (!boxBookLinks(boxId).some(l => l.sectionId === sectionId)) return;
    const box = allBoxes().find(b => b.id === boxId);
    if (box) out.push({ kind: "box", boxId: box.id, boxTitle: box.title, boxDate: boxStudyDay(box) || box.date });
  });
  return out;
}
function jumpToExam(id) {
  const ex = findExam(id);
  if (!ex) return;
  navigate({ tab: "exams", examGroup: ex.group, examView: "list", examId: id, scroll: { type: "exam", id } });
}
// One book section row: counts (computed), per-section test entry, study
// status, mastery, personal note, and the exams linked to it.
function bookTopicRow(tp) {
  const s = topicStats(tp);
  const row = document.createElement("div");
  row.className = "book-topic";
  row.id = "topic-row-" + tp.id;
  const links = reverseBookLinks(tp.id);
  const examLinks = links.filter(l => l.kind === "exam");
  const asgLinks = links.filter(l => l.kind === "assignment");
  const boxLinks = links.filter(l => l.kind === "box");
  const meta = topicMetaText(tp);
  row.innerHTML =
    '<div class="bt-head"><span class="bt-title">' + esc(topicTitle(tp)) + '</span>' +
    '<span class="bt-pct">' + (s.pct == null ? "—" : FA_PCT(s.pct)) + '</span></div>' +
    (meta ? '<div class="bt-sub">' + esc(meta) + '</div>' : '') +
    '<div class="bt-nums"><span>' + t("totalLabel") + '<b>' + FA(s.total) + '</b></span>' +
    '<span>' + t("solvedLabel") + '<b>' + FA(s.solved) + '</b></span>' +
    '<span>' + t("correctLabel") + '<b>' + FA(s.correct) + '</b></span>' +
    '<span>' + t("wrongLabel") + '<b>' + FA(s.wrong) + '</b></span>' +
    '<span>' + t("unansweredLabel") + '<b>' + (s.unanswered == null ? "—" : FA(s.unanswered)) + '</b></span>' +
    '<span>' + t("remainingLabel") + '<b>' + (s.remaining == null ? "—" : FA(s.remaining)) + '</b></span>' +
    '<span>' + t("accuracyLabel") + '<b>' + (s.acc == null ? "—" : FA_PCT(s.acc)) + '</b></span></div>' +
    '<div class="progress"><div style="width:' + (s.pct == null ? 0 : s.pct) + '%"></div></div>' +
    '<div class="bt-edit">' +
    '<label>' + t("totalTestsInput") + ' <input type="number" min="0" class="bt-total" value="' + s.total + '"></label>' +
    '<label>' + t("manualSolvedInput") + ' <input type="number" min="0" class="bt-manual" value="' + (tp.manual_solved || 0) + '"></label>' +
    '<label>' + t("manualCorrectInput") + ' <input type="number" min="0" class="bt-manual-c" value="' + (tp.manual_correct || 0) + '"></label>' +
    '<label>' + t("manualWrongInput") + ' <input type="number" min="0" class="bt-manual-w" value="' + (tp.manual_wrong || 0) + '"></label>' +
    '<label>' + t("masteryLabel") + ' <select class="bt-mastery">' + masteryOptions(tp.mastery || "") + '</select></label>' +
    '<label>' + t("statusLabel") + ' <select class="bt-status">' + statusOptions(tp.status || "") + '</select></label>' +
    '<label class="bt-note-lbl">' + t("noteLabel") + ' <input type="text" class="bt-note" value="' + esc(tp.note || "") + '" placeholder="' + esc(t("notePh")) + '"></label>' +
    '<button class="edit-btn bt-rename">' + t("renameTopic") + '</button></div>' +
    (examLinks.length ? '<div class="bt-links"><span class="bt-links-label">' + t("linkedExamsLabel") + '</span>' + examLinks.map(l =>
      '<button class="jump-btn bt-link-jump" data-exam="' + l.examId + '">' + esc(l.examName + " — " + l.topicName) + '</button>').join("") + '</div>' : '') +
    (asgLinks.length ? '<div class="bt-links"><span class="bt-links-label">' + t("linkedAssignmentsLabel") + '</span>' + asgLinks.map(l =>
      '<button class="jump-btn bt-link-jump-asg" data-box="' + esc(l.boxId) + '">' + esc(l.boxTitle) + '</button>').join("") + '</div>' : '') +
    (boxLinks.length ? '<div class="bt-links"><span class="bt-links-label">' + t("linkedBoxesLabel") + '</span>' + boxLinks.map(l =>
      '<button class="jump-btn bt-link-jump-box" data-box="' + esc(l.boxId) + '" data-day="' + esc(l.boxDate) + '">' + esc(l.boxTitle) + '</button>').join("") + '</div>' : '');
  const clampManual = () => {
    tp.manual_solved = Math.max(0, tp.manual_solved || 0);
    tp.manual_correct = Math.min(tp.manual_solved, Math.max(0, tp.manual_correct || 0));
    tp.manual_wrong = Math.min(Math.max(0, tp.manual_solved - tp.manual_correct), Math.max(0, tp.manual_wrong || 0));
  };
  row.querySelector(".bt-total").addEventListener("change", (e) => {
    tp.tests_total = Math.max(0, parseInt(e.target.value, 10) || 0);
    saveTestbook(); renderAll();
  });
  row.querySelector(".bt-manual").addEventListener("change", (e) => {
    tp.manual_solved = Math.max(0, parseInt(e.target.value, 10) || 0);
    clampManual(); saveTestbook(); renderAll();
  });
  row.querySelector(".bt-manual-c").addEventListener("change", (e) => {
    tp.manual_correct = Math.max(0, parseInt(e.target.value, 10) || 0);
    clampManual(); saveTestbook(); renderAll();
  });
  row.querySelector(".bt-manual-w").addEventListener("change", (e) => {
    tp.manual_wrong = Math.max(0, parseInt(e.target.value, 10) || 0);
    clampManual(); saveTestbook(); renderAll();
  });
  row.querySelector(".bt-mastery").addEventListener("change", (e) => {
    tp.mastery = e.target.value; saveTestbook(); renderAll();
  });
  row.querySelector(".bt-status").addEventListener("change", (e) => {
    tp.status = e.target.value; saveTestbook(); renderAll();
  });
  row.querySelector(".bt-note").addEventListener("change", (e) => {
    tp.note = e.target.value; saveTestbook();
  });
  row.querySelector(".bt-rename").addEventListener("click", () => {
    const name = prompt(t("renameTopicPrompt"), tp.title);
    if (name == null) return;
    tp.title = name.trim() || tp.title;
    saveTestbook(); renderAll();
  });
  row.querySelectorAll(".bt-link-jump").forEach(btn => btn.addEventListener("click", (e) => {
    e.stopPropagation();
    jumpToExam(btn.dataset.exam);
  }));
  row.querySelectorAll(".bt-link-jump-asg").forEach(btn => btn.addEventListener("click", (e) => {
    e.stopPropagation();
    const boxId = btn.dataset.box;
    navigate({ tab: "assignments" });
    setTimeout(() => {
      const el = document.getElementById("asg-row-" + boxId);
      if (el) el.scrollIntoView({ block: "center" });
    }, 60);
  }));
  row.querySelectorAll(".bt-link-jump-box").forEach(btn => btn.addEventListener("click", (e) => {
    e.stopPropagation();
    navigate({ tab: "program", day: btn.dataset.day });
  }));
  return row;
}
function renderBookView(bookId) {
  const book = (TESTBOOK.books || []).find(b => b.id === bookId);
  if (!book) { openBookId = null; return; }
  document.getElementById("testbookMain").hidden = true;
  const view = document.getElementById("bookView");
  view.hidden = false;
  document.getElementById("bookTitle").textContent = t("bookPrefix") + bookName(book);
  document.getElementById("bookNote").textContent = book.books_note || "";
  const st = bookStats(book);
  document.getElementById("bookStats").innerHTML =
    statCard(t("bookProgress"), st.pct == null ? "—" : FA_PCT(st.pct), "") +
    statCard(t("solved"), FA(st.solved), "") +
    statCard(t("remainingT"), st.remaining != null ? FA(st.remaining) : "—", st.total ? t("ofTotalTests", { n: FA(st.total) }) : t("enterTotalTests"));
  const wrap = document.getElementById("bookChapters");
  wrap.innerHTML = "";
  let lastGrade = null;
  (book.chapters || []).forEach(ch => {
    // شیمی groups its chapters by grade (دهم / یازدهم / دوازدهم).
    if (ch.grade && ch.grade !== lastGrade) {
      lastGrade = ch.grade;
      const gh = document.createElement("h3");
      gh.className = "grade-head";
      gh.textContent = t({ "دهم": "grade10", "یازدهم": "grade11", "دوازدهم": "grade12" }[ch.grade] || "grade10");
      wrap.appendChild(gh);
    }
    const det = document.createElement("details");
    det.className = "topic";
    det.open = true;
    const chSolved = ch.topics.reduce((s, t) => s + topicStats(t).solved, 0);
    const chTotal = ch.topics.reduce((s, t) => s + (t.tests_total || 0), 0);
    det.innerHTML = "<summary><span>" + esc(chapterTitle(ch)) + "</span><span>" + FA(chSolved) +
      t("solvedSuffix") + (chTotal ? t("ofWord") + FA(chTotal) : "") +
      (ch.pending ? ' · <span class="pending-badge">' + esc(t("chapterPendingShort")) + "</span>" : "") + "</span></summary>";
    if (ch.pending) {
      const p = document.createElement("p");
      p.className = "muted";
      p.textContent = t("chapterPending");
      det.appendChild(p);
    }
    (ch.topics || []).forEach(tp => det.appendChild(bookTopicRow(tp)));
    const addBtn = document.createElement("button");
    addBtn.className = "btn";
    addBtn.textContent = t("addTopicBtn");
    addBtn.addEventListener("click", () => {
      const name = prompt(t("newTopicPrompt"));
      if (!name || !name.trim()) return;
      ch.topics.push({ id: "t-" + Date.now(), title: name.trim(), tests_total: 0, manual_solved: 0, manual_correct: 0, manual_wrong: 0, mastery: "", status: "", note: "" });
      saveTestbook(); renderAll();
    });
    det.appendChild(addBtn);
    const addCh = document.createElement("button");
    addCh.className = "btn";
    addCh.textContent = t("addChapterBtn");
    addCh.addEventListener("click", () => {
      const name = prompt(t("newChapterPrompt"));
      if (!name || !name.trim()) return;
      book.chapters.push({ id: "ch-" + Date.now(), title: name.trim(), topics: [] });
      saveTestbook(); renderAll();
    });
    det.appendChild(addCh);
    wrap.appendChild(det);
  });
  // Legacy topics: old v1 topics with no chapter in the new book. Their
  // counts are kept here so the migration never hides them.
  const legacy = Object.values(TESTBOOK.legacy || {}).filter(lg => lg.bookId === book.id);
  if (legacy.length) {
    const det = document.createElement("details");
    det.className = "topic legacy-block";
    det.open = true;
    det.innerHTML = "<summary><span>" + esc(t("legacyTitle")) + "</span><span>" +
      FA(legacy.reduce((s, lg) => s + topicStats(lg).solved, 0)) + t("solvedSuffix") + "</span></summary>" +
      '<p class="muted">' + esc(t("legacyNote")) + '</p>';
    legacy.forEach(lg => det.appendChild(bookTopicRow(lg)));
    wrap.appendChild(det);
  }
}
document.getElementById("bookBack").addEventListener("click", () => {
  navigate({ tab: "testbook", bookId: null });
});

// ---- Test-book tab (own page) ----
function renderTestbookTab() {
  const bc = document.getElementById("bookCardsTb");
  if (!bc) return;
  bc.innerHTML = "";
  (TESTBOOK.books || []).forEach(book => {
    const st = bookStats(book);
    const card = document.createElement("button");
    card.className = "book-card " + colorClass(book.name);
    card.innerHTML = '<div class="book-name">' + esc(bookName(book)) + '</div>' +
      '<div class="book-pct">' + (st.pct == null ? "—" : FA_PCT(st.pct)) + '</div>' +
      '<div class="book-sub">' + FA(st.solved) + t("solvedSuffix") +
      (st.total ? t("ofWord") + FA(st.total) : '') +
      (st.remaining != null ? ' · ' + FA(st.remaining) + t("remainingSuffixT") : '') + '</div>' +
      '<div class="progress"><div style="width:' + (st.pct == null ? 0 : st.pct) + '%"></div></div>';
    card.addEventListener("click", () => { navigate({ tab: "testbook", bookId: book.id }); });
    bc.appendChild(card);
  });
  if (!openBookId) {
    const bv = document.getElementById("bookView");
    if (bv) bv.hidden = true;
    const tm = document.getElementById("testbookMain");
    if (tm) tm.hidden = false;
  }
}
function jumpToTopic(topicId) {
  const found = topicById(topicId);
  if (!found || !found.book) return;
  navigate({ tab: "testbook", bookId: found.book.id, scroll: { type: "topic", id: topicId } });
}

// ---- Calendar tab ----
// Two months: Aban (1 Aban = Friday 23 Oct 2026) then Azar (1 Azar =
// Sunday 22 Nov 2026), 30 days each, Saturday-first week. Dates are
// formatted with isoOf (local date) — toISOString is UTC and shifts every
// cell one day back on a Tehran-timezone machine.
function renderCalendar() {
  const grid = document.getElementById("calGrid");
  grid.innerHTML = "";
  const byDay = {};
  // Calendar cells group by STUDY day: a box starting before 03:30
  // belongs to the previous study day and shows in that day's cell.
  allBoxes().forEach(b => { const sd = boxStudyDay(b) || b.date; (byDay[sd] = byDay[sd] || []).push(b); });
  const months = [
    { key: "calMonthAban", start: new Date(2026, 9, 23), lead: 6 },
    { key: "calMonthAzar", start: new Date(2026, 10, 22), lead: 1 },
  ];
  months.forEach(mo => {
    const h = document.createElement("div");
    h.className = "cal-month";
    h.textContent = t(mo.key);
    grid.appendChild(h);
    t("calDow").forEach(d => {
      const el = document.createElement("div"); el.className = "cal-dow"; el.textContent = d; grid.appendChild(el);
    });
    for (let i = 0; i < mo.lead; i++)
      grid.appendChild(Object.assign(document.createElement("div"), { className: "cal-cell empty" }));
    for (let day = 1; day <= 30; day++) {
      const date = new Date(mo.start.getFullYear(), mo.start.getMonth(), mo.start.getDate() + (day - 1));
      const iso = isoOf(date);
      const boxes = byDay[iso] || [];
      const done = boxes.filter(isDone).length;
      const cell = document.createElement("button");
      cell.className = "cal-cell" + (iso === selectedDay ? " sel" : "") + (iso === TODAY ? " today" : "") +
        (isDayDone(iso) ? " day-done" : "");
      cell.innerHTML = '<div class="n">' + FA(day) + (isDayDone(iso) ? " ✓" : "") + '</div><div class="c">' +
        (boxes.length ? "<b>" + FA(done) + "/" + FA(boxes.length) + "</b> " + t("boxesWord") : "—") + "</div>";
      cell.addEventListener("click", () => { navigate({ tab: "program", day: iso }); });
      grid.appendChild(cell);
    }
  });
  const j = gregToJalali(selectedDay);
  document.getElementById("calDayTitle").textContent =
    weekdayFa(selectedDay) + " " + j.text + " " + t("dayBoxesSuffix");
  const box = document.getElementById("calDayBoxes");
  box.innerHTML = "";
  const tickRow = document.createElement("div");
  tickRow.className = "day-tick-row";
  tickRow.appendChild(dayTickEl(selectedDay));
  if (isDayDone(selectedDay)) {
    const badge = document.createElement("span");
    badge.className = "done-badge";
    badge.textContent = t("doneBadge");
    tickRow.appendChild(badge);
  }
  box.appendChild(tickRow);
  const list = (byDay[selectedDay] || []).slice().sort((a, b) => a.start.localeCompare(b.start));
  if (!list.length) box.innerHTML += '<p class="muted">' + t("noBoxDay") + '</p>';
  list.forEach((b, i) => box.appendChild(partCard(b, i)));
}
document.getElementById("addBoxBtn").addEventListener("click", () => {
  const title = document.getElementById("newBoxTitle").value.trim();
  if (!title) { alert(t("boxTitleAlert")); return; }
  const start = document.getElementById("newBoxStart").value || "09:00";
  const end = document.getElementById("newBoxEnd").value || "10:30";
  const id = "custom-" + Date.now();
  const subject = title.split(":")[0].split("—")[0].trim() || "عمومی";
  const isTest = /تست|تکلیف|آزمون/.test(title);
  (state.custom_boxes = state.custom_boxes || []).push({
    id, date: selectedDay, start, end, subject, topic: title, title,
    is_test: isTest, tests_total: 0, note: ""
  });
  if (isTest && Array.isArray(state.assignments)) {
    state.assignments.push({ id: "asg-" + id, boxId: id, type: "test" });
  }
  document.getElementById("newBoxTitle").value = "";
  saveState(); renderAll();
});

// ---- Overdue tab: done past parts only (backlog rule) ----
// Undone past boxes are NOT listed here — they are already scheduled in the
// current programme through 27 Azar. This view is the completed record:
// parts actually done on past days, with their test counts.
function renderRemaining() {
  const wrap = document.getElementById("remainingList");
  wrap.innerHTML = "";
  const donePast = allBoxes()
    .filter(b => isDone(b) && boxStudyDay(b) < TODAY)
    .sort((a, b) => ((boxStudyDay(a) || a.date) + a.start).localeCompare((boxStudyDay(b) || b.date) + b.start));
  if (!donePast.length) {
    wrap.innerHTML = '<p class="muted">' + t("noOverdue") + '</p>';
    return;
  }
  donePast.forEach(b => {
    const tr = testOf(b);
    const total = b.tests_total || 0;
    const sd = boxStudyDay(b) || b.date;
    const row = document.createElement("div");
    row.className = "part done " + colorClass(b.subject);
    row.innerHTML =
      '<div class="part-top">' +
        '<input type="checkbox" checked aria-label="' + t("fDone") + '">' +
        '<div style="flex:1"><div class="part-title">' + esc(b.title) + '</div>' +
        '<div class="part-time">' + weekdayFa(sd) + ' ' + gregToJalali(sd).text + ' · ' + esc(b.start) + ' – ' + esc(b.end) + ' · ' + esc(subjName(b.subject)) + '</div>' +
        '<div class="part-time">' + t("doneTestsLabel") + (total ? FA(tr.completed || 0) + " " + t("testsWord") + t("ofWord") + FA(total) : (b.is_test ? t("totalNotEntered2") : "—")) +
        '</div></div>' +
      '</div>' +
      '<div class="part-actions"><button class="edit-btn">' + t("editBtn") + '</button></div>';
    row.querySelector('input[type="checkbox"]').addEventListener("change", (e) => {
      state.done[b.id] = e.target.checked;
      if (!e.target.checked) delete state.done[b.id];
      saveState(); renderAll();
    });
    row.querySelector(".edit-btn").addEventListener("click", () => openEditBox(b));
    wrap.appendChild(row);
  });
}

// ---- Overview tab ----
function renderOverview() {
  const boxes = allBoxes();
  const subjects = {};
  boxes.forEach(b => {
    const s = subjects[b.subject] = subjects[b.subject] || { total: 0, done: 0, tests: 0, correct: 0, testBoxes: 0, testBoxesLeft: 0 };
    s.total++; if (isDone(b)) s.done++;
    const tr = testOf(b); s.tests += tr.completed || 0; s.correct += tr.correct || 0;
    if (b.is_test) { s.testBoxes++; if (!isDone(b)) s.testBoxesLeft++; }
  });
  const rows = Object.keys(subjects).sort((a, b) => subjects[b].testBoxesLeft - subjects[a].testBoxesLeft);
  document.getElementById("overviewStats").innerHTML =
    "<p>" + t("totalProgram") + t("summaryLine", { done: FA(boxes.filter(isDone).length), total: FA(boxes.length), tests: FA(boxes.reduce((s, b) => s + (testOf(b).completed || 0), 0)) }) + "</p>";
  let html = '<table><tr><th>' + t("thSubject") + '</th><th>' + t("thProgress") + '</th><th>' + t("thBox") + '</th><th>' + t("thTestsLeft") + '</th><th>' + t("thAccuracy") + '</th></tr>';
  rows.forEach(s => {
    const st = subjects[s];
    const acc = st.tests ? FA_PCT(st.correct / st.tests * 100) : "—";
    html += "<tr><td><span class=\"subj-dot " + colorClass(s) + "\"></span>" + esc(subjName(s)) + "</td><td>" + FA_PCT(st.total ? st.done / st.total * 100 : 0) +
      '</td><td>' + FA(st.done) + "/" + FA(st.total) + "</td><td>" + FA(st.testBoxesLeft) +
      " " + t("boxesWord") + "</td><td>" + acc + "</td></tr>";
  });
  document.getElementById("overviewTable").innerHTML = html + "</table>";
  const byDay = {};
  boxes.forEach(b => { const sd = boxStudyDay(b) || b.date; (byDay[sd] = byDay[sd] || []).push(b); });
  let n7 = "";
  for (let i = 0; i < 7; i++) {
    const iso = addDays(TODAY, i);
    const list = byDay[iso] || [];
    const done = list.filter(isDone).length;
    const dayActual = list.reduce((s, b) => s + timerTotalSeconds(b.id), 0);
    n7 += "<div class='trow topic' style='display:flex;justify-content:space-between'><span>" + weekdayFa(iso) + " " + gregToJalali(iso).text +
      "</span><span>" + FA(done) + "/" + FA(list.length) + " " + t("boxesWord") + (isDayDone(iso) ? " ✓" : "") +
      " · " + t("tmActual") + ": " + (dayActual > 0 ? fmtDuration(Math.round(dayActual / 60)) : "—") + "</span></div>";
  }
  document.getElementById("next7").innerHTML = n7;
  const byTopic = {};
  boxes.filter(b => !isDone(b)).forEach(b => {
    byTopic[b.subject + " — " + b.topic] = (byTopic[b.subject + " — " + b.topic] || 0) + 1;
  });
  const top = Object.keys(byTopic).sort((a, b) => byTopic[b] - byTopic[a]).slice(0, 8);
  document.getElementById("topTopics").innerHTML = top.length
    ? top.map(tp => "<div class='trow topic' style='display:flex;justify-content:space-between'><span>" + esc(tp) + "</span><span>" + FA(byTopic[tp]) + " " + t("boxesWord") + "</span></div>").join("")
    : '<p class="muted">' + t("topTopicsEmpty") + '</p>';
  // --- Moved here from the Dashboard: test-book summary chips. ---
  const bc = document.getElementById("bookSummary");
  bc.innerHTML = "";
  (TESTBOOK.books || []).forEach(book => {
    const st = bookStats(book);
    const chip = document.createElement("button");
    chip.className = "book-chip " + colorClass(book.name);
    chip.innerHTML = '<span class="bc-name">' + esc(bookName(book)) + '</span>' +
      '<span class="bc-val">' + (st.pct == null ? "—" : FA_PCT(st.pct)) + ' · ' +
      FA(st.solved) + t("solvedSuffix") + (st.total ? t("ofWord") + FA(st.total) : '') +
      (st.remaining != null ? ' · ' + FA(st.remaining) + t("remainingSuffixT") : '') + '</span>';
    chip.addEventListener("click", () => { navigate({ tab: "testbook", bookId: book.id }); });
    bc.appendChild(chip);
  });

  // --- Moved here from the Dashboard: overall stat cards. ---
  const doneBoxes = boxes.filter(isDone);
  const testsDone = boxes.reduce((s, b) => s + (testOf(b).completed || 0), 0);
  const testsCorrect = boxes.reduce((s, b) => s + (testOf(b).correct || 0), 0);
  const testsRemaining = boxes.reduce((s, b) => {
    const total = b.tests_total || 0;
    return s + (total ? Math.max(0, total - (testOf(b).completed || 0)) : 0);
  }, 0);
  // Backlog rule: the stat counts parts actually done on past STUDY days, not undone ones.
  const donePastBoxes = boxes.filter(b => isDone(b) && boxStudyDay(b) < TODAY);
  const pct = boxes.length ? Math.round(doneBoxes.length / boxes.length * 100) : 0;
  document.getElementById("overviewStatGrid").innerHTML =
    statCard(t("statOverall"), FA_PCT(pct), FA(doneBoxes.length) + t("ofWord") + FA(boxes.length) + " " + t("boxesWord")) +
    statCard(t("statDone"), FA(doneBoxes.length), t("boxesWord")) +
    statCard(t("statRemaining"), FA(boxes.length - doneBoxes.length), t("boxesWord")) +
    statCard(t("statOverdue"), FA(donePastBoxes.length), t("overdueSub")) +
    statCard(t("statTestsDone"), FA(testsDone), FA(testsCorrect) + " " + t("correctWord")) +
    statCard(t("statTestsRemaining"), testsRemaining ? FA(testsRemaining) : "—", t("testsRemainingSub"));

  // --- Moved here from the Dashboard: week strip (7 days from today). ---
  const strip = document.getElementById("weekStrip");
  strip.innerHTML = "";
  for (let i = 0; i < 7; i++) {
    const d = addDays(TODAY, i);
    const list = boxes.filter(b => boxStudyDay(b) === d);
    const dn = list.filter(isDone).length;
    const el = document.createElement("div");
    el.className = "week-day" + (isDayDone(d) ? " done" : "") + (d === TODAY ? " today" : "");
    el.innerHTML = '<div class="wd-name">' + weekdayFa(d) + '</div>' +
      '<div class="wd-date">' + gregToJalali(d).text + '</div>' +
      '<div class="wd-count">' + FA(dn) + "/" + FA(list.length) + '</div>' +
      '<div class="wd-badge">' + (isDayDone(d) ? t("doneBadge") : (list.length ? t("waiting") : "—")) + "</div>";
    el.addEventListener("click", () => { navigate({ tab: "program", day: d }); });
    strip.appendChild(el);
  }

  // --- Moved here from the Dashboard: per-subject progress bars. ---
  const bySubj = {};
  boxes.forEach(b => {
    const s = bySubj[b.subject] = bySubj[b.subject] || { total: 0, done: 0 };
    s.total++; if (isDone(b)) s.done++;
  });
  const order = ["حسابان", "فیزیک", "شیمی"];
  const names = [...order.filter(n => bySubj[n]),
    ...Object.keys(bySubj).filter(n => !order.includes(n)).sort((a, b) => bySubj[b].total - bySubj[a].total)];
  document.getElementById("subjectBars").innerHTML = names.map(n => {
    const s = bySubj[n];
    const p = s.total ? Math.round(s.done / s.total * 100) : 0;
    return '<div class="subj-bar ' + colorClass(n) + '"><span class="sb-name">' + esc(subjName(n)) + '</span>' +
      '<div class="progress"><div style="width:' + p + '%"></div></div>' +
      '<span class="sb-val">' + FA_PCT(p) + " · " + FA(s.done) + "/" + FA(s.total) + "</span></div>";
  }).join("");

  // Exams sections live ONLY in the Overview (not on the Dashboard):
  // upcoming exams (30 days) + the nearest exam's budget.
  renderDashExams();
}

// ---- Subject Stats modal ----
function subjectStats(name) {
  const boxes = allBoxes().filter(b => b.title.includes(name) || b.subject.includes(name));
  const done = boxes.filter(isDone);
  const mins = done.reduce((s, b) => s + minutesBetween(b.start, b.end), 0);
  const tests = done.reduce((s, b) => s + (testOf(b).completed || 0), 0);
  const correct = done.reduce((s, b) => s + (testOf(b).correct || 0), 0);
  const acc = tests ? (correct / tests * 100) : null;
  const pct = boxes.length ? (done.length / boxes.length * 100) : 0;
  return { mins, tests, correct, acc, pct };
}
function renderSubjectStats() {
  const wrap = document.getElementById("subjectStatsList");
  wrap.innerHTML = "";
  (state.subjects || []).forEach((name, i) => {
    const st = subjectStats(name);
    const card = document.createElement("div");
    card.className = "subj-card " + colorClass(name);
    card.innerHTML =
      '<div class="row"><span class="name">' + esc(subjName(name)) + '</span>' +
      '<button class="rm" title="' + t("stDeleteTitle") + '">✕</button></div>' +
      '<div class="stat3">' +
        '<div><div class="v cyan">' + fmtDuration(st.mins) + '</div><div class="l">' + t("stTimeStudied") + '</div></div>' +
        '<div><div class="v orange">' + FA(st.tests) + '</div><div class="l">' + t("stTestsCompleted") + '</div></div>' +
        '<div><div class="v lime">' + (st.acc == null ? "—" : FA_PCT(st.acc)) + '</div><div class="l">' + t("stAccuracy", { n: FA(st.correct) }) + '</div></div>' +
      '</div>' +
      '<div class="progress"><div style="width:' + st.pct + '%"></div></div>';
    card.querySelector(".rm").addEventListener("click", () => {
      state.subjects = state.subjects.filter(s => s !== name);
      saveState(); renderSubjectStats();
    });
    wrap.appendChild(card);
  });
}
function closeStatsModal() {
  hideAllModalsUI();
  closeModalHistory();
}
document.getElementById("statsBtn").addEventListener("click", () => {
  renderSubjectStats();
  document.getElementById("statsModal").classList.add("open");
  pushModalRoute({ kind: "stats" });
});
document.getElementById("statsClose").addEventListener("click", closeStatsModal);
document.getElementById("statsModal").addEventListener("click", (e) => {
  if (e.target.id === "statsModal") closeStatsModal();
});
document.getElementById("addSubjectBtn").addEventListener("click", () => {
  const inp = document.getElementById("newSubjectInput");
  const name = inp.value.trim();
  if (!name) return;
  if (!state.subjects.includes(name)) state.subjects.push(name);
  inp.value = "";
  saveState(); renderSubjectStats();
});


// ---- Assignments tab (تکالیف) ----
// An assignment IS a daily box's test work, seen from a second place.
// It stores only {id, boxId, type}; title/date/subject/tests/done are all
// read live from the underlying box + state.tests + state.done, so an edit
// in either view updates the other and the count is never stored twice.
function assignmentsList() {
  if (!Array.isArray(state.assignments)) return [];
  const removed = new Set(state.assignmentsRemoved || []);
  const boxes = {};
  allBoxes().forEach(b => { boxes[b.id] = b; });
  return state.assignments
    .filter(a => !removed.has(a.boxId) && boxes[a.boxId])
    .map(a => ({ assignment: a, box: boxes[a.boxId] }));
}
function subjectForBook(bookId) {
  return { chem: "شیمی", calc: "حسابان", phys: "فیزیک" }[bookId] || "";
}
function bookForSubject(subject) {
  return { "شیمی": "chem", "حسابان": "calc", "فیزیک": "phys" }[subject] || null;
}
function renderAssignments() {
  const wrap = document.getElementById("assignmentsList");
  if (!wrap) return;
  const list = assignmentsList();
  // Sort: not-done first, then by date
  list.sort((x, y) => ((isDone(x.box) ? 1 : 0) - (isDone(y.box) ? 1 : 0)) ||
    (x.box.date + x.box.start).localeCompare(y.box.date + y.box.start));
  wrap.innerHTML = "";
  if (!list.length) {
    wrap.innerHTML = '<p class="muted">' + t("noAssignments") + '</p>';
    return;
  }
  list.forEach(({ assignment: a, box: b }) => {
    const tr = testOf(b);
    const total = b.tests_total || 0;
    const remaining = total ? Math.max(0, total - (tr.completed || 0)) : null;
    const linkId = linkedTopicId(b);
    const linkInfo = linkId && topicById(linkId);
    const examLinks = linkId ? reverseBookLinks(linkId).filter(l => l.kind === "exam") : [];
    const sd = boxStudyDay(b) || b.date;
    const row = document.createElement("div");
    row.className = "part assign-card " + colorClass(b.subject) + (isDone(b) ? " done" : "");
    row.id = "asg-row-" + b.id;
    row.innerHTML =
      '<div class="part-top">' +
        '<input type="checkbox" ' + (isDone(b) ? "checked" : "") + ' aria-label="' + t("fDone") + '">' +
        '<div style="flex:1"><div class="part-title">' + esc(b.title) + '</div>' +
        '<div class="part-time">' + weekdayFa(sd) + ' ' + gregToJalali(sd).text + ' · ' +
        esc(b.start) + ' – ' + esc(b.end) + ' · ' + esc(subjName(b.subject)) +
        (b.topic && b.topic !== b.title ? ' · ' + esc(b.topic) : '') + '</div>' +
        '<div class="part-time">' + t("testsLabel") + FA(tr.completed || 0) + t("doneSuffix") +
        (total ? t("ofWord") + FA(total) + ' · ' + FA(remaining) + t("remainingSuffix") : t("totalNotEntered")) +
        t("correctLabel") + FA(tr.correct || 0) + '</div>' +
        '<div class="part-time">' + actualVsHtml(b) + '</div>' +
        '<div class="link-badge ' + (linkInfo ? "on" : "off") + '">' +
        (linkInfo ? t("connected") + esc((linkInfo.book ? bookName(linkInfo.book) + ' › ' : '') + topicTitle(linkInfo.topic)) :
                    t("notConnected")) + '</div></div>' +
      '</div>' +
      (examLinks.length ? '<div class="bt-links"><span class="bt-links-label">' + t("linkedExamsLabel") + '</span>' + examLinks.map(l =>
        '<button class="jump-btn bt-link-jump" data-exam="' + l.examId + '">' + esc(l.examName + " — " + l.topicName) + '</button>').join("") + '</div>' : '') +
      genericLinkRowHtml(assignmentBookLinks(a), "asg:" + a.id) +
      '<div class="tests-row">' +
        '<label>' + t("fCompleted") + '<input type="number" min="0" class="a-completed" value="' + (tr.completed || 0) + '"></label>' +
        '<label>' + t("fCorrect") + '<input type="number" min="0" class="a-correct" value="' + (tr.correct || 0) + '"></label>' +
        '<label>' + t("totalTestsInput") + '<input type="number" min="0" class="a-total" value="' + total + '"></label>' +
      '</div>' +
      '<div class="part-actions">' +
        '<button class="edit-btn">' + t("editBtn") + '</button>' +
        (linkInfo ? '<button class="jump-btn">' + t("goToTopic") + '</button>' : '') +
        '<button class="del-btn">' + t("delAsg") + '</button>' +
      '</div>';
    row.querySelector('input[type="checkbox"]').addEventListener("change", (e) => {
      state.done[b.id] = e.target.checked;
      if (!e.target.checked) delete state.done[b.id];
      saveState(); renderAll();
    });
    row.querySelector(".a-completed").addEventListener("change", (e) => setBoxTests(b.id, "completed", e.target.value));
    row.querySelector(".a-correct").addEventListener("change", (e) => setBoxTests(b.id, "correct", e.target.value));
    row.querySelector(".a-total").addEventListener("change", (e) => {
      state.tests_total[b.id] = Math.max(0, parseInt(e.target.value, 10) || 0);
      saveState(); renderAll();
    });
    row.querySelector(".edit-btn").addEventListener("click", () => openEditBox(b));
    const jump = row.querySelector(".jump-btn");
    if (jump) jump.addEventListener("click", () => jumpToTopic(linkId));
    row.querySelectorAll(".bt-link-jump").forEach(btn => btn.addEventListener("click", () => jumpToExam(btn.dataset.exam)));
    row.querySelector(".del-btn").addEventListener("click", () => {
      if (!confirm(t("delAsgConfirm"))) return;
      if (b.id.startsWith("custom-")) {
        state.custom_boxes = (state.custom_boxes || []).filter(x => x.id !== b.id);
      } else {
        state.deleted = (state.deleted || []).concat([b.id]);
      }
      if (state.boxBookLinks) delete state.boxBookLinks[b.id];
      state.assignments = state.assignments.filter(x => x.boxId !== b.id);
      saveState(); renderAll();
    });
    wireOwnerLinkRow(row, "asg:" + a.id,
      () => assignmentBookLinks(a),
      (entries) => { if (entries.length) a.bookLinks = entries; else delete a.bookLinks; });
    wrap.appendChild(row);
  });
}

// ---- Assignment creation form: subject -> book -> chapter -> topic ----
function asgBookOptions(subject) {
  const bookId = bookForSubject(subject);
  let html = '<option value="none">' + t("noBookLink") + '</option>';
  (TESTBOOK.books || []).forEach(book => {
    html += '<option value="' + book.id + '"' + (book.id === bookId ? " selected" : "") + '>' + t("bookWord") + esc(bookName(book)) + '</option>';
  });
  return html;
}
function asgFillCascade() {
  const subject = document.getElementById("asgSubject").value;
  const type = document.getElementById("asgType").value;
  const bookSel = document.getElementById("asgBook");
  const chSel = document.getElementById("asgChapter");
  const tpSel = document.getElementById("asgTopic");
  const row = document.getElementById("asgBookRow");
  const isTest = type === "test";
  row.style.display = isTest ? "" : "none";
  document.getElementById("asgHint").textContent = isTest
    ? t("asgHintTest")
    : t("asgHintOther");
  bookSel.innerHTML = asgBookOptions(subject);
  const bookId = bookSel.value === "none" ? null : bookSel.value;
  const book = (TESTBOOK.books || []).find(b => b.id === bookId);
  chSel.innerHTML = book ? book.chapters.map(ch =>
    '<option value="' + ch.id + '">' + esc(chapterTitle(ch)) + '</option>').join("") : "";
  const ch = book ? book.chapters[0] : null;
  tpSel.innerHTML = ch ? ch.topics.map(t =>
    '<option value="' + t.id + '">' + esc(topicTitle(t)) + '</option>').join("") : "";
}
function asgInitForm() {
  const subjSel = document.getElementById("asgSubject");
  const subjects = [...new Set(allBoxes().map(x => x.subject))].sort();
  ["شیمی", "حسابان", "فیزیک"].forEach(s => { if (!subjects.includes(s)) subjects.unshift(s); });
  subjSel.innerHTML = subjects.map(s => '<option value="' + esc(s) + '">' + esc(subjName(s)) + '</option>').join("");
  document.getElementById("asgDate").value = TODAY;
  subjSel.addEventListener("change", asgFillCascade);
  document.getElementById("asgType").addEventListener("change", asgFillCascade);
  document.getElementById("asgBook").addEventListener("change", () => {
    const book = (TESTBOOK.books || []).find(b => b.id === document.getElementById("asgBook").value);
    const chSel = document.getElementById("asgChapter");
    const tpSel = document.getElementById("asgTopic");
    chSel.innerHTML = book ? book.chapters.map(ch =>
      '<option value="' + ch.id + '">' + esc(chapterTitle(ch)) + '</option>').join("") : "";
    const ch = book ? book.chapters[0] : null;
    tpSel.innerHTML = ch ? ch.topics.map(t =>
      '<option value="' + t.id + '">' + esc(topicTitle(t)) + '</option>').join("") : "";
  });
  document.getElementById("asgChapter").addEventListener("change", () => {
    const book = (TESTBOOK.books || []).find(b => b.id === document.getElementById("asgBook").value);
    const ch = book ? book.chapters.find(c => c.id === document.getElementById("asgChapter").value) : null;
    document.getElementById("asgTopic").innerHTML = ch ? ch.topics.map(t =>
      '<option value="' + t.id + '">' + esc(topicTitle(t)) + '</option>').join("") : "";
  });
  document.getElementById("asgAddBtn").addEventListener("click", () => {
    const title = document.getElementById("asgTitle").value.trim();
    if (!title) { alert(t("asgTitleAlert")); return; }
    const date = document.getElementById("asgDate").value || TODAY;
    const subject = subjSel.value;
    const type = document.getElementById("asgType").value;
    const total = Math.max(0, parseInt(document.getElementById("asgTotal").value, 10) || 0);
    const note = document.getElementById("asgNote").value;
    const topicId = (type === "test" && document.getElementById("asgBook").value !== "none")
      ? document.getElementById("asgTopic").value : null;
    const id = "custom-" + Date.now();
    const isTest = type === "test";
    (state.custom_boxes = state.custom_boxes || []).push({
      id, date, start: "09:00", end: "10:30", subject,
      topic: topicId && topicById(topicId) ? topicById(topicId).topic.title : title,
      title, is_test: isTest, tests_total: isTest ? total : 0, note
    });
    state.topicLinks = state.topicLinks || {};
    if (topicId) state.topicLinks[id] = topicId;
    else state.topicLinks[id] = "none";
    if (Array.isArray(state.assignments)) {
      state.assignments.push({ id: "asg-" + id, boxId: id, type });
    }
    document.getElementById("asgTitle").value = "";
    document.getElementById("asgNote").value = "";
    saveState(); renderAll();
    alert(t("asgAdded"));
  });
  asgFillCascade();
}

// ---- Exams system (آزمون‌ها) — three independent stores + Dashboard link ----
// Data model: state.exams = { maz: [...], zoodbist: [...], school: [...] }.
// Each exam: { id, group, name, stage, subject, date, jalaliFa, jalaliEn,
//   type, questions, status ("upcoming"|"held"|"analyzed"),
//   focusFa, focusEn,
//   budget: [{ subject, questions, chapters: [{ name, topics: [{ name, questions }] }] }],
//   result: { taraz, rank, rankTotal, correct, wrong, unanswered, note } | null }
// Live data lives ONLY in state.exams (persisted via /api/state).
// public/exams.json is the SEED only: on first load, missing seed exams are
// added (old state.examResults are folded into exam.result). Deleted seed
// exams are remembered in state.examsRemoved so they are never re-seeded.
let examGroup = "maz";
let examView = "cats";        // "cats" = three category cards | "list" = category's exam list
let selectedExamId = null;    // exam shown in the detail column
// Which budget topics are expanded to show their subtopics (UI-only state,
// keyed "examId|subjectIdx|chapterIdx|topicIdx" — not persisted).
const expandedBudgetTopics = new Set();
// Which budget <details> chapters are open (same reason: re-renders must
// not collapse a chapter the user just opened to work on subtopics).
const openBudgetChapters = new Set();

function deriveExamStatus(ex) {
  if (ex.result) return "analyzed";
  if (!ex.date) return "upcoming";
  return ex.date < realTodayIso() ? "held" : "upcoming";
}
function ensureExams() {
  if (!state.exams || typeof state.exams !== "object") state.exams = { maz: [], zoodbist: [], school: [] };
  ["maz", "zoodbist", "school"].forEach(g => { if (!Array.isArray(state.exams[g])) state.exams[g] = []; });
  state.examsRemoved = state.examsRemoved || [];
  const removed = new Set(state.examsRemoved);
  const seed = (EXAMS.exams || []);
  let changed = false;
  seed.forEach(se => {
    if (removed.has(se.id) || findExam(se.id)) return;
    const e = Object.assign({}, se);
    e.result = (state.examResults || {})[se.id] || null;
    e.status = e.status || deriveExamStatus(e);
    e.budget = e.budget || [];
    if (!state.exams[e.group]) state.exams[e.group] = [];
    state.exams[e.group].push(e);
    changed = true;
  });
  if (changed) saveState();
}
function allExams() {
  return ["maz", "zoodbist", "school"].reduce((acc, g) => acc.concat(state.exams[g] || []), []);
}
function findExam(id) { return allExams().find(e => e.id === id) || null; }
function examStatusOf(ex) { return ex.status || deriveExamStatus(ex); }
function examDisplayName(ex) {
  if (ex.name) return ex.name;
  if (ex.group === "maz") return t("exStage", { n: FA(ex.stage) });
  const s = ex.stage ? t("exStage", { n: FA(ex.stage) }) + " — " : "";
  const sub = ex.subject ? subjName(ex.subject) : "";
  if (s || sub) return s + sub;
  return t(examGroupKey(ex.group)) + " — " + (ex.date || t("exNoDate"));
}
function examDateText(ex) {
  if (!ex.date) return t("exNoDate");
  const j = (LANG === "fa" ? ex.jalaliFa : ex.jalaliEn) || gregToJalali(ex.date).text;
  return weekdayName(ex.date) + " " + j;
}
function examGroupKey(group) {
  return group === "maz" ? "exSubMaz" : group === "zoodbist" ? "exSubZb" : "exSubSchool";
}
function examGroupLabel(ex) {
  return t(examGroupKey(ex.group));
}
function isUpcomingExam(ex) {
  return examStatusOf(ex) === "upcoming" && !!ex.date && ex.date >= realTodayIso();
}
function upcomingExams(days) {
  const end = addDays(realTodayIso(), days);
  return allExams().filter(e => isUpcomingExam(e) && e.date <= end)
    .sort((a, b) => a.date.localeCompare(b.date));
}
function nearestExam() {
  const u = upcomingExams(36500);
  return u.length ? u[0] : null;
}
// realTodayIso: the REAL calendar date (not the study day). Used ONLY
// for the exam countdown (nearestExam / upcoming exams): an exam is a
// calendar event with a clock time (e.g. 13 Azar 08:00), so "days left"
// counts down from the calendar date — at 01:00 on exam day the exam is
// still today, even though the study day is still yesterday.
function realTodayIso() { return isoOf(new Date()); }
function examDaysLeft(ex) {
  if (!ex.date) return null;
  const today = new Date(realTodayIso() + "T12:00:00");
  const d = new Date(ex.date + "T12:00:00");
  return Math.round((d - today) / 86400000);
}
function examTypeLabel(type) {
  return { topical: t("exTypeTopical"), review: t("exTypeReview"),
           comprehensive: t("exTypeComprehensive"), descriptive: t("exTypeDescriptive"),
           school: t("exTypeSchool") }[type] || type;
}

// ---------- Budget topic -> test-book topic linking (computed, never stored) ----------
// Keywords per book topic; a budget topic links to every book topic whose
// keyword appears in its text. Short keywords (<=3 chars) must match a whole
// token, so "آب" does not false-match "آبکاری". Falls back to the existing
// autoTopicId (single best match) when no keyword hits.
const TOPIC_KEYWORDS = {
  "chem-c1-s1": ["کیهان"], "chem-c2-s5": ["گاز"], "chem-c3-s1": ["آب"],
  "chem-c4-s1": ["هدایای زمینی"], "chem-c5-s1": ["غذای سالم"], "chem-c6-s1": ["پوشاک"],
  "chem-c7-s1": ["مولکول"], "chem-c7-s3": ["pH", "اسید"],
  "chem-c8-s1": ["الکترون"], "chem-c8-s3": ["سلول سوختی"], "chem-c8-s6": ["آبکاری"],
  "chem-c9-s1": ["هنر"], "chem-c10-s1": ["آینده"],
  "calc-c1-l1": ["تابع"], "calc-c6-l51": ["مثلثات"],
  "calc-c7-l67": ["حد و پیوستگی"], "calc-c7-l72": ["نامتناهی", "بی‌نهایت"],
  "calc-c3-l24": ["معادله", "نامعادله", "تعیین علامت"],
  "calc-c5-l38": ["نمایی", "لگاریتم"], "calc-c10-l104": ["الگو", "دنباله"],
  "calc-c11-l110": ["توان گویا"], "calc-c8-l80": ["مشتق"],
  "phys-c1-w1": ["حرکت", "شتاب"],
  "phys-c2-w1": ["دینامیک", "حرکت دایره‌ای"], "phys-c3-w1": ["نوسان", "موج"],
  "phys-c4-w1": ["برهم‌کنش"], "phys-c5-w1": ["اتمی"], "phys-c6-w1": ["هسته‌ای"]
};
function bookOfSubject(subject) {
  if (!subject) return null;
  if (/شیمی/.test(subject)) return "chem";
  if (/حسابان|ریاضی/.test(subject)) return "calc";
  if (/فیزیک/.test(subject)) return "phys";
  if (/گسسته/.test(subject)) return "disc";
  return null;
}
function budgetTopicLinks(subject, topicName) {
  const bookId = bookOfSubject(subject);
  if (!bookId) return [];
  const text = topicName || "";
  const tokens = text.split(/[\s،؛:()\-–—\[\]]+/).filter(Boolean);
  const ids = [];
  (TESTBOOK.books || []).filter(b => b.id === bookId).forEach(book => {
    (book.chapters || []).forEach(ch => (ch.topics || []).forEach(tp => {
      const kws = TOPIC_KEYWORDS[tp.id] || [];
      const hit = kws.some(kw => {
        if (kw.indexOf(" ") >= 0) return text.indexOf(kw) >= 0;
        if (kw.length <= 3) return tokens.indexOf(kw) >= 0;
        return tokens.some(tok => tok.indexOf(kw) >= 0) || text.indexOf(kw) >= 0;
      });
      if (hit) ids.push(tp.id);
    }));
  });
  if (!ids.length) {
    const primary = autoTopicId({ subject: subject || "", title: topicName, topic: "" });
    if (primary) ids.push(primary);
  }
  return ids;
}
// Study progress of one budget topic, computed from the program/test books:
// done when its linked book topic(s) are fully solved (or all linked boxes
// are ticked when no total was ever entered), studying when some tests are
// done, not-studied when none. "nolink" when the topic has no test-book
// counterpart (e.g. geometry — there is no such book).
// When the topic has subtopics, THEY decide the progress instead:
// done when every subtopic is ticked, studying when some are, not-studied
// when none are. links are still computed (for the +تکلیف button).
// A MANUAL bookLinks list (set by the user) is authoritative: progress
// comes only from those sections, aggregated across ALL of them. Without
// one, the computed keyword match below is used as a fallback for the
// progress pill only — it never creates a link.
function budgetTopicProgress(subject, topicName, subtopics, links) {
  const ids = budgetTopicLinks(subject, topicName);
  const manual = (Array.isArray(links) ? links : []).map(l => l && l.sectionId).filter(Boolean);
  const subs = Array.isArray(subtopics) ? subtopics : [];
  if (subs.length) {
    const done = subs.filter(s => s.done).length;
    const st = done === subs.length ? "done" : (done > 0 ? "studying" : "not");
    const all = manual.concat(ids.filter(i => manual.indexOf(i) < 0));
    return { state: st, solved: done, total: subs.length, links: all, subtopics: true };
  }
  if (manual.length) {
    let solved = 0, total = 0, any = false;
    manual.forEach(id => {
      const found = topicById(id);
      if (!found) return;
      any = true;
      const s = topicStats(found.topic);
      solved += s.solved; total += s.total;
    });
    if (!any) return { state: "nolink", solved: 0, total: 0, links: [], manual: true, broken: true };
    let st;
    if (total > 0) st = solved >= total ? "done" : (solved > 0 ? "studying" : "not");
    else {
      const boxes = allBoxes().filter(b => manual.indexOf(linkedTopicId(b)) >= 0);
      st = boxes.length && boxes.every(isDone) ? "done" : (solved > 0 ? "studying" : "not");
    }
    return { state: st, solved, total, links: manual, manual: true };
  }
  if (!ids.length) return { state: "nolink", solved: 0, total: 0, links: [] };
  let solved = 0, total = 0;
  ids.forEach(id => {
    const found = topicById(id);
    if (!found) return;
    const s = topicStats(found.topic);
    solved += s.solved; total += s.total;
  });
  let st;
  if (total > 0) st = solved >= total ? "done" : (solved > 0 ? "studying" : "not");
  else {
    const boxes = allBoxes().filter(b => ids.indexOf(linkedTopicId(b)) >= 0);
    st = boxes.length && boxes.every(isDone) ? "done" : (solved > 0 ? "studying" : "not");
  }
  return { state: st, solved, total, links: ids };
}
// Whole-exam readiness, aggregated from its budget topics.
function examReadiness(ex) {
  const topics = [];
  (ex.budget || []).forEach(s => (s.chapters || []).forEach(ch =>
    (ch.topics || []).forEach(tp => topics.push({ subject: s.subject, name: tp.name, subtopics: tp.subtopics, bookLinks: topicLinks(tp) }))));
  if (!topics.length) return null;
  let done = 0, studying = 0;
  topics.forEach(tp => {
    const p = budgetTopicProgress(tp.subject, tp.name, tp.subtopics, tp.bookLinks);
    if (p.state === "done") done++;
    else if (p.state === "studying") studying++;
  });
  return { total: topics.length, done, studying,
           pct: Math.round(done / topics.length * 100),
           state: done === topics.length ? "done" : (done > 0 || studying > 0 ? "studying" : "not") };
}
function progPillHtml(state) {
  const key = { done: "exProgDone", studying: "exProgStudying",
                not: "exProgNotStudied", nolink: "exProgNoLink" }[state];
  return '<span class="prog-pill p-' + state + '">' + t(key) + '</span>';
}
// ---------- Budget subtopics (زیرمبحث‌ها) ----------
// Data: topic.subtopics = [{ id, name, questions (nullable), done }].
// Stored inside state.exams with the topic itself; topics without the key
// behave as if they had [] — nothing else in the schema changes.
// Workflow: the user copies the ready-made prompt (copy-prompt button),
// asks Gemini for the fine subtopics of that topic, then pastes the list
// (one subtopic per line) into the bulk box here. No AI API is called.
function newSubId() {
  return "sub-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 7);
}
function ensureSubtopics(tp) {
  if (!Array.isArray(tp.subtopics)) tp.subtopics = [];
  return tp.subtopics;
}
// One subtopic per non-empty line; strips common list prefixes ("1. ", "۱)",
// "- ", "• ") so a pasted Gemini list works as-is.
function parseBulkLines(text) {
  return String(text || "").split(/\r?\n/).map(line => {
    let s = line.trim();
    s = s.replace(/^[\d۰-۹]+[.)）:：\-–]\s*/, "").replace(/^[-•*–—]\s*/, "").trim();
    return s;
  }).filter(Boolean);
}
function buildGeminiPrompt(ex, subject, chapter, topicName) {
  return t("exSubPrompt", {
    topic: topicName,
    chapter: chapter || "",
    subject: subjName(subject),
    exam: examDisplayName(ex),
    date: examDateText(ex)
  });
}
function copyTextToClipboard(text, btn) {
  const done = () => {
    const old = btn.textContent;
    btn.textContent = t("exSubCopied");
    btn.classList.add("copied");
    setTimeout(() => { btn.textContent = old; btn.classList.remove("copied"); }, 1600);
  };
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(done).catch(() => fallbackCopy(text, done));
  } else fallbackCopy(text, done);
}
function fallbackCopy(text, done) {
  const ta = document.createElement("textarea");
  ta.value = text;
  ta.style.position = "fixed"; ta.style.opacity = "0";
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand("copy"); } catch (e) {}
  ta.remove();
  done();
}
function subtopicsPanelHtml(ex, subj, ch, tp, key) {
  const subs = Array.isArray(tp.subtopics) ? tp.subtopics : [];
  let html = '<div class="subtopics" data-tkey="' + esc(key) + '">' +
    '<div class="sub-head"><span>' + t("exSubtopics") + ' · ' + FA(subs.length) + '</span>' +
    '<button class="btn sub-prompt-btn" data-action="copy-prompt">' + t("exSubCopyPrompt") + '</button></div>';
  if (!subs.length) html += '<p class="muted">' + t("exSubNone") + '</p>';
  subs.forEach(sub => {
    html += '<div class="sub-row' + (sub.done ? " done" : "") + '" data-sub="' + esc(sub.id) + '">' +
      '<input type="checkbox" class="sub-done" ' + (sub.done ? "checked" : "") + ' aria-label="' + esc(t("fDone")) + '">' +
      '<button class="sub-name" data-action="rename" title="' + esc(t("exSubRenamePrompt")) + '">' + esc(sub.name) + '</button>' +
      '<label class="sub-q-lbl">' + t("exBudgetQuestions") + ' <input type="number" min="0" class="sub-q" value="' + (sub.questions != null ? sub.questions : "") + '"></label>' +
      '<button class="sub-del" data-action="del-sub" title="' + esc(t("delBtn")) + '">✕</button>' +
      '</div>';
  });
  html += '<div class="sub-add-row">' +
    '<input type="text" class="sub-add-name" placeholder="' + esc(t("exSubAddPh")) + '">' +
    '<input type="number" min="0" class="sub-add-q" placeholder="' + esc(t("exBudgetQuestions")) + '">' +
    '<button class="btn sub-add-btn" data-action="add-sub">' + t("exSubAdd") + '</button></div>' +
    '<textarea class="sub-bulk" rows="3" placeholder="' + esc(t("exSubBulkPh")) + '"></textarea>' +
    '<button class="btn btn-lime sub-bulk-btn" data-action="add-bulk">' + t("exSubAddAll") + '</button>' +
    '</div>';
  return html;
}
// Budget rendering, shared by the Dashboard and the exam cards. Reads the
// exam's stored budget exactly — nothing is invented here.
// Every topic is expandable: click its name to show its subtopics (tick,
// rename, question count, delete), a single-add row, a bulk-paste box for
// Gemini's list, and the copy-prompt button.
// Which budget topic's inline book-link editor is open (UI-only, not persisted).
let linkEditingKey = null;
// ---------- Manual exam-topic -> book-section links (MULTI-SELECT) ----------
// The user sets the links himself, per budget topic: one book at a time,
// any chapters, any sections inside them (checkboxes, with select-all per
// chapter). Stored as topic.bookLinks = [{ bookId, chapterId, sectionId }]
// inside state.exams (same persistence as subtopics). Nothing is ever
// linked automatically. A section links to a topic at most once.
// The open editor works on a draft (linkDraft) — Cancel discards it.
// Read helper: returns the normalised list (migrates the old single
// topic.bookLink to a one-entry list on the fly).
function topicLinks(tp) {
  if (!tp) return [];
  const list = Array.isArray(tp.bookLinks)
    ? tp.bookLinks.filter(l => l && l.sectionId)
    : [];
  // Defensive: a legacy single bookLink is folded in even if an (empty)
  // bookLinks list already exists — never silently drop a stored link.
  if (tp.bookLink && tp.bookLink.sectionId &&
      !list.some(l => l.sectionId === tp.bookLink.sectionId)) list.push(tp.bookLink);
  return list;
}
// One-time migration: convert every legacy single bookLink into bookLinks.
// Runs after state is loaded (and after a backup restore), so old data
// survives exactly as it was — one entry, same section. Returns true when
// anything was converted, so the caller can persist the migration at once.
function normalizeExamLinks() {
  let changed = false;
  allExams().forEach(ex => (ex.budget || []).forEach(s => (s.chapters || []).forEach(ch =>
    (ch.topics || []).forEach(tp => {
      if (!Array.isArray(tp.bookLinks)) {
        tp.bookLinks = [];
        changed = true;
      }
      // A legacy single bookLink is folded into the list even when a
      // (possibly empty) bookLinks array already exists — a stored link
      // must never be dropped by the migration.
      if (tp.bookLink && tp.bookLink.sectionId &&
          !tp.bookLinks.some(l => l && l.sectionId === tp.bookLink.sectionId)) {
        tp.bookLinks.push(tp.bookLink);
        changed = true;
      }
      if (tp.bookLink) { delete tp.bookLink; changed = true; }
      const before = tp.bookLinks.length;
      const seen = new Set();
      tp.bookLinks = tp.bookLinks.filter(l => {
        if (!l || !l.sectionId || seen.has(l.sectionId)) return false;
        seen.add(l.sectionId);
        return true;
      });
      if (tp.bookLinks.length !== before) changed = true;
    }))));
  return changed;
}
// ---------- Manual book links for assignments & study boxes (v1.9.0) ----------
// Same model as exam-topic links: manual only, multi-select, stored in
// state.json (so B2 backup covers them). Assignments carry bookLinks on
// the assignment object; boxes carry them in state.boxBookLinks[boxId]
// (shipped boxes are read-only data, so their links live in state, like
// ticks and edits). Deleting a link never deletes data; deleting a box
// drops only that box's own links.
// Normalise any bookLinks list: drop broken entries, drop duplicates
// (first occurrence wins), keep the stored shape.
function bookLinksOf(list) {
  if (!Array.isArray(list)) return [];
  const seen = new Set();
  const out = [];
  list.forEach(l => {
    if (!l || !l.sectionId || seen.has(l.sectionId)) return;
    seen.add(l.sectionId);
    out.push({ bookId: l.bookId || "", chapterId: l.chapterId || "", sectionId: l.sectionId });
  });
  return out;
}
function boxBookLinks(boxId) {
  return bookLinksOf((state.boxBookLinks || {})[boxId]);
}
function assignmentBookLinks(a) {
  return bookLinksOf(a && a.bookLinks);
}
// One-time normalisation (runs after state load and after a backup
// restore): every stored assignment/box link list is deduped and cleaned.
function normalizeBoxBookLinks() {
  if (!state.boxBookLinks || typeof state.boxBookLinks !== "object") { state.boxBookLinks = {}; return true; }
  let changed = false;
  Object.keys(state.boxBookLinks).forEach(id => {
    const clean = bookLinksOf(state.boxBookLinks[id]);
    if (clean.length !== (state.boxBookLinks[id] || []).length) changed = true;
    if (clean.length) state.boxBookLinks[id] = clean;
    else { delete state.boxBookLinks[id]; changed = true; }
  });
  return changed;
}
function normalizeAssignmentLinks() {
  let changed = false;
  (state.assignments || []).forEach(a => {
    if (a.bookLinks === undefined) return;
    const clean = bookLinksOf(a.bookLinks);
    if (clean.length !== a.bookLinks.length) changed = true;
    if (clean.length) a.bookLinks = clean;
    else { delete a.bookLinks; changed = true; }
  });
  return changed;
}
// Shared link row (chips + add/edit/remove) for ANY link owner — exam
// topics, assignments and study boxes render the same row and the same
// multi-select editor; only the save target differs (see wireOwnerLinkRow).
function genericLinkRowHtml(links, key) {
  if (linkEditingKey === key) return '<div class="budget-link-row">' + linkEditorHtml() + '</div>';
  if (links.length) {
    const chips = links.map(l => {
      const label = linkLabel(l);
      return '<span class="book-link-chip">' + esc(label || t("exLinkBroken")) +
        '<button class="bl-chip-x" data-action="del-one-link" data-section="' + esc(l.sectionId) +
        '" title="' + esc(t("exLinkRemoveOne")) + '">✕</button></span>';
    }).join("");
    return '<div class="budget-link-row"><span class="bl-count">' + t("exLinkCount", { n: FA(links.length) }) + '</span>' + chips +
      '<button class="edit-btn bt-link-edit" data-action="edit-link">' + t("exLinkChange") + '</button>' +
      '<button class="edit-btn bt-link-del" data-action="del-link">' + t("exLinkRemove") + '</button></div>';
  }
  return '<div class="budget-link-row"><button class="edit-btn bt-link-add" data-action="add-link">' + t("exLinkBook") + '</button></div>';
}
// Wire one owner's link row (a part card, an assignment row, or the edit
// modal's link block): open the editor, remove one link, remove all
// links, or save the editor draft. getLinks/setLinks read/write the
// owner's own list; onSaved re-renders just that surface (renderAll by
// default; the modal passes its own re-render so the modal stays open).
function wireOwnerLinkRow(container, key, getLinks, setLinks, onSaved, onCancel) {
  const after = () => { saveState(); if (onSaved) onSaved(); else renderAll(); };
  container.querySelectorAll("[data-action='add-link'], [data-action='edit-link']").forEach(btn => btn.addEventListener("click", (e) => {
    e.stopPropagation();
    const links = getLinks();
    linkDraft = {
      bookId: (links[0] && links[0].bookId) || ((TESTBOOK.books || [])[0] || {}).id || "",
      entries: links.map(l => ({ bookId: l.bookId || "", chapterId: l.chapterId || "", sectionId: l.sectionId }))
    };
    linkEditingKey = key;
    if (onSaved) onSaved(); else renderAll();
  }));
  container.querySelectorAll("[data-action='del-one-link']").forEach(btn => btn.addEventListener("click", (e) => {
    e.stopPropagation();
    setLinks(getLinks().filter(l => l.sectionId !== btn.dataset.section));
    after();
  }));
  container.querySelectorAll("[data-action='del-link']").forEach(btn => btn.addEventListener("click", (e) => {
    e.stopPropagation();
    setLinks([]);
    linkEditingKey = null;
    linkDraft = null;
    after();
  }));
  const editor = container.querySelector(".link-editor");
  if (editor) wireLinkEditorSaveCancel(editor, (entries) => {
    setLinks(entries);
    linkEditingKey = null;
    linkDraft = null;
    after();
  }, onCancel ? () => { linkEditingKey = null; linkDraft = null; onCancel(); } : null);
}
// Multi-select editor wiring shared by every owner: book switch,
// chapter/section checkboxes, save (deduped, in book order) / cancel.
// onCancel re-renders the owner's surface instead of the whole app
// (the edit modal passes its own re-render so the modal stays open).
function wireLinkEditorSaveCancel(editor, onSave, onCancel) {
  const bookSel = editor.querySelector(".bl-book");
  bookSel.addEventListener("change", () => {
    linkDraft.bookId = bookSel.value;
    renderLinkChapters(editor);
  });
  wireLinkChapterEvents(editor);
  refreshLinkEditor(editor);
  editor.querySelector(".bl-save").addEventListener("click", (e) => {
    e.stopPropagation();
    if (!linkDraft.entries.length) { alert(t("exLinkNeedSection")); return; }
    const order = linkDraftOrderIndex();
    const entries = linkDraft.entries
      .filter((l, i, arr) => arr.findIndex(x => x.sectionId === l.sectionId) === i)
      .map(l => ({ bookId: l.bookId || "", chapterId: l.chapterId || "", sectionId: l.sectionId }))
      .sort((a, b) => (order[a.sectionId] != null ? order[a.sectionId] : 1e9) -
                       (order[b.sectionId] != null ? order[b.sectionId] : 1e9));
    onSave(entries);
  });
  editor.querySelector(".bl-cancel").addEventListener("click", (e) => {
    e.stopPropagation();
    linkEditingKey = null;
    linkDraft = null;
    if (onCancel) onCancel(); else renderAll();
  });
}
// "Book — Chapter — Section" label for one link (null when broken).
function linkLabel(l) {
  const found = topicById(l.sectionId);
  if (!found) return null;
  const parts = [];
  if (found.book) parts.push(bookName(found.book));
  if (found.chapter) parts.push(chapterTitle(found.chapter));
  parts.push(topicTitle(found.topic));
  return parts.join(" — ");
}
// The open multi-select editor's draft (UI-only, not persisted until Save).
let linkDraft = null; // { bookId, entries: [{ bookId, chapterId, sectionId }] }
function linkDraftOrderIndex() {
  const order = {};
  let i = 0;
  (TESTBOOK.books || []).forEach(book => (book.chapters || []).forEach(ch =>
    (ch.topics || []).forEach(tp => { order[tp.id] = i++; })));
  return order;
}
function linkRowHtml(tp, key) {
  return genericLinkRowHtml(topicLinks(tp), key);
}
// One chapter of the link editor: a header row with the chapter's
// select-all checkbox + an expand toggle + "x/y selected" count, and a
// collapsible body listing every section with its own checkbox.
// (A plain div, not <details>: a checkbox inside <summary> would toggle
// the chapter open/closed on every click.)
function linkEditorChapterHtml(book, ch, draftSet, open) {
  const topics = ch.topics || [];
  const sel = topics.filter(tp2 => draftSet.has(tp2.id)).length;
  return '<div class="bl-ch" data-chapter="' + esc(ch.id) + '">' +
    '<div class="bl-ch-head"><input type="checkbox" class="bl-ch-all" ' + (topics.length && sel === topics.length ? "checked" : "") +
    ' aria-label="' + esc(t("exLinkSelectAll")) + '">' +
    '<button type="button" class="bl-ch-toggle"><span class="bl-ch-chev">' + (open ? "▾" : "▸") + '</span>' +
    '<span class="bl-ch-name">' + esc(chapterTitle(ch)) + '</span>' +
    '<span class="bl-ch-count">' + FA(sel) + '/' + FA(topics.length) + '</span></button></div>' +
    '<div class="bl-sections"' + (open ? "" : ' style="display:none"') + '>' + topics.map(tp2 =>
      '<label class="bl-sec"><input type="checkbox" class="bl-sec-cb" data-section="' + esc(tp2.id) +
      '" data-chapter="' + esc(ch.id) + '" data-book="' + esc(book.id) + '"' +
      (draftSet.has(tp2.id) ? " checked" : "") + '><span>' + esc(topicTitle(tp2)) + '</span></label>').join("") +
    '</div></div>';
}
function linkEditorHtml() {
  const books = TESTBOOK.books || [];
  const draft = linkDraft || { bookId: "", entries: [] };
  const book = books.find(b => b.id === draft.bookId) || books[0] || null;
  const draftSet = new Set(draft.entries.map(l => l.sectionId));
  const chips = draft.entries.map(l => {
    const label = linkLabel(l);
    return '<span class="book-link-chip">' + esc(label || t("exLinkBroken")) +
      '<button class="bl-chip-x" data-action="del-draft-link" data-section="' + esc(l.sectionId) +
      '" title="' + esc(t("exLinkRemoveOne")) + '">✕</button></span>';
  }).join("");
  return '<div class="link-editor">' +
    '<select class="bl-book">' + books.map(b =>
      '<option value="' + b.id + '"' + (book && b.id === book.id ? " selected" : "") + '>' + esc(bookName(b)) + '</option>').join("") + '</select>' +
    '<div class="bl-selected">' +
      (draft.entries.length ? chips : '<span class="muted">' + esc(t("exLinkNoneSelected")) + '</span>') +
    '</div>' +
    '<div class="bl-selected-count">' + t("exLinkSelected", { n: FA(draft.entries.length) }) + '</div>' +
    '<div class="bl-chapters">' + (book ? (book.chapters || []).map((ch, ci) =>
      linkEditorChapterHtml(book, ch, draftSet, ci === 0)).join("") : "") + '</div>' +
    '<div class="bl-actions">' +
    '<button class="btn btn-lime bl-save">' + t("exLinkSave") + '</button>' +
    '<button class="btn bl-cancel">' + t("exLinkCancel") + '</button></div></div>';
}
// Rebuild only the chapter list (book switch); then refresh counts/chips.
function renderLinkChapters(editor) {
  const books = TESTBOOK.books || [];
  const book = books.find(b => b.id === linkDraft.bookId) || books[0] || null;
  const draftSet = new Set(linkDraft.entries.map(l => l.sectionId));
  const box = editor.querySelector(".bl-chapters");
  box.innerHTML = book ? (book.chapters || []).map((ch, ci) =>
    linkEditorChapterHtml(book, ch, draftSet, ci === 0)).join("") : "";
  wireLinkChapterEvents(editor);
  refreshLinkEditor(editor);
}
// Sync chips, count, chapter counts and checkboxes with the draft —
// without rebuilding the editor (keeps open chapters and scroll position).
function refreshLinkEditor(editor) {
  const draftSet = new Set(linkDraft.entries.map(l => l.sectionId));
  const selBox = editor.querySelector(".bl-selected");
  selBox.innerHTML = linkDraft.entries.length ? linkDraft.entries.map(l => {
    const label = linkLabel(l);
    return '<span class="book-link-chip">' + esc(label || t("exLinkBroken")) +
      '<button class="bl-chip-x" data-action="del-draft-link" data-section="' + esc(l.sectionId) +
      '" title="' + esc(t("exLinkRemoveOne")) + '">✕</button></span>';
  }).join("") : '<span class="muted">' + esc(t("exLinkNoneSelected")) + '</span>';
  editor.querySelector(".bl-selected-count").textContent = t("exLinkSelected", { n: FA(linkDraft.entries.length) });
  editor.querySelectorAll(".bl-ch").forEach(det => {
    const cbs = [...det.querySelectorAll(".bl-sec-cb")];
    const sel = cbs.filter(cb => draftSet.has(cb.dataset.section)).length;
    const count = det.querySelector(".bl-ch-count");
    if (count) count.textContent = FA(sel) + "/" + FA(cbs.length);
    const all = det.querySelector(".bl-ch-all");
    if (all) {
      all.checked = cbs.length > 0 && sel === cbs.length;
      all.indeterminate = sel > 0 && sel < cbs.length;
    }
    cbs.forEach(cb => { cb.checked = draftSet.has(cb.dataset.section); });
  });
  selBox.querySelectorAll("[data-action='del-draft-link']").forEach(btn =>
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      linkDraft.entries = linkDraft.entries.filter(l => l.sectionId !== btn.dataset.section);
      refreshLinkEditor(editor);
    }));
}
function wireLinkChapterEvents(editor) {
  editor.querySelectorAll(".bl-ch-toggle").forEach(btn => btn.addEventListener("click", (e) => {
    e.stopPropagation();
    const ch = btn.closest(".bl-ch");
    const secs = ch.querySelector(".bl-sections");
    const chev = btn.querySelector(".bl-ch-chev");
    const isOpen = secs.style.display !== "none";
    secs.style.display = isOpen ? "none" : "";
    if (chev) chev.textContent = isOpen ? "▸" : "▾";
  }));
  editor.querySelectorAll(".bl-ch-all").forEach(all => all.addEventListener("change", (e) => {
    e.stopPropagation();
    const det = all.closest(".bl-ch");
    const cbs = [...det.querySelectorAll(".bl-sec-cb")];
    if (all.checked) {
      cbs.forEach(cb => {
        if (!linkDraft.entries.some(l => l.sectionId === cb.dataset.section))
          linkDraft.entries.push({ bookId: cb.dataset.book, chapterId: cb.dataset.chapter, sectionId: cb.dataset.section });
      });
    } else {
      const ids = new Set(cbs.map(cb => cb.dataset.section));
      linkDraft.entries = linkDraft.entries.filter(l => !ids.has(l.sectionId));
    }
    refreshLinkEditor(editor);
  }));
  editor.querySelectorAll(".bl-sec-cb").forEach(cb => cb.addEventListener("change", () => {
    if (cb.checked) {
      if (!linkDraft.entries.some(l => l.sectionId === cb.dataset.section))
        linkDraft.entries.push({ bookId: cb.dataset.book, chapterId: cb.dataset.chapter, sectionId: cb.dataset.section });
    } else {
      linkDraft.entries = linkDraft.entries.filter(l => l.sectionId !== cb.dataset.section);
    }
    refreshLinkEditor(editor);
  }));
}
function budgetHtml(ex) {
  if (!ex.budget || !ex.budget.length) return "";
  let html = '<div class="budget">';
  ex.budget.forEach((s, si) => {
    html += '<div class="budget-subj"><div class="bs-head"><span class="bs-name">' +
      esc(subjName(s.subject)) + '</span><span class="bs-q">' +
      (s.questions != null ? t("exQuestions", { n: FA(s.questions) }) : "—") + '</span></div>';
    (s.chapters || []).forEach((ch, ci) => {
      const chKey = ex.id + "|" + si + "|" + ci;
      html += '<details class="budget-ch" data-chkey="' + esc(chKey) + '"' +
        (openBudgetChapters.has(chKey) ? " open" : "") + '><summary>' + esc(subjName(ch.name)) + '</summary>';
      (ch.topics || []).forEach((tp, ti) => {
        const key = ex.id + "|" + si + "|" + ci + "|" + ti;
        const open = expandedBudgetTopics.has(key);
        const p = budgetTopicProgress(s.subject, tp.name, tp.subtopics, topicLinks(tp));
        const pill = p.subtopics
          ? '<span class="prog-pill p-' + p.state + '">' + t("exSubProgress", { done: FA(p.solved), total: FA(p.total) }) + '</span>'
          : progPillHtml(p.state);
        html += '<div class="budget-topic-wrap" data-tkey="' + esc(key) + '">' +
          '<div class="budget-topic">' +
          '<button class="bt-toggle" data-action="toggle" title="' + esc(t("exSubtopics")) + '">' +
          '<span class="bt-chev">' + (open ? "▾" : "▸") + '</span>' +
          '<span class="bt-name">' + esc(tp.name) + '</span></button>' +
          '<span class="bt-q">' + (tp.questions != null ? FA(tp.questions) : "—") + '</span>' +
          pill +
          (p.links.length ? '<button class="jump-btn bt-asg" data-topic="' + p.links[0] +
            '" data-subject="' + esc(s.subject) + '">' + t("exAddAssignment") + '</button>' : '') +
          '</div>';
        html += linkRowHtml(tp, key);
        if (open) html += subtopicsPanelHtml(ex, s, ch, tp, key);
        html += '</div>';
      });
      html += '</details>';
    });
    html += '</div>';
  });
  return html + '</div>';
}
function wireBudgetSubtopics(container, ex) {
  container.querySelectorAll(".budget-ch").forEach(d => {
    d.addEventListener("toggle", () => {
      if (d.open) openBudgetChapters.add(d.dataset.chkey);
      else openBudgetChapters.delete(d.dataset.chkey);
    });
  });
  container.querySelectorAll(".budget-topic-wrap").forEach(wrap => {
    const key = wrap.dataset.tkey;
    const parts = key.split("|");
    const si = +parts[1], ci = +parts[2], ti = +parts[3];
    // Always resolve the LIVE topic object from state (renderAll rebuilds
    // the DOM, so stale references would silently edit a dead copy).
    const getTp = () => {
      const live = findExam(ex.id);
      if (!live) return null;
      const s = (live.budget || [])[si];
      if (!s) return null;
      const ch = (s.chapters || [])[ci];
      if (!ch) return null;
      return (ch.topics || [])[ti] || null;
    };
    const getCtx = () => {
      const live = findExam(ex.id) || ex;
      const s = (live.budget || [])[si] || {};
      const ch = (s.chapters || [])[ci] || {};
      return { live, subject: s.subject || "", chapter: ch.name || "" };
    };
    const refresh = () => { saveState(); renderAll(); };
    // Manual book links: open the multi-select editor, remove one link,
    // or remove all links of this topic.
    wrap.querySelectorAll("[data-action='add-link'], [data-action='edit-link']").forEach(btn => btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const tp = getTp();
      const links = topicLinks(tp);
      linkDraft = {
        bookId: (links[0] && links[0].bookId) || ((TESTBOOK.books || [])[0] || {}).id || "",
        entries: links.map(l => ({ bookId: l.bookId || "", chapterId: l.chapterId || "", sectionId: l.sectionId }))
      };
      linkEditingKey = key;
      renderAll();
    }));
    wrap.querySelectorAll("[data-action='del-one-link']").forEach(btn => btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const tp = getTp();
      if (!tp) return;
      tp.bookLinks = topicLinks(tp).filter(l => l.sectionId !== btn.dataset.section);
      refresh();
    }));
    wrap.querySelectorAll("[data-action='del-link']").forEach(btn => btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const tp = getTp();
      if (!tp) return;
      tp.bookLinks = [];
      delete tp.bookLink;
      linkEditingKey = null;
      linkDraft = null;
      refresh();
    }));
    // Multi-select editor: book switch, chapter/section checkboxes, save/cancel.
    const editor = wrap.querySelector(".link-editor");
    if (editor) wireLinkEditorSaveCancel(editor, (entries) => {
      const tp = getTp();
      if (!tp) return;
      tp.bookLinks = entries;
      delete tp.bookLink;
      linkEditingKey = null;
      linkDraft = null;
      refresh();
    });
    wrap.querySelectorAll(".bt-toggle").forEach(btn => btn.addEventListener("click", (e) => {
      e.stopPropagation();
      if (expandedBudgetTopics.has(key)) expandedBudgetTopics.delete(key);
      else expandedBudgetTopics.add(key);
      renderAll();
    }));
    wrap.querySelectorAll(".sub-prompt-btn").forEach(btn => btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const tp = getTp();
      if (!tp) return;
      const ctx = getCtx();
      copyTextToClipboard(buildGeminiPrompt(ctx.live, ctx.subject, ctx.chapter, tp.name), btn);
    }));
    wrap.querySelectorAll(".sub-row").forEach(row => {
      const subId = row.dataset.sub;
      const subDone = row.querySelector(".sub-done");
      if (subDone) subDone.addEventListener("change", (e) => {
        const tp = getTp();
        if (!tp) return;
        const sub = (tp.subtopics || []).find(s => s.id === subId);
        if (sub) { sub.done = e.target.checked; refresh(); }
      });
      const subName = row.querySelector(".sub-name");
      if (subName) subName.addEventListener("click", (e) => {
        e.stopPropagation();
        const tp = getTp();
        if (!tp) return;
        const sub = (tp.subtopics || []).find(s => s.id === subId);
        if (!sub) return;
        const name = prompt(t("exSubRenamePrompt"), sub.name);
        if (name == null) return;
        sub.name = name.trim() || sub.name;
        refresh();
      });
      const subQ = row.querySelector(".sub-q");
      if (subQ) subQ.addEventListener("change", (e) => {
        const tp = getTp();
        if (!tp) return;
        const sub = (tp.subtopics || []).find(s => s.id === subId);
        if (!sub) return;
        const v = e.target.value.trim();
        sub.questions = v === "" ? null : Math.max(0, parseInt(v, 10) || 0);
        refresh();
      });
      const subDel = row.querySelector(".sub-del");
      if (subDel) subDel.addEventListener("click", (e) => {
        e.stopPropagation();
        const tp = getTp();
        if (!tp) return;
        tp.subtopics = (tp.subtopics || []).filter(s => s.id !== subId);
        refresh();
      });
    });
    const addBtn = wrap.querySelector(".sub-add-btn");
    if (addBtn) addBtn.addEventListener("click", () => {
      const tp = getTp();
      if (!tp) return;
      const nameInp = wrap.querySelector(".sub-add-name");
      const qInp = wrap.querySelector(".sub-add-q");
      const name = (nameInp.value || "").trim();
      if (!name) return;
      const qv = (qInp.value || "").trim();
      ensureSubtopics(tp).push({
        id: newSubId(), name,
        questions: qv === "" ? null : Math.max(0, parseInt(qv, 10) || 0),
        done: false
      });
      refresh();
    });
    const bulkBtn = wrap.querySelector(".sub-bulk-btn");
    if (bulkBtn) bulkBtn.addEventListener("click", () => {
      const tp = getTp();
      if (!tp) return;
      const ta = wrap.querySelector(".sub-bulk");
      const lines = parseBulkLines(ta.value);
      if (!lines.length) return;
      const arr = ensureSubtopics(tp);
      lines.forEach(n => arr.push({ id: newSubId(), name: n, questions: null, done: false }));
      refresh();
    });
  });
}
function wireBudgetButtons(container) {
  container.querySelectorAll(".bt-asg").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      jumpToAssignmentForTopic(btn.dataset.topic, btn.dataset.subject);
    });
  });
}
function jumpToAssignmentForTopic(topicId, subjectName) {
  const found = topicById(topicId);
  if (!found) return;
  navigate({ tab: "assignments" });
  const subj = subjectForBook(found.book.id);
  const subjSel = document.getElementById("asgSubject");
  if (subj && subjSel) { subjSel.value = subj; asgFillCascade(); }
  setTimeout(() => {
    const bookSel = document.getElementById("asgBook");
    bookSel.value = found.book.id;
    bookSel.dispatchEvent(new Event("change"));
    setTimeout(() => {
      const chSel = document.getElementById("asgChapter");
      chSel.value = found.chapter.id;
      chSel.dispatchEvent(new Event("change"));
      setTimeout(() => {
        document.getElementById("asgTopic").value = topicId;
        document.getElementById("asgTitle").focus();
      }, 40);
    }, 40);
  }, 40);
}

// ---------- Dashboard: upcoming exams (30 days) + nearest exam budget ----------
function renderDashExams() {
  const wrap = document.getElementById("dashUpcomingExams");
  if (wrap) {
    wrap.innerHTML = "";
    const up = upcomingExams(30);
    // Same box, three columns: ماز / زودبیست / مدرسه. Same exams, same data
    // (30-day upcoming, nearest first), only regrouped by category.
    const cols = document.createElement("div");
    cols.className = "ovw-exams-cols";
    ["maz", "zoodbist", "school"].forEach(g => {
      const col = document.createElement("div");
      col.className = "ovw-exam-col";
      col.dataset.group = g;
      const h = document.createElement("h3");
      h.className = "ovw-exam-col-title";
      h.textContent = t(examGroupKey(g));
      col.appendChild(h);
      const list = up.filter(ex => ex.group === g);
      if (!list.length) {
        const p = document.createElement("p");
        p.className = "muted";
        p.textContent = t("exCatNone");
        col.appendChild(p);
      } else list.forEach(ex => {
        const days = examDaysLeft(ex);
        const r = examReadiness(ex);
        const row = document.createElement("div");
        row.className = "dash-exam-row";
        row.innerHTML =
          '<span class="type-badge b-' + ex.group + '">' + t(examGroupKey(ex.group)) + '</span>' +
          '<span class="de-name">' + esc(examDisplayName(ex)) + '</span>' +
          '<span class="de-date">' + esc(examDateText(ex)) + '</span>' +
          '<span class="de-days">' + (days === 0 ? t("exToday") : (days === 1 ? t("exDayLeft") : t("exDaysLeft", { n: FA(days) }))) + '</span>' +
          '<span class="de-read">' + (r ? t("exReadiness") + ": " + FA_PCT(r.pct / 100) + " " + progPillHtml(r.state) : t("exNoReadiness")) + '</span>';
        row.addEventListener("click", () => openExamDetail(ex.id));
        col.appendChild(row);
      });
      cols.appendChild(col);
    });
    wrap.appendChild(cols);
  }
  const nb = document.getElementById("dashNearestBudget");
  if (!nb) return;
  nb.innerHTML = "";
  const near = nearestExam();
  if (!near) { nb.innerHTML = '<p class="muted">' + t("exNoUpcoming") + '</p>'; return; }
  const days = examDaysLeft(near);
  const head = document.createElement("div");
  head.className = "dash-nearest";
  head.innerHTML = '<div class="dn-label">' + t("dashNearestLabel") + '</div>' +
    '<div class="dn-title">' + esc(examDisplayName(near)) +
    ' <span class="type-badge b-' + near.group + '">' + t(examGroupKey(near.group)) + '</span></div>' +
    '<div class="dn-meta">' + esc(examDateText(near)) + ' · ' +
    (days === 0 ? t("exToday") : (days === 1 ? t("exDayLeft") : t("exDaysLeft", { n: FA(days) }))) +
    ' · ' + esc(examTypeLabel(near.type)) + '</div>';
  head.addEventListener("click", () => openExamDetail(near.id));
  nb.appendChild(head);
  if (near.budget && near.budget.length) {
    const bwrap = document.createElement("div");
    bwrap.innerHTML = budgetHtml(near);
    wireBudgetButtons(bwrap);
    wireBudgetSubtopics(bwrap, near);
    nb.appendChild(bwrap);
  } else {
    const p = document.createElement("p");
    p.className = "muted";
    p.textContent = t("exNoBudget");
    nb.appendChild(p);
    const btn = document.createElement("button");
    btn.className = "btn btn-lime";
    btn.textContent = t("exAddBudget");
    btn.addEventListener("click", () => openExamModal(near.id));
    nb.appendChild(btn);
  }
}
function openExamDetail(id) {
  const ex = findExam(id);
  if (!ex) return;
  navigate({ tab: "exams", examGroup: ex.group, examView: "list", examId: id, scroll: { type: "exam", id } });
}

// ---------- Exams tab: two-column management layout ----------
// Start column: three category cards (initial state) or the selected
// category's exam list (compact cards, independent scroll).
// End column: an empty-state hint (initial) or the selected exam's full
// detail card (budget, result, actions — the existing examCard).
// Selection changes re-render the panels only; there is no page reload.
const EXAM_CAT_ICONS = {
  maz: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>',
  zoodbist: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>',
  school: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10L12 5 2 10l10 5 10-5z"/><path d="M6 12v5c0 1.7 2.7 3 6 3s6-1.3 6-3v-5"/></svg>'
};
const EXAM_CAT_DESC = { maz: "exCatMazDesc", zoodbist: "exCatZbDesc", school: "exCatSchoolDesc" };

function examCatCard(group) {
  const items = (state.exams[group] || []).slice()
    .sort((a, b) => (a.date || "9999").localeCompare(b.date || "9999"));
  const next = items.find(e => isUpcomingExam(e));
  const card = document.createElement("button");
  card.className = "exam-cat-card cat-" + group;
  card.innerHTML =
    '<span class="cat-ico">' + EXAM_CAT_ICONS[group] + '</span>' +
    '<span class="cat-body"><span class="cat-name">' + t(examGroupKey(group)) + '</span>' +
    '<span class="cat-desc">' + t(EXAM_CAT_DESC[group]) + '</span>' +
    '<span class="cat-meta"><span>' + t("exCatCount", { n: FA(items.length) }) + '</span>' +
    (next
      ? '<span>' + t("exCatNext", { date: examDateText(next) }) + '</span>'
      : '<span>' + t("exCatNone") + '</span>') +
    '</span></span>';
  card.addEventListener("click", () => {
    navigate({ tab: "exams", examGroup: group, examView: "list", examId: items.length ? items[0].id : null });
  });
  return card;
}
function examListItem(ex, isNext, isSelected) {
  const status = examStatusOf(ex);
  const days = examDaysLeft(ex);
  const statusKey = { upcoming: "exStatusUpcoming", held: "exStatusHeld",
                      analyzed: "exStatusAnalyzed" }[status];
  const item = document.createElement("button");
  item.className = "exam-list-item" + (isSelected ? " selected" : "");
  item.innerHTML =
    '<span class="eli-top"><span class="eli-name">' + esc(examDisplayName(ex)) + '</span>' +
    '<span class="exam-status ' + (isNext ? "next" : status) + '">' +
    esc(isNext ? t("exStatusNext") : t(statusKey)) + '</span></span>' +
    '<span class="eli-meta"><span>' + esc(examDateText(ex)) + '</span>' +
    '<span>' + esc(examTypeLabel(ex.type)) + '</span>' +
    (ex.questions ? '<span>' + t("exQuestions", { n: FA(ex.questions) }) + '</span>' : '') +
    (days != null && status === "upcoming"
      ? '<span class="eli-days">' + (days === 0 ? t("exToday") : (days === 1 ? t("exDayLeft") : t("exDaysLeft", { n: FA(days) }))) + '</span>'
      : '') +
    '</span>';
  item.addEventListener("click", () => { navigate({ tab: "exams", examGroup: ex.group, examView: "list", examId: ex.id }); });
  return item;
}
function examDetailEmptyHtml(hintKey) {
  return '<div class="exam-detail-empty"><div class="ede-ico">' + EXAM_CAT_ICONS.maz +
    '</div><div class="ede-title">' + t("tabExams") + '</div><p>' + t(hintKey) + '</p></div>';
}
function renderExams() {
  const banner = document.getElementById("examNextBanner");
  const start = document.getElementById("examsStart");
  const detail = document.getElementById("examsDetail");
  if (!banner || !start || !detail) return;
  ensureExams();
  const next = nearestExam();
  if (next) {
    const days = examDaysLeft(next);
    banner.innerHTML = '<div class="exam-next"><div class="en-label">' + t("exNextExam") + '</div>' +
      '<div class="en-title">' + esc(examGroupLabel(next) + " — " + examDisplayName(next)) + '</div>' +
      '<div class="en-meta">' + esc(examDateText(next)) + ' · ' + esc(examTypeLabel(next.type)) + '</div>' +
      '<div class="en-days">' + (days === 0 ? t("exToday") : (days === 1 ? t("exDayLeft") : t("exDaysLeft", { n: FA(days) }))) + '</div></div>';
  } else {
    banner.innerHTML = '<p class="muted">' + t("exNoUpcoming") + '</p>';
  }

  start.innerHTML = "";
  detail.innerHTML = "";
  if (examView === "cats") {
    ["maz", "zoodbist", "school"].forEach(g => start.appendChild(examCatCard(g)));
    detail.innerHTML = examDetailEmptyHtml("exSelectCatHint");
    return;
  }
  // List view for the selected category.
  const back = document.createElement("button");
  back.className = "btn exams-back";
  back.textContent = "← " + t("exBackToCats");
  back.addEventListener("click", () => { navigate({ tab: "exams", examView: "cats", examId: null }); });
  start.appendChild(back);
  const note = document.createElement("p");
  note.className = "muted";
  note.textContent = t({ maz: "exGroupMazNote", zoodbist: "exGroupZbNote", school: "exGroupSchoolNote" }[examGroup]);
  start.appendChild(note);
  const addBtn = document.createElement("button");
  addBtn.className = "btn btn-lime";
  addBtn.textContent = t("exAddExam");
  addBtn.addEventListener("click", () => openExamModal(null, examGroup));
  start.appendChild(addBtn);
  const items = (state.exams[examGroup] || []).slice()
    .sort((a, b) => (a.date || "9999").localeCompare(b.date || "9999") || (a.stage || 0) - (b.stage || 0));
  if (!selectedExamId || !items.some(e => e.id === selectedExamId)) {
    selectedExamId = items.length ? items[0].id : null;
  }
  const list = document.createElement("div");
  list.className = "exams-list";
  items.forEach(ex => list.appendChild(examListItem(ex, next && ex.id === next.id, ex.id === selectedExamId)));
  start.appendChild(list);
  const sel = selectedExamId ? findExam(selectedExamId) : null;
  if (sel) detail.appendChild(examCard(sel, next && sel.id === next.id));
  else detail.innerHTML = examDetailEmptyHtml("exSelectExamHint");
}
function examResultHtml(ex) {
  const r = ex.result;
  if (!r) return '<p class="muted">' + t("exNoResult") + '</p>';
  const attempted = (r.correct || 0) + (r.wrong || 0);
  const acc = attempted ? (r.correct / attempted * 100) : null;
  let html = '<div class="exam-result"><span><b>' + t("exTaraz") + ':</b> ' +
    (r.taraz != null ? FA(r.taraz) : "—") + '</span>' +
    '<span><b>' + t("exRank") + ':</b> ' + (r.rank != null ? FA(r.rank) : "—") +
    (r.rankTotal != null ? ' ' + t("exRankOf", { n: FA(r.rankTotal) }) : "") + '</span>' +
    '<span><b>' + t("exCorrect") + ':</b> ' + FA(r.correct || 0) + '</span>' +
    '<span><b>' + t("exWrong") + ':</b> ' + FA(r.wrong || 0) + '</span>' +
    '<span><b>' + t("exUnanswered") + ':</b> ' + FA(r.unanswered || 0) + '</span>' +
    (acc != null ? '<span><b>' + t("exAccuracy") + ':</b> ' + FA_PCT(acc) +
      ' <span class="muted">(' + t("exAttempted", { n: FA(attempted) }) + ')</span></span>' : "") +
    '</div>';
  if (r.note) html += '<p class="muted">' + t("exNote") + ': ' + esc(r.note) + '</p>';
  return html;
}
function examCard(ex, isNext) {
  const status = examStatusOf(ex);
  const r = ex.result || {};
  const card = document.createElement("div");
  card.className = "exam-card st-" + status + (isNext ? " st-next" : "");
  card.id = "exam-card-" + ex.id;
  const statusKey = { upcoming: "exStatusUpcoming", held: "exStatusHeld",
                      analyzed: "exStatusAnalyzed" }[status];
  const statusText = isNext ? t("exStatusNext") : t(statusKey);
  const days = examDaysLeft(ex);
  card.innerHTML =
    '<div class="exam-head"><span class="exam-title">' + esc(examGroupLabel(ex) + " — " + examDisplayName(ex)) + '</span>' +
    '<span class="exam-status ' + (isNext ? "next" : status) + '">' + esc(statusText) + '</span></div>' +
    '<div class="exam-meta"><span class="type-badge b-' + ex.group + '">' + t(examGroupKey(ex.group)) + '</span> ' +
    esc(examDateText(ex)) + ' · ' + esc(examTypeLabel(ex.type)) + ' · ' +
    (ex.questions ? t("exQuestions", { n: FA(ex.questions) }) : t("exQuestionsDescriptive")) +
    (days != null && status === "upcoming" ? ' · ' + (days === 0 ? t("exToday") : (days === 1 ? t("exDayLeft") : t("exDaysLeft", { n: FA(days) }))) : "") + '</div>' +
    '<div class="exam-focus">' + esc(LANG === "fa" ? (ex.focusFa || "") : (ex.focusEn || ex.focusFa || "")) + '</div>' +
    '<div class="exam-budget-wrap">' + (ex.budget && ex.budget.length ? budgetHtml(ex) : '<p class="muted">' + t("exNoBudget") + '</p>') + '</div>' +
    '<div class="exam-result-wrap">' + examResultHtml(ex) + '</div>' +
    '<div class="part-actions">' +
      '<button class="edit-btn ex-edit">' + t("exEditExam") + '</button>' +
      '<button class="edit-btn ex-result-btn">' + t("exEditResult") + '</button>' +
      '<button class="del-btn ex-del">' + t("exDeleteExam") + '</button>' +
    '</div>' +
    '<div class="exam-form" hidden>' +
      '<div class="form-row">' +
        '<label>' + t("exTaraz") + ' <input type="number" min="0" class="xf-taraz" value="' + (r.taraz != null ? r.taraz : "") + '"></label>' +
        '<label>' + t("exRank") + ' <input type="number" min="0" class="xf-rank" value="' + (r.rank != null ? r.rank : "") + '"></label>' +
        '<label>' + t("exRankOf", { n: "" }).trim() + ' <input type="number" min="0" class="xf-ranktotal" value="' + (r.rankTotal != null ? r.rankTotal : "") + '"></label>' +
      '</div>' +
      '<div class="form-row">' +
        '<label>' + t("exCorrect") + ' <input type="number" min="0" class="xf-correct" value="' + (r.correct != null ? r.correct : "") + '"></label>' +
        '<label>' + t("exWrong") + ' <input type="number" min="0" class="xf-wrong" value="' + (r.wrong != null ? r.wrong : "") + '"></label>' +
        '<label>' + t("exUnanswered") + ' <input type="number" min="0" class="xf-unanswered" value="' + (r.unanswered != null ? r.unanswered : "") + '"></label>' +
      '</div>' +
      '<div class="form-row"><label style="flex:1">' + t("exNote") + ' <input type="text" class="xf-note" value="' + esc(r.note || "") + '" placeholder="' + esc(t("exNotePh")) + '"></label></div>' +
      '<div class="form-row">' +
        '<button class="btn btn-lime xf-save">' + t("exSaveResult") + '</button>' +
        (ex.result ? '<button class="btn xf-del">' + t("exDeleteResult") + '</button>' : '') +
      '</div>' +
    '</div>';
  wireBudgetButtons(card);
  wireBudgetSubtopics(card, ex);
  const form = card.querySelector(".exam-form");
  card.querySelector(".ex-result-btn").addEventListener("click", () => { form.hidden = !form.hidden; });
  card.querySelector(".ex-edit").addEventListener("click", () => openExamModal(ex.id));
  card.querySelector(".ex-del").addEventListener("click", () => {
    if (!confirm(t("exDeleteExamConfirm"))) return;
    deleteExamById(ex.id);
  });
  const numVal = (sel) => {
    const v = card.querySelector(sel).value.trim();
    return v === "" ? null : Math.max(0, parseInt(v, 10) || 0);
  };
  card.querySelector(".xf-save").addEventListener("click", () => {
    ex.result = {
      taraz: numVal(".xf-taraz"), rank: numVal(".xf-rank"), rankTotal: numVal(".xf-ranktotal"),
      correct: numVal(".xf-correct"), wrong: numVal(".xf-wrong"), unanswered: numVal(".xf-unanswered"),
      note: card.querySelector(".xf-note").value.trim()
    };
    if (examStatusOf(ex) === "upcoming") ex.status = "analyzed";
    saveState(); renderAll();
    alert(t("exResultSaved"));
  });
  const del = card.querySelector(".xf-del");
  if (del) del.addEventListener("click", () => {
    if (!confirm(t("exDeleteResultConfirm"))) return;
    ex.result = null;
    saveState(); renderAll();
  });
  return card;
}
function deleteExamById(id) {
  const ex = findExam(id);
  if (!ex) return;
  state.exams[ex.group] = (state.exams[ex.group] || []).filter(x => x.id !== id);
  state.examsRemoved = state.examsRemoved || [];
  if (!state.examsRemoved.includes(id)) state.examsRemoved.push(id);
  saveState(); renderAll();
  alert(t("exExamDeleted"));
}

// ---------- Exam create/edit modal (incl. structured budget editor) ----------
let editingExamId = null;
let editingBudget = [];
function cleanBudget(budget) {
  return (budget || []).filter(s => s.subject && s.subject.trim()).map(s => ({
    subject: s.subject.trim(),
    questions: (s.questions === "" || s.questions == null) ? null : Math.max(0, parseInt(s.questions, 10) || 0),
    chapters: (s.chapters || []).filter(ch => (ch.name && ch.name.trim()) || (ch.topics || []).some(tp => tp.name && tp.name.trim())).map(ch => ({
      name: (ch.name || "").trim(),
      topics: (ch.topics || []).filter(tp => tp.name && tp.name.trim()).map(tp => {
        const out = {
          name: tp.name.trim(),
          questions: (tp.questions === "" || tp.questions == null) ? null : Math.max(0, parseInt(tp.questions, 10) || 0)
        };
        // Subtopics live on the topic: keep them through a modal edit, or
        // editing an exam in the modal would silently wipe them.
        const subs = (tp.subtopics || []).filter(s => s.name && s.name.trim()).map(s => ({
          id: s.id || newSubId(), name: s.name.trim(),
          questions: (s.questions === "" || s.questions == null) ? null : Math.max(0, parseInt(s.questions, 10) || 0),
          done: !!s.done
        }));
        if (subs.length) out.subtopics = subs;
        // Manual book links live on the topic too: keep them through a
        // modal edit (migrating the old single bookLink to the list).
        const links = topicLinks(tp);
        if (links.length) out.bookLinks = links.map(l => ({
          bookId: l.bookId || "", chapterId: l.chapterId || "",
          sectionId: l.sectionId
        }));
        return out;
      })
    }))
  })).filter(s => s.chapters.length);
}
function renderBudgetEditor() {
  const wrap = document.getElementById("xfBudget");
  wrap.innerHTML = "";
  editingBudget.forEach((s, si) => {
    const sDiv = document.createElement("div");
    sDiv.className = "be-subj";
    sDiv.innerHTML =
      '<div class="form-row"><input type="text" class="be-subject" list="budgetSubjectList" placeholder="' + esc(t("exBudgetSubjectPh")) + '" value="' + esc(s.subject || "") + '">' +
      '<input type="number" min="0" class="be-subj-q" placeholder="' + esc(t("exBudgetQuestions")) + '" value="' + (s.questions != null ? s.questions : "") + '">' +
      '<button class="btn be-del-subj" title="' + esc(t("delBtn")) + '">✕</button></div>' +
      '<div class="be-chapters"></div>' +
      '<button class="btn be-add-ch">' + t("exAddChapter") + '</button>';
    sDiv.querySelector(".be-subject").addEventListener("input", (e) => { s.subject = e.target.value; });
    sDiv.querySelector(".be-subj-q").addEventListener("input", (e) => { s.questions = e.target.value === "" ? null : e.target.value; });
    sDiv.querySelector(".be-del-subj").addEventListener("click", () => {
      editingBudget.splice(si, 1); renderBudgetEditor();
    });
    const chWrap = sDiv.querySelector(".be-chapters");
    (s.chapters || []).forEach((ch, ci) => {
      const cDiv = document.createElement("div");
      cDiv.className = "be-ch";
      cDiv.innerHTML =
        '<div class="form-row"><input type="text" class="be-ch-name" placeholder="' + esc(t("exBudgetChapterPh")) + '" value="' + esc(ch.name || "") + '">' +
        '<button class="btn be-del-ch" title="' + esc(t("delBtn")) + '">✕</button></div>' +
        '<div class="be-topics"></div>' +
        '<button class="btn be-add-topic">' + t("exAddTopic") + '</button>';
      cDiv.querySelector(".be-ch-name").addEventListener("input", (e) => { ch.name = e.target.value; });
      cDiv.querySelector(".be-del-ch").addEventListener("click", () => {
        s.chapters.splice(ci, 1); renderBudgetEditor();
      });
      const tpWrap = cDiv.querySelector(".be-topics");
      (ch.topics || []).forEach((tp, ti) => {
        const tRow = document.createElement("div");
        tRow.className = "form-row be-topic";
        tRow.innerHTML =
          '<input type="text" class="be-topic-name" placeholder="' + esc(t("exBudgetTopicPh")) + '" value="' + esc(tp.name || "") + '">' +
          '<input type="number" min="0" class="be-topic-q" placeholder="' + esc(t("exBudgetQuestions")) + '" value="' + (tp.questions != null ? tp.questions : "") + '">' +
          '<button class="btn be-del-topic" title="' + esc(t("delBtn")) + '">✕</button>';
        tRow.querySelector(".be-topic-name").addEventListener("input", (e) => { tp.name = e.target.value; });
        tRow.querySelector(".be-topic-q").addEventListener("input", (e) => { tp.questions = e.target.value === "" ? null : e.target.value; });
        tRow.querySelector(".be-del-topic").addEventListener("click", () => {
          ch.topics.splice(ti, 1); renderBudgetEditor();
        });
        tpWrap.appendChild(tRow);
      });
      cDiv.querySelector(".be-add-topic").addEventListener("click", () => {
        ch.topics.push({ name: "", questions: null }); renderBudgetEditor();
      });
      chWrap.appendChild(cDiv);
    });
    sDiv.querySelector(".be-add-ch").addEventListener("click", () => {
      s.chapters.push({ name: "", topics: [{ name: "", questions: null }] }); renderBudgetEditor();
    });
    wrap.appendChild(sDiv);
  });
  // datalist of known subjects for the subject inputs
  let dl = document.getElementById("budgetSubjectList");
  if (!dl) {
    dl = document.createElement("datalist");
    dl.id = "budgetSubjectList";
    document.body.appendChild(dl);
  }
  dl.innerHTML = ["حسابان", "هندسه", "گسسته و آمار", "فیزیک", "شیمی",
                  "ادبیات", "عربی", "دینی", "زبان انگلیسی"].map(s => "<option value=\"" + esc(s) + "\">").join("");
}
function fillExamModal(id, group) {
  editingExamId = id || null;
  const ex = id ? findExam(id) : null;
  const g = ex ? ex.group : (group || "maz");
  document.getElementById("examModalTitle").textContent = ex ? t("exEditExam") : t("exAddExam");
  // Only prefill the name when the user set one explicitly. Seed exams get
  // their display name COMPUTED (stage/subject), so it keeps translating
  // between FA/EN; storing the computed FA name would freeze it in Persian.
  document.getElementById("xfName").value = ex && ex.name ? ex.name : "";
  document.getElementById("xfName").placeholder = ex ? examDisplayName(ex) : t("exExamNamePh");
  document.getElementById("xfGroup").value = g;
  document.getElementById("xfType").value = ex ? ex.type : (g === "school" ? "school" : g === "zoodbist" ? "descriptive" : "topical");
  document.getElementById("xfStatus").value = ex ? examStatusOf(ex) : "upcoming";
  document.getElementById("xfDate").value = ex && ex.date ? ex.date : "";
  document.getElementById("xfQuestions").value = ex && ex.questions != null ? ex.questions : "";
  document.getElementById("xfFocus").value = ex ? (ex.focusFa || "") : "";
  document.getElementById("xfDelete").style.display = ex ? "" : "none";
  editingBudget = ex ? JSON.parse(JSON.stringify(ex.budget || [])) : [];
  renderBudgetEditor();
  document.getElementById("examModal").classList.add("open");
}
// User-initiated open: fill the form AND push a history entry (Back closes it).
function openExamModal(id, group) { fillExamModal(id, group); pushModalRoute({ kind: "exam", examId: id || undefined, group: group || undefined }); }
function hideExamModalUI() {
  document.getElementById("examModal").classList.remove("open");
  editingExamId = null;
  editingBudget = [];
}
function closeExamModal() {
  hideExamModalUI();
  closeModalHistory();
}
document.getElementById("examClose").addEventListener("click", closeExamModal);
document.getElementById("xfCancel").addEventListener("click", closeExamModal);
document.getElementById("examModal").addEventListener("click", (e) => {
  if (e.target.id === "examModal") closeExamModal();
});
document.getElementById("xfAddSubject").addEventListener("click", () => {
  editingBudget.push({ subject: "", questions: null, chapters: [{ name: "", topics: [{ name: "", questions: null }] }] });
  renderBudgetEditor();
});
document.getElementById("xfDelete").addEventListener("click", () => {
  if (!editingExamId) return;
  if (!confirm(t("exDeleteExamConfirm"))) return;
  const id = editingExamId;
  closeExamModal();
  deleteExamById(id);
});
document.getElementById("xfSave").addEventListener("click", () => {
  const name = document.getElementById("xfName").value.trim();
  const group = document.getElementById("xfGroup").value;
  const type = document.getElementById("xfType").value;
  const status = document.getElementById("xfStatus").value;
  const date = document.getElementById("xfDate").value || null;
  const qv = document.getElementById("xfQuestions").value.trim();
  const questions = qv === "" ? null : Math.max(0, parseInt(qv, 10) || 0);
  const focus = document.getElementById("xfFocus").value.trim();
  const budget = cleanBudget(editingBudget);
  let savedId = editingExamId;
  if (editingExamId) {
    const ex = findExam(editingExamId);
    if (ex) {
      if (ex.group !== group) {
        state.exams[ex.group] = (state.exams[ex.group] || []).filter(x => x.id !== ex.id);
        ex.group = group;
        state.exams[group].push(ex);
      }
      // Keep name null for seed exams so the display name stays computed
      // (and therefore translatable); only an explicit user name is stored.
      Object.assign(ex, { name: name || null, type, status, date, questions,
                          budget, focusFa: focus, focusEn: focus });
      examGroup = group;
    }
  } else {
    const id = group + "-" + Date.now();
    const ex = { id, group, name: name || (t(examGroupKey(group)) + " — " + (date || t("exNoDate"))),
                 stage: null, subject: null, date, jalaliFa: null, jalaliEn: null,
                 type, questions, status, focusFa: focus, focusEn: focus, budget, result: null };
    state.exams[group].push(ex);
    examGroup = group;
    examView = "list";
    selectedExamId = ex.id;
    savedId = id;
  }
  saveState(); hideExamModalUI(); dismissModalEntry();
  navigate({ tab: "exams", examGroup: group, examView: "list", examId: savedId });
  alert(t("exExamSaved"));
});

// ---------- History routing (mouse side buttons + browser Back/Forward) ----------
// Every view is a route: {tab, examGroup, examView, examId, bookId, day, modal, scroll}.
// The route lives in the URL hash (#/exams/maz/maz-5) so a reload restores the
// view; the full route object (incl. the scroll target) lives in history.state.
// Back/Forward — mouse side buttons, Alt+Left/Right, browser buttons — fire
// popstate; we apply the stored route without touching history again.
// User-initiated navigation goes through navigate(): it pushes ONE entry per
// action and never pushes a duplicate of the current route. Modals get their
// own entry too, so Back closes the modal (same as Cancel — drafts are only
// committed on Save, and the exam modal edits a clone, so nothing saved is
// ever lost by going back).
const TABS = ["dashboard", "program", "assignments", "testbook", "remaining", "exams", "overview", "gemini", "backup", "analytics"];
let currentTab = "dashboard";
let currentRoute = null;
let modalPushed = false; // true only when WE pushed the modal's history entry
function normalizeRoute(r) {
  const out = { tab: (r && TABS.includes(r.tab)) ? r.tab : "dashboard" };
  if (out.tab === "exams") {
    out.examGroup = ["maz", "zoodbist", "school"].includes(r.examGroup) ? r.examGroup : examGroup;
    out.examView = r.examView === "list" ? "list" : "cats";
    out.examId = out.examView === "list" ? (r.examId || null) : null;
  }
  if (out.tab === "testbook") out.bookId = r.bookId || null;
  if (out.tab === "program") out.day = (typeof r.day === "string" && /^\d{4}-\d{2}-\d{2}$/.test(r.day)) ? r.day : selectedDay;
  if (r.modal) out.modal = r.modal; // {kind:"edit"|"exam"|"stats", boxId?, examId?, group?}
  if (r.scroll) out.scroll = r.scroll; // {type:"exam"|"topic", id} — history.state only, never in the hash
  return out;
}
function routeForTab(tab) {
  const base = { tab };
  if (tab === "exams") { base.examGroup = examGroup; base.examView = examView; base.examId = examView === "list" ? selectedExamId : null; }
  if (tab === "testbook") base.bookId = openBookId;
  if (tab === "program") base.day = selectedDay;
  return base;
}
function routeEquals(a, b) {
  if (!a || !b) return a === b;
  const keys = ["tab", "examGroup", "examView", "examId", "bookId", "day"];
  if (!keys.every(k => (a[k] || null) === (b[k] || null))) return false;
  const am = a.modal, bm = b.modal;
  if (!am && !bm) return true;
  if (!am || !bm) return false;
  return am.kind === bm.kind && (am.boxId || null) === (bm.boxId || null) &&
    (am.examId || null) === (bm.examId || null) && (am.group || null) === (bm.group || null);
}
function routeToHash(r) {
  let h = "#/" + r.tab;
  if (r.tab === "program" && r.day) h += "/" + r.day;
  if (r.tab === "testbook" && r.bookId) h += "/" + encodeURIComponent(r.bookId);
  if (r.tab === "exams" && r.examView === "list") {
    h += "/" + r.examGroup;
    if (r.examId) h += "/" + encodeURIComponent(r.examId);
  }
  if (r.modal) {
    const q = ["modal=" + r.modal.kind];
    if (r.modal.boxId) q.push("box=" + encodeURIComponent(r.modal.boxId));
    if (r.modal.examId) q.push("exam=" + encodeURIComponent(r.modal.examId));
    if (r.modal.group) q.push("group=" + r.modal.group);
    h += "?" + q.join("&");
  }
  return h;
}
function hashToRoute() {
  const raw = (location.hash || "").replace(/^#\/?/, "");
  if (!raw) return { tab: "dashboard" };
  const parts = raw.split("?");
  const seg = parts[0].split("/").filter(Boolean).map(s => { try { return decodeURIComponent(s); } catch (e) { return s; } });
  const r = { tab: TABS.includes(seg[0]) ? seg[0] : "dashboard" };
  if (r.tab === "program" && seg[1] && /^\d{4}-\d{2}-\d{2}$/.test(seg[1])) r.day = seg[1];
  if (r.tab === "testbook" && seg[1]) r.bookId = seg[1];
  if (r.tab === "exams" && seg[1] && ["maz", "zoodbist", "school"].includes(seg[1])) {
    r.examGroup = seg[1]; r.examView = "list";
    if (seg[2]) r.examId = seg[2];
  }
  if (parts[1]) {
    const p = new URLSearchParams(parts[1]);
    if (p.get("modal")) r.modal = { kind: p.get("modal"), boxId: p.get("box") || undefined,
      examId: p.get("exam") || undefined, group: p.get("group") || undefined };
  }
  return r;
}
function hideAllModalsUI() {
  ["editModal", "examModal", "statsModal"].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.remove("open");
  });
}
// UI-only modal open (no history write) — used when a route carrying a modal
// is applied (Back/Forward into it, or a reload on a modal hash).
function showModalUI(m) {
  if (!m) return;
  if (m.kind === "edit" && m.boxId) {
    const b = allBoxes().find(x => x.id === m.boxId);
    if (b) fillEditBox(b);
  } else if (m.kind === "exam") {
    fillExamModal(m.examId || null, m.group);
  } else if (m.kind === "stats") {
    renderSubjectStats();
    document.getElementById("statsModal").classList.add("open");
  }
}
// Apply a route: set section state, switch tab, render, open/close modals,
// scroll to a target. Never touches history — popstate and navigate() own that.
function applyRoute(r) {
  r = normalizeRoute(r);
  modalPushed = !!(r.modal && applyRoute._fromState);
  currentRoute = r;
  currentTab = r.tab;
  if (r.tab === "exams") { examGroup = r.examGroup; examView = r.examView; selectedExamId = r.examId; }
  if (r.tab === "testbook") openBookId = r.bookId;
  if (r.tab === "program" && r.day) selectedDay = r.day;
  hideAllModalsUI();
  switchTab(r.tab);
  renderAll();
  if (r.modal) showModalUI(r.modal);
  if (r.scroll) {
    const id = r.scroll.type === "exam" ? "exam-card-" + r.scroll.id : "topic-row-" + r.scroll.id;
    setTimeout(() => { const el = document.getElementById(id); if (el) el.scrollIntoView({ behavior: "smooth", block: "center" }); }, 80);
  }
}
function navigate(partial) {
  const r = normalizeRoute(Object.assign({}, routeForTab(partial.tab || (currentRoute && currentRoute.tab) || "dashboard"), partial));
  // A modal is open: drop its history entry first (replace, not back) so
  // Back never resurrects a modal the user already left.
  if (currentRoute && currentRoute.modal) {
    const base = Object.assign({}, currentRoute); delete base.modal;
    hideAllModalsUI();
    history.replaceState({ route: base }, "", routeToHash(base));
    currentRoute = base;
    modalPushed = false;
  }
  if (routeEquals(r, currentRoute)) { applyRoute(r); return; }
  history.pushState({ route: r }, "", routeToHash(r));
  applyRoute(r);
}
// Push a history entry for an opened modal (Back closes it, Forward reopens).
function pushModalRoute(modal) {
  if (!currentRoute) return;
  const r = Object.assign({}, currentRoute, { modal });
  if (routeEquals(r, currentRoute)) return;
  history.pushState({ route: r }, "", routeToHash(r));
  currentRoute = r;
  modalPushed = true;
}
// Replace the modal entry with its base route (used after Save: no Back step).
function dismissModalEntry() {
  if (currentRoute && currentRoute.modal) {
    const base = Object.assign({}, currentRoute); delete base.modal;
    history.replaceState({ route: base }, "", routeToHash(base));
    currentRoute = base;
  }
  modalPushed = false;
  hideAllModalsUI();
}
// User-initiated modal close (Cancel / X / backdrop): step back if we pushed
// the modal entry; otherwise just replace it away (fresh load on a modal hash
// must never navigate the user out of the app).
function closeModalHistory() {
  if (currentRoute && currentRoute.modal && modalPushed) {
    modalPushed = false;
    history.back();
  } else {
    dismissModalEntry();
  }
}
window.addEventListener("popstate", (e) => {
  const st = e.state;
  const r = (st && st.route) ? st.route : hashToRoute();
  applyRoute._fromState = !!(st && st.route);
  try { applyRoute(r); } finally { applyRoute._fromState = false; }
});
window.addEventListener("hashchange", () => {
  const r = hashToRoute();
  if (!routeEquals(normalizeRoute(r), currentRoute)) applyRoute(r);
});
function initRouting() {
  const r = normalizeRoute(hashToRoute());
  history.replaceState({ route: r }, "", routeToHash(r));
  applyRoute(r);
}

// ---- Tabs / theme / reset ----
function switchTab(name) {
  currentTab = name;
  document.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t.dataset.tab === name));
  ["dashboard", "program", "assignments", "testbook", "remaining", "exams", "overview", "gemini", "backup", "analytics"].forEach(n => {
    const el = document.getElementById("tab-" + n);
    if (el) el.hidden = (n !== name);
  });
}
document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => navigate({ tab: tab.dataset.tab }));
});
document.getElementById("themeBtn").addEventListener("click", () => {
  state.theme = (state.theme === "dark") ? "light" : "dark";
  document.documentElement.setAttribute("data-theme", state.theme);
  saveState();
});
document.getElementById("resetBtn").addEventListener("click", () => {
  if (!confirm(t("confirmReset"))) return;
  state = { done: {}, tests: {}, tests_total: {}, subjects: state.subjects, theme: state.theme, lang: state.lang,
            custom_boxes: [], deleted: [], edits: {}, daysDone: {}, topicLinks: {},
            examResults: {},
            exams: null, examsRemoved: [],
            assignments: null, assignmentsRemoved: [],
            boxBookLinks: {},
            actualMinutes: {}, timerSessions: [], activeTimer: null };
  saveState(); renderAll();
});

// ---- Gemini tab (server-side key) ----
async function refreshKeyStatus() {
  try {
    const res = await fetch("/api/gemini-key");
    const j = await res.json();
    document.getElementById("keyStatus").textContent = j.has_key
      ? t("keySavedStatus", { masked: j.masked })
      : t("keyNotEntered");
  } catch (e) {
    document.getElementById("keyStatus").textContent = t("keyServerDown");
  }
}
document.getElementById("saveKeyBtn").addEventListener("click", async () => {
  const key = document.getElementById("geminiKeyInput").value.trim();
  if (!key) { alert(t("keyEmpty")); return; }
  const res = await fetch("/api/gemini-key", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ key })
  });
  if (res.ok) {
    document.getElementById("geminiKeyInput").value = "";
    refreshKeyStatus();
    alert(t("keySavedMsg"));
  } else {
    alert(t("keySaveFailed"));
  }
});
// ---- Gemini model picker (server-side selection, default gemini-2.5-flash) ----
// The model is stored on the server (gemini_model.txt) and used by /api/gemini,
// so the analysis button always uses the model shown here. The list button
// asks Google which models THIS key can use — the diagnostic for a 404.
const KNOWN_GEMINI_MODELS = ["gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash",
  "gemini-2.0-flash-lite", "gemini-1.5-pro", "gemini-1.5-flash"];
const CUSTOM_MODEL_VALUE = "__custom__";
function geminiModelChosen() {
  const sel = document.getElementById("geminiModelSelect");
  const custom = document.getElementById("geminiModelCustom");
  if (sel && sel.value === CUSTOM_MODEL_VALUE) return (custom ? custom.value : "").trim();
  return sel ? sel.value : "";
}
function syncModelCustomVisibility() {
  const sel = document.getElementById("geminiModelSelect");
  const custom = document.getElementById("geminiModelCustom");
  if (sel && custom) custom.style.display = sel.value === CUSTOM_MODEL_VALUE ? "" : "none";
}
async function refreshGeminiModel() {
  const sel = document.getElementById("geminiModelSelect");
  const status = document.getElementById("geminiModelStatus");
  if (!sel) return;
  sel.innerHTML = KNOWN_GEMINI_MODELS.map(m =>
    '<option value="' + m + '">' + m + '</option>').join("") +
    '<option value="' + CUSTOM_MODEL_VALUE + '">' + esc(t("gmModelCustomOpt")) + '</option>';
  try {
    const res = await fetch("/api/gemini-model");
    const j = await res.json();
    const model = j.model || KNOWN_GEMINI_MODELS[0];
    if (KNOWN_GEMINI_MODELS.indexOf(model) >= 0) {
      sel.value = model;
      document.getElementById("geminiModelCustom").value = "";
    } else {
      sel.value = CUSTOM_MODEL_VALUE;
      document.getElementById("geminiModelCustom").value = model;
    }
    if (status) status.textContent = t("gmModelCurrent", { model });
  } catch (e) {
    if (status) status.textContent = t("keyServerDown");
  }
  syncModelCustomVisibility();
}
async function saveGeminiModel(model) {
  const status = document.getElementById("geminiModelStatus");
  const res = await fetch("/api/gemini-model", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model })
  });
  if (res.ok) {
    const j = await res.json();
    if (status) status.textContent = t("gmModelSaved", { model: j.model });
    return true;
  }
  if (status) status.textContent = t("gmModelInvalid");
  return false;
}
document.getElementById("geminiModelSelect").addEventListener("change", syncModelCustomVisibility);
document.getElementById("geminiModelSaveBtn").addEventListener("click", async () => {
  const model = geminiModelChosen();
  if (!model) { alert(t("gmModelInvalid")); return; }
  if (await saveGeminiModel(model)) refreshGeminiModel();
});
document.getElementById("geminiListModelsBtn").addEventListener("click", async () => {
  const list = document.getElementById("geminiModelsList");
  list.innerHTML = '<p class="muted">' + esc(t("gmModelsLoading")) + '</p>';
  try {
    const res = await fetch("/api/gemini-models");
    const j = await res.json();
    if (!res.ok) {
      const msg = (j.error && j.error.indexOf("معتبر نیست") !== -1) ? t("keyInvalid") : (j.error || t("gmModelsFailed"));
      list.innerHTML = '<p class="muted"><span class="error">' + esc(msg) + '</span></p>';
      return;
    }
    const models = j.models || [];
    if (!models.length) {
      list.innerHTML = '<p class="muted">' + esc(t("gmModelsNone")) + '</p>';
      return;
    }
    list.innerHTML = '<p class="muted">' + esc(t("gmModelsAvailable")) + '</p>' +
      '<div class="gm-model-chips">' + models.map(m => {
        // /api/gemini-models returns full metadata objects (older shape: plain strings).
        const id = (typeof m === "string") ? m : (m.id || "");
        return '<button class="btn gm-model-chip" data-model="' + esc(id) + '">' + esc(id) + '</button>';
      }).join("") + '</div>';
    list.querySelectorAll(".gm-model-chip").forEach(btn => btn.addEventListener("click", async () => {
      const model = btn.dataset.model;
      if (await saveGeminiModel(model)) refreshGeminiModel();
    }));
  } catch (e) {
    list.innerHTML = '<p class="muted"><span class="error">' + esc(t("serverUnreachable")) + '</span></p>';
  }
});
// ---- Gemini model test panel (v1.6.0) ----
// Discovers the REAL usable models from /api/gemini-models (the live API
// list — new models Google adds appear automatically; nothing here is the
// source of truth), tests each with ONE tiny cheap request via
// POST /api/gemini-test, and compares them. Official capability info comes
// from Google's documentation (ai.google.dev/gemini-api/docs/models, read
// 2026-11-24); a capability is "high" only where the docs state it outright
// — anything else renders as «نامشخص». Tests NEVER change the default
// selected model (gemini_model.txt). Results persist in localStorage.
const GM_TEST_STORE_KEY = "konkur-gm-test-v1";
// Knowledge base keyed by exact model id. use/limits are short bilingual
// descriptions translated from Google's docs; qualitative ratings are
// "high" or null (null = unverified = «نامشخص»). status follows the docs:
// 2.5-flash/pro deprecated, 2.0-flash/flash-lite shut down.
const GM_MODEL_INFO = {
  "gemini-4-carbon": { status: "stable", use: { fa: "قوی‌ترین مدل استدلالی — مهندسی نرم‌افزار پیچیده، کار دانشی چندرسانه‌ای، استدلال علمی و امنیت سایبری", en: "Strongest reasoning model — complex software engineering, multimodal knowledge work, scientific reasoning, cybersecurity defense" }, reasoning: "high", coding: "high", vision: "high", multimodal: "high", speed: null, limits: "Max output 64K / 1M tokens", tags: ["reasoning", "coding", "research", "fileImage", "exam"] },
  "gemini-4-neon": { status: "stable", use: { fa: "هوش در سطح مرز دانش با انجام سریع کارهای پیچیده — مهندسی نرم‌افزار، کار دانشی و علمی", en: "Frontier-level intelligence with fast end-to-end task completion — complex software engineering, knowledge work, science" }, reasoning: "high", coding: "high", vision: null, multimodal: null, speed: "high", limits: "Max output 64K / 1M tokens", tags: ["reasoning", "coding", "research", "fast", "exam"] },
  "gemini-4-hydrogen": { status: "stable", use: { fa: "هوش پیشرفته برای همه — سریع و کم‌مصرف برای کدنویسی روزمره و کارهای عاملی", en: "Cutting-edge intelligence for everyone — speed and efficiency for everyday coding and agentic workflows" }, reasoning: null, coding: "high", vision: null, multimodal: null, speed: "high", limits: "Max output 64K / 1M tokens", tags: ["coding", "fast", "teaching"] },
  "gemini-4-argon": { status: "stable", use: { fa: "مدل استدلالی بهینه — پاسخ سریع‌تر و مصرف توکن کمتر از Carbon در کدنویسی، ریاضی و علوم", en: "Efficient frontier reasoning model — faster responses, lower token spend than Carbon, for complex coding, agentic, math, science" }, reasoning: "high", coding: "high", vision: null, multimodal: null, speed: "high", limits: "Max output 64K / 1M tokens", tags: ["reasoning", "coding", "research", "exam"] },
  "gemini-3.8-flash": { status: "stable", use: { fa: "مدل Flash نسل قبل برای مهندسی نرم‌افزار، عامل‌های خودگردان و کارهای سازمانی پیچیده", en: "Previous-generation Flash model for software engineering, autonomous agents, complex enterprise workflows" }, reasoning: null, coding: "high", vision: null, multimodal: null, speed: null, limits: null, tags: ["coding", "research", "exam"] },
  "gemini-3.6-flash": { status: "stable", use: { fa: "مدل Flash نسل قبل — تعادل سرعت و چندرسانه‌ای برای کارهای عاملی و روزمره", en: "Previous-generation Flash model balancing speed and multimodal capabilities across general agentic and everyday tasks" }, reasoning: null, coding: null, vision: null, multimodal: "high", speed: "high", limits: null, tags: ["fast", "fileImage", "teaching"] },
  "gemini-3.5-flash-lite": { status: "stable", use: { fa: "سریع‌ترین و اقتصادی‌ترین مدل 3.5 برای اجرای پرحجم", en: "Fastest, most cost-effective 3.5 model for high-throughput execution" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: "high", limits: null, tags: ["fast"] },
  "gemini-3.1-flash-lite": { status: "stable", use: { fa: "عملکرد در سطح مرز دانش با کسری از هزینه", en: "Frontier-class performance rivaling larger models at a fraction of the cost" }, reasoning: "high", coding: null, vision: null, multimodal: null, speed: "high", limits: null, tags: ["fast", "reasoning", "exam"] },
  "gemini-3-flash-preview": { status: "preview", use: { fa: "عملکرد در سطح مرز دانش با کسری از هزینه (پیش‌نمایش)", en: "Frontier-class performance rivaling larger models at a fraction of the cost (preview)" }, reasoning: "high", coding: null, vision: null, multimodal: null, speed: "high", limits: null, tags: ["fast", "reasoning", "exam"] },
  "gemini-3.1-pro-preview": { status: "preview", use: null, reasoning: null, coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: [] },
  "gemini-2.5-pro": { status: "deprecated", use: { fa: "پیشرفته‌ترین مدل خانواده‌ی 2.5 برای کارهای پیچیده — استدلال عمیق و کدنویسی. منسوخ شده؛ از ۱ دسامبر ۲۰۲۶ به gemini-3.8-flash هدایت می‌شود", en: "Most advanced model for complex tasks in the 2.5 family — deep reasoning and coding. Deprecated; routes to gemini-3.8-flash from 1 Dec 2026" }, reasoning: "high", coding: "high", vision: null, multimodal: null, speed: null, limits: null, tags: ["reasoning", "coding", "research", "exam"] },
  "gemini-2.5-flash": { status: "deprecated", use: { fa: "بهترین نسبت قیمت به عملکرد برای کارهای پرحجم کم‌تأخیر که استدلال می‌خواهند. منسوخ شده؛ از ۱ دسامبر ۲۰۲۶ به gemini-3.5-flash-lite هدایت می‌شود", en: "Best price-performance model for low-latency, high-volume tasks that require reasoning. Deprecated; routes to gemini-3.5-flash-lite from 1 Dec 2026" }, reasoning: "high", coding: null, vision: null, multimodal: null, speed: "high", limits: null, tags: ["reasoning", "fast", "exam"] },
  "gemini-2.5-flash-lite": { status: "stable", use: { fa: "سریع‌ترین و اقتصادی‌ترین مدل چندرسانه‌ای خانواده‌ی 2.5", en: "Fastest and most budget-friendly multimodal model in the 2.5 family" }, reasoning: null, coding: null, vision: null, multimodal: "high", speed: "high", limits: null, tags: ["fast", "fileImage"] },
  "gemini-2.0-flash": { status: "shutdown", use: { fa: "مدل کارآمد نسل دوم — سرعت بالا، ابزار بومی و پنجره‌ی ۱ میلیون توکنی. خاموش شده است", en: "Second-generation workhorse model — superior speed, native tool use, 1M token context. Shut down" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: "high", limits: null, tags: ["fast"] },
  "gemini-2.0-flash-lite": { status: "shutdown", use: { fa: "سریع‌ترین مدل نسل دوم، بهینه برای هزینه و تأخیر کم. خاموش شده است", en: "Fastest second-generation model, optimized for cost efficiency and low latency. Shut down" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: "high", limits: null, tags: ["fast"] },
  "gemini-1.5-pro": { status: "unknown", use: null, reasoning: null, coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: [] },
  "gemini-1.5-flash": { status: "unknown", use: null, reasoning: null, coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: [] },
  "gemini-nano-banana-2.1": { status: "stable", use: { fa: "تولید و ویرایش تصویر با کیفیت بصری بهتر، تایپوگرافی و سازگاری چندمرحله‌ای", en: "High-efficiency image generation and editing with improved visual quality, typography, multi-turn consistency" }, reasoning: null, coding: null, vision: "high", multimodal: null, speed: null, limits: null, tags: ["fileImage"] },
  "gemini-3.1-flash-image": { status: "stable", use: { fa: "خلق بصری در مقیاس تولید با هوش سری 3 و سرعت بالا", en: "High-efficiency production-scale visual creation, combining Gemini 3 intelligence with fast generation speeds" }, reasoning: null, coding: null, vision: "high", multimodal: null, speed: null, limits: null, tags: ["fileImage"] },
  "gemini-3.1-flash-lite-image": { status: "stable", use: { fa: "سریع‌ترین و ارزان‌ترین مدل تصویر جمینای برای سرعت و مقیاس", en: "Fastest and cheapest Gemini image model, engineered for velocity and scale" }, reasoning: null, coding: null, vision: "high", multimodal: null, speed: "high", limits: null, tags: ["fileImage"] },
  "gemini-3-pro-image": { status: "stable", use: { fa: "موتور طراحی حرفه‌ای با هسته‌ی استدلالی برای تصاویر 4K استودیویی", en: "Professional design engine with a reasoning core for studio-quality 4K visuals" }, reasoning: null, coding: null, vision: "high", multimodal: null, speed: null, limits: null, tags: ["fileImage"] },
  "gemini-2.5-flash-image": { status: "stable", use: { fa: "تولید و ویرایش بومی تصویر پیشرفته برای کارهای خلاقانه‌ی سریع", en: "State-of-the-art native image generation and editing for fast, creative workflows" }, reasoning: null, coding: null, vision: "high", multimodal: null, speed: null, limits: null, tags: ["fileImage"] },
  "gemini-3.8-flash-tts": { status: "stable", use: { fa: "مدل تبدیل متن به گفتار پیشرو برای کیفیت استودیویی و بازیگری رسا", en: "Flagship creative text-to-speech model for studio-grade voice fidelity, expressive acting" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: [] },
  "gemini-3.8-flash-lite-tts": { status: "stable", use: { fa: "تبدیل متن به گفتار سریع و اقتصادی برای تولید پرحجم", en: "Fast, cost-efficient text-to-speech model for high-throughput production" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: "high", limits: null, tags: [] },
  "gemini-3.8-live": { status: "stable", use: { fa: "گزینه‌ی پیش‌فرض برای تجربه‌های صوتی کم‌تأخیر بدون تأخیر استدلال", en: "Default Live API model for most low-latency voice agent experiences without reasoning delays" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: "high", limits: null, tags: [] },
  "gemini-3.8-live-extended-thinking": { status: "stable", use: { fa: "مدل صوتی با استدلال بالا برای گفت‌وگوی زنده", en: "High-reasoning Live API model for voice interactions when higher background reasoning is required" }, reasoning: "high", coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: ["reasoning"] },
  "gemini-2.5-flash-preview-tts": { status: "stable", use: { fa: "تبدیل متن به گفتار سریع و قابل‌کنترل برای دستیارهای بلادرنگ", en: "Fast and controllable text-to-speech for low-latency, cost-efficient applications" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: "high", limits: null, tags: [] },
  "gemini-2.5-pro-preview-tts": { status: "stable", use: { fa: "سنتز گفتار باکیفیت برای پادکست و کتاب صوتی", en: "High-fidelity speech synthesis optimized for quality in structured workflows like podcasts and audiobooks" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: [] },
  "gemini-2.5-flash-native-audio-preview-12-2025": { status: "stable", use: { fa: "مدل Live پیشرو برای عامل‌های صوتی و تصویری دوطرفه‌ی کم‌تأخیر", en: "Flagship Live API model for low-latency, bidirectional voice and video agents" }, reasoning: null, coding: null, vision: null, multimodal: "high", speed: "high", limits: null, tags: [] },
  "gemini-3.5-transcribe": { status: "stable", use: { fa: "تبدیل گفتار به متن کم‌تأخیر با تشخیص گوینده و زمان‌بندی کلمات", en: "Low-latency speech-to-text model with speaker diarization and word timestamps" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: "high", limits: null, tags: [] },
  "gemini-3.1-flash-live-preview": { status: "stable", use: { fa: "مدل صوتی قدیمی؛ گوگل مهاجرت به Gemini 3.8 Live را پیشنهاد می‌کند", en: "Legacy audio-to-audio preview model; Google recommends updating to Gemini 3.8 Live" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: [] },
  "gemini-3.1-flash-tts-preview": { status: "stable", use: { fa: "مدل گفتاری قدیمی؛ مهاجرت به 3.8 Flash TTS پیشنهاد می‌شود", en: "Legacy TTS preview model; Google recommends updating to Gemini 3.8 Flash TTS" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: [] },
  "gemini-omni-1.2-flash": { status: "stable", use: { fa: "تولید و ویرایش ویدیوی سریع تا ۱۵ ثانیه با صدای بومی", en: "Fast video generation and editing up to 15 seconds with native audio" }, reasoning: null, coding: null, vision: "high", multimodal: null, speed: "high", limits: null, tags: ["fileImage"] },
  "gemini-omni-1.1-flash": { status: "stable", use: { fa: "تولید و ویرایش ویدیوی سریع تا ۱۵ ثانیه با صدای بومی", en: "Fast video generation and editing up to 15 seconds with native audio" }, reasoning: null, coding: null, vision: "high", multimodal: null, speed: "high", limits: null, tags: ["fileImage"] },
  "deep-research-preview-04-2026": { status: "preview", use: { fa: "مدل عاملی پژوهش عمیق — برنامه‌ریزی و اجرای چندمرحله‌ای پژوهش روی صدها منبع", en: "Agentic model that autonomously plans and executes multi-step research across hundreds of sources" }, reasoning: "high", coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: ["research", "reasoning", "exam"] },
  "deep-research-max-preview-04-2026": { status: "preview", use: { fa: "بیشترین جامعیت در گردآوری و ترکیب خودکار منابع", en: "Maximum comprehensiveness for automated context gathering and synthesis" }, reasoning: "high", coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: ["research", "reasoning", "exam"] },
};
const GM_TAG_KEYS = { coding: "gmTestTagCoding", research: "gmTestTagResearch", reasoning: "gmTestTagReasoning", fast: "gmTestTagFast", fileImage: "gmTestTagFileImage", teaching: "gmTestTagTeaching", exam: "gmTestTagExam" };
const GM_USE_CASES = [
  { key: "gmTestUseResearch", tags: ["research", "reasoning"], prefer: "reasoning" },
  { key: "gmTestUseBudget", tags: ["reasoning", "research"], prefer: "reasoning" },
  { key: "gmTestUsePlanning", tags: ["fast", "reasoning"], prefer: "speed" },
  { key: "gmTestUseCoding", tags: ["coding"], prefer: "coding" },
  { key: "gmTestUseLargeDoc", tags: ["research", "reasoning"], prefer: "context" },
];
let gmTestModels = [];
let gmTestResults = {};
let gmTestLastAt = 0;
let gmTestRunning = false;
let gmTestDefaultModel = "";
function gmInfo(id) {
  return GM_MODEL_INFO[id] || { status: "unknown", use: null, reasoning: null, coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: [] };
}
function gmFamilyRank(id) {
  if (id.indexOf("gemini-4") === 0) return 0;
  if (id.indexOf("gemini-3") === 0) return 1;
  if (id.indexOf("gemini-2.5") === 0) return 2;
  if (id.indexOf("gemini-2.0") === 0) return 3;
  if (id.indexOf("gemini-1.5") === 0) return 4;
  return 5;
}
// Long-document ability is derived from the API's own context limit
// (>= 1M input tokens), never guessed.
function gmLongDoc(m) {
  return (typeof m.inputTokenLimit === "number" && m.inputTokenLimit >= 1000000) ? "high" : null;
}
function gmCapVal(v) { return v === "high" ? t("gmTestValHigh") : t("gmTestUnknown"); }
function gmErrLabel(kind) {
  return { auth: "gmTestErrAuth", rate_limit: "gmTestErrRate", not_found: "gmTestErrNotFound", network: "gmTestErrNetwork", model: "gmTestErrModel", unknown: "gmTestErrUnknown" }[kind] || "gmTestErrUnknown";
}
function gmFmtTokens(n) {
  if (typeof n !== "number" || !n) return "—";
  if (n >= 1000000) { const v = Math.round(n / 100000) / 10; return (v % 1 ? v : Math.round(v)) + "M"; }
  if (n >= 1000) return Math.round(n / 1000) + "K";
  return String(n);
}
function gmLatencyOf(m) { const r = gmTestResults[m.id]; return (r && typeof r.latencyMs === "number") ? r.latencyMs : null; }
function gmTestLoadStored() {
  try {
    const raw = localStorage.getItem(GM_TEST_STORE_KEY);
    if (!raw) return;
    const j = JSON.parse(raw);
    if (j && typeof j === "object") { gmTestResults = j.results || {}; gmTestLastAt = j.lastAt || 0; }
  } catch (e) {}
}
function gmTestSaveStored() {
  try { localStorage.setItem(GM_TEST_STORE_KEY, JSON.stringify({ results: gmTestResults, lastAt: gmTestLastAt })); } catch (e) {}
}
async function gmTestFetchModels() {
  const res = await fetch("/api/gemini-models");
  const j = await res.json();
  if (!res.ok) {
    const msg = (j.error && j.error.indexOf("معتبر نیست") !== -1) ? t("keyInvalid") : (j.error || t("gmTestLoadFailed"));
    throw new Error(msg);
  }
  const list = (j.models || []).map(m => (typeof m === "string")
    ? { id: m, displayName: m, description: "", version: "", inputTokenLimit: null, outputTokenLimit: null, methods: [] }
    : m);
  // Known models missing from this key's list are shown too, marked unavailable.
  const seen = {};
  list.forEach(m => { seen[m.id] = true; });
  Object.keys(GM_MODEL_INFO).concat(KNOWN_GEMINI_MODELS).forEach(id => {
    if (!seen[id]) list.push({ id, displayName: id, description: "", version: "", inputTokenLimit: null, outputTokenLimit: null, methods: [], listed: false });
  });
  list.forEach(m => { if (m.listed !== false) m.listed = true; });
  return list;
}
async function gmTestOne(id) {
  const res = await fetch("/api/gemini-test", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ model: id }) });
  const j = await res.json();
  if (!res.ok) return { ok: false, latencyMs: null, errorKind: "unknown", errorMessage: j.error || t("gmTestLoadFailed"), at: Date.now() };
  return { ok: !!j.ok, latencyMs: (typeof j.latencyMs === "number" ? j.latencyMs : null), errorKind: j.errorKind || (j.ok ? "" : "unknown"), errorMessage: j.errorMessage || "", at: Date.now() };
}
function gmTestSortedModels() {
  const sort = (document.getElementById("gmTestSort") || {}).value || "status";
  const arr = gmTestModels.slice();
  const statusRank = m => {
    const r = gmTestResults[m.id];
    if (r && r.testing) return 1;
    if (r && r.ok) return 0;
    if (r && !r.ok) return 2;
    return 3;
  };
  if (sort === "speed") arr.sort((a, b) => (gmLatencyOf(a) == null ? Infinity : gmLatencyOf(a)) - (gmLatencyOf(b) == null ? Infinity : gmLatencyOf(b)));
  else if (sort === "type") arr.sort((a, b) => gmFamilyRank(a.id) - gmFamilyRank(b.id) || a.id.localeCompare(b.id));
  else arr.sort((a, b) => statusRank(a) - statusRank(b) || gmFamilyRank(a.id) - gmFamilyRank(b.id));
  return arr;
}
function gmTestCardHtml(m) {
  const info = gmInfo(m.id);
  const r = gmTestResults[m.id];
  const status = !m.listed ? "na" : (r && r.testing ? "testing" : (r ? (r.ok ? "ok" : "fail") : "idle"));
  const statusText = !m.listed ? t("gmTestNotListed") : (r && r.testing ? t("gmTestTestingStatus") : (r ? (r.ok ? t("gmTestOk") : t("gmTestFailed")) : t("gmTestUntested")));
  const lat = gmLatencyOf(m);
  const docNote = info.status === "deprecated" ? t("gmTestDeprecated") : (info.status === "shutdown" ? t("gmTestShutdown") : (info.status === "preview" ? t("gmTestPreview") : ""));
  const isDefault = gmTestDefaultModel && m.id === gmTestDefaultModel;
  const tags = (info.tags || []).map(tag => '<span class="gm-tag">' + esc(t(GM_TAG_KEYS[tag] || "gmTestUnknown")) + '</span>').join("");
  const useText = info.use ? (info.use[LANG] || info.use.en || info.use.fa) : t("gmTestUnknown");
  const capRow = (labelKey, val) => '<tr><td>' + esc(t(labelKey)) + '</td><td>' + esc(val) + '</td></tr>';
  return '<div class="gm-test-card">' +
    '<div class="gm-test-head"><div><div class="gm-test-name">' + esc(m.displayName || m.id) + '</div>' +
    '<div class="gm-test-id">' + esc(m.id) + '</div></div>' +
    '<span class="gm-status ' + status + '">' + esc(statusText) + '</span></div>' +
    '<div class="gm-test-meta">' +
    (m.version ? esc(m.version) + ' · ' : '') + esc(t("gmTestCapContext")) + ': ' + esc(gmFmtTokens(m.inputTokenLimit)) + ' / ' + esc(gmFmtTokens(m.outputTokenLimit)) +
    (docNote ? ' · ' + esc(docNote) : '') +
    (isDefault ? ' · <b>' + esc(t("gmTestIsDefault")) + '</b>' : '') +
    (lat != null ? '<br>' + esc(t("gmTestLatency", { ms: FA(lat) })) : '') +
    '</div>' +
    (r && !r.ok && !r.testing ? '<div class="gm-test-err">' + esc(t(gmErrLabel(r.errorKind))) + (r.errorMessage ? '<br>' + esc(r.errorMessage) : '') + '</div>' : '') +
    (tags ? '<div class="gm-test-tags">' + tags + '</div>' : '') +
    '<details><summary>' + esc(t("gmTestDetails")) + '</summary><table class="gm-cap-table">' +
    capRow("gmTestCapUse", useText) +
    capRow("gmTestCapReasoning", gmCapVal(info.reasoning)) +
    capRow("gmTestCapCoding", gmCapVal(info.coding)) +
    capRow("gmTestCapLongDoc", gmCapVal(gmLongDoc(m))) +
    capRow("gmTestCapVision", gmCapVal(info.vision)) +
    capRow("gmTestCapMultimodal", gmCapVal(info.multimodal)) +
    capRow("gmTestCapSpeed", gmCapVal(info.speed)) +
    capRow("gmTestCapContext", gmFmtTokens(m.inputTokenLimit) + " / " + gmFmtTokens(m.outputTokenLimit)) +
    capRow("gmTestCapLimits", info.limits || t("gmTestUnknown")) +
    '</table></details>' +
    '<div style="margin-top:8px"><button class="btn" data-retest="' + esc(m.id) + '"' + (gmTestRunning ? ' disabled' : '') + '>' + esc(t("gmTestRetest")) + '</button></div>' +
    '</div>';
}
function gmRenderTestCards() {
  const el = document.getElementById("gmTestList");
  if (!el) return;
  if (!gmTestModels.length) { el.innerHTML = ""; return; }
  el.innerHTML = gmTestSortedModels().map(m => gmTestCardHtml(m)).join("");
  el.querySelectorAll("[data-retest]").forEach(btn => btn.addEventListener("click", async () => {
    const id = btn.dataset.retest;
    if (gmTestRunning) return;
    gmTestResults[id] = { testing: true };
    gmRenderTestCards();
    const r = await gmTestOne(id);
    gmTestResults[id] = r;
    gmTestLastAt = Date.now();
    gmTestSaveStored();
    gmRenderTestCards(); gmRenderTestSummary(); gmRenderTestCompare(); gmRenderTestRecs();
  }));
}
function gmRenderTestSummary() {
  const sEl = document.getElementById("gmTestSummary");
  const lEl = document.getElementById("gmTestLast");
  if (!sEl) return;
  let ok = 0, fail = 0, na = 0;
  gmTestModels.forEach(m => {
    if (!m.listed) { na++; return; }
    const r = gmTestResults[m.id];
    if (r && r.ok) ok++;
    else if (r && !r.ok && !r.testing) fail++;
  });
  sEl.textContent = gmTestModels.length ? t("gmTestSummary", { ok: FA(ok), fail: FA(fail), na: FA(na) }) : t("gmTestSummaryNone");
  if (lEl) lEl.textContent = gmTestLastAt ? t("gmTestLast", { time: new Date(gmTestLastAt).toLocaleString(LANG === "fa" ? "fa-IR" : "en-GB") }) : t("gmTestLastNever");
}
function gmRenderTestCompare() {
  const el = document.getElementById("gmTestCompare");
  if (!el) return;
  const tested = gmTestModels.filter(m => { const r = gmTestResults[m.id]; return r && !r.testing; });
  if (!tested.length) {
    el.innerHTML = '<h3 class="section-title" style="margin-top:16px">' + esc(t("gmTestCompareTitle")) + '</h3><p class="muted">' + esc(t("gmTestCompareHint")) + '</p>';
    return;
  }
  tested.sort((a, b) => {
    const ra = gmTestResults[a.id], rb = gmTestResults[b.id];
    if (ra.ok !== rb.ok) return ra.ok ? -1 : 1;
    return (ra.latencyMs == null ? Infinity : ra.latencyMs) - (rb.latencyMs == null ? Infinity : rb.latencyMs);
  });
  const rows = [
    ["gmTestRowReasoning", m => gmCapVal(gmInfo(m.id).reasoning)],
    ["gmTestRowCoding", m => gmCapVal(gmInfo(m.id).coding)],
    ["gmTestRowSpeed", m => gmCapVal(gmInfo(m.id).speed)],
    ["gmTestRowFileImage", m => gmCapVal(gmInfo(m.id).multimodal)],
    ["gmTestRowCapacity", m => gmFmtTokens(m.inputTokenLimit)],
    ["gmTestRowStatus", m => { const r = gmTestResults[m.id]; return r.ok ? t("gmTestOk") : t(gmErrLabel(r.errorKind)); }],
    ["gmTestRowPerf", m => { const r = gmTestResults[m.id]; return r.ok ? (r.latencyMs != null ? FA(r.latencyMs) + " ms" : "—") : t(gmErrLabel(r.errorKind)); }],
  ];
  let html = '<h3 class="section-title" style="margin-top:16px">' + esc(t("gmTestCompareTitle")) + '</h3><div class="gm-compare-wrap"><table><tr><th></th>' +
    tested.map(m => '<th>' + esc(m.displayName || m.id) + '</th>').join("") + '</tr>';
  rows.forEach(pair => {
    html += '<tr><td>' + esc(t(pair[0])) + '</td>' + tested.map(m => '<td>' + esc(pair[1](m)) + '</td>').join("") + '</tr>';
  });
  el.innerHTML = html + '</table></div>';
}
function gmPickForUseCase(uc) {
  const cands = gmTestModels.filter(m => {
    const r = gmTestResults[m.id];
    if (!r || !r.ok) return false;
    const tags = gmInfo(m.id).tags || [];
    return uc.tags.some(tag => tags.indexOf(tag) >= 0);
  });
  if (!cands.length) return null;
  const score = m => {
    const info = gmInfo(m.id);
    const r = gmTestResults[m.id];
    let s = 0;
    if (uc.prefer === "reasoning" && info.reasoning === "high") s += 10;
    if (uc.prefer === "coding" && info.coding === "high") s += 10;
    if (uc.prefer === "context" && typeof m.inputTokenLimit === "number") s += Math.min(5, m.inputTokenLimit / 1000000);
    if (uc.prefer === "speed" && typeof r.latencyMs === "number") s += Math.max(0, 5 - r.latencyMs / 1000);
    return s;
  };
  cands.sort((a, b) => score(b) - score(a) || (gmLatencyOf(a) == null ? Infinity : gmLatencyOf(a)) - (gmLatencyOf(b) == null ? Infinity : gmLatencyOf(b)));
  return cands[0];
}
function gmRenderTestRecs() {
  const el = document.getElementById("gmTestRecs");
  if (!el) return;
  const anyTested = gmTestModels.some(m => { const r = gmTestResults[m.id]; return r && !r.testing; });
  let html = '<h3 class="section-title" style="margin-top:16px">' + esc(t("gmTestRecsTitle")) + '</h3>';
  if (!anyTested) { el.innerHTML = html + '<p class="muted">' + esc(t("gmTestRecsHint")) + '</p>'; return; }
  html += '<div class="gm-rec-list">';
  GM_USE_CASES.forEach(uc => {
    const pick = gmPickForUseCase(uc);
    html += '<div>' + esc(t(uc.key)) + ': ' + (pick ? '<b>' + esc(pick.displayName || pick.id) + '</b> <span class="muted">(' + esc(pick.id) + ')</span>' : esc(t("gmTestNoPick"))) + '</div>';
  });
  el.innerHTML = html + '</div>';
}
function refreshGmTestPanel() { gmRenderTestCards(); gmRenderTestSummary(); gmRenderTestCompare(); gmRenderTestRecs(); }
async function gmTestAll() {
  if (gmTestRunning) return;
  const btn = document.getElementById("gmTestAllBtn");
  const listEl = document.getElementById("gmTestList");
  gmTestRunning = true;
  if (btn) { btn.disabled = true; btn.textContent = t("gmTestTesting"); }
  try {
    if (!gmTestModels.length) {
      if (listEl) listEl.innerHTML = '<p class="muted">' + esc(t("gmModelsLoading")) + '</p>';
      gmTestModels = await gmTestFetchModels();
      try { const dm = await (await fetch("/api/gemini-model")).json(); gmTestDefaultModel = dm.model || ""; } catch (e) {}
    }
    gmRenderTestCards();
    for (const m of gmTestModels) {
      gmTestResults[m.id] = { testing: true };
      gmRenderTestCards();
      const r = await gmTestOne(m.id);
      gmTestResults[m.id] = r;
      gmTestLastAt = Date.now();
      gmTestSaveStored();
      gmRenderTestCards();
      await new Promise(r2 => setTimeout(r2, 250));
    }
  } catch (e) {
    if (listEl) listEl.innerHTML = '<p class="muted"><span class="error">' + esc(e.message || t("gmTestLoadFailed")) + '</span></p>';
  } finally {
    gmTestRunning = false;
    if (btn) { btn.disabled = false; btn.textContent = t("gmTestAllBtn"); }
    // Re-render once more so the per-model retest buttons are enabled again
    // (during the run they were rendered disabled).
    gmRenderTestCards();
    gmRenderTestSummary(); gmRenderTestCompare(); gmRenderTestRecs();
  }
}
document.getElementById("gmTestAllBtn").addEventListener("click", gmTestAll);
document.getElementById("gmTestSort").addEventListener("change", gmRenderTestCards);
// Load the live model list in the background so the panel is populated when
// the Gemini tab opens; a missing/invalid key just shows its message here.
gmTestLoadStored();
(async function gmTestInit() {
  try {
    gmTestModels = await gmTestFetchModels();
    try { const dm = await (await fetch("/api/gemini-model")).json(); gmTestDefaultModel = dm.model || ""; } catch (e) {}
    gmRenderTestCards(); gmRenderTestSummary(); gmRenderTestCompare(); gmRenderTestRecs();
  } catch (e) {
    const listEl = document.getElementById("gmTestList");
    if (listEl) listEl.innerHTML = '<p class="muted"><span class="error">' + esc(e.message || t("gmTestLoadFailed")) + '</span></p>';
    gmRenderTestSummary();
  }
})();
document.getElementById("analyzeBtn").addEventListener("click", async () => {
  const out = document.getElementById("geminiOut");
  out.textContent = t("analyzing");
  const boxes = allBoxes();
  const done = boxes.filter(isDone).length;
  const bySubject = {};
  boxes.forEach(b => {
    const s = bySubject[b.subject] = bySubject[b.subject] || { total: 0, done: 0 };
    s.total++; if (isDone(b)) s.done++;
  });
  const lines = Object.keys(bySubject).map(s =>
    subjName(s) + ": " + bySubject[s].done + " / " + bySubject[s].total + " " + t("boxesWord")).join("\n");
  const bookLines = (TESTBOOK.books || []).map(book => {
    const st = bookStats(book);
    return t("bookPrefix") + bookName(book) + ": " + st.solved + t("solvedSuffix") +
      (st.total ? t("ofWord") + st.total : "") + (st.pct == null ? "" : " (" + FA_PCT(st.pct) + ")");
  }).join("\n");
  const question = document.getElementById("geminiQuestion").value.trim();
  const prompt = t("promptIntro") +
    t("promptStatus", { done, total: boxes.length, lines, books: bookLines }) +
    (question ? t("promptQuestion") + question : "") +
    t("promptTasks") +
    (question ? t("promptQ4") : "");
  try {
    const res = await fetch("/api/gemini", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt })
    });
    const j = await res.json();
    if (!res.ok) {
      let msg;
      if (j.error && j.error.indexOf("معتبر نیست") !== -1) msg = t("keyInvalid");
      else if (j.error && j.error.indexOf("HTTP 404") !== -1) msg = t("gmModelNotFound");
      else msg = j.error || t("keyInvalid");
      out.innerHTML = '<span class="error">' + esc(msg) + "</span>";
      return;
    }
    out.textContent = j.text;
  } catch (e) {
    out.innerHTML = '<span class="error">' + t("serverUnreachable") + '</span>';
  }
});

// ---- Backup (local automatic + B2 cloud) ----
// Local backups are always on: every save snapshots state.json / testbook.json
// into the data dir (outside the app folder). The cloud layer is inert until
// B2 credentials are entered in the Backup tab.
let backupStatusCache = null;

function fmtBackupTs(iso) {
  if (!iso) return "";
  return String(iso).replace("T", " ").replace(/\+.*$/, "");
}

async function refreshBackupStatus() {
  const pill = document.getElementById("backupPill");
  try {
    const res = await fetch("/api/backup");
    const j = await res.json();
    backupStatusCache = j;
    if (!pill) return;
    pill.dataset.live = "1";
    const cloud = j.cloud || {};
    if (cloud.conflict || (cloud.last_sync && cloud.last_sync.ok === false)) {
      pill.textContent = t("bkPillError");
      pill.className = "pill-backup err";
    } else if (cloud.enabled && cloud.configured) {
      pill.textContent = t("bkPillOk");
      pill.className = "pill-backup ok";
    } else {
      pill.textContent = t("bkPillLocal");
      pill.className = "pill-backup";
    }
  } catch (e) {
    if (pill) { pill.textContent = t("bkPillError"); pill.className = "pill-backup err"; }
  }
}

async function refreshDataFromServer() {
  try {
    const [dRes, sRes, tRes] = await Promise.all([fetch("data.json"), fetch("/api/state"), fetch("/api/testbook")]);
    if (dRes.ok) DATA = await dRes.json();
    if (sRes.ok) state = Object.assign(state, await sRes.json());
    if (tRes.ok) TESTBOOK = await tRes.json();
    normalizeExamLinks(); normalizeBoxBookLinks(); normalizeAssignmentLinks();
  } catch (e) {}
  renderAll();
}

function bkVersionRow(v, kind) {
  const row = document.createElement("div");
  row.className = "bk-row";
  const kb = v.size ? (Math.round(v.size / 102.4) / 10) + " KB" : "";
  row.innerHTML = '<span class="bk-file">' + esc(v.file) + '</span>' +
    '<span class="bk-meta">' + esc(fmtBackupTs(v.ts_iso)) + (kb ? " · " + kb : "") +
    (v.verified === false ? " · ⚠" : "") + '</span>' +
    '<button class="btn bk-restore-btn">' + t("bkRestore") + "</button>";
  row.querySelector(".bk-restore-btn").addEventListener("click", async () => {
    if (!confirm(t("bkRestoreConfirm"))) return;
    try {
      const res = await fetch("/api/backup/restore", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind, file: v.file })
      });
      if (res.ok) {
        alert(t("bkRestored"));
        await refreshDataFromServer();
        renderBackup();
      } else alert(t("bkRestoreFailed"));
    } catch (e) { alert(t("bkRestoreFailed")); }
  });
  return row;
}

function bkCloudRow(kind, entry) {
  const row = document.createElement("div");
  row.className = "bk-row";
  const ts = entry.ts ? fmtBackupTs(new Date(entry.ts * 1000).toISOString()) : "";
  row.innerHTML = '<span class="bk-file">' + esc(kind) + " — " + esc(entry.key || "") + '</span>' +
    '<span class="bk-meta">' + esc(ts) + '</span>' +
    '<button class="btn bk-restore-btn">' + t("bkRestore") + "</button>";
  row.querySelector(".bk-restore-btn").addEventListener("click", async () => {
    if (!confirm(t("bkRestoreConfirm"))) return;
    try {
      const res = await fetch("/api/backup/restore-cloud", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind, key: entry.key })
      });
      if (res.ok) {
        alert(t("bkRestored"));
        await refreshDataFromServer();
        renderBackup();
      } else alert(t("bkRestoreFailed"));
    } catch (e) { alert(t("bkRestoreFailed")); }
  });
  return row;
}

async function renderBackup() {
  let status = backupStatusCache;
  let list = null, b2cfg = null;
  try {
    const [sRes, lRes, cRes] = await Promise.all([
      fetch("/api/backup"), fetch("/api/backup/list"), fetch("/api/backup/b2-config")
    ]);
    if (sRes.ok) { status = await sRes.json(); backupStatusCache = status; }
    if (lRes.ok) list = await lRes.json();
    if (cRes.ok) b2cfg = await cRes.json();
  } catch (e) { /* server unreachable — leave the panel as-is */ }
  if (!status) return;
  refreshUpdateStatus();
  refreshAutoUpdate();
  renderCalendarPanel();
  const dirEl = document.getElementById("bkDataDir");
  if (dirEl) dirEl.textContent = t("bkDataDir", { d: status.data_dir || "" });
  const local = status.local || {};
  const last = local.last_backup;
  const localInfo = document.getElementById("bkLocalInfo");
  if (localInfo) {
    localInfo.textContent = (last ? t("bkLastBackup", { t: fmtBackupTs(last.ts_iso) }) : t("bkNoBackup")) +
      " · " + t("bkVersionsCount", { n: FA((local.state_backups || 0) + (local.testbook_backups || 0)) });
  }
  const cloud = status.cloud || {};
  const cloudInfo = document.getElementById("bkCloudInfo");
  if (cloudInfo) {
    let line;
    if (!cloud.configured) line = t("bkCloudNotConfigured");
    else if (!cloud.enabled) line = t("bkCloudDisabled");
    else if (cloud.last_sync && cloud.last_sync.ok === false) line = t("bkCloudError", { e: cloud.last_sync.error || "" });
    else line = t("bkCloudEnabled") + " · " +
      (cloud.last_sync && cloud.last_sync.ts_iso ? t("bkCloudLastSync", { t: fmtBackupTs(cloud.last_sync.ts_iso) }) : t("bkCloudNever"));
    cloudInfo.textContent = line;
  }
  const conflictBox = document.getElementById("bkConflictBox");
  if (conflictBox) {
    conflictBox.hidden = !cloud.conflict;
    conflictBox.innerHTML = "";
    if (cloud.conflict) {
      const c = cloud.conflict;
      conflictBox.innerHTML = '<p><b>' + t("bkCloudConflict") + '</b></p>' +
        '<p class="muted">' + t("bkCloudConflictNote") + "</p>";
      const mineBtn = document.createElement("button");
      mineBtn.className = "btn btn-lime";
      mineBtn.textContent = t("bkCloudUseMine");
      mineBtn.addEventListener("click", async () => {
        await fetch("/api/backup/resolve-conflict", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ kind: c.kind })
        });
        refreshBackupStatus(); renderBackup();
      });
      const cloudBtn = document.createElement("button");
      cloudBtn.className = "btn";
      cloudBtn.textContent = t("bkCloudUseCloud");
      cloudBtn.addEventListener("click", async () => {
        if (!confirm(t("bkRestoreConfirm"))) return;
        const res = await fetch("/api/backup/restore-cloud", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ kind: c.kind, key: c.remote_key })
        });
        if (res.ok) { alert(t("bkRestored")); await refreshDataFromServer(); }
        else alert(t("bkRestoreFailed"));
        renderBackup();
      });
      conflictBox.appendChild(mineBtn);
      conflictBox.appendChild(cloudBtn);
    }
  }
  if (list) {
    const stateBox = document.getElementById("bkStateVersions");
    const tbBox = document.getElementById("bkTbVersions");
    const cloudBox = document.getElementById("bkCloudVersions");
    const stateVs = (list.versions || []).filter(v => v.kind === "state");
    const tbVs = (list.versions || []).filter(v => v.kind === "testbook");
    if (stateBox) {
      stateBox.innerHTML = "";
      if (!stateVs.length) stateBox.innerHTML = '<p class="muted">' + t("bkNoBackup") + "</p>";
      stateVs.slice(0, 30).forEach(v => stateBox.appendChild(bkVersionRow(v, "state")));
    }
    if (tbBox) {
      tbBox.innerHTML = "";
      if (!tbVs.length) tbBox.innerHTML = '<p class="muted">' + t("bkNoBackup") + "</p>";
      tbVs.slice(0, 30).forEach(v => tbBox.appendChild(bkVersionRow(v, "testbook")));
    }
    if (cloudBox) {
      cloudBox.innerHTML = "";
      const manifest = (list.cloud && list.cloud.manifest) || null;
      if (!manifest || (!manifest.state && !manifest.testbook)) {
        cloudBox.innerHTML = '<p class="muted">' + (cloud.configured ? t("bkCloudNever") : t("bkCloudNotConfigured")) + "</p>";
      } else {
        if (manifest.state) cloudBox.appendChild(bkCloudRow("state", manifest.state));
        if (manifest.testbook) cloudBox.appendChild(bkCloudRow("testbook", manifest.testbook));
      }
    }
  }
  if (b2cfg) {
    const ep = document.getElementById("bkEndpoint");
    const bk = document.getElementById("bkBucket");
    const kid = document.getElementById("bkKeyId");
    if (ep && !ep.value) ep.value = b2cfg.endpoint || "s3.us-west-000.backblazeb2.com";
    if (bk && !bk.value) bk.value = b2cfg.bucket || "konkur-backup";
    if (kid && b2cfg.key_id_masked) kid.placeholder = b2cfg.key_id_masked;
    const st = document.getElementById("bkB2Status");
    if (st && b2cfg.configured) st.textContent = t("bkCloudEnabled") + (b2cfg.enabled ? "" : " — " + t("bkCloudDisabled"));
  }
}

document.getElementById("backupPill").addEventListener("click", () => navigate({ tab: "backup" }));
document.getElementById("bkNowBtn").addEventListener("click", async () => {
  const btn = document.getElementById("bkNowBtn");
  try {
    const res = await fetch("/api/backup/now", { method: "POST" });
    if (res.ok) {
      backupStatusCache = await res.json();
      alert(t("bkNowDone"));
    }
  } catch (e) {}
  refreshBackupStatus(); renderBackup();
  if (btn) btn.textContent = t("bkNowBtn");
});

// ---- In-app self-update (Part 5) ----
// The server validates the zip, backs up the current code into the data dir,
// installs over the app folder (data dir untouched) and restarts itself.
// The page polls /api/version until the expected version answers, then reloads.
async function refreshUpdateStatus() {
  try {
    const res = await fetch("/api/update/status");
    if (!res.ok) return;
    const j = await res.json();
    const ver = document.getElementById("updVersion");
    if (ver) ver.textContent = j.version.version +
      (j.version.build_date ? " (" + j.version.build_date + ")" : "");
    const info = document.getElementById("updBackupInfo");
    const rb = document.getElementById("updRollbackBtn");
    if (j.backups && j.backups.length) {
      const b = j.backups[0];
      if (info) info.textContent = t("updBackupOf", { version: b.version || "?", date: b.ts_iso || "" });
      if (rb) rb.disabled = false;
    } else {
      if (info) info.textContent = t("updNoBackup");
      if (rb) rb.disabled = true;
    }
  } catch (e) { /* server unreachable — leave the panel as-is */ }
}
function updSetBusy(busy, msgKey) {
  ["updInstallFileBtn", "updInstallUrlBtn", "updRollbackBtn"].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.disabled = busy;
  });
  const st = document.getElementById("updStatus");
  if (st && msgKey) st.textContent = t(msgKey);
}
async function updWaitForServer(expectedVersion) {
  // The old server exits ~1s after the install response; the new one needs
  // ~3-4s to come up. Wait first so we never reload against the old server.
  await new Promise(r => setTimeout(r, 4000));
  const st = document.getElementById("updStatus");
  for (let i = 0; i < 30; i++) {
    try {
      const res = await fetch("/api/version");
      if (res.ok) {
        const j = await res.json();
        if (!expectedVersion || j.version === expectedVersion) {
          if (st) st.textContent = t("updServerBack");
          setTimeout(() => location.reload(), 800);
          return true;
        }
      }
    } catch (e) { /* server still down — keep polling */ }
    await new Promise(r => setTimeout(r, 1000));
  }
  if (st) st.textContent = t("updServerDown");
  updSetBusy(false);
  if (typeof updAutoSetBusy === "function") updAutoSetBusy(false);
  return false;
}
async function updHandleInstallResponse(res) {
  const st = document.getElementById("updStatus");
  let j = {};
  try { j = await res.json(); } catch (e) {}
  if (!res.ok) {
    if (st) st.textContent = t("updFailed", { error: j.error || res.status });
    updSetBusy(false);
    return;
  }
  if (st) st.textContent = t("updDone");
  updWaitForServer(j.version && j.version.version);
}
document.getElementById("updInstallFileBtn").addEventListener("click", async () => {
  const file = document.getElementById("updFile").files[0];
  if (!file) { alert(t("updNoFile")); return; }
  updSetBusy(true, "updInstalling");
  try {
    const res = await fetch("/api/update/upload", {
      method: "POST", headers: { "Content-Type": "application/zip" }, body: file
    });
    await updHandleInstallResponse(res);
  } catch (e) {
    const st = document.getElementById("updStatus");
    if (st) st.textContent = t("updFailed", { error: t("serverUnreachable") });
    updSetBusy(false);
  }
});
document.getElementById("updInstallUrlBtn").addEventListener("click", async () => {
  const url = document.getElementById("updUrl").value.trim();
  if (!url) { alert(t("updNoUrl")); return; }
  updSetBusy(true, "updInstalling");
  try {
    const res = await fetch("/api/update/url", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url })
    });
    await updHandleInstallResponse(res);
  } catch (e) {
    const st = document.getElementById("updStatus");
    if (st) st.textContent = t("updFailed", { error: t("serverUnreachable") });
    updSetBusy(false);
  }
});
document.getElementById("updRollbackBtn").addEventListener("click", async () => {
  if (!confirm(t("updRollbackConfirm"))) return;
  updSetBusy(true, "updInstalling");
  try {
    const res = await fetch("/api/update/rollback", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({})
    });
    let j = {};
    try { j = await res.json(); } catch (e) {}
    const st = document.getElementById("updStatus");
    if (!res.ok) {
      if (st) st.textContent = t("updFailed", { error: j.error || res.status });
      updSetBusy(false);
      return;
    }
    if (st) st.textContent = t("updRollbackDone");
    updWaitForServer(j.version && j.version.version);
  } catch (e) {
    const st = document.getElementById("updStatus");
    if (st) st.textContent = t("updFailed", { error: t("serverUnreachable") });
    updSetBusy(false);
  }
});

// ---- One-click auto-update (v1.10.0) ----
// The release channel is the public StudyFlow repo (latest.json manifest).
// A check only notifies; installing always needs the user's click on the
// «دانلود و نصب» button. Download progress comes from the server, which
// streams the zip, verifies its SHA-256 against the manifest, then runs
// the standard install + restart flow.
let updAutoLastPhase = null;
let updAutoPollTimer = null;
let updAutoAvailableVersion = null;
function updAutoSetBusy(busy) {
  ["updCheckBtn", "updInstallAutoBtn", "updManifestSaveBtn"].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.disabled = busy;
  });
}
function updAutoShowProgress(show) {
  const w = document.getElementById("updAutoProgressWrap");
  if (w) w.hidden = !show;
}
function updAutoSetProgress(pct) {
  const bar = document.getElementById("updAutoProgressBar");
  if (bar) bar.style.width = Math.max(0, Math.min(100, pct || 0)) + "%";
}
function updAutoRenderStatus(res) {
  const st = document.getElementById("updAutoStatus");
  const notes = document.getElementById("updAutoNotes");
  const btn = document.getElementById("updInstallAutoBtn");
  if (!st) return;
  let msg = "";
  updAutoAvailableVersion = null;
  if (btn) btn.hidden = true;
  const r = res && res.last_result;
  if (res && res.last_error) {
    msg = t("updCheckFailed", { error: res.last_error });
  } else if (r) {
    if (r.blocked_min_version) {
      msg = t("updMinVersion", { min: r.blocked_min_version });
    } else if (r.update_available) {
      msg = t("updAvailable", { version: r.version });
      updAutoAvailableVersion = r.version;
      if (btn) {
        btn.hidden = false;
        btn.textContent = t("updInstallAuto", { version: r.version });
      }
    } else {
      msg = t("updUpToDate", { version: r.current_version || (res.current && res.current.version) || "" });
    }
    if (notes) notes.textContent = r.notes || "";
  } else {
    msg = t("updNeverChecked");
  }
  if (res && res.last_check) msg += " · " + t("updLastCheck", { time: fmtBackupTs(res.last_check) });
  st.textContent = msg;
}
async function refreshAutoUpdate() {
  try {
    const res = await fetch("/api/update/auto");
    if (!res.ok) return;
    const j = await res.json();
    const urlEl = document.getElementById("updManifestUrl");
    if (urlEl && document.activeElement !== urlEl) urlEl.value = (j.config && j.config.manifest_url) || "";
    updAutoRenderStatus(j);
    const st = j.state;
    if (st && (st.phase === "downloading" || st.phase === "verifying" || st.phase === "installing")) {
      updAutoPollProgress(st.version);
    }
  } catch (e) { /* server unreachable — leave the panel as-is */ }
}
function updAutoPollProgress(expectedVersion) {
  if (updAutoPollTimer) return;
  updAutoShowProgress(true);
  updAutoLastPhase = null;
  updAutoPollTimer = setInterval(async () => {
    let st;
    try {
      const res = await fetch("/api/update/auto-progress");
      if (!res.ok) throw new Error("http " + res.status);
      st = await res.json();
    } catch (e) {
      // Server down: if we were already installing, the restart is under
      // way — wait for the new server. Otherwise it is a real failure.
      if (updAutoLastPhase === "installing" || updAutoLastPhase === "done") {
        clearInterval(updAutoPollTimer); updAutoPollTimer = null;
        updWaitForServer(expectedVersion);
      } else {
        const el = document.getElementById("updAutoStatus");
        if (el) el.textContent = t("updCheckFailed", { error: t("serverUnreachable") });
        clearInterval(updAutoPollTimer); updAutoPollTimer = null;
        updAutoSetBusy(false); updSetBusy(false);
      }
      return;
    }
    updAutoLastPhase = st.phase;
    const el = document.getElementById("updAutoStatus");
    if (st.phase === "downloading") {
      updAutoSetProgress(st.percent || 0);
      if (el) el.textContent = t("updDownloading", { pct: FA(st.percent || 0) });
    } else if (st.phase === "verifying") {
      updAutoSetProgress(100);
      if (el) el.textContent = t("updVerifying");
    } else if (st.phase === "installing") {
      updAutoSetProgress(100);
      if (el) el.textContent = t("updInstalling");
    } else if (st.phase === "done") {
      clearInterval(updAutoPollTimer); updAutoPollTimer = null;
      if (el) el.textContent = t("updDone");
      updWaitForServer(st.version || expectedVersion);
    } else if (st.phase === "error") {
      clearInterval(updAutoPollTimer); updAutoPollTimer = null;
      updAutoShowProgress(false);
      if (el) el.textContent = t("updFailed", { error: st.error || "?" });
      updAutoSetBusy(false); updSetBusy(false);
    }
  }, 1000);
}
document.getElementById("updCheckBtn").addEventListener("click", async () => {
  const st = document.getElementById("updAutoStatus");
  updAutoSetBusy(true);
  if (st) st.textContent = t("updChecking");
  try {
    const res = await fetch("/api/update/check", { method: "POST" });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) {
      if (st) st.textContent = t("updCheckFailed", { error: j.error || res.status });
      updAutoSetBusy(false);
      return;
    }
    updAutoRenderStatus({ last_check: j.checked_at, last_result: j, last_error: null, current: { version: j.current_version } });
  } catch (e) {
    if (st) st.textContent = t("updCheckFailed", { error: t("serverUnreachable") });
  }
  updAutoSetBusy(false);
});
document.getElementById("updManifestSaveBtn").addEventListener("click", async () => {
  const urlEl = document.getElementById("updManifestUrl");
  const st = document.getElementById("updAutoStatus");
  const url = urlEl ? urlEl.value.trim() : "";
  try {
    const res = await fetch("/api/update/auto-config", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ manifest_url: url })
    });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) {
      if (st) st.textContent = t("updCheckFailed", { error: j.error || res.status });
      return;
    }
    if (urlEl) urlEl.value = j.manifest_url || "";
    if (st) st.textContent = t("updManifestSaved");
    // NOTE: no refreshAutoUpdate() here — it would overwrite the "saved"
    // confirmation with the last-check status. The saved state is shown
    // again the next time the Backup tab renders.
  } catch (e) {
    if (st) st.textContent = t("updCheckFailed", { error: t("serverUnreachable") });
  }
});
document.getElementById("updInstallAutoBtn").addEventListener("click", async () => {
  const version = updAutoAvailableVersion;
  if (!version) return;
  if (!confirm(t("updInstallAutoConfirm", { version }))) return;
  updAutoSetBusy(true);
  updSetBusy(true); // also lock the manual update buttons during the install
  updAutoShowProgress(true);
  updAutoSetProgress(0);
  const st = document.getElementById("updAutoStatus");
  if (st) st.textContent = t("updDownloading", { pct: FA(0) });
  try {
    const res = await fetch("/api/update/install-auto", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ version })
    });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) {
      if (st) st.textContent = t("updFailed", { error: j.error || res.status });
      updAutoSetBusy(false); updSetBusy(false);
      updAutoShowProgress(false);
      return;
    }
    updAutoPollProgress(j.version || version);
  } catch (e) {
    if (st) st.textContent = t("updFailed", { error: t("serverUnreachable") });
    updAutoSetBusy(false); updSetBusy(false);
    updAutoShowProgress(false);
  }
});
document.getElementById("bkSaveBtn").addEventListener("click", async () => {
  const st = document.getElementById("bkB2Status");
  const body = {
    endpoint: document.getElementById("bkEndpoint").value.trim(),
    bucket: document.getElementById("bkBucket").value.trim() || "konkur-backup",
    key_id: document.getElementById("bkKeyId").value.trim(),
    application_key: document.getElementById("bkAppKey").value.trim(),
    enabled: true
  };
  try {
    const res = await fetch("/api/backup/b2-config", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    if (res.ok) {
      document.getElementById("bkAppKey").value = "";
      document.getElementById("bkKeyId").value = "";
      if (st) st.textContent = t("bkB2Saved");
      alert(t("bkB2Saved"));
    } else {
      const j = await res.json().catch(() => ({}));
      if (st) st.textContent = j.error || t("bkB2TestFail");
    }
  } catch (e) { if (st) st.textContent = t("serverUnreachable"); }
  refreshBackupStatus(); renderBackup();
});
document.getElementById("bkTestBtn").addEventListener("click", async () => {
  const st = document.getElementById("bkB2Status");
  if (st) st.textContent = t("analyzing");
  try {
    const res = await fetch("/api/backup/b2-test", { method: "POST" });
    const j = await res.json();
    if (st) st.textContent = j.ok ? t("bkB2TestOk") : t("bkB2TestFail") + (j.error ? ": " + j.error : "");
  } catch (e) { if (st) st.textContent = t("serverUnreachable"); }
});
document.getElementById("bkClearBtn").addEventListener("click", async () => {
  if (!confirm(t("bkB2ClearConfirm"))) return;
  const st = document.getElementById("bkB2Status");
  try {
    await fetch("/api/backup/b2-clear", { method: "POST" });
    document.getElementById("bkKeyId").value = "";
    document.getElementById("bkAppKey").value = "";
    if (st) st.textContent = t("bkB2Cleared");
  } catch (e) { if (st) st.textContent = t("serverUnreachable"); }
  refreshBackupStatus(); renderBackup();
});


// ---- Calendar sync (v1.8.0 pull, v1.11.0 two-way): ICS pull + manual file
// import for reading; OAuth 2.0 (Desktop-app client) pushes app edits back
// to Google Calendar. Credentials + tokens live server-side only and are
// only ever shown masked. Push is debounced server-side (~15s after a box
// edit) plus a manual «ارسال تغییرات به گوگل» button.
let calImportContent = "", calImportFilename = "";
let calWired = false;
function calSummaryText(sm) {
  if (!sm) return "";
  let out = t("calAdded", { n: FA(sm.added || 0) }) + " · " + t("calUpdated", { n: FA(sm.updated || 0) }) + " · " + t("calRemoved", { n: FA(sm.removed || 0) });
  if (sm.skipped_tombstone) out += " · " + t("calSkippedTomb", { n: FA(sm.skipped_tombstone) });
  if (sm.kept_touched) out += " · " + t("calKeptTouched", { n: FA(sm.kept_touched) });
  if (sm.conflicts) out += " · " + t("calConflictsTitle") + ": " + FA(sm.conflicts);
  return out;
}
function calPushSummaryText(sm) {
  if (!sm) return "";
  return t("calPushDone", { c: FA(sm.created || 0), u: FA(sm.updated || 0), d: FA(sm.removed || 0) }) + (sm.error_count ? " · \\u26a0 " + FA(sm.error_count) : "");
}
async function renderCalendarPanel() {
  let st = null;
  try { const r = await fetch("/api/calendar/status"); if (r.ok) st = await r.json(); } catch (e) {}
  if (!st) return;
  const cfg = st.config || {};
  const urlEl = document.getElementById("calIcsUrl");
  if (urlEl) urlEl.placeholder = cfg.ics_url_masked || t("calIcsPh");
  const intEl = document.getElementById("calInterval");
  if (intEl) intEl.value = cfg.interval_minutes || 30;
  const enEl = document.getElementById("calEnabled");
  if (enEl) enEl.checked = !!cfg.enabled;
  const stEl = document.getElementById("calStatus");
  if (stEl) {
    stEl.textContent = cfg.configured
      ? (cfg.last_sync ? t("calLastSync", { t: fmtBackupTs(cfg.last_sync) }) + (cfg.last_summary ? " — " + calSummaryText(cfg.last_summary) : "") : t("calNeverSynced")) + (cfg.last_error ? " · \\u26a0 " + cfg.last_error : "")
      : t("calNoConfig");
  }
  const psEl = document.getElementById("calProgStats");
  if (psEl && st.programme) psEl.textContent = t("calProgrammeStats", { n: FA(st.programme.box_count || 0), m: FA(st.programme.mapped || 0), tb: FA(st.programme.tombstones || 0) });
  // --- OAuth + push status (v1.11.0) ---
  const oAuth = st.oauth || {};
  const push = st.push || {};
  const cidEl = document.getElementById("calClientId");
  if (cidEl) cidEl.placeholder = oAuth.client_id_masked || t("calClientIdPh");
  const oEl = document.getElementById("calOAuthStatus");
  if (oEl) {
    oEl.textContent = oAuth.connected
      ? t("calOAuthConnected", { email: oAuth.email || "—", t: oAuth.expires_at ? fmtBackupTs(new Date(oAuth.expires_at * 1000).toISOString()) : "—" })
      : (oAuth.credentials_set ? t("calOAuthNotConnected") : t("calOAuthNoCreds"));
  }
  const pEl = document.getElementById("calPushStatus");
  if (pEl) {
    let txt = "";
    if (!push.connected) {
      txt = t("calPushNotConnected");
    } else {
      if (push.pending_count) txt += t("calPushPending", { n: FA(push.pending_count) });
      const lp = push.last_push;
      if (lp) {
        if (txt) txt += " · ";
        txt += t("calPushLast", { t: fmtBackupTs(lp.ts), s: lp.ok ? calPushSummaryText(lp.summary) : (lp.error || t("calError")) });
      } else if (!txt) {
        txt = t("calPushNever");
      }
    }
    pEl.textContent = txt;
  }
  const cfEl = document.getElementById("calConflicts");
  if (cfEl) {
    const conf = push.conflicts || [];
    cfEl.innerHTML = conf.length
      ? '<p><b>' + t("calConflictsTitle") + '</b></p>' + conf.map(c =>
          '<p class="muted">\\u26a0 ' + esc(t("calConflictNote", { title: c.title || c.box_id })) + '</p>').join("")
      : "";
  }
  const logEl = document.getElementById("calLog");
  if (logEl) {
    const log = st.log || [];
    logEl.innerHTML = log.length ? log.slice().reverse().map(e =>
      '<div class="cal-log-row"><b>' + esc(fmtBackupTs(e.ts)) + ' · ' + esc(e.source || "") + '</b><br>' +
      esc(calSummaryText(e.summary || {})) +
      ((e.lines || []).length ? '<br><span class="muted">' + esc((e.lines || []).slice(0, 5).join(" | ")) + '</span>' : '') + '</div>').join("") : '<p class="muted">' + t("calLogEmpty") + '</p>';
  }
}
function readFileText(f) {
  return new Promise((resolve, reject) => {
    if (f.text) { f.text().then(resolve, () => {
      const r = new FileReader(); r.onload = () => resolve(r.result); r.onerror = reject; r.readAsText(f);
    }); return; }
    const r = new FileReader(); r.onload = () => resolve(r.result); r.onerror = reject; r.readAsText(f);
  });
}
function wireCalendarPanel() {
  if (calWired) return; calWired = true;
  const saveBtn = document.getElementById("calSaveBtn");
  if (saveBtn) saveBtn.addEventListener("click", async () => {
    const st = document.getElementById("calStatus");
    const url = (document.getElementById("calIcsUrl").value || "").trim();
    const interval = parseInt((document.getElementById("calInterval").value || "30"), 10) || 30;
    const enabled = document.getElementById("calEnabled").checked;
    try {
      const res = await fetch("/api/calendar/config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ics_url: url, interval_minutes: interval, enabled }) });
      const j = await res.json();
      if (res.ok) { document.getElementById("calIcsUrl").value = ""; if (st) st.textContent = t("calSaved"); }
      else if (st) st.textContent = j.error || t("calError");
    } catch (e) { if (st) st.textContent = t("serverUnreachable"); }
    renderCalendarPanel();
  });
  const syncBtn = document.getElementById("calSyncBtn");
  if (syncBtn) syncBtn.addEventListener("click", async () => {
    const st = document.getElementById("calStatus");
    if (st) st.textContent = t("calSyncing");
    try {
      const res = await fetch("/api/calendar/sync", { method: "POST" });
      const j = await res.json();
      if (res.ok && j.summary) { if (st) st.textContent = calSummaryText(j.summary); await refreshDataFromServer(); }
      else if (st) st.textContent = (j.error || t("calError"));
    } catch (e) { if (st) st.textContent = t("serverUnreachable"); }
    renderCalendarPanel();
  });
  const clearBtn = document.getElementById("calClearBtn");
  if (clearBtn) clearBtn.addEventListener("click", async () => {
    if (!confirm(t("calClearConfirm"))) return;
    try { await fetch("/api/calendar/clear", { method: "POST" }); } catch (e) {}
    renderCalendarPanel();
  });
  // --- OAuth + push wiring (v1.11.0) ---
  const oSaveBtn = document.getElementById("calOAuthSaveBtn");
  if (oSaveBtn) oSaveBtn.addEventListener("click", async () => {
    const st = document.getElementById("calOAuthStatus");
    const cid = (document.getElementById("calClientId").value || "").trim();
    const csec = (document.getElementById("calClientSecret").value || "").trim();
    try {
      const res = await fetch("/api/calendar/oauth/credentials", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ client_id: cid, client_secret: csec }) });
      const j = await res.json();
      if (res.ok) {
        document.getElementById("calClientId").value = "";
        document.getElementById("calClientSecret").value = "";
        // Update from the response directly: a full panel re-render here
        // would immediately overwrite the "saved" confirmation.
        const cidEl = document.getElementById("calClientId");
        if (cidEl && j.client_id_masked) cidEl.placeholder = j.client_id_masked;
        if (st) st.textContent = t("calOAuthSaved");
      } else if (st) st.textContent = j.error || t("calError");
    } catch (e) { if (st) st.textContent = t("serverUnreachable"); }
  });
  const connBtn = document.getElementById("calConnectBtn");
  if (connBtn) connBtn.addEventListener("click", async () => {
    const st = document.getElementById("calOAuthStatus");
    try {
      const res = await fetch("/api/calendar/oauth/auth-url");
      const j = await res.json();
      if (res.ok && j.url) window.open(j.url, "_blank");
      else if (st) st.textContent = j.error || t("calOAuthNoClient");
    } catch (e) { if (st) st.textContent = t("serverUnreachable"); }
  });
  const disBtn = document.getElementById("calDisconnectBtn");
  if (disBtn) disBtn.addEventListener("click", async () => {
    if (!confirm(t("calOAuthDisconnectConfirm"))) return;
    const st = document.getElementById("calOAuthStatus");
    try {
      const res = await fetch("/api/calendar/oauth/disconnect", { method: "POST" });
      if (res.ok) {
        // Update from the response directly: a full panel re-render here
        // would immediately overwrite the "disconnected" confirmation.
        if (st) st.textContent = t("calOAuthDisconnected");
        const pEl = document.getElementById("calPushStatus");
        if (pEl) pEl.textContent = t("calPushNotConnected");
        const cfEl = document.getElementById("calConflicts");
        if (cfEl) cfEl.innerHTML = "";
      }
    } catch (e) { if (st) st.textContent = t("serverUnreachable"); }
  });
  const pushBtn = document.getElementById("calPushBtn");
  if (pushBtn) pushBtn.addEventListener("click", async () => {
    const st = document.getElementById("calPushStatus");
    if (st) st.textContent = t("calPushing");
    try {
      const res = await fetch("/api/calendar/push", { method: "POST" });
      const j = await res.json();
      if (res.ok && j.summary) { if (st) st.textContent = calPushSummaryText(j.summary); }
      else if (st) st.textContent = t("calPushFailed", { e: j.error || t("calError") });
    } catch (e) { if (st) st.textContent = t("serverUnreachable"); }
    renderCalendarPanel();
  });
  const fileEl = document.getElementById("calFile");
  const prevEl = document.getElementById("calImportPreview");
  const applyBtn = document.getElementById("calImportApplyBtn");
  const cancelBtn = document.getElementById("calImportCancelBtn");
  const hideImportActions = () => { if (applyBtn) applyBtn.hidden = true; if (cancelBtn) cancelBtn.hidden = true; };
  if (fileEl) fileEl.addEventListener("change", async () => {
    const f = fileEl.files && fileEl.files[0];
    if (!f) return;
    calImportFilename = f.name;
    try { calImportContent = await readFileText(f); } catch (e) { if (prevEl) prevEl.textContent = t("calError"); return; }
    if (prevEl) prevEl.innerHTML = '<p class="muted">' + t("calSyncing") + '</p>';
    try {
      const res = await fetch("/api/calendar/import-preview", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ filename: f.name, content: calImportContent }) });
      const j = await res.json();
      if (!res.ok) { if (prevEl) prevEl.innerHTML = '<p class="muted">\\u26a0 ' + esc(j.error || t("calError")) + '</p>'; hideImportActions(); return; }
      const sm = j.summary || {};
      if (prevEl) prevEl.innerHTML = '<p><b>' + t("calImportPreviewTitle") + ' — ' + esc(f.name) + '</b></p><p>' + calSummaryText(sm) + '</p>' +
        ((sm.added_titles || []).length ? '<p class="muted">+ ' + esc(sm.added_titles.join(" · ")) + '</p>' : '') +
        ((sm.updated_titles || []).length ? '<p class="muted">~ ' + esc(sm.updated_titles.join(" · ")) + '</p>' : '') +
        ((sm.removed_titles || []).length ? '<p class="muted">\\u2212 ' + esc(sm.removed_titles.join(" · ")) + '</p>' : '');
      if (applyBtn) applyBtn.hidden = false;
      if (cancelBtn) cancelBtn.hidden = false;
    } catch (e) { if (prevEl) prevEl.textContent = t("serverUnreachable"); hideImportActions(); }
  });
  if (applyBtn) applyBtn.addEventListener("click", async () => {
    const st = document.getElementById("calStatus");
    if (!calImportContent) return;
    try {
      const res = await fetch("/api/calendar/import", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ filename: calImportFilename, content: calImportContent }) });
      const j = await res.json();
      if (res.ok && j.summary) {
        if (st) st.textContent = calSummaryText(j.summary);
        if (prevEl) prevEl.innerHTML = '<p><b>' + t("calImportApplied") + '</b> — ' + calSummaryText(j.summary) + '</p>';
        await refreshDataFromServer();
      } else if (st) st.textContent = (j.error || t("calError"));
    } catch (e) { if (st) st.textContent = t("serverUnreachable"); }
    calImportContent = ""; calImportFilename = "";
    if (fileEl) fileEl.value = "";
    hideImportActions();
    renderCalendarPanel();
  });
  if (cancelBtn) cancelBtn.addEventListener("click", () => {
    calImportContent = ""; calImportFilename = "";
    if (fileEl) fileEl.value = "";
    if (prevEl) prevEl.innerHTML = "";
    hideImportActions();
  });
}


wireCalendarPanel();
loadAll();
