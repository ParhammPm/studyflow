#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Backblaze B2 (S3-compatible API) client — pure Python standard library only.

No credentials are stored here and none are ever shipped: the server keeps
them in %APPDATA%\\KonkurApp\\b2_config.json (outside the app folder) and the
client only ever receives them at runtime. Until a config exists the cloud
layer is inert — the local backup layer works on its own.

B2's S3 endpoint is per-region (e.g. s3.us-west-000.backblazeb2.com); the
endpoint is configurable and the SigV4 region is derived from it. B2's free
tier is 10 GB with no credit card at signup.

SigV4 signing is implemented by hand (AWS Signature Version 4). The
sign_request() function is verified in tests against the AWS-documented
example (GET https://iam.amazonaws.com/?Action=ListUsers&Version=2010-05-08,
expected signature 5d672d79c15b13162d9279b0855cfba6789a8edb4c82c400e06b5924a6f2b5d7).
"""
import hashlib
import hmac
import json
import re
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

ALGORITHM = "AWS4-HMAC-SHA256"
DEFAULT_ENDPOINT = "s3.us-west-000.backblazeb2.com"
DEFAULT_REGION = "us-west-000"


def _hmac(key, msg):
    if isinstance(msg, str):
        msg = msg.encode("utf-8")
    return hmac.new(key, msg, hashlib.sha256).digest()


def _sha256_hex(data):
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def _pct_encode(s, safe=""):
    return urllib.parse.quote(str(s), safe=safe)


def region_from_endpoint(endpoint):
    """Derive the SigV4 region from a B2 S3 endpoint host.

    s3.us-west-000.backblazeb2.com -> us-west-000. Anything unrecognised
    falls back to the default region.
    """
    m = re.match(r"^s3\.([a-z0-9-]+)\.backblazeb2\.com$", (endpoint or "").strip())
    return m.group(1) if m else DEFAULT_REGION


def canonical_request(method, url, headers, payload_hash):
    """Build the AWS SigV4 canonical request.

    headers: dict of header name -> value (names are lower-cased, values
    trimmed, sorted by name). Returns (canonical_request, signed_headers).
    """
    parsed = urllib.parse.urlparse(url)
    # Canonical URI: each path segment percent-encoded, "/" preserved.
    uri = "/".join(_pct_encode(seg, safe="-_.~") for seg in parsed.path.split("/"))
    if not uri.startswith("/"):
        uri = "/" + uri
    # Canonical query string: sorted by name, percent-encoded.
    params = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
    params.sort(key=lambda kv: (kv[0], kv[1]))
    query = "&".join(_pct_encode(k, safe="-_.~") + "=" + _pct_encode(v, safe="-_.~")
                     for k, v in params)
    canon_headers = ""
    signed = []
    for name in sorted(headers):
        canon_headers += name.lower() + ":" + str(headers[name]).strip() + "\n"
        signed.append(name.lower())
    signed_headers = ";".join(signed)
    return ("\n".join([method.upper(), uri, query, canon_headers,
                       signed_headers, payload_hash]),
            signed_headers)


def sign_request(method, url, headers, payload, access_key, secret_key,
                 region, service="s3", now=None):
    """Sign a request. Returns a NEW headers dict including Authorization
    and x-amz-date. Only the headers passed in are signed — callers that
    want the payload hash signed add x-amz-content-sha256 themselves
    (B2Client does). `now` is a datetime (UTC) — pass one in tests to
    reproduce the AWS example vector; defaults to current time.
    """
    if now is None:
        now = datetime.now(timezone.utc)
    amzdate = now.strftime("%Y%m%dT%H%M%SZ")
    datestamp = now.strftime("%Y%m%d")
    payload = payload or b""
    payload_hash = _sha256_hex(payload)
    hdrs = dict(headers)
    hdrs["x-amz-date"] = amzdate
    canon, signed_headers = canonical_request(method, url, hdrs, payload_hash)
    scope = "{}/{}/{}/aws4_request".format(datestamp, region, service)
    string_to_sign = "\n".join([ALGORITHM, amzdate, scope, _sha256_hex(canon)])
    k_date = _hmac(("AWS4" + secret_key).encode("utf-8"), datestamp)
    k_region = _hmac(k_date, region)
    k_service = _hmac(k_region, service)
    k_signing = _hmac(k_service, "aws4_request")
    signature = hmac.new(k_signing, string_to_sign.encode("utf-8"),
                         hashlib.sha256).hexdigest()
    hdrs["Authorization"] = (
        "{} Credential={}/{}, SignedHeaders={}, Signature={}".format(
            ALGORITHM, access_key, scope, signed_headers, signature))
    return hdrs


class B2Error(Exception):
    """A B2 S3-API request failed (HTTP error or network error)."""
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


class B2Client:
    """Minimal S3-compatible client for one Backblaze B2 bucket.

    Config keys: endpoint (host, e.g. s3.us-west-000.backblazeb2.com),
    key_id (application key ID), application_key, bucket.
    """

    def __init__(self, config):
        self.endpoint = str(config.get("endpoint") or DEFAULT_ENDPOINT).strip()
        self.endpoint = re.sub(r"^https?://", "", self.endpoint).strip("/ ")
        self.region = str(config.get("region") or
                          region_from_endpoint(self.endpoint)).strip()
        self.key_id = str(config.get("key_id") or "").strip()
        self.application_key = str(config.get("application_key") or "").strip()
        self.bucket = str(config.get("bucket") or "konkur-backup").strip()
        if not self.key_id or not self.application_key:
            raise B2Error("B2 is not configured (missing key ID or application key)")
        self.base_url = "https://{}/{}".format(self.endpoint, self.bucket)

    def _request(self, method, key, data=None, content_type=None, timeout=30):
        url = "{}/{}".format(self.base_url,
                             urllib.parse.quote(key, safe="/-_.~"))
        payload = data if data is not None else b""
        headers = {"host": self.endpoint,
                   "x-amz-content-sha256": _sha256_hex(payload)}
        if content_type:
            headers["Content-Type"] = content_type
        signed = sign_request(method, url, headers, payload,
                              self.key_id, self.application_key, self.region, "s3")
        req = urllib.request.Request(
            url,
            data=payload if method in ("PUT", "POST") else None,
            headers=signed, method=method)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.read(), resp.status
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", "replace")[:500]
            raise B2Error("B2 HTTP {}: {}".format(exc.code, body), status=exc.code)
        except Exception as exc:
            raise B2Error("B2 connection failed: {}".format(exc))

    def put_object(self, key, data, content_type="application/json"):
        self._request("PUT", key, data=data, content_type=content_type)
        return True

    def get_object(self, key):
        body, _ = self._request("GET", key)
        return body

    def get_json(self, key):
        """GET a JSON object; returns None on 404 (missing object)."""
        try:
            raw = self.get_object(key)
        except B2Error as exc:
            if exc.status == 404:
                return None
            raise
        return json.loads(raw.decode("utf-8"))

    def list_objects(self, prefix="", max_keys=100):
        """List object keys under a prefix (ListObjectsV2, one page)."""
        query = urllib.parse.urlencode(
            {"list-type": "2", "prefix": prefix, "max-keys": str(max_keys)})
        url = "{}?{}".format(self.base_url, query)
        headers = {"host": self.endpoint, "x-amz-content-sha256": _sha256_hex(b"")}
        signed = sign_request("GET", url, headers, b"",
                              self.key_id, self.application_key, self.region, "s3")
        req = urllib.request.Request(url, headers=signed, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                body = resp.read()
        except urllib.error.HTTPError as exc:
            raise B2Error("B2 HTTP {}: {}".format(
                exc.code, exc.read().decode("utf-8", "replace")[:500]), status=exc.code)
        except Exception as exc:
            raise B2Error("B2 connection failed: {}".format(exc))
        root = ET.fromstring(body)
        ns = {"s3": "http://s3.amazonaws.com/doc/2006-03-01/"}
        keys = []
        for el in root.findall("s3:Contents", ns):
            k = el.find("s3:Key", ns)
            if k is not None and k.text:
                keys.append(k.text)
        return keys

    def test_connection(self):
        """Read-only check: list one object under the backup prefix.
        Returns (ok, error_message_or_None)."""
        try:
            self.list_objects(prefix="konkur-backup/", max_keys=1)
            return True, None
        except B2Error as exc:
            if exc.status == 404:
                return True, None  # bucket exists, prefix simply empty
            return False, str(exc)
