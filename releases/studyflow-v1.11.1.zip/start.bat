@echo off
cd /d "%~dp0"
python --version >nul 2>&1
if errorlevel 1 goto nopython
start "" "http://localhost:8765"
python -u server.py
pause
exit /b 0
:nopython
echo Python is not installed. Please install Python from python.org and tick Add Python to PATH, then run start.bat again.
pause
exit /b 1
