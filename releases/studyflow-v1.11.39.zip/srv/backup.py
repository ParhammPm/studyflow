#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""StudyFlow server — backup + cloud layer (v1.11.38, P3-10).

Local versioned backups (backups/) and Backblaze B2 cloud sync.
Moved verbatim from server.py; behaviour is unchanged. No HTTP, no
calendar logic: other modules import from here, and nothing here
imports from them (except srv.common), so there is no import cycle.
"""
import json
import os
import re
import shutil
import threading
import time
from datetime import datetime

try:
    import b2 as b2mod
except Exception:
    b2mod = None

from srv.common import (
    APP_KEY_FILE,
    APP_STATE_FILE,
    APP_TESTBOOK_FILE,
    B2_CONFIG_FILE,
    BACKUP_DIR,
    BACKUP_META_FILE,
    CALENDAR_DATA_FILE,
    CLOUD_MANIFEST_KEY,
    CLOUD_PREFIX,
    DATA_DIR,
    GOOGLE_PUSH_FILE,
    KEY_FILE,
    MAX_BACKUPS_PER_KIND,
    STATE_FILE,
    TESTBOOK_FILE,
    atomic_write,
    atomic_write_json,
    ensure_data_dir,
    iso_now,
    now_ts,
    read_json_file,
    sha256_bytes,
    valid_state,
    valid_testbook,
)


_VERIFY_BOOL_CACHE = {}

def migrate_legacy_files():
    """Move app-folder data files into the data dir — only when the data-dir
    file does not exist yet. The app folder becomes replaceable code."""
    ensure_data_dir()
    for app_path, data_path in ((APP_STATE_FILE, STATE_FILE),
                                (APP_TESTBOOK_FILE, TESTBOOK_FILE),
                                (APP_KEY_FILE, KEY_FILE)):
        if os.path.exists(data_path) or not os.path.exists(app_path):
            continue
        try:
            if app_path.endswith(".json"):
                data, err = read_json_file(app_path)
                if data is None:
                    print("Migration skipped (unreadable): {}".format(app_path))
                    continue
            shutil.move(app_path, data_path)
            print("Migrated {} -> {}".format(app_path, data_path))
            # Snapshot the migrated file at once, so the pre-migration
            # content is preserved as the first backup version.
            if app_path.endswith(".json"):
                kind = "state" if "state" in os.path.basename(app_path) else "testbook"
                create_backup(kind, force=True)
        except Exception as exc:
            print("Migration failed for {}: {}".format(app_path, exc))


def rebuild_backup_meta():
    """Rebuild backup_meta.json by scanning backups/ (audit §5 item 1.10):
    every versioned file is re-verified (filename pattern, SHA-256,
    JSON parses, schema valid) and re-listed newest-first, capped at
    MAX_BACKUPS_PER_KIND per kind. Files that fail verification are
    skipped, never listed. The rebuilt meta is saved and returned."""
    versions = []
    if os.path.isdir(BACKUP_DIR):
        for fname in sorted(os.listdir(BACKUP_DIR)):
            m = re.match(r"^(state|testbook|programme|push)-(\d{8}-\d{6})-([0-9a-f]{8})\.json$", fname)
            if not m:
                continue
            kind, tsstr, short = m.groups()
            path = os.path.join(BACKUP_DIR, fname)
            try:
                with open(path, "rb") as f:
                    raw = f.read()
                digest = sha256_bytes(raw)
                if not digest.startswith(short):
                    continue
                data = json.loads(raw.decode("utf-8"))
                if kind == "state" and not valid_state(data):
                    continue
                if kind == "testbook" and not valid_testbook(data):
                    continue
                if kind == "programme" and not (
                        isinstance(data, dict) and isinstance(data.get("boxes"), list)):
                    continue
                if kind == "push" and not isinstance(data, dict):
                    continue
                ts = datetime.strptime(tsstr, "%Y%m%d-%H%M%S").timestamp()
                versions.append({"kind": kind, "file": fname, "ts": ts,
                                 "ts_iso": datetime.fromtimestamp(ts).isoformat(),
                                 "sha256": digest, "size": len(raw), "source": "local"})
            except Exception:
                continue
    versions.sort(key=lambda v: v.get("ts", 0), reverse=True)
    kept = []
    counts = {}
    for v in versions:
        k = v.get("kind")
        counts[k] = counts.get(k, 0) + 1
        if counts[k] <= MAX_BACKUPS_PER_KIND:
            kept.append(v)
    meta = {"versions": kept}
    save_backup_meta(meta)
    print("Rebuilt backup_meta.json from backups/ scan: {} versions".format(len(kept)))
    return meta


def load_backup_meta():
    data, _ = read_json_file(BACKUP_META_FILE)
    if isinstance(data, dict) and isinstance(data.get("versions"), list):
        return data
    # Missing or corrupt meta: the backup files themselves are the source
    # of truth — rebuild the index from them (audit §5 item 1.10).
    return rebuild_backup_meta()


def save_backup_meta(meta):
    try:
        atomic_write_json(BACKUP_META_FILE, meta)
    except Exception as exc:
        print("Could not save backup meta: {}".format(exc))


def list_local_versions(kind=None):
    meta = load_backup_meta()
    versions = meta.get("versions", [])
    if kind:
        versions = [v for v in versions if v.get("kind") == kind]
    return sorted(versions, key=lambda v: v.get("ts", 0), reverse=True)


def verify_backup_entry(entry):
    """Verify one backup version: file exists, SHA-256 matches, JSON parses,
    schema is valid. Returns the parsed data or None."""
    if not entry or not entry.get("file"):
        return None
    path = os.path.join(BACKUP_DIR, entry["file"])
    if not os.path.exists(path):
        return None
    try:
        with open(path, "rb") as f:
            raw = f.read()
    except Exception:
        return None
    if sha256_bytes(raw) != entry.get("sha256"):
        return None
    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception:
        return None
    if entry.get("kind") == "state" and not valid_state(data):
        return None
    if entry.get("kind") == "testbook" and not valid_testbook(data):
        return None
    if entry.get("kind") == "programme" and not (
            isinstance(data, dict) and isinstance(data.get("boxes"), list)):
        return None
    if entry.get("kind") == "push" and not isinstance(data, dict):
        return None
    return data


def backup_entry_verified(entry):
    """Cached verified? check for the backup list: backup files are
    immutable (versioned filenames carry their hash), so a (file, sha,
    size) key stays valid. Avoids re-reading + re-hashing + re-parsing
    every backup on every GET /api/backup/list."""
    key = (entry.get("file"), entry.get("sha256"), entry.get("size"))
    if key in _VERIFY_BOOL_CACHE:
        return _VERIFY_BOOL_CACHE[key]
    ok = verify_backup_entry(entry) is not None
    if len(_VERIFY_BOOL_CACHE) > 500:
        _VERIFY_BOOL_CACHE.clear()
    _VERIFY_BOOL_CACHE[key] = ok
    return ok


def create_backup(kind, force=False):
    """Snapshot the current data file into backups/. Skips when the content
    is identical to the newest backup of that kind (unless force=True).
    Returns the version entry or None."""
    src = {"state": STATE_FILE, "testbook": TESTBOOK_FILE,
           "programme": CALENDAR_DATA_FILE, "push": GOOGLE_PUSH_FILE}.get(kind, STATE_FILE)
    if not os.path.exists(src):
        return None
    try:
        with open(src, "rb") as f:
            raw = f.read()
    except Exception as exc:
        print("Backup failed (read {}): {}".format(src, exc))
        return None
    digest = sha256_bytes(raw)
    meta = load_backup_meta()
    existing = [v for v in meta.get("versions", []) if v.get("kind") == kind]
    existing.sort(key=lambda v: v.get("ts", 0), reverse=True)
    if not force and existing and existing[0].get("sha256") == digest:
        return existing[0]
    ts = now_ts()
    fname = "{}-{}-{}.json".format(
        kind, datetime.fromtimestamp(ts).strftime("%Y%m%d-%H%M%S"), digest[:8])
    try:
        atomic_write(os.path.join(BACKUP_DIR, fname), raw)
    except Exception as exc:
        print("Backup failed (write {}): {}".format(fname, exc))
        return None
    entry = {"kind": kind, "file": fname, "ts": ts, "ts_iso": iso_now(),
             "sha256": digest, "size": len(raw), "source": "local"}
    versions = [entry] + [v for v in meta.get("versions", []) if v != entry]
    # Prune to MAX_BACKUPS_PER_KIND per kind (oldest first), deleting files.
    kept = []
    counts = {}
    for v in versions:
        k = v.get("kind")
        counts[k] = counts.get(k, 0) + 1
        if counts[k] <= MAX_BACKUPS_PER_KIND:
            kept.append(v)
        else:
            try:
                os.remove(os.path.join(BACKUP_DIR, v["file"]))
            except Exception:
                pass
    meta["versions"] = kept
    save_backup_meta(meta)
    return entry


def newest_verified_backup(kind):
    for entry in list_local_versions(kind):
        data = verify_backup_entry(entry)
        if data is not None:
            return entry, data
    return None, None


def load_b2_config():
    data, _ = read_json_file(B2_CONFIG_FILE)
    if isinstance(data, dict):
        return data
    return None


def save_b2_config(cfg):
    # Credential file (holds the B2 application key): 0600, owner only
    # (audit §5 item 1.10).
    atomic_write_json(B2_CONFIG_FILE, cfg, mode=0o600)


def masked_b2_config(cfg):
    if not cfg:
        return {"configured": False, "enabled": False, "bucket": None,
                "endpoint": None, "key_id_masked": ""}
    kid = str(cfg.get("key_id") or "")
    return {"configured": bool(cfg.get("key_id") and cfg.get("application_key")),
            "enabled": bool(cfg.get("enabled")),
            "bucket": cfg.get("bucket") or "konkur-backup",
            "endpoint": cfg.get("endpoint") or b2mod.DEFAULT_ENDPOINT if b2mod else None,
            "key_id_masked": (kid[:4] + "••••" + kid[-2:]) if len(kid) > 6 else "••••"}


def cloud_restore_latest(kind):
    """Last-resort restore: download the newest cloud snapshot for `kind`,
    verify SHA-256 + JSON + schema. Returns parsed data or None."""
    if not b2mod:
        return None
    cfg = load_b2_config()
    if not cfg or not cfg.get("enabled"):
        return None
    try:
        client = b2mod.B2Client(cfg)
        manifest = client.get_json(CLOUD_MANIFEST_KEY)
        if not manifest or kind not in manifest:
            return None
        entry = manifest[kind]
        raw = client.get_object(entry["key"])
        if sha256_bytes(raw) != entry.get("sha256"):
            print("Cloud restore rejected: SHA mismatch for {}".format(entry["key"]))
            return None
        data = json.loads(raw.decode("utf-8"))
        if kind == "state" and not valid_state(data):
            return None
        if kind == "testbook" and not valid_testbook(data):
            return None
        print("Restored {} from cloud snapshot {}".format(kind, entry["key"]))
        return data
    except Exception as exc:
        print("Cloud restore failed: {}".format(exc))
        return None


class CloudSync:
    """Background sync thread: uploads versioned snapshots + latest.json
    manifest to B2. Never overwrites a newer remote version — on conflict it
    keeps BOTH and records the conflict for the UI to resolve."""

    def __init__(self):
        self._event = threading.Event()
        self._immediate = threading.Event()
        self._lock = threading.Lock()
        self.last_sync = None          # {"ts", "ts_iso", "ok", "error"}
        self.last_synced_sha = {"state": None, "testbook": None,
                                "programme": None}
        self.conflict = None           # {"kind", "remote_ts", "remote_key", "remote_sha256"}

    def request(self, immediate=False):
        self._event.set()
        if immediate:
            self._immediate.set()

    def run(self):
        while True:
            self._event.wait(timeout=60)
            self._event.clear()
            if self._immediate.is_set():
                self._immediate.clear()
            else:
                # Debounce: wait a little in case more saves arrive.
                time.sleep(15)
            try:
                self.sync_once()
            except Exception as exc:
                with self._lock:
                    self.last_sync = {"ts": now_ts(), "ts_iso": iso_now(),
                                      "ok": False, "error": str(exc)}
                print("Cloud sync error: {}".format(exc))

    def sync_once(self):
        if not b2mod:
            return
        cfg = load_b2_config()
        if not cfg or not cfg.get("enabled"):
            return
        client = b2mod.B2Client(cfg)
        try:
            manifest = client.get_json(CLOUD_MANIFEST_KEY) or {}
        except Exception as exc:
            raise b2mod.B2Error("Could not read cloud manifest: {}".format(exc))
        changed = False
        uploaded = {}  # kinds uploaded this run; marked synced only after the manifest lands
        for kind, path in (("state", STATE_FILE), ("testbook", TESTBOOK_FILE),
                           ("programme", CALENDAR_DATA_FILE)):
            if not os.path.exists(path):
                continue
            with open(path, "rb") as f:
                raw = f.read()
            digest = sha256_bytes(raw)
            if self.last_synced_sha.get(kind) == digest:
                continue
            remote = manifest.get(kind) or {}
            if remote.get("sha256") and remote.get("sha256") != digest:
                # Remote holds different content. If it is NEWER than the
                # local file, do not overwrite it — record the conflict and
                # keep both versions; the user resolves it in the UI.
                if remote.get("ts", 0) > int(os.path.getmtime(path)):
                    with self._lock:
                        self.conflict = {"kind": kind,
                                         "remote_ts": remote.get("ts"),
                                         "remote_key": remote.get("key"),
                                         "remote_sha256": remote.get("sha256")}
                    print("Cloud sync conflict on {}: remote is newer, keeping both".format(kind))
                    continue
            ts = now_ts()
            key = "{}-{}-{}.json".format(
                kind, datetime.fromtimestamp(ts).strftime("%Y%m%d-%H%M%S"), digest[:8])
            client.put_object(CLOUD_PREFIX + key, raw, "application/json")
            manifest[kind] = {"key": CLOUD_PREFIX + key, "sha256": digest, "ts": ts}
            manifest["updated_ts"] = ts
            changed = True
            # Record the upload only AFTER the manifest below is written:
            # marking it synced here would orphan the object if the
            # manifest upload then failed (never retried until the
            # content changed again or the server restarted).
            uploaded[kind] = digest
            if self.conflict and self.conflict.get("kind") == kind:
                with self._lock:
                    self.conflict = None
        if changed:
            client.put_object(CLOUD_MANIFEST_KEY,
                              json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8"),
                              "application/json")
            with self._lock:
                for k, d in uploaded.items():
                    self.last_synced_sha[k] = d
        with self._lock:
            self.last_sync = {"ts": now_ts(), "ts_iso": iso_now(), "ok": True, "error": None}


def cloud_status():
    cfg = load_b2_config()
    masked = masked_b2_config(cfg)
    with CLOUD_SYNC._lock:
        last_sync = CLOUD_SYNC.last_sync
        conflict = CLOUD_SYNC.conflict
        last_synced = dict(CLOUD_SYNC.last_synced_sha)
    return {"configured": masked["configured"], "enabled": masked["enabled"],
            "bucket": masked["bucket"], "endpoint": masked["endpoint"],
            "key_id_masked": masked["key_id_masked"],
            "last_sync": last_sync, "conflict": conflict,
            "last_synced": last_synced}


def backup_status_payload():
    state_versions = list_local_versions("state")
    tb_versions = list_local_versions("testbook")
    prog_versions = list_local_versions("programme")
    push_versions = list_local_versions("push")
    all_versions = list_local_versions()
    last = all_versions[0] if all_versions else None
    # v1.11.23 (QA BUG-009): surface preserved corrupt files so a
    # silent auto-recovery is visible in the Backup tab / API instead
    # of only in the server console.
    corrupt_files = []
    try:
        for name in sorted(os.listdir(DATA_DIR), reverse=True):
            if ".corrupt-" in name:
                p = os.path.join(DATA_DIR, name)
                if os.path.isfile(p):
                    corrupt_files.append({"file": name,
                                          "size": os.path.getsize(p)})
    except Exception:
        pass
    return {
        "data_dir": DATA_DIR,
        "local": {
            "state_backups": len(state_versions),
            "testbook_backups": len(tb_versions),
            "programme_backups": len(prog_versions),
            "push_backups": len(push_versions),
            "last_backup": last,
            "corrupt_files": corrupt_files,
        },
        "cloud": cloud_status(),
    }



CLOUD_SYNC = CloudSync()
