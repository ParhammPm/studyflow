#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Konkur local site server — Python standard library only, no pip installs.
Run:  python server.py        (or start.bat on Windows)
Then open http://localhost:8765

DATA LIVES OUTSIDE THE APP FOLDER (Layer 0):
  Windows:  %APPDATA%\\KonkurApp\\   (state.json, testbook.json,
            gemini_key.txt, b2_config.json, backups\\)
  Linux:    ~/.local/share/KonkurApp/   macOS: ~/Library/Application Support/KonkurApp/
  Override for tests:  KONKUR_DATA_DIR env var.
  On first run the server MIGRATES any state.json / testbook.json /
  gemini_key.txt found in the app folder into the data dir (move, not copy),
  so extracting a new zip over the old folder can never lose data. The app
  folder itself is replaceable code only — the shipped zip contains NO
  state.json / testbook.json / gemini_key.txt / b2_config.json.

BACKUPS (Layer 1): every save is atomic (temp file + os.replace) and creates
a versioned local backup (backups/<kind>-<ts>-<sha8>.json, ~30 kept per kind,
SHA-256 in backup_meta.json). A missing/corrupt state.json or testbook.json
is auto-restored from the newest VERIFIED backup (local first, then cloud)
before empty defaults are ever served.

CLOUD (Layer 2): Backblaze B2, S3-compatible, pure-stdlib SigV4 (b2.py).
A background thread uploads versioned snapshots + a latest.json manifest.
The cloud layer is DISABLED until B2 credentials are entered in the app's
Backup tab (saved server-side in the data dir, never shipped, never sent to
the browser). On conflict the remote version is kept and the local one is
uploaded as a new version — nothing is ever auto-overwritten.

Endpoints:
  GET  /                -> public/index.html
  GET  /api/health      -> {"ok": true}
  GET  /api/state       -> saved state (ticks, test counts, edits, subjects, theme, daysDone, topicLinks, assignments, examResults)
  POST /api/state       -> save state (atomic + versioned backup + cloud sync request)
  GET  /api/testbook    -> test books (chapters/topics, tests_total, manual_solved)
  POST /api/testbook    -> save test books (atomic + versioned backup + cloud sync request)
  GET  /api/gemini-key  -> {"has_key": bool, "masked": "..."} (never the full key)
  POST /api/gemini-key  -> {"key": "..."} saves the key to gemini_key.txt (server-side only)
  GET  /api/gemini-model -> {"model": "..."} (selected model, default gemini-2.5-flash)
  POST /api/gemini-model -> {"model": "..."} saves the selected model to gemini_model.txt
  GET  /api/gemini-models -> {"models": [...]} lists the models this key can use (generateContent)
  POST /api/gemini      -> {"prompt": "..."} proxies to Gemini with the selected model, returns {"text": "..."}
  GET  /api/backup      -> backup status (data dir, local counts, cloud state)
  GET  /api/backup/list -> local versions + cloud manifest entries
  POST /api/backup/now  -> snapshot both files now + request immediate cloud sync
  POST /api/backup/restore       -> {"kind": "state"|"testbook", "file": "..."} restore a local version
  POST /api/backup/restore-cloud -> {"kind": ..., "key": "..."} restore a cloud version
  GET  /api/backup/b2-config -> masked B2 settings (never secrets)
  POST /api/backup/b2-config -> save B2 settings {endpoint, key_id, application_key, bucket, enabled}
  POST /api/backup/b2-test    -> read-only connection test (list 1 object)
  POST /api/backup/b2-clear   -> delete the stored B2 credentials
  GET  /api/version           -> current app version {version, build_date} (from version.json)
  GET  /data.json            -> merged programme (calendar_data.json) when present, else shipped data.json
  GET  /api/calendar/status  -> masked calendar config + programme stats + sync log
  GET  /api/calendar/config  -> masked calendar config (ICS URL never in full)
  POST /api/calendar/config  -> save {ics_url, interval_minutes, enabled}
  POST /api/calendar/sync    -> fetch the ICS URL now and merge (PULL only)
  POST /api/calendar/import-preview -> dry-run merge of an uploaded .ics/.json file
  POST /api/calendar/import  -> apply the uploaded file's merge (after preview)
  POST /api/calendar/clear   -> remove the calendar config (programme data kept)
  GET  /api/update/status     -> {version, backups:[code-backup metas]} (code backups live in the data dir)
  POST /api/update/upload     -> raw .zip bytes in the body; validate, back up current code, install, restart
  POST /api/update/url        -> {url} download a .zip, then the same install flow
  POST /api/update/rollback   -> {backup?} restore the newest (or named) code backup, then restart
  An update NEVER touches the data dir (state.json, testbook.json, gemini_key.txt,
  gemini_model.txt, b2_config.json) — it only replaces the code/app folder, after
  copying the current code to a versioned backup inside the data dir.
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import zipfile
from datetime import date, datetime, timedelta, timezone
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

try:
    import b2 as b2mod
except Exception:
    b2mod = None

BASE = os.path.dirname(os.path.abspath(__file__))
PUBLIC = os.path.join(BASE, "public")
PORT = 8765
GEMINI_API_BASE = "https://generativelanguage.googleapis.com/v1beta"
DEFAULT_GEMINI_MODEL = "gemini-2.5-flash"

# ---------- Layer 0: data directory (outside the app folder) ----------
APP_STATE_FILE = os.path.join(BASE, "state.json")          # legacy: migration source only
APP_TESTBOOK_FILE = os.path.join(BASE, "testbook.json")    # legacy: migration source only
APP_KEY_FILE = os.path.join(BASE, "gemini_key.txt")        # legacy: migration source only


def resolve_data_dir():
    override = os.environ.get("KONKUR_DATA_DIR")
    if override:
        return override
    appdata = os.environ.get("APPDATA")
    if appdata:
        return os.path.join(appdata, "KonkurApp")
    home = os.path.expanduser("~")
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", "KonkurApp")
    return os.path.join(home, ".local", "share", "KonkurApp")


DATA_DIR = resolve_data_dir()
STATE_FILE = os.path.join(DATA_DIR, "state.json")
TESTBOOK_FILE = os.path.join(DATA_DIR, "testbook.json")
KEY_FILE = os.path.join(DATA_DIR, "gemini_key.txt")
# The selected Gemini model is stored server-side (data dir) and used by /api/gemini.
MODEL_FILE = os.path.join(DATA_DIR, "gemini_model.txt")
B2_CONFIG_FILE = os.path.join(DATA_DIR, "b2_config.json")
BACKUP_DIR = os.path.join(DATA_DIR, "backups")
BACKUP_META_FILE = os.path.join(DATA_DIR, "backup_meta.json")
MAX_BACKUPS_PER_KIND = 30
CLOUD_PREFIX = "konkur-backup/"
CLOUD_MANIFEST_KEY = "latest.json"

DEFAULT_STATE = {
    "done": {},
    "tests": {},
    "tests_total": {},
    "subjects": ["گسسته", "شیمی", "حسابان", "فیزیک", "هندسه", "عربی", "دینی", "ادبیات", "زبان انگلیسی"],
    "theme": "dark",
    "lang": "fa",
    "custom_boxes": [],
    "deleted": [],
    "edits": {},
    "daysDone": {},
    "topicLinks": {},
    "assignments": None,
    "assignmentsRemoved": [],
    # Real study time (v1.8.0): actualMinutes[boxId] = finished seconds
    # (timer stops + manual entries); timerSessions = the session records
    # behind that total; activeTimer = the running/paused session, stored
    # server-side so a restart resumes it honestly from its stored start.
    "actualMinutes": {},
    "timerSessions": [],
    "activeTimer": None,
    # Exams (state.exams): three independent stores {maz, zoodbist, school}.
    # Null = not migrated yet; the app seeds from public/exams.json on first
    # load and folds the old examResults into each exam's result field.
    "exams": None,
    "examsRemoved": [],
    # Exam results (state.examResults): only Maz stage 4 is pre-filled — the
    # user's verified result. Every other exam starts empty. Kept for the
    # migration into state.exams; new results live on the exam objects.
    "examResults": {"maz-4": {"taraz": 7411, "rank": 17664, "rankTotal": 52614,
                              "correct": 17, "wrong": 10, "unanswered": 68, "note": ""}},
}


# ---------- Small helpers ----------
def sha256_bytes(raw):
    return hashlib.sha256(raw).hexdigest()


def now_ts():
    return int(time.time())


def iso_now():
    return datetime.now().astimezone().isoformat(timespec="seconds")


def ensure_data_dir():
    os.makedirs(BACKUP_DIR, exist_ok=True)


def atomic_write(path, raw):
    """Write bytes atomically: temp file in the same dir + os.replace."""
    ensure_data_dir()
    tmp = "{}.{}.tmp".format(path, os.getpid())
    with open(tmp, "wb") as f:
        f.write(raw)
        f.flush()
        try:
            os.fsync(f.fileno())
        except OSError:
            pass
    os.replace(tmp, path)


def atomic_write_json(path, obj):
    atomic_write(path, json.dumps(obj, ensure_ascii=False, indent=2).encode("utf-8"))


def read_json_file(path):
    """Returns (obj or None, error or None)."""
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f), None
    except Exception as exc:
        return None, exc


def valid_state(data):
    return isinstance(data, dict)


def valid_testbook(data):
    return isinstance(data, dict) and isinstance(data.get("books"), list)


def merge_state(data):
    merged = dict(DEFAULT_STATE)
    merged.update(data or {})
    return merged


# ---------- Layer 0: one-time migration out of the app folder ----------
def migrate_legacy_files():
    """Move app-folder data files into the data dir — only when the data-dir
    file does not exist yet. The app folder becomes replaceable code."""
    ensure_data_dir()
    for app_path, data_path in ((APP_STATE_FILE, STATE_FILE),
                                (APP_TESTBOOK_FILE, TESTBOOK_FILE),
                                (APP_KEY_FILE, KEY_FILE)):
        if os.path.exists(data_path) or not os.path.exists(app_path):
            continue
        try:
            if app_path.endswith(".json"):
                data, err = read_json_file(app_path)
                if data is None:
                    print("Migration skipped (unreadable): {}".format(app_path))
                    continue
            shutil.move(app_path, data_path)
            print("Migrated {} -> {}".format(app_path, data_path))
            # Snapshot the migrated file at once, so the pre-migration
            # content is preserved as the first backup version.
            if app_path.endswith(".json"):
                kind = "state" if "state" in os.path.basename(app_path) else "testbook"
                create_backup(kind, force=True)
        except Exception as exc:
            print("Migration failed for {}: {}".format(app_path, exc))


# ---------- Layer 1: versioned local backups ----------
def load_backup_meta():
    data, _ = read_json_file(BACKUP_META_FILE)
    if isinstance(data, dict) and isinstance(data.get("versions"), list):
        return data
    return {"versions": []}


def save_backup_meta(meta):
    try:
        atomic_write_json(BACKUP_META_FILE, meta)
    except Exception as exc:
        print("Could not save backup meta: {}".format(exc))


def list_local_versions(kind=None):
    meta = load_backup_meta()
    versions = meta.get("versions", [])
    if kind:
        versions = [v for v in versions if v.get("kind") == kind]
    return sorted(versions, key=lambda v: v.get("ts", 0), reverse=True)


def verify_backup_entry(entry):
    """Verify one backup version: file exists, SHA-256 matches, JSON parses,
    schema is valid. Returns the parsed data or None."""
    if not entry or not entry.get("file"):
        return None
    path = os.path.join(BACKUP_DIR, entry["file"])
    if not os.path.exists(path):
        return None
    try:
        with open(path, "rb") as f:
            raw = f.read()
    except Exception:
        return None
    if sha256_bytes(raw) != entry.get("sha256"):
        return None
    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception:
        return None
    if entry.get("kind") == "state" and not valid_state(data):
        return None
    if entry.get("kind") == "testbook" and not valid_testbook(data):
        return None
    if entry.get("kind") == "programme" and not (
            isinstance(data, dict) and isinstance(data.get("boxes"), list)):
        return None
    return data


def create_backup(kind, force=False):
    """Snapshot the current data file into backups/. Skips when the content
    is identical to the newest backup of that kind (unless force=True).
    Returns the version entry or None."""
    src = {"state": STATE_FILE, "testbook": TESTBOOK_FILE,
           "programme": CALENDAR_DATA_FILE}.get(kind, STATE_FILE)
    if not os.path.exists(src):
        return None
    try:
        with open(src, "rb") as f:
            raw = f.read()
    except Exception as exc:
        print("Backup failed (read {}): {}".format(src, exc))
        return None
    digest = sha256_bytes(raw)
    meta = load_backup_meta()
    existing = [v for v in meta.get("versions", []) if v.get("kind") == kind]
    existing.sort(key=lambda v: v.get("ts", 0), reverse=True)
    if not force and existing and existing[0].get("sha256") == digest:
        return existing[0]
    ts = now_ts()
    fname = "{}-{}-{}.json".format(
        kind, datetime.fromtimestamp(ts).strftime("%Y%m%d-%H%M%S"), digest[:8])
    try:
        atomic_write(os.path.join(BACKUP_DIR, fname), raw)
    except Exception as exc:
        print("Backup failed (write {}): {}".format(fname, exc))
        return None
    entry = {"kind": kind, "file": fname, "ts": ts, "ts_iso": iso_now(),
             "sha256": digest, "size": len(raw), "source": "local"}
    versions = [entry] + [v for v in meta.get("versions", []) if v != entry]
    # Prune to MAX_BACKUPS_PER_KIND per kind (oldest first), deleting files.
    kept = []
    counts = {}
    for v in versions:
        k = v.get("kind")
        counts[k] = counts.get(k, 0) + 1
        if counts[k] <= MAX_BACKUPS_PER_KIND:
            kept.append(v)
        else:
            try:
                os.remove(os.path.join(BACKUP_DIR, v["file"]))
            except Exception:
                pass
    meta["versions"] = kept
    save_backup_meta(meta)
    return entry


def newest_verified_backup(kind):
    for entry in list_local_versions(kind):
        data = verify_backup_entry(entry)
        if data is not None:
            return entry, data
    return None, None


# ---------- Layer 2: Backblaze B2 cloud sync ----------
def load_b2_config():
    data, _ = read_json_file(B2_CONFIG_FILE)
    if isinstance(data, dict):
        return data
    return None


def save_b2_config(cfg):
    atomic_write_json(B2_CONFIG_FILE, cfg)


def masked_b2_config(cfg):
    if not cfg:
        return {"configured": False, "enabled": False, "bucket": None,
                "endpoint": None, "key_id_masked": ""}
    kid = str(cfg.get("key_id") or "")
    return {"configured": bool(cfg.get("key_id") and cfg.get("application_key")),
            "enabled": bool(cfg.get("enabled")),
            "bucket": cfg.get("bucket") or "konkur-backup",
            "endpoint": cfg.get("endpoint") or b2mod.DEFAULT_ENDPOINT if b2mod else None,
            "key_id_masked": (kid[:4] + "••••" + kid[-2:]) if len(kid) > 6 else "••••"}


def cloud_restore_latest(kind):
    """Last-resort restore: download the newest cloud snapshot for `kind`,
    verify SHA-256 + JSON + schema. Returns parsed data or None."""
    if not b2mod:
        return None
    cfg = load_b2_config()
    if not cfg or not cfg.get("enabled"):
        return None
    try:
        client = b2mod.B2Client(cfg)
        manifest = client.get_json(CLOUD_MANIFEST_KEY)
        if not manifest or kind not in manifest:
            return None
        entry = manifest[kind]
        raw = client.get_object(entry["key"])
        if sha256_bytes(raw) != entry.get("sha256"):
            print("Cloud restore rejected: SHA mismatch for {}".format(entry["key"]))
            return None
        data = json.loads(raw.decode("utf-8"))
        if kind == "state" and not valid_state(data):
            return None
        if kind == "testbook" and not valid_testbook(data):
            return None
        print("Restored {} from cloud snapshot {}".format(kind, entry["key"]))
        return data
    except Exception as exc:
        print("Cloud restore failed: {}".format(exc))
        return None


class CloudSync:
    """Background sync thread: uploads versioned snapshots + latest.json
    manifest to B2. Never overwrites a newer remote version — on conflict it
    keeps BOTH and records the conflict for the UI to resolve."""

    def __init__(self):
        self._event = threading.Event()
        self._immediate = threading.Event()
        self._lock = threading.Lock()
        self.last_sync = None          # {"ts", "ts_iso", "ok", "error"}
        self.last_synced_sha = {"state": None, "testbook": None}
        self.conflict = None           # {"kind", "remote_ts", "remote_key", "remote_sha256"}

    def request(self, immediate=False):
        self._event.set()
        if immediate:
            self._immediate.set()

    def run(self):
        while True:
            self._event.wait(timeout=60)
            self._event.clear()
            if self._immediate.is_set():
                self._immediate.clear()
            else:
                # Debounce: wait a little in case more saves arrive.
                time.sleep(15)
            try:
                self.sync_once()
            except Exception as exc:
                with self._lock:
                    self.last_sync = {"ts": now_ts(), "ts_iso": iso_now(),
                                      "ok": False, "error": str(exc)}
                print("Cloud sync error: {}".format(exc))

    def sync_once(self):
        if not b2mod:
            return
        cfg = load_b2_config()
        if not cfg or not cfg.get("enabled"):
            return
        client = b2mod.B2Client(cfg)
        try:
            manifest = client.get_json(CLOUD_MANIFEST_KEY) or {}
        except Exception as exc:
            raise b2mod.B2Error("Could not read cloud manifest: {}".format(exc))
        changed = False
        for kind, path in (("state", STATE_FILE), ("testbook", TESTBOOK_FILE),
                           ("programme", CALENDAR_DATA_FILE)):
            if not os.path.exists(path):
                continue
            with open(path, "rb") as f:
                raw = f.read()
            digest = sha256_bytes(raw)
            if self.last_synced_sha.get(kind) == digest:
                continue
            remote = manifest.get(kind) or {}
            if remote.get("sha256") and remote.get("sha256") != digest:
                # Remote holds different content. If it is NEWER than the
                # local file, do not overwrite it — record the conflict and
                # keep both versions; the user resolves it in the UI.
                if remote.get("ts", 0) > int(os.path.getmtime(path)):
                    with self._lock:
                        self.conflict = {"kind": kind,
                                         "remote_ts": remote.get("ts"),
                                         "remote_key": remote.get("key"),
                                         "remote_sha256": remote.get("sha256")}
                    print("Cloud sync conflict on {}: remote is newer, keeping both".format(kind))
                    continue
            ts = now_ts()
            key = "{}-{}-{}.json".format(
                kind, datetime.fromtimestamp(ts).strftime("%Y%m%d-%H%M%S"), digest[:8])
            client.put_object(CLOUD_PREFIX + key, raw, "application/json")
            manifest[kind] = {"key": CLOUD_PREFIX + key, "sha256": digest, "ts": ts}
            manifest["updated_ts"] = ts
            changed = True
            with self._lock:
                self.last_synced_sha[kind] = digest
            if self.conflict and self.conflict.get("kind") == kind:
                with self._lock:
                    self.conflict = None
        if changed:
            client.put_object(CLOUD_MANIFEST_KEY,
                              json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8"),
                              "application/json")
        with self._lock:
            self.last_sync = {"ts": now_ts(), "ts_iso": iso_now(), "ok": True, "error": None}


CLOUD_SYNC = CloudSync()


def cloud_status():
    cfg = load_b2_config()
    masked = masked_b2_config(cfg)
    with CLOUD_SYNC._lock:
        last_sync = CLOUD_SYNC.last_sync
        conflict = CLOUD_SYNC.conflict
        last_synced = dict(CLOUD_SYNC.last_synced_sha)
    return {"configured": masked["configured"], "enabled": masked["enabled"],
            "bucket": masked["bucket"], "endpoint": masked["endpoint"],
            "key_id_masked": masked["key_id_masked"],
            "last_sync": last_sync, "conflict": conflict,
            "last_synced": last_synced}


# ---------- State / testbook load & save (with auto-restore) ----------
def load_testbook():
    data, _ = read_json_file(TESTBOOK_FILE)
    if data is not None and valid_testbook(data):
        return data
    if data is not None:
        print("testbook.json is corrupt — restoring from backup")
    entry, backup = newest_verified_backup("testbook")
    if backup is not None:
        atomic_write_json(TESTBOOK_FILE, backup)
        print("Restored testbook.json from backup {}".format(entry["file"]))
        return backup
    data, _ = read_json_file(APP_TESTBOOK_FILE)
    if data is not None and valid_testbook(data):
        atomic_write_json(TESTBOOK_FILE, data)
        return data
    data = cloud_restore_latest("testbook")
    if data is not None:
        atomic_write_json(TESTBOOK_FILE, data)
        return data
    return {"books": []}


def save_testbook(data):
    atomic_write_json(TESTBOOK_FILE, data)
    create_backup("testbook")
    CLOUD_SYNC.request()
    return data


def load_state():
    data, _ = read_json_file(STATE_FILE)
    if data is not None and valid_state(data):
        return merge_state(data)
    if data is not None:
        print("state.json is corrupt — restoring from backup")
    entry, backup = newest_verified_backup("state")
    if backup is not None:
        atomic_write_json(STATE_FILE, backup)
        print("Restored state.json from backup {}".format(entry["file"]))
        return merge_state(backup)
    data, _ = read_json_file(APP_STATE_FILE)
    if data is not None and valid_state(data):
        atomic_write_json(STATE_FILE, data)
        return merge_state(data)
    data = cloud_restore_latest("state")
    if data is not None:
        atomic_write_json(STATE_FILE, data)
        return merge_state(data)
    return dict(DEFAULT_STATE)


def save_state(data):
    merged = merge_state(data)
    atomic_write_json(STATE_FILE, merged)
    create_backup("state")
    CLOUD_SYNC.request()
    return merged


def read_key():
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE, encoding="utf-8") as f:
            return f.read().strip()
    return ""


# Gemini model names are used inside a URL path, so only the characters
# Google allows in a model id may pass (letters, digits, dot, dash, _).
MODEL_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$")


def read_model():
    if os.path.exists(MODEL_FILE):
        try:
            with open(MODEL_FILE, encoding="utf-8") as f:
                m = f.read().strip()
            if MODEL_RE.match(m):
                return m
        except Exception:
            pass
    return DEFAULT_GEMINI_MODEL


def valid_model(name):
    return bool(name) and bool(MODEL_RE.match(name))


def masked_key(key):
    if not key:
        return ""
    if len(key) <= 8:
        return "••••••••"
    return key[:4] + "••••••••" + key[-4:]


# ---------- Gemini request core (shared by /api/gemini and /api/gemini-test) ----------
# The stored key is NEVER logged and NEVER returned to the browser; only the
# masked form (first/last 4 chars) ever leaves the server. Error messages from
# Google do not contain the key.
TEST_PROMPT = "Reply with exactly this word: OK"
TEST_MAX_TOKENS = 8


def _gemini_request(model, prompt, timeout=60, max_tokens=None):
    """One generateContent call with the stored key.

    Returns a dict: {"ok", "text", "kind", "code", "message"}.
    kind is None on success, else one of: auth | rate_limit | not_found |
    network | model | unknown. "message" is the exact upstream error text
    (or a local message for network/empty-response failures).
    """
    key = read_key()
    if not key:
        return {"ok": False, "text": "", "kind": "auth", "code": None,
                "message": "کلید API جمینای معتبر نیست"}
    body = {"contents": [{"parts": [{"text": prompt}]}]}
    if max_tokens:
        body["generationConfig"] = {"maxOutputTokens": max_tokens}
    payload = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        GEMINI_API_BASE + "/models/" + model + ":generateContent?key=" + key,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            result = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail_msg = ""
        try:
            detail = json.loads(exc.read().decode("utf-8", "replace"))
            detail_msg = str(((detail.get("error") or {}).get("message") or "")).strip()
        except Exception:
            pass
        if exc.code in (400, 401, 403):
            kind = "auth"
        elif exc.code == 404:
            kind = "not_found"
        elif exc.code == 429:
            kind = "rate_limit"
        elif exc.code >= 500:
            kind = "model"
        else:
            kind = "unknown"
        if not detail_msg:
            detail_msg = "خطای سرور جمینای: HTTP " + str(exc.code)
        return {"ok": False, "text": "", "kind": kind, "code": exc.code,
                "message": detail_msg}
    except Exception as exc:
        return {"ok": False, "text": "", "kind": "network", "code": None,
                "message": "ارتباط با جمینای برقرار نشد: " + str(exc)}
    parts = result.get("candidates", [{}])[0].get("content", {}).get("parts", [])
    text = "".join(p.get("text", "") for p in parts).strip()
    if not text:
        return {"ok": False, "text": "", "kind": "model", "code": None,
                "message": "جمینای پاسخی نداد"}
    return {"ok": True, "text": text, "kind": None, "code": None, "message": ""}


def backup_status_payload():
    state_versions = list_local_versions("state")
    tb_versions = list_local_versions("testbook")
    prog_versions = list_local_versions("programme")
    all_versions = list_local_versions()
    last = all_versions[0] if all_versions else None
    return {
        "data_dir": DATA_DIR,
        "local": {
            "state_backups": len(state_versions),
            "testbook_backups": len(tb_versions),
            "programme_backups": len(prog_versions),
            "last_backup": last,
        },
        "cloud": cloud_status(),
    }


# ---------- In-app self-update (Part 5) ----------
# The app folder holds ONLY code. User data (state.json, testbook.json,
# gemini_key.txt, gemini_model.txt, b2_config.json) lives in the data dir and
# is never touched by an update. Before every install the current code folder
# is copied to a versioned backup inside the data dir, so a bad update can be
# rolled back from the UI.
VERSION_FILE = os.path.join(BASE, "version.json")
CODE_BACKUP_DIR = os.path.join(DATA_DIR, "code-backups")
UPDATE_STAGING_DIR = os.path.join(DATA_DIR, "update-staging")
MAX_UPDATE_ZIP_BYTES = 50 * 1024 * 1024
MAX_CODE_BACKUPS = 3
UPDATE_REQUIRED = ("server.py", "public/index.html", "public/app.js")
# Data files that must never be overwritten or deleted inside the app folder,
# even if an update zip (or an old install) contains them there.
PROTECTED_APP_FILES = ("state.json", "testbook.json", "gemini_key.txt",
                       "gemini_model.txt", "b2_config.json")


def read_version():
    data, _ = read_json_file(VERSION_FILE)
    if isinstance(data, dict) and data.get("version"):
        return {"version": str(data["version"]),
                "build_date": str(data.get("build_date") or "")}
    return {"version": "dev", "build_date": ""}


def validate_update_zip(path):
    """Returns (version_dict, error_str). error_str is None when valid."""
    if not os.path.exists(path) or not zipfile.is_zipfile(path):
        return None, "فایل zip معتبر نیست"
    try:
        with zipfile.ZipFile(path) as zf:
            names = zf.namelist()
            for n in names:
                parts = n.replace("\\", "/").split("/")
                if n.startswith("/") or n.startswith("\\") or ".." in parts \
                        or (len(n) > 1 and n[1] == ":"):
                    return None, "فایل zip مسیرهای غیرمجاز دارد"
            missing = [r for r in UPDATE_REQUIRED if r not in names]
            if missing:
                return None, "این فایل zip کامل نیست — کم دارد: " + ", ".join(missing)
            if zf.testzip() is not None:
                return None, "فایل zip خراب است"
            version = {"version": "dev", "build_date": ""}
            if "version.json" in names:
                try:
                    v = json.loads(zf.read("version.json").decode("utf-8"))
                    if isinstance(v, dict) and v.get("version"):
                        version = {"version": str(v["version"]),
                                   "build_date": str(v.get("build_date") or "")}
                except Exception:
                    pass
            return version, None
    except Exception as exc:
        return None, "خواندن فایل zip ممکن نشد: " + str(exc)


def _wipe_app_folder():
    """Delete everything in the app folder except protected data files.
    Missing-file errors are ignored (a running server.py may be locked on
    Windows — extraction overwrites it anyway)."""
    for entry in os.listdir(BASE):
        if entry in PROTECTED_APP_FILES:
            continue
        p = os.path.join(BASE, entry)
        try:
            if os.path.isdir(p):
                shutil.rmtree(p, ignore_errors=True)
            else:
                os.remove(p)
        except Exception:
            pass


def _verify_app_tree():
    return [r for r in UPDATE_REQUIRED
            if not os.path.exists(os.path.join(BASE, r))]


def create_code_backup():
    ensure_data_dir()
    os.makedirs(CODE_BACKUP_DIR, exist_ok=True)
    v = read_version()
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    safe_v = re.sub(r"[^A-Za-z0-9._-]+", "_", v["version"]) or "dev"
    name = "code-backup-{}-{}".format(ts, safe_v)
    dest = os.path.join(CODE_BACKUP_DIR, name)
    # Two installs in the same second with the same version must not collide.
    n = 2
    while os.path.exists(dest):
        name = "code-backup-{}-{}-{}".format(ts, safe_v, n)
        dest = os.path.join(CODE_BACKUP_DIR, name)
        n += 1

    def _ignore(d, names):
        return [n for n in names if n == "__pycache__" or n.endswith(".pyc")]

    shutil.copytree(BASE, dest, ignore=_ignore)
    meta = {"name": name, "version": v["version"], "build_date": v["build_date"],
            "ts": now_ts(), "ts_iso": iso_now()}
    try:
        with open(os.path.join(dest, "code-backup-meta.json"),
                  "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)
    except Exception:
        pass
    prune_code_backups()
    return meta


def list_code_backups():
    if not os.path.isdir(CODE_BACKUP_DIR):
        return []
    out = []
    for name in sorted(os.listdir(CODE_BACKUP_DIR), reverse=True):
        p = os.path.join(CODE_BACKUP_DIR, name)
        if not os.path.isdir(p):
            continue
        meta = None
        try:
            with open(os.path.join(p, "code-backup-meta.json"),
                      encoding="utf-8") as f:
                meta = json.load(f)
        except Exception:
            pass
        out.append(meta if isinstance(meta, dict) and meta.get("name")
                   else {"name": name, "version": "?", "build_date": "",
                         "ts": 0, "ts_iso": ""})
    return out


def prune_code_backups():
    for b in list_code_backups()[MAX_CODE_BACKUPS:]:
        shutil.rmtree(os.path.join(CODE_BACKUP_DIR, b["name"]),
                      ignore_errors=True)


def restore_code_backup(name):
    """Copy a code backup over the app folder. Returns (ok, error_str)."""
    src = os.path.join(CODE_BACKUP_DIR, name)
    if not os.path.isdir(src):
        return False, "پشتیبان کد پیدا نشد"
    _wipe_app_folder()

    def _ignore(d, names):
        return [n for n in names if n == "code-backup-meta.json"]

    try:
        shutil.copytree(src, BASE, dirs_exist_ok=True, ignore=_ignore)
    except Exception as exc:
        return False, "بازگردانی ممکن نشد: " + str(exc)
    missing = _verify_app_tree()
    if missing:
        return False, "پس از بازگشت، این فایل‌ها پیدا نشدند: " + ", ".join(missing)
    return True, None


def install_update_zip(zip_path):
    """Validate, back up current code, extract over the app folder.
    Returns (new_version_dict, backup_meta, error_str). On any failure
    after the wipe, the code backup is restored immediately — the server
    is never left half-installed and never restarts into a broken tree."""
    version, err = validate_update_zip(zip_path)
    if err:
        return None, None, err
    ensure_data_dir()
    # Legacy data files still sitting in the app folder (pre-backup builds):
    # move them to the data dir first so the wipe cannot touch them.
    for fname in PROTECTED_APP_FILES:
        app_path = os.path.join(BASE, fname)
        data_path = os.path.join(DATA_DIR, fname)
        if os.path.exists(app_path) and not os.path.exists(data_path):
            try:
                shutil.move(app_path, data_path)
            except Exception:
                pass
    backup = None
    try:
        backup = create_code_backup()
    except Exception as exc:
        return None, None, "ساخت پشتیبان کد ممکن نشد: " + str(exc)
    try:
        _wipe_app_folder()
        with zipfile.ZipFile(zip_path) as zf:
            for info in zf.infolist():
                if info.is_dir():
                    continue
                parts = info.filename.replace("\\", "/").split("/")
                if "__pycache__" in parts:
                    continue
                if len(parts) == 1 and parts[0] in PROTECTED_APP_FILES:
                    continue  # never extract a data file into the app folder
                zf.extract(info, BASE)
    except Exception as exc:
        restore_code_backup(backup["name"])
        return None, backup, "نصب ناتمام ماند و نسخه‌ی قبل برگردانده شد: " + str(exc)
    missing = _verify_app_tree()
    if missing:
        restore_code_backup(backup["name"])
        return None, backup, "پس از استخراج، این فایل‌ها پیدا نشدند: " + ", ".join(missing)
    return version, backup, None


def schedule_restart():
    """Spawn a detached helper that waits for this process to exit, then
    re-launches the server (same interpreter, same data dir via the
    inherited environment). The current process exits ~1s later, after the
    HTTP response has reached the browser."""
    ensure_data_dir()
    py = sys.executable or "python"
    if sys.platform == "win32":
        helper = os.path.join(DATA_DIR, "restart-helper.bat")
        content = ("@echo off\r\n"
                   "timeout /t 3 /nobreak >nul\r\n"
                   "cd /d \"" + BASE + "\"\r\n"
                   "start \"\" /min \"" + py + "\" -u server.py\r\n")
        try:
            with open(helper, "w", encoding="utf-8", newline="") as f:
                f.write(content)
            subprocess.Popen(
                ["cmd", "/c", helper],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                creationflags=getattr(subprocess, "DETACHED_PROCESS", 0)
                | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
                close_fds=True)
        except Exception as exc:
            print("Restart helper failed: {}".format(exc))
            return
    else:
        helper = os.path.join(DATA_DIR, "restart-helper.sh")
        log_path = os.path.join(DATA_DIR, "server.log")
        content = ("#!/bin/sh\nsleep 3\ncd \"" + BASE + "\"\n"
                   "nohup \"" + py + "\" -u server.py >> \"" + log_path + "\" 2>&1 &\n")
        try:
            with open(helper, "w", encoding="utf-8") as f:
                f.write(content)
            os.chmod(helper, 0o755)
            subprocess.Popen(["/bin/sh", helper],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             stdin=subprocess.DEVNULL, start_new_session=True,
                             close_fds=True)
        except Exception as exc:
            print("Restart helper failed: {}".format(exc))
            return

    def _exit_later():
        time.sleep(1)
        os._exit(0)

    threading.Thread(target=_exit_later, daemon=True).start()


# ---------- Calendar sync (Part A, v1.8.0) ----------
# PULL-ONLY Google Calendar sync. The merged programme lives in the DATA DIR
# (calendar_data.json), never in the shipped data.json, because the app folder
# is replaceable code (self-update wipes it). The shipped data.json stays the
# seed: the first sync matches its 318 boxes to feed events and persists the
# UID -> boxId mapping, so later syncs are stable. App edits never push back
# to Google Calendar in this version (that needs an OAuth client the user
# creates himself) — the UI says so plainly.
#
# Sources (all parsed server-side, stdlib only):
#   * Auto sync: the private ICS ("Secret address in iCal format") the user
#     pastes once. Fetched on demand, on server start, and on a schedule.
#   * Manual import: an uploaded .ics file, or a JSON export in the Google
#     Calendar API shape ({items: [...]} — the shape the programme was built
#     from) or a plain array of {date, start, end, title} events. Works
#     offline, with no ICS URL configured.
# Both paths run the SAME merge (merge_calendar_events). Imports first run a
# dry-run preview; applying needs a second, explicit call.
#
# Merge rules (never lose his work):
#   * New event -> new box, fresh id continuing after the highest bNNN,
#     tests_total 0, subject/topic/is_test derived from the title.
#   * Moved/renamed event -> the matching box gets the new date/time/title,
#     but state is NEVER touched (done, tests, tests_total, edits, notes,
#     daysDone all live in state.json and the merge never writes there).
#   * Cancelled/missing event -> the box is removed ONLY if it was never
#     touched in the app (no tick, no tests, no edit, no tests_total). A
#     touched box is kept and unlinked instead. Removals are scoped to the
#     feed's own date span, so a partial export (e.g. 23 Nov-18 Dec) can
#     never delete boxes outside its range. For file imports, mere absence
#     never removes (the file may be partial) — only events the file marks
#     cancelled do; the live sync (the feed IS the whole calendar) also
#     removes events that disappeared from the feed.
#   * A box the user deleted in the app (state.deleted) tombstones its UID:
#     the event is never recreated by a later sync, and the UID stays in
#     tombstone_uids in the data dir. An app-edited box keeps its own title
#     (only its date/time follow the calendar) and is never removed.
# Every applied sync appends a summary + decision lines to the sync log
# (calendar_config.json, last 100 entries).
TEHRAN = timezone(timedelta(hours=3, minutes=30))
CALENDAR_CONFIG_FILE = os.path.join(DATA_DIR, "calendar_config.json")
CALENDAR_DATA_FILE = os.path.join(DATA_DIR, "calendar_data.json")
CALENDAR_LOG_MAX = 100
CALENDAR_FETCH_TIMEOUT = 25
CALENDAR_MAX_BYTES = 5 * 1024 * 1024
SLEEP_MARKER = "گوشی رو بذار کنار"
KNOWN_SUBJECTS = ["تحلیل آزمون", "مرور دفترچه خطا", "مرور و جمع‌بندی آزمون",
                  "جلسه مشاور درسی", "زبان انگلیسی", "حسابان", "شیمی", "فیزیک",
                  "هندسه", "گسسته", "عربی", "دینی", "ادبیات", "آزمون"]


def _split_outside_parens(text):
    """Last ': ' outside any parentheses, or None (so '(پارت ۲: …)' never
    splits a topic but 'دیدن جلسه: §۸' does)."""
    depth = 0
    last = None
    i = 0
    while i < len(text) - 1:
        ch = text[i]
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth = max(0, depth - 1)
        elif ch == ":" and text[i + 1] == " " and depth == 0:
            last = i
        i += 1
    return last


def clean_event_title(title):
    t = (title or "").strip()
    t = re.sub(r"\s*\(مفید:[^)]*\)\s*$", "", t)
    t = re.sub(r"\s*\(انجام شد\)\s*$", "", t)
    return t.strip()


def derive_subject_topic(title):
    """Subject/topic for a calendar summary, matching how the shipped 318
    boxes were derived from their summaries (verified against data.json:
    'X: rest' -> subject X; 'X — rest' -> subject X; 'کلاس X …' and
    'X آفلاین پایه' -> subject X with the full cleaned title as topic;
    'X دهم/دوازدهم (آزمون) — rest' -> subject X, topic rest)."""
    t = clean_event_title(title)
    if not t:
        return ("", "")
    # 'تست آزمون ۷: <rest>' / 'تست آزمون ۲ (هفته ۳): <rest>' — the original
    # build stripped that planning prefix: topic is the whole remainder,
    # subject is derived from the remainder ('آزمون' when it names none).
    m = re.match(r"^تست آزمون\s*\d*\s*(\([^)]*\))?\s*:\s*(.+)$", t)
    if m:
        rest = m.group(2).strip()
        s2, _ = derive_subject_topic(rest)
        return (rest if s2 == rest else s2, rest) if s2 != rest else ("آزمون", rest)
    for special in ("مرور دفترچه خطا", "جلسه مشاور درسی", "مرور و جمع‌بندی آزمون"):
        if t == special:
            return (special, t)
        if t.startswith(special + " — "):
            return (special, t.split(" — ", 1)[1].strip())
        if t.startswith(special + " "):
            return (special, t)
    if t.startswith("تحلیل آزمون"):
        if " — " in t:
            return ("تحلیل آزمون", t.split(" — ", 1)[1].strip())
        return ("تحلیل آزمون", t)
    if t.startswith("آزمون"):
        return ("آزمون", t)
    if ":" in t:
        left, right = t.split(":", 1)
        if left.strip() in KNOWN_SUBJECTS:
            return (left.strip(), right.strip())
    if " — " in t:
        left, right = t.split(" — ", 1)
        left = left.strip()
        right = right.strip()
        if left in KNOWN_SUBJECTS:
            ci = _split_outside_parens(right)
            return (left, right[ci + 2:] if ci is not None else right)
        # 'کلاس [زنده|آفلاین] <subject> … — <rest>' -> topic is
        # 'کلاس <subject> — <rest>' with a trailing parenthetical dropped.
        mc = re.match(r"^کلاس\s+(?:زنده|آفلاین)?\s*"
                      r"(حسابان|شیمی|فیزیک|هندسه|گسسته|عربی|دینی|ادبیات|زبان انگلیسی)\b", left)
        if mc:
            r2 = re.sub(r"\s*\([^)]*\)\s*$", "", right).strip()
            return (mc.group(1), "کلاس " + mc.group(1) + (" — " + r2 if r2 else ""))
        for s in KNOWN_SUBJECTS:
            if s in left:
                # Left is only the subject + grade words / a parenthetical
                # qualifier (e.g. 'هندسه دوازدهم', 'حسابان (آزمون)',
                # 'هندسه دوازدهم و دهم (تکلیف و آزمون)') -> topic = right.
                rest = left.replace(s, "", 1).strip()
                if re.fullmatch(r"((دهم|یازدهم|دوازدهم)(\s+و\s+(دهم|یازدهم|دوازدهم))?)?"
                                r"\s*(\([^)]*\))?", rest):
                    ci = _split_outside_parens(right)
                    return (s, right[ci + 2:] if ci is not None else right)
                return (s, t)
    # 'کلاس [زنده|آفلاین] <subject> …' -> topic is 'کلاس <subject>'.
    m = re.match(r"^کلاس\s+(?:زنده|آفلاین)?\s*"
                 r"(حسابان|شیمی|فیزیک|هندسه|گسسته|عربی|دینی|ادبیات|زبان انگلیسی)\b", t)
    if m:
        return (m.group(1), "کلاس " + m.group(1))
    for s in KNOWN_SUBJECTS:
        if s in t:
            return (s, t)
    return (t, t)


def event_is_test(title):
    """Test box? The shipped boxes are test boxes when the title carries
    تست / تکلیف / آزمون — except a parenthesised '(آزمون)' qualifier, a
    'بدون تکلیف' class, or the 'کلاس جبرانی … + آزمون + دوره' class.
    (Checked against all 318 shipped boxes: 0 mismatches.)"""
    t = clean_event_title(title)
    # A parenthetical qualifier naming an exam ('(آزمون)',
    # '(پارت ۵: آزمون ۱ ساعته)') does not make the box a test box — but
    # '(آمادگی آزمون)' (preparation FOR an exam) and '(تست آزمون)' do count.
    def _strip_qualifier(m):
        inner = m.group(1)
        if "آزمون" in inner and "تست" not in inner and "آمادگی" not in inner:
            return ""
        return m.group(0)
    t2 = re.sub(r"\(([^)]*)\)", _strip_qualifier, t)
    if "بدون تکلیف" in t or t.startswith("کلاس جبرانی") \
            or t.startswith("مرور و جمع‌بندی آزمون"):
        return False
    return bool(re.search(r"تست|تکلیف|آزمون", t2))


# ---------- ICS parsing (stdlib only) ----------
def _ics_unfold(text):
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    out = []
    for ln in lines:
        if ln[:1] in (" ", "\t") and out:
            out[-1] += ln[1:]
        else:
            out.append(ln)
    return out


def _ics_split(line):
    """'DTSTART;TZID=Asia/Tehran:20261124T090000' -> ({'TZID': ...}, value)."""
    if ":" not in line:
        return {}, line
    head, value = line.split(":", 1)
    parts = head.split(";")
    params = {}
    for p in parts[1:]:
        if "=" in p:
            k, v = p.split("=", 1)
            params[k.strip().upper()] = v.strip()
    return params, value.strip()


def _parse_ics_dt(value, params):
    """Returns (aware datetime in Tehran, is_all_day) or (None, False)."""
    value = (value or "").strip()
    if not value:
        return None, False
    if params.get("VALUE", "").upper() == "DATE" or re.match(r"^\d{8}$", value):
        try:
            d = datetime.strptime(value[:8], "%Y%m%d").date()
        except Exception:
            return None, False
        return datetime(d.year, d.month, d.day, tzinfo=TEHRAN), True
    m = re.match(r"^(\d{8})T(\d{6})(Z)?$", value)
    if not m:
        try:
            dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=TEHRAN)
            return dt.astimezone(TEHRAN), False
        except Exception:
            return None, False
    base = datetime.strptime(m.group(1) + m.group(2), "%Y%m%d%H%M%S")
    if m.group(3) == "Z":
        return base.replace(tzinfo=timezone.utc).astimezone(TEHRAN), False
    tzid = (params.get("TZID") or "").upper()
    if tzid in ("UTC", "GMT", "ETC/UTC"):
        return base.replace(tzinfo=timezone.utc).astimezone(TEHRAN), False
    # TZID=Asia/Tehran, or a floating time: both read as Tehran local.
    return base.replace(tzinfo=TEHRAN), False


def _parse_rrule(value):
    out = {}
    for part in (value or "").split(";"):
        if "=" in part:
            k, v = part.split("=", 1)
            out[k.strip().upper()] = v.strip()
    return out


def _expand_rrule(start_dt, end_dt, rrule, exdates, range_start, range_end):
    """Expand one recurring master into (start, end) instances inside the
    date range. Day-by-day walk: simple, and correct for DAILY / WEEKLY /
    MONTHLY / YEARLY with INTERVAL, COUNT, UNTIL, BYDAY and EXDATE."""
    freq = (rrule.get("FREQ") or "").upper()
    if freq not in ("DAILY", "WEEKLY", "MONTHLY", "YEARLY"):
        return [(start_dt, end_dt)]
    try:
        interval = max(1, int(rrule.get("INTERVAL") or 1))
    except Exception:
        interval = 1
    count = None
    try:
        if rrule.get("COUNT"):
            count = int(rrule["COUNT"])
    except Exception:
        count = None
    until_date = None
    if rrule.get("UNTIL"):
        u, _ = _parse_ics_dt(rrule["UNTIL"], {})
        if u is not None:
            until_date = u.date()
    byday = None
    if rrule.get("BYDAY"):
        days = {"MO": 0, "TU": 1, "WE": 2, "TH": 3, "FR": 4, "SA": 5, "SU": 6}
        byday = sorted(days[d] for d in rrule["BYDAY"].split(",") if d in days)
    duration = end_dt - start_dt
    start_date = start_dt.date()
    ex = set()
    for e in exdates or []:
        ex.add(e.date() if hasattr(e, "date") else e)
        if hasattr(e, "hour"):
            ex.add(e)
    out = []
    made = 0
    d = max(start_date, range_start)
    while d <= range_end:
        if until_date and d > until_date:
            break
        if count is not None and made >= count:
            break
        ok = False
        delta_days = (d - start_date).days
        if freq == "DAILY":
            ok = delta_days % interval == 0
        elif freq == "WEEKLY":
            wanted = byday if byday else [start_dt.weekday()]
            ok = d.weekday() in wanted and (delta_days // 7) % interval == 0
        elif freq == "MONTHLY":
            months = (d.year - start_date.year) * 12 + (d.month - start_date.month)
            ok = d.day == start_date.day and months % interval == 0
        elif freq == "YEARLY":
            ok = (d.month == start_date.month and d.day == start_date.day
                  and (d.year - start_date.year) % interval == 0)
        if ok:
            inst_start = datetime(d.year, d.month, d.day, start_dt.hour,
                                  start_dt.minute, start_dt.second, tzinfo=TEHRAN)
            if inst_start not in ex and d not in ex:
                out.append((inst_start, inst_start + duration))
                made += 1
            elif count is not None:
                made += 1
        d += timedelta(days=1)
    return out


def parse_ics(text):
    """Parse ICS text into raw events: {uid, title, start_dt, end_dt,
    status, all_day}. Recurring masters are expanded into instances
    (uid suffixed with the instance start); a cancelled master cancels
    all its instances."""
    raw = []
    cur = None
    for ln in _ics_unfold(text or ""):
        line = ln.strip()
        if line == "BEGIN:VEVENT":
            cur = {"props": []}
        elif line == "END:VEVENT" and cur is not None:
            props = {}
            for name, params, value in cur["props"]:
                props.setdefault(name, []).append((params, value))
            uid = ""
            for params, value in props.get("UID", []):
                uid = value
                break
            title = ""
            for params, value in props.get("SUMMARY", []):
                title = value
                break
            status = "confirmed"
            for params, value in props.get("STATUS", []):
                status = value.strip().lower()
                break
            s_dt, s_all = None, False
            e_dt = None
            for params, value in props.get("DTSTART", []):
                s_dt, s_all = _parse_ics_dt(value, params)
                break
            for params, value in props.get("DTEND", []):
                e_dt, _ = _parse_ics_dt(value, params)
                break
            if uid and title and s_dt is not None:
                if e_dt is None:
                    e_dt = s_dt + timedelta(hours=1)
                exdates = []
                for params, value in props.get("EXDATE", []):
                    for piece in value.split(","):
                        ed, _ = _parse_ics_dt(piece.strip(), params)
                        if ed is not None:
                            exdates.append(ed)
                rrules = [v for _, v in props.get("RRULE", [])]
                if rrules:
                    rng = _programme_range()
                    for inst_s, inst_e in _expand_rrule(
                            s_dt, e_dt, _parse_rrule(rrules[0]), exdates,
                            rng[0], rng[1]):
                        raw.append({"uid": uid + "#" + inst_s.strftime("%Y%m%dT%H%M"),
                                    "title": title, "start_dt": inst_s,
                                    "end_dt": inst_e, "status": status,
                                    "all_day": s_all})
                else:
                    raw.append({"uid": uid, "title": title, "start_dt": s_dt,
                                "end_dt": e_dt, "status": status,
                                "all_day": s_all})
            cur = None
        elif cur is not None and ":" in line:
            name = line.split(":", 1)[0].split(";", 1)[0].strip().upper()
            params, value = _ics_split(line)
            cur["props"].append((name, params, value))
    return raw


# ---------- JSON export parsing ----------
def _iso_to_tehran(value):
    """ISO datetime (with offset, Z, or floating) -> Tehran datetime."""
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except Exception:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=TEHRAN)
    return dt.astimezone(TEHRAN)


def parse_calendar_json(text):
    """Parse a calendar JSON export into the same raw-event shape as
    parse_ics. Accepts: (a) the Google Calendar API export
    ({items: [{id, iCalUID, summary, start: {dateTime}, end: {dateTime},
    status, recurringEventId}]}); (b) a plain array of events
    ({date, start, end, title}); (c) {boxes: [...]} in the same shape."""
    try:
        data = json.loads(text)
    except Exception as exc:
        raise ValueError("فایل JSON معتبر نیست: {}".format(exc))
    items = None
    if isinstance(data, dict) and isinstance(data.get("items"), list):
        items = data["items"]
    elif isinstance(data, list):
        items = data
    elif isinstance(data, dict) and isinstance(data.get("boxes"), list):
        items = data["boxes"]
    else:
        raise ValueError("ساختار JSON شناخته نشد — باید {items: [...]} یا آرایه‌ای از رویدادها باشد")
    raw = []
    rng = None
    for it in items:
        if not isinstance(it, dict):
            continue
        title = it.get("summary") or it.get("title") or ""
        status = str(it.get("status") or "confirmed").lower()
        uid = it.get("iCalUID") or it.get("uid") or it.get("id") or ""
        if it.get("recurringEventId"):
            uid = str(it.get("id") or uid)  # instances are unique by id
        start = it.get("start")
        end = it.get("end")
        s_dt = e_dt = None
        all_day = False
        if isinstance(start, dict):
            if start.get("dateTime"):
                s_dt = _iso_to_tehran(start["dateTime"])
            elif start.get("date"):
                all_day = True
                try:
                    d = datetime.strptime(start["date"][:10], "%Y-%m-%d").date()
                    s_dt = datetime(d.year, d.month, d.day, tzinfo=TEHRAN)
                except Exception:
                    s_dt = None
        elif isinstance(start, str):
            if "T" in start:
                s_dt = _iso_to_tehran(start)
            elif it.get("date"):
                try:
                    d = datetime.strptime(str(it["date"])[:10], "%Y-%m-%d").date()
                    hh, mm = (start.split(":") + ["0"])[:2]
                    s_dt = datetime(d.year, d.month, d.day, int(hh), int(mm), tzinfo=TEHRAN)
                except Exception:
                    s_dt = None
        if isinstance(end, dict):
            if end.get("dateTime"):
                e_dt = _iso_to_tehran(end["dateTime"])
            elif end.get("date"):
                try:
                    d = datetime.strptime(end["date"][:10], "%Y-%m-%d").date()
                    e_dt = datetime(d.year, d.month, d.day, tzinfo=TEHRAN)
                except Exception:
                    e_dt = None
        elif isinstance(end, str):
            if "T" in end:
                e_dt = _iso_to_tehran(end)
            elif s_dt is not None:
                try:
                    hh, mm = (end.split(":") + ["0"])[:2]
                    e_dt = datetime(s_dt.year, s_dt.month, s_dt.day, int(hh), int(mm), tzinfo=TEHRAN)
                except Exception:
                    e_dt = None
        if not title or s_dt is None:
            continue
        if e_dt is None:
            e_dt = s_dt + timedelta(hours=1)
        if not uid:
            uid = "manual-" + sha256_bytes(
                (s_dt.strftime("%Y-%m-%d %H:%M") + "|" + title).encode("utf-8"))[:12]
        # A Google item carrying its own RRULE (no expanded instances in
        # the file): expand it the same way as an ICS master.
        recurrence = it.get("recurrence") or []
        rrule = None
        for r in recurrence:
            if isinstance(r, str) and r.startswith("RRULE:"):
                rrule = _parse_rrule(r[len("RRULE:"):])
                break
        if rrule:
            if rng is None:
                rng = _programme_range()
            for inst_s, inst_e in _expand_rrule(s_dt, e_dt, rrule, [], rng[0], rng[1]):
                raw.append({"uid": str(uid) + "#" + inst_s.strftime("%Y%m%dT%H%M"),
                            "title": title, "start_dt": inst_s, "end_dt": inst_e,
                            "status": status, "all_day": all_day})
        else:
            raw.append({"uid": str(uid), "title": title, "start_dt": s_dt,
                        "end_dt": e_dt, "status": status, "all_day": all_day})
    return raw


def normalize_events(raw):
    """Raw events -> present events [{uid, title, date, start, end}],
    cancelled uids, and skip counts. Filters the nightly sleep reminder
    and zero-duration events (the same filter the original build used),
    skips all-day events, and dedupes by UID."""
    events = []
    cancelled = set()
    counts = {"skipped_sleep": 0, "skipped_zero": 0, "skipped_allday": 0,
              "cancelled": 0, "duplicates": 0}
    seen = {}
    for ev in raw or []:
        uid = str(ev.get("uid") or "")
        title = (ev.get("title") or "").strip()
        s_dt = ev.get("start_dt")
        e_dt = ev.get("end_dt")
        if not uid or not title or s_dt is None or e_dt is None:
            continue
        if str(ev.get("status") or "").lower() in ("cancelled", "canceled"):
            cancelled.add(uid)
            counts["cancelled"] += 1
            continue
        if SLEEP_MARKER in title:
            counts["skipped_sleep"] += 1
            continue
        if e_dt <= s_dt:
            counts["skipped_zero"] += 1
            continue
        if ev.get("all_day"):
            counts["skipped_allday"] += 1
            continue
        key = uid
        if key in seen and (seen[key]["date"], seen[key]["start"]) != (
                s_dt.strftime("%Y-%m-%d"), s_dt.strftime("%H:%M")):
            key = uid + "#" + s_dt.strftime("%Y%m%dT%H%M")
        if key in seen:
            counts["duplicates"] += 1
            continue
        item = {"uid": key, "title": title, "date": s_dt.strftime("%Y-%m-%d"),
                "start": s_dt.strftime("%H:%M"), "end": e_dt.strftime("%H:%M")}
        seen[key] = item
        events.append(item)
    events.sort(key=lambda e: (e["date"], e["start"], e["title"]))
    return events, cancelled, counts


# ---------- Programme store (data dir) ----------
def _programme_range():
    """(first, last) programme dates, for recurring-event expansion."""
    data, _ = read_json_file(CALENDAR_DATA_FILE)
    boxes = []
    if isinstance(data, dict) and isinstance(data.get("boxes"), list):
        boxes = data["boxes"]
    else:
        shipped, _ = read_json_file(os.path.join(BASE, "data.json"))
        if isinstance(shipped, dict) and isinstance(shipped.get("boxes"), list):
            boxes = shipped["boxes"]
    if boxes:
        dates = sorted(b["date"] for b in boxes if b.get("date"))
        if dates:
            return (datetime.strptime(dates[0], "%Y-%m-%d").date(),
                    datetime.strptime(dates[-1], "%Y-%m-%d").date())
    today = datetime.now(tz=TEHRAN).date()
    return (today, today + timedelta(days=180))


def load_programme():
    data, _ = read_json_file(CALENDAR_DATA_FILE)
    if isinstance(data, dict) and isinstance(data.get("boxes"), list):
        data.setdefault("uid_map", {})
        data.setdefault("tombstone_uids", [])
        data.setdefault("tombstone_box_ids", [])
        data.setdefault("meta", {})
        return data
    entry, backup = newest_verified_backup("programme")
    if backup is not None:
        atomic_write_json(CALENDAR_DATA_FILE, backup)
        print("Restored calendar programme from backup {}".format(entry["file"]))
        return backup
    shipped, _ = read_json_file(os.path.join(BASE, "data.json"))
    if isinstance(shipped, dict) and isinstance(shipped.get("boxes"), list):
        return {"meta": dict(shipped.get("meta") or {}),
                "boxes": shipped["boxes"], "uid_map": {},
                "tombstone_uids": [], "tombstone_box_ids": []}
    return {"meta": {}, "boxes": [], "uid_map": {},
            "tombstone_uids": [], "tombstone_box_ids": []}


def save_programme(prog):
    atomic_write_json(CALENDAR_DATA_FILE, prog)
    create_backup("programme")
    CLOUD_SYNC.request()
    return prog


def _box_touched(state, box_id):
    """Was this box ever touched in the app? (tick, tests, edit, total)."""
    if (state.get("done") or {}).get(box_id):
        return True
    tr = (state.get("tests") or {}).get(box_id) or {}
    if (tr.get("completed") or 0) > 0:
        return True
    if box_id in (state.get("edits") or {}):
        return True
    if box_id in (state.get("tests_total") or {}):
        return True
    return False


def merge_calendar_events(events, cancelled_uids, source_label, apply=True,
                          remove_missing=True):
    """The single merge used by auto sync AND manual import. With
    apply=False it is a dry run (preview): nothing is written, no log.
    remove_missing: True for the live auto/manual sync (the ICS feed IS
    the whole calendar, so an absent event was deleted in Google);
    False for file imports (a file may be a partial export — there only
    events explicitly marked cancelled in the file remove boxes).
    Returns a summary dict with counts and capped title lists."""
    prog = load_programme()
    boxes = prog["boxes"]
    uid_map = dict(prog.get("uid_map") or {})
    tomb_uids = set(prog.get("tombstone_uids") or [])
    tomb_box = set(prog.get("tombstone_box_ids") or [])
    state = load_state()
    deleted = set(state.get("deleted") or [])
    edits = state.get("edits") or {}
    # Boxes deleted in the app tombstone their UID: never resurrected.
    for uid, bid in list(uid_map.items()):
        if bid in deleted:
            tomb_uids.add(uid)
            tomb_box.add(bid)
            del uid_map[uid]
    tomb_box |= deleted
    by_id = {b["id"]: b for b in boxes}
    dates = sorted({e["date"] for e in events})
    span = (dates[0], dates[-1]) if dates else (None, None)
    log = []
    added, updated, removed = [], [], []
    skipped_tomb = 0
    kept_touched = 0
    next_num = 318
    for b in boxes:
        m = re.match(r"^b(\d+)$", b.get("id") or "")
        if m:
            next_num = max(next_num, int(m.group(1)))

    def find_unmapped(date, start, title):
        for b in boxes:
            if b["id"] in deleted or b["id"] in uid_map.values():
                continue
            if b["date"] == date and b["start"] == start and b["title"] == title:
                return b
        return None

    def find_deleted_match(date, start, title):
        # A box the user already deleted in the app: match it ONLY to
        # tombstone the UID — its event must never be recreated as a new box.
        for b in boxes:
            if b["id"] in deleted and b["date"] == date \
                    and b["start"] == start and b["title"] == title:
                return b
        return None

    seen_uids = set()
    for ev in events:
        uid = ev["uid"]
        seen_uids.add(uid)
        if uid in tomb_uids:
            skipped_tomb += 1
            log.append("رد شد (حذف‌شده در برنامه): {}".format(ev["title"]))
            continue
        bid = uid_map.get(uid)
        box = by_id.get(bid) if bid else None
        if bid and box is None:
            del uid_map[uid]
            bid = None
        if box is None:
            dm = find_deleted_match(ev["date"], ev["start"], ev["title"])
            if dm is not None:
                tomb_uids.add(uid)
                tomb_box.add(dm["id"])
                skipped_tomb += 1
                log.append("رد شد (حذف‌شده در برنامه): {}".format(ev["title"]))
                continue
            m = find_unmapped(ev["date"], ev["start"], ev["title"])
            if m:
                uid_map[uid] = m["id"]
                box = m
                bid = m["id"]
                log.append("تطبیق اول: {} -> {}".format(ev["title"], bid))
        if box is not None:
            if bid in deleted:
                tomb_uids.add(uid)
                uid_map.pop(uid, None)
                skipped_tomb += 1
                log.append("رد شد (حذف‌شده در برنامه): {}".format(ev["title"]))
                continue
            subj, topic = derive_subject_topic(ev["title"])
            changes = {}
            if box.get("date") != ev["date"]:
                changes["date"] = ev["date"]
            if box.get("start") != ev["start"]:
                changes["start"] = ev["start"]
            if box.get("end") != ev["end"]:
                changes["end"] = ev["end"]
            if box.get("title") != ev["title"]:
                changes["title"] = ev["title"]
            if changes:
                edited_here = bid in edits
                if edited_here and "title" in changes:
                    # The user's own title wins; only the schedule follows
                    # the calendar for an app-edited box.
                    log.append("عنوانِ ویرایش‌شده در برنامه حفظ شد: {}".format(box.get("title")))
                    del changes["title"]
                if not changes:
                    continue
                for k, v in changes.items():
                    box[k] = v
                if "title" in changes:
                    box["subject"] = subj
                    box["topic"] = topic
                    box["is_test"] = event_is_test(ev["title"])
                updated.append(ev["title"])
                log.append("به‌روز شد: {} ({})".format(ev["title"], bid))
            continue
        # Brand-new event -> brand-new box.
        next_num += 1
        nid = "b{}".format(next_num)
        subj, topic = derive_subject_topic(ev["title"])
        nb = {"id": nid, "date": ev["date"], "start": ev["start"],
              "end": ev["end"], "subject": subj, "topic": topic,
              "title": ev["title"], "is_test": event_is_test(ev["title"]),
              "tests_total": 0, "note": ""}
        boxes.append(nb)
        by_id[nid] = nb
        uid_map[uid] = nid
        added.append(ev["title"])
        log.append("اضافه شد: {} ({})".format(ev["title"], nid))
    # Removals: mapped UIDs absent from the feed, scoped to the feed's
    # own date span (a partial export never deletes outside its range).
    # With remove_missing=False (file imports) only events the file marks
    # cancelled are removal candidates — mere absence means nothing there.
    for uid, bid in list(uid_map.items()):
        if uid in seen_uids:
            continue
        if not remove_missing and uid not in (cancelled_uids or set()):
            continue
        box = by_id.get(bid)
        if box is None:
            del uid_map[uid]
            continue
        if span[0] and not (span[0] <= box.get("date", "") <= span[1]):
            continue
        if bid in deleted:
            tomb_uids.add(uid)
            del uid_map[uid]
            continue
        if _box_touched(state, bid):
            del uid_map[uid]  # orphan: keep the box, drop the link
            kept_touched += 1
            log.append("حفظ شد (در برنامه لمس شده): {} ({})".format(box.get("title"), bid))
            continue
        boxes.remove(box)
        del by_id[bid]
        del uid_map[uid]
        removed.append(box.get("title") or bid)
        log.append("حذف شد (از تقویم حذف شده): {} ({})".format(box.get("title"), bid))
    summary = {"added": len(added), "updated": len(updated),
               "removed": len(removed), "skipped_tombstone": skipped_tomb,
               "kept_touched": kept_touched,
               "cancelled": len(cancelled_uids or []),
               "span_from": span[0], "span_to": span[1],
               "box_count": len(boxes),
               "added_titles": added[:20], "updated_titles": updated[:20],
               "removed_titles": removed[:20]}
    if apply:
        prog["boxes"] = boxes
        prog["uid_map"] = uid_map
        prog["tombstone_uids"] = sorted(tomb_uids)
        prog["tombstone_box_ids"] = sorted(tomb_box)
        meta = dict(prog.get("meta") or {})
        meta["last_sync"] = iso_now()
        meta["last_source"] = source_label
        prog["meta"] = meta
        save_programme(prog)
        append_calendar_log(source_label, summary, log)
    return summary


# ---------- Calendar config + log ----------
def load_calendar_config():
    data, _ = read_json_file(CALENDAR_CONFIG_FILE)
    if isinstance(data, dict):
        data.setdefault("log", [])
        return data
    return {"ics_url": "", "interval_minutes": 30, "enabled": False,
            "last_sync": None, "last_error": None, "last_summary": None,
            "log": []}


def save_calendar_config(cfg):
    atomic_write_json(CALENDAR_CONFIG_FILE, cfg)


def masked_ics_url(url):
    url = (url or "").strip()
    if not url:
        return ""
    m = re.match(r"^(https?://[^/]+/).*$", url)
    head = m.group(1) if m else ""
    return head + "•••" + url[-8:] if len(url) > 16 else "•••"


def masked_calendar_config(cfg):
    return {"configured": bool((cfg.get("ics_url") or "").strip()),
            "enabled": bool(cfg.get("enabled")),
            "ics_url_masked": masked_ics_url(cfg.get("ics_url") or ""),
            "interval_minutes": int(cfg.get("interval_minutes") or 30),
            "last_sync": cfg.get("last_sync"),
            "last_error": cfg.get("last_error"),
            "last_summary": cfg.get("last_summary")}


def append_calendar_log(source, summary, lines):
    cfg = load_calendar_config()
    log = cfg.get("log") or []
    log.append({"ts": iso_now(), "source": source, "summary": summary,
                "lines": (lines or [])[:60]})
    cfg["log"] = log[-CALENDAR_LOG_MAX:]
    try:
        save_calendar_config(cfg)
    except Exception as exc:
        print("Could not save calendar log: {}".format(exc))


def calendar_status_payload():
    cfg = load_calendar_config()
    prog = load_programme()
    return {"config": masked_calendar_config(cfg),
            "programme": {"box_count": len(prog.get("boxes") or []),
                          "mapped": len(prog.get("uid_map") or {}),
                          "tombstones": len(prog.get("tombstone_uids") or []),
                          "last_source": (prog.get("meta") or {}).get("last_source")},
            "log": (cfg.get("log") or [])[-20:]}


# ---------- ICS fetch + sync runs ----------
def fetch_ics(url):
    req = urllib.request.Request(
        url, headers={"User-Agent": "KonkurApp-CalendarSync/1.8"}, method="GET")
    with urllib.request.urlopen(req, timeout=CALENDAR_FETCH_TIMEOUT) as resp:
        raw = resp.read(CALENDAR_MAX_BYTES + 1)
    if len(raw) > CALENDAR_MAX_BYTES:
        raise ValueError("فایل ICS خیلی بزرگ است")
    return raw.decode("utf-8", "replace")


def run_calendar_sync(source_label):
    """Fetch the configured ICS URL and merge it. On any failure the last
    good programme is kept untouched and the error is recorded."""
    cfg = load_calendar_config()
    url = (cfg.get("ics_url") or "").strip()
    if not url:
        return {"ok": False, "error": "آدرس ICS تنظیم نشده است"}
    try:
        text = fetch_ics(url)
    except Exception as exc:
        err = "دریافت ICS ممکن نشد: {}".format(exc)
        cfg["last_error"] = err
        save_calendar_config(cfg)
        append_calendar_log(source_label, {"added": 0, "updated": 0, "removed": 0,
                                           "error": err}, [err])
        return {"ok": False, "error": err}
    try:
        raw = parse_ics(text)
    except Exception as exc:
        err = "خواندن ICS ممکن نشد: {}".format(exc)
        cfg["last_error"] = err
        save_calendar_config(cfg)
        return {"ok": False, "error": err}
    events, cancelled, counts = normalize_events(raw)
    if not events and not cancelled:
        err = "در فید هیچ رویداد درسی پیدا نشد — داده‌ی قبلی حفظ شد"
        cfg["last_error"] = err
        save_calendar_config(cfg)
        append_calendar_log(source_label, {"added": 0, "updated": 0, "removed": 0,
                                           "error": err}, [err])
        return {"ok": False, "error": err}
    summary = merge_calendar_events(events, cancelled, source_label, apply=True)
    summary["skipped"] = counts
    cfg = load_calendar_config()
    cfg["last_sync"] = iso_now()
    cfg["last_error"] = None
    cfg["last_summary"] = summary
    save_calendar_config(cfg)
    return {"ok": True, "summary": summary, "counts": counts}


def run_calendar_import(content, filename, source_label, apply):
    """Parse uploaded file content (ICS or JSON) and merge it. With
    apply=False this is the preview: nothing is written and nothing is
    logged. Returns (ok, payload)."""
    name = (filename or "").lower()
    text = content or ""
    try:
        if name.endswith(".json") or text.lstrip()[:1] in ("{", "["):
            raw = parse_calendar_json(text)
            fmt = "json"
        else:
            raw = parse_ics(text)
            fmt = "ics"
    except ValueError as exc:
        return False, {"error": str(exc)}
    except Exception as exc:
        return False, {"error": "خواندن فایل ممکن نشد: {}".format(exc)}
    events, cancelled, counts = normalize_events(raw)
    if not events and not cancelled:
        return False, {"error": "در فایل هیچ رویداد درسی پیدا نشد"}
    summary = merge_calendar_events(events, cancelled, source_label, apply=apply,
                                   remove_missing=False)
    summary["skipped"] = counts
    if apply:
        cfg = load_calendar_config()
        cfg["last_sync"] = iso_now()
        cfg["last_error"] = None
        cfg["last_summary"] = summary
        save_calendar_config(cfg)
    return True, {"format": fmt, "summary": summary, "counts": counts}


CAL_SYNC_STATE = {"last_attempt": 0.0}


def calendar_sync_loop():
    """Background thread: auto-sync on the configured interval, plus one
    sync shortly after server start when a URL is configured."""
    time.sleep(5)
    while True:
        try:
            cfg = load_calendar_config()
            if cfg.get("enabled") and (cfg.get("ics_url") or "").strip():
                interval = max(5, int(cfg.get("interval_minutes") or 30)) * 60
                now = time.time()
                if now - CAL_SYNC_STATE["last_attempt"] >= interval:
                    CAL_SYNC_STATE["last_attempt"] = now
                    run_calendar_sync("auto")
        except Exception as exc:
            print("Calendar auto-sync error: {}".format(exc))
        time.sleep(60)



class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=PUBLIC, **kwargs)

    def log_message(self, fmt, *args):
        pass  # keep the console quiet

    def _send_json(self, status, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    def do_GET(self):
        if self.path in ("/api/health", "/api/health/"):
            self._send_json(200, {"ok": True, "port": PORT})
            return
        if self.path in ("/api/state", "/api/state/"):
            self._send_json(200, load_state())
            return
        if self.path in ("/api/testbook", "/api/testbook/"):
            self._send_json(200, load_testbook())
            return
        if self.path in ("/api/gemini-key", "/api/gemini-key/"):
            key = read_key()
            self._send_json(200, {"has_key": bool(key), "masked": masked_key(key)})
            return
        if self.path in ("/api/gemini-model", "/api/gemini-model/"):
            self._send_json(200, {"model": read_model()})
            return
        if self.path in ("/api/gemini-models", "/api/gemini-models/"):
            # Diagnostic for the 404: list the models THIS key can actually use.
            key = read_key()
            if not key:
                self._send_json(400, {"error": "کلید API جمینای معتبر نیست"})
                return
            req = urllib.request.Request(
                GEMINI_API_BASE + "/models?pageSize=100&key=" + key, method="GET")
            try:
                with urllib.request.urlopen(req, timeout=30) as resp:
                    result = json.loads(resp.read().decode("utf-8"))
            except urllib.error.HTTPError as exc:
                if exc.code in (400, 401, 403):
                    self._send_json(400, {"error": "کلید API جمینای معتبر نیست"})
                else:
                    self._send_json(502, {"error": "خطای سرور جمینای: HTTP " + str(exc.code)})
                return
            except Exception as exc:
                self._send_json(502, {"error": "ارتباط با جمینای برقرار نشد: " + str(exc)})
                return
            models = []
            for m in result.get("models", []) or []:
                name = str(m.get("name") or "")
                if name.startswith("models/"):
                    name = name[len("models/"):]
                methods = m.get("supportedGenerationMethods") or []
                if name and "generateContent" in methods:
                    # Full API metadata: the test panel shows the exact id,
                    # display name, version and context limits from Google.
                    models.append({
                        "id": name,
                        "displayName": str(m.get("displayName") or name),
                        "description": str(m.get("description") or ""),
                        "version": str(m.get("version") or ""),
                        "inputTokenLimit": m.get("inputTokenLimit"),
                        "outputTokenLimit": m.get("outputTokenLimit"),
                        "methods": methods,
                    })
            models.sort(key=lambda x: x["id"])
            self._send_json(200, {"models": models})
            return
        if self.path in ("/api/backup", "/api/backup/"):
            self._send_json(200, backup_status_payload())
            return
        if self.path in ("/api/backup/list", "/api/backup/list/"):
            versions = []
            for v in list_local_versions():
                versions.append(dict(v, verified=verify_backup_entry(v) is not None))
            cloud = None
            cfg = load_b2_config()
            if cfg and cfg.get("enabled") and b2mod:
                try:
                    client = b2mod.B2Client(cfg)
                    manifest = client.get_json(CLOUD_MANIFEST_KEY) or {}
                    cloud = {"manifest": manifest}
                except Exception as exc:
                    cloud = {"error": str(exc)}
            self._send_json(200, {"versions": versions, "cloud": cloud})
            return
        if self.path in ("/api/backup/b2-config", "/api/backup/b2-config/"):
            self._send_json(200, masked_b2_config(load_b2_config()))
            return
        if self.path in ("/api/version", "/api/version/"):
            self._send_json(200, read_version())
            return
        if self.path in ("/api/update/status", "/api/update/status/"):
            self._send_json(200, {"version": read_version(),
                                  "backups": list_code_backups()})
            return
        if self.path in ("/data.json", "/data.json/"):
            try:
                prog, _ = read_json_file(CALENDAR_DATA_FILE)
                if isinstance(prog, dict) and isinstance(prog.get("boxes"), list):
                    self._send_json(200, {"meta": prog.get("meta") or {},
                                          "boxes": prog["boxes"]})
                    return
                with open(os.path.join(BASE, "data.json"), encoding="utf-8") as f:
                    data = json.load(f)
                self._send_json(200, data)
            except Exception as exc:
                self._send_json(500, {"error": str(exc)})
            return
        if self.path in ("/api/calendar/status", "/api/calendar/status/"):
            self._send_json(200, calendar_status_payload())
            return
        if self.path in ("/api/calendar/config", "/api/calendar/config/"):
            self._send_json(200, masked_calendar_config(load_calendar_config()))
            return
        super().do_GET()

    def do_POST(self):
        if self.path in ("/api/state", "/api/state/"):
            data = self._read_json()
            if not data:
                # Never let an empty/unreadable body wipe real data to defaults.
                self._send_json(400, {"error": "empty body"})
                return
            saved = save_state(data)
            self._send_json(200, saved)
            return
        if self.path in ("/api/testbook", "/api/testbook/"):
            data = self._read_json()
            if not data:
                self._send_json(400, {"error": "empty body"})
                return
            saved = save_testbook(data)
            self._send_json(200, saved)
            return
        if self.path in ("/api/gemini-key", "/api/gemini-key/"):
            data = self._read_json()
            key = str(data.get("key") or "").strip()
            if not key:
                self._send_json(400, {"error": "کلید خالی است"})
                return
            atomic_write(KEY_FILE, key.encode("utf-8"))
            self._send_json(200, {"has_key": True, "masked": masked_key(key)})
            return
        if self.path in ("/api/gemini-model", "/api/gemini-model/"):
            data = self._read_json()
            model = str(data.get("model") or "").strip()
            if not valid_model(model):
                self._send_json(400, {"error": "نام مدل معتبر نیست"})
                return
            atomic_write(MODEL_FILE, model.encode("utf-8"))
            self._send_json(200, {"model": model})
            return
        if self.path in ("/api/backup/now", "/api/backup/now/"):
            create_backup("state", force=True)
            create_backup("testbook", force=True)
            create_backup("programme", force=True)
            CLOUD_SYNC.request(immediate=True)
            self._send_json(200, backup_status_payload())
            return
        if self.path in ("/api/backup/restore", "/api/backup/restore/"):
            data = self._read_json()
            kind = data.get("kind")
            fname = data.get("file") or ""
            if kind not in ("state", "testbook", "programme") or "/" in fname or "\\" in fname:
                self._send_json(400, {"error": "bad request"})
                return
            entry = None
            for v in list_local_versions(kind):
                if v.get("file") == fname:
                    entry = v
                    break
            if entry is None:
                self._send_json(404, {"error": "version not found"})
                return
            restored = verify_backup_entry(entry)
            if restored is None:
                self._send_json(400, {"error": "backup failed verification"})
                return
            if kind == "state":
                atomic_write_json(STATE_FILE, restored)
                with CLOUD_SYNC._lock:
                    CLOUD_SYNC.last_synced_sha["state"] = None
            elif kind == "programme":
                atomic_write_json(CALENDAR_DATA_FILE, restored)
                with CLOUD_SYNC._lock:
                    CLOUD_SYNC.last_synced_sha["programme"] = None
            else:
                atomic_write_json(TESTBOOK_FILE, restored)
                with CLOUD_SYNC._lock:
                    CLOUD_SYNC.last_synced_sha["testbook"] = None
            self._send_json(200, {"ok": True, "restored": entry["file"]})
            return
        if self.path in ("/api/backup/resolve-conflict", "/api/backup/resolve-conflict/"):
            # Explicit user choice after a cloud conflict: upload the LOCAL
            # version as the newest cloud snapshot. The remote versioned
            # object is never deleted, so both versions stay in the cloud.
            data = self._read_json()
            kind = data.get("kind")
            if kind not in ("state", "testbook"):
                self._send_json(400, {"error": "bad request"})
                return
            with CLOUD_SYNC._lock:
                if CLOUD_SYNC.conflict and CLOUD_SYNC.conflict.get("kind") == kind:
                    CLOUD_SYNC.conflict = None
                CLOUD_SYNC.last_synced_sha[kind] = None
            # Force the manifest to accept ours next sync: temporarily clear
            # the remote-newer check by uploading now, directly.
            if b2mod:
                cfg = load_b2_config()
                if cfg and cfg.get("enabled"):
                    try:
                        client = b2mod.B2Client(cfg)
                        manifest = client.get_json(CLOUD_MANIFEST_KEY) or {}
                        path = STATE_FILE if kind == "state" else TESTBOOK_FILE
                        with open(path, "rb") as f:
                            raw = f.read()
                        digest = sha256_bytes(raw)
                        ts = now_ts()
                        key = "{}-{}-{}.json".format(
                            kind, datetime.fromtimestamp(ts).strftime("%Y%m%d-%H%M%S"), digest[:8])
                        client.put_object(CLOUD_PREFIX + key, raw, "application/json")
                        manifest[kind] = {"key": CLOUD_PREFIX + key, "sha256": digest, "ts": ts}
                        manifest["updated_ts"] = ts
                        client.put_object(CLOUD_MANIFEST_KEY,
                                          json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8"),
                                          "application/json")
                        with CLOUD_SYNC._lock:
                            CLOUD_SYNC.last_synced_sha[kind] = digest
                            CLOUD_SYNC.last_sync = {"ts": now_ts(), "ts_iso": iso_now(),
                                                  "ok": True, "error": None}
                        self._send_json(200, {"ok": True, "uploaded": key})
                        return
                    except Exception as exc:
                        self._send_json(502, {"error": str(exc)})
                        return
            self._send_json(200, {"ok": True, "uploaded": None})
            return
        if self.path in ("/api/backup/restore-cloud", "/api/backup/restore-cloud/"):
            data = self._read_json()
            kind = data.get("kind")
            key = data.get("key") or ""
            if kind not in ("state", "testbook") or not key.startswith(CLOUD_PREFIX):
                self._send_json(400, {"error": "bad request"})
                return
            if not b2mod:
                self._send_json(500, {"error": "cloud module unavailable"})
                return
            cfg = load_b2_config()
            if not cfg or not cfg.get("enabled"):
                self._send_json(400, {"error": "cloud not configured"})
                return
            try:
                client = b2mod.B2Client(cfg)
                manifest = client.get_json(CLOUD_MANIFEST_KEY) or {}
                entry = manifest.get(kind) or {}
                if entry.get("key") != key:
                    self._send_json(404, {"error": "cloud version not found"})
                    return
                raw = client.get_object(key)
                if sha256_bytes(raw) != entry.get("sha256"):
                    self._send_json(400, {"error": "cloud version failed verification"})
                    return
                parsed = json.loads(raw.decode("utf-8"))
                if kind == "state" and not valid_state(parsed):
                    self._send_json(400, {"error": "cloud version failed verification"})
                    return
                if kind == "testbook" and not valid_testbook(parsed):
                    self._send_json(400, {"error": "cloud version failed verification"})
                    return
                if kind == "state":
                    atomic_write_json(STATE_FILE, parsed)
                else:
                    atomic_write_json(TESTBOOK_FILE, parsed)
                with CLOUD_SYNC._lock:
                    CLOUD_SYNC.last_synced_sha[kind] = None
                    CLOUD_SYNC.conflict = None
                self._send_json(200, {"ok": True, "restored": key})
            except Exception as exc:
                self._send_json(502, {"error": str(exc)})
            return
        if self.path in ("/api/backup/b2-config", "/api/backup/b2-config/"):
            data = self._read_json()
            cfg = load_b2_config() or {}
            endpoint = str(data.get("endpoint") or cfg.get("endpoint") or
                           (b2mod.DEFAULT_ENDPOINT if b2mod else "")).strip()
            endpoint = re.sub(r"^https?://", "", endpoint).strip("/ ")
            key_id = str(data.get("key_id") or "").strip()
            app_key = str(data.get("application_key") or "").strip()
            bucket = str(data.get("bucket") or cfg.get("bucket") or "konkur-backup").strip()
            enabled = bool(data.get("enabled"))
            # Keep existing secrets when the form sends them back masked/empty.
            if not key_id and cfg.get("key_id"):
                key_id = cfg["key_id"]
            if not app_key and cfg.get("application_key"):
                app_key = cfg["application_key"]
            if enabled and (not key_id or not app_key):
                self._send_json(400, {"error": "key_id و application_key لازم است"})
                return
            new_cfg = {"endpoint": endpoint, "key_id": key_id,
                       "application_key": app_key, "bucket": bucket,
                       "enabled": enabled}
            save_b2_config(new_cfg)
            with CLOUD_SYNC._lock:
                CLOUD_SYNC.conflict = None
                CLOUD_SYNC.last_synced_sha = {"state": None, "testbook": None}
            if enabled:
                CLOUD_SYNC.request(immediate=True)
            self._send_json(200, masked_b2_config(new_cfg))
            return
        if self.path in ("/api/backup/b2-test", "/api/backup/b2-test/"):
            if not b2mod:
                self._send_json(500, {"error": "cloud module unavailable"})
                return
            cfg = load_b2_config()
            if not cfg or not cfg.get("key_id"):
                self._send_json(400, {"error": "B2 تنظیم نشده است"})
                return
            try:
                client = b2mod.B2Client(cfg)
                ok, err = client.test_connection()
                self._send_json(200, {"ok": ok, "error": err})
            except Exception as exc:
                self._send_json(200, {"ok": False, "error": str(exc)})
            return
        if self.path in ("/api/backup/b2-clear", "/api/backup/b2-clear/"):
            try:
                if os.path.exists(B2_CONFIG_FILE):
                    os.remove(B2_CONFIG_FILE)
            except Exception:
                pass
            with CLOUD_SYNC._lock:
                CLOUD_SYNC.conflict = None
                CLOUD_SYNC.last_synced_sha = {"state": None, "testbook": None}
            self._send_json(200, {"ok": True})
            return
        if self.path in ("/api/gemini", "/api/gemini/"):
            key = read_key()
            if not key:
                self._send_json(400, {"error": "کلید API جمینای معتبر نیست"})
                return
            data = self._read_json()
            prompt = str(data.get("prompt") or "").strip()
            if not prompt:
                self._send_json(400, {"error": "متن خالی است"})
                return
            r = _gemini_request(read_model(), prompt, timeout=60)
            if not r["ok"]:
                # Response shapes preserved exactly (the client checks for
                # "معتبر نیست" and "HTTP 404" in the error text).
                if r["kind"] == "auth":
                    self._send_json(400, {"error": "کلید API جمینای معتبر نیست"})
                elif r["kind"] == "network":
                    self._send_json(502, {"error": r["message"]})
                elif r["kind"] == "model" and r["code"] is None:
                    self._send_json(502, {"error": "جمینای پاسخی نداد"})
                elif r["code"]:
                    self._send_json(502, {"error": "خطای سرور جمینای: HTTP " + str(r["code"])})
                else:
                    self._send_json(502, {"error": r["message"]})
                return
            self._send_json(200, {"text": r["text"]})
            return
        if self.path in ("/api/gemini-test", "/api/gemini-test/"):
            # Live per-model test: one tiny, cheap request (max 8 output
            # tokens) to the named model with the stored key. Never changes
            # the default selected model. Returns latency + classified error.
            data = self._read_json()
            model = str(data.get("model") or "").strip()
            if not valid_model(model):
                self._send_json(400, {"error": "نام مدل معتبر نیست"})
                return
            t0 = time.time()
            r = _gemini_request(model, TEST_PROMPT, timeout=30,
                                max_tokens=TEST_MAX_TOKENS)
            latency_ms = int(round((time.time() - t0) * 1000))
            self._send_json(200, {
                "ok": r["ok"],
                "model": model,
                "latencyMs": latency_ms,
                "errorKind": r["kind"] or "",
                "errorMessage": "" if r["ok"] else r["message"],
            })
            return
        if self.path in ("/api/update/upload", "/api/update/upload/"):
            # Raw .zip bytes in the body (Content-Type: application/zip).
            length = int(self.headers.get("Content-Length") or 0)
            if length <= 0 or length > MAX_UPDATE_ZIP_BYTES:
                self._send_json(400, {"error": "فایل zip خالی است یا خیلی بزرگ است"})
                return
            ensure_data_dir()
            os.makedirs(UPDATE_STAGING_DIR, exist_ok=True)
            staged = os.path.join(
                UPDATE_STAGING_DIR,
                "update-{}.zip".format(datetime.now().strftime("%Y%m%d-%H%M%S")))
            try:
                with open(staged, "wb") as f:
                    remaining = length
                    while remaining > 0:
                        chunk = self.rfile.read(min(65536, remaining))
                        if not chunk:
                            break
                        f.write(chunk)
                        remaining -= len(chunk)
            except Exception as exc:
                self._send_json(400, {"error": "دریافت فایل ممکن نشد: " + str(exc)})
                return
            version, backup, err = install_update_zip(staged)
            try:
                os.remove(staged)
            except Exception:
                pass
            if err:
                self._send_json(400, {"error": err})
                return
            self._send_json(200, {"ok": True, "version": version, "backup": backup})
            try:
                self.wfile.flush()
            except Exception:
                pass
            schedule_restart()
            return
        if self.path in ("/api/update/url", "/api/update/url/"):
            data = self._read_json()
            url = str(data.get("url") or "").strip()
            if not (url.startswith("http://") or url.startswith("https://")):
                self._send_json(400, {"error": "لینک باید با http:// یا https:// شروع شود"})
                return
            ensure_data_dir()
            os.makedirs(UPDATE_STAGING_DIR, exist_ok=True)
            staged = os.path.join(
                UPDATE_STAGING_DIR,
                "update-{}.zip".format(datetime.now().strftime("%Y%m%d-%H%M%S")))
            try:
                req = urllib.request.Request(url, method="GET",
                                             headers={"User-Agent": "KonkurApp-Updater"})
                with urllib.request.urlopen(req, timeout=60) as resp:
                    total = 0
                    with open(staged, "wb") as f:
                        while True:
                            chunk = resp.read(65536)
                            if not chunk:
                                break
                            total += len(chunk)
                            if total > MAX_UPDATE_ZIP_BYTES:
                                raise ValueError("فایل zip خیلی بزرگ است")
                            f.write(chunk)
            except ValueError as exc:
                self._send_json(400, {"error": str(exc)})
                return
            except Exception as exc:
                self._send_json(502, {"error": "دانلود فایل ممکن نشد: " + str(exc)})
                return
            version, backup, err = install_update_zip(staged)
            try:
                os.remove(staged)
            except Exception:
                pass
            if err:
                self._send_json(400, {"error": err})
                return
            self._send_json(200, {"ok": True, "version": version, "backup": backup})
            try:
                self.wfile.flush()
            except Exception:
                pass
            schedule_restart()
            return
        if self.path in ("/api/update/rollback", "/api/update/rollback/"):
            data = self._read_json()
            backups = list_code_backups()
            name = str(data.get("backup") or "").strip()
            if not name:
                if not backups:
                    self._send_json(400, {"error": "نسخه‌ی قبلی برای بازگشت وجود ندارد"})
                    return
                name = backups[0]["name"]
            ok, err = restore_code_backup(name)
            if not ok:
                self._send_json(400, {"error": err})
                return
            restored = None
            for b in backups:
                if b["name"] == name:
                    restored = b
                    break
            self._send_json(200, {"ok": True, "version": {
                "version": (restored or {}).get("version", "dev"),
                "build_date": (restored or {}).get("build_date", "")},
                "backup": restored})
            try:
                self.wfile.flush()
            except Exception:
                pass
            schedule_restart()
            return
        if self.path in ("/api/calendar/config", "/api/calendar/config/"):
            data = self._read_json()
            cfg = load_calendar_config()
            url = str(data.get("ics_url") or "").strip()
            if url and not (url.startswith("http://") or url.startswith("https://")):
                self._send_json(400, {"error": "آدرس ICS باید با http:// یا https:// شروع شود"})
                return
            try:
                interval = int(data.get("interval_minutes") or cfg.get("interval_minutes") or 30)
            except Exception:
                interval = 30
            interval = max(5, min(1440, interval))
            enabled = bool(data.get("enabled")) if "enabled" in data else bool(cfg.get("enabled"))
            if url:
                cfg["ics_url"] = url
            elif "ics_url" in data:
                cfg["ics_url"] = ""
            cfg["interval_minutes"] = interval
            cfg["enabled"] = enabled and bool(cfg.get("ics_url"))
            save_calendar_config(cfg)
            self._send_json(200, masked_calendar_config(cfg))
            return
        if self.path in ("/api/calendar/sync", "/api/calendar/sync/"):
            result = run_calendar_sync("manual")
            self._send_json(200 if result.get("ok") else 502, result)
            return
        if self.path in ("/api/calendar/import-preview", "/api/calendar/import-preview/"):
            data = self._read_json()
            content = str(data.get("content") or "")
            if not content.strip():
                self._send_json(400, {"error": "فایل خالی است"})
                return
            ok, payload = run_calendar_import(
                content, str(data.get("filename") or ""), "import-preview", apply=False)
            self._send_json(200 if ok else 400, payload)
            return
        if self.path in ("/api/calendar/import", "/api/calendar/import/"):
            data = self._read_json()
            content = str(data.get("content") or "")
            if not content.strip():
                self._send_json(400, {"error": "فایل خالی است"})
                return
            ok, payload = run_calendar_import(
                content, str(data.get("filename") or ""), "import", apply=True)
            self._send_json(200 if ok else 400, payload)
            return
        if self.path in ("/api/calendar/clear", "/api/calendar/clear/"):
            try:
                if os.path.exists(CALENDAR_CONFIG_FILE):
                    os.remove(CALENDAR_CONFIG_FILE)
            except Exception:
                pass
            self._send_json(200, {"ok": True})
            return
        self._send_json(404, {"error": "not found"})


if __name__ == "__main__":
    ensure_data_dir()
    migrate_legacy_files()
    sync_thread = threading.Thread(target=CLOUD_SYNC.run, daemon=True)
    sync_thread.start()
    cal_thread = threading.Thread(target=calendar_sync_loop, daemon=True)
    cal_thread.start()
    # Retry the bind: after a self-update restart the old process may still
    # be releasing the port when the new one starts.
    server = None
    last_exc = None
    for attempt in range(12):
        try:
            server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
            break
        except OSError as exc:
            last_exc = exc
            time.sleep(1)
    if server is None:
        print("Could not bind port {}: {}".format(PORT, last_exc))
        raise SystemExit(1)
    print("Konkur local site running at http://localhost:8765")
    print("Data directory: {}".format(DATA_DIR))
    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
