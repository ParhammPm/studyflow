#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Konkur local site server — Python standard library only, no pip installs.
Run:  python server.py        (or start.bat on Windows)
Then open http://localhost:8765

DATA LIVES OUTSIDE THE APP FOLDER (Layer 0):
  Windows:  %APPDATA%\\KonkurApp\\   (state.json, testbook.json,
            gemini_key.txt, b2_config.json, google_oauth.json,
            google_push_state.json, calendar_config.json,
            calendar_data.json, backups\\)
  Linux:    ~/.local/share/KonkurApp/   macOS: ~/Library/Application Support/KonkurApp/
  Override for tests:  KONKUR_DATA_DIR env var.
  On first run the server MIGRATES any state.json / testbook.json /
  gemini_key.txt found in the app folder into the data dir (move, not copy),
  so extracting a new zip over the old folder can never lose data. The app
  folder itself is replaceable code only — the shipped zip contains NO
  state.json / testbook.json / gemini_key.txt / b2_config.json.

BACKUPS (Layer 1): every save is atomic (temp file + os.replace) and creates
a versioned local backup (backups/<kind>-<ts>-<sha8>.json, ~30 kept per kind,
SHA-256 in backup_meta.json). A missing/corrupt state.json or testbook.json
is auto-restored from the newest VERIFIED backup (local first, then cloud)
before empty defaults are ever served.

CLOUD (Layer 2): Backblaze B2, S3-compatible, pure-stdlib SigV4 (b2.py).
A background thread uploads versioned snapshots + a latest.json manifest.
The cloud layer is DISABLED until B2 credentials are entered in the app's
Backup tab (saved server-side in the data dir, never shipped, never sent to
the browser). On conflict the remote version is kept and the local one is
uploaded as a new version — nothing is ever auto-overwritten.

Endpoints:
  GET  /                -> public/index.html
  GET  /api/health      -> {"ok": true}
  GET  /api/state       -> saved state (ticks, test counts, edits, subjects, theme, daysDone, topicLinks, assignments, examResults)
  POST /api/state       -> save state (atomic + versioned backup + cloud sync request)
  GET  /api/testbook    -> test books (chapters/topics, tests_total, manual_solved)
  POST /api/testbook    -> save test books (atomic + versioned backup + cloud sync request)
  GET  /api/gemini-key  -> {"has_key": bool, "masked": "..."} (never the full key)
  POST /api/gemini-key  -> {"key": "..."} saves the key to gemini_key.txt (server-side only)
  GET  /api/gemini-model -> {"model": "..."} (selected model, default gemini-2.5-flash)
  POST /api/gemini-model -> {"model": "..."} saves the selected model to gemini_model.txt
  GET  /api/gemini-models -> {"models": [...]} lists the models this key can use (generateContent)
  POST /api/gemini      -> {"prompt": "..."} proxies to Gemini with the selected model, returns {"text": "..."}
  GET  /api/backup      -> backup status (data dir, local counts, cloud state)
  GET  /api/backup/list -> local versions + cloud manifest entries
  POST /api/backup/now  -> snapshot both files now + request immediate cloud sync
  POST /api/backup/restore       -> {"kind": "state"|"testbook", "file": "..."} restore a local version
  POST /api/backup/restore-cloud -> {"kind": ..., "key": "..."} restore a cloud version
  GET  /api/backup/b2-config -> masked B2 settings (never secrets)
  POST /api/backup/b2-config -> save B2 settings {endpoint, key_id, application_key, bucket, enabled}
  POST /api/backup/b2-test    -> read-only connection test (list 1 object)
  POST /api/backup/b2-clear   -> delete the stored B2 credentials
  GET  /api/version           -> current app version {version, build_date} (from version.json)
  GET  /data.json            -> merged programme (calendar_data.json) when present, else shipped data.json
  GET  /api/calendar/status  -> masked calendar config + programme stats + sync log + OAuth/push status
  GET  /api/calendar/config  -> masked calendar config (ICS URL never in full)
  POST /api/calendar/config  -> save {ics_url, interval_minutes, enabled}
  POST /api/calendar/sync    -> fetch the ICS URL now and merge (PULL)
  POST /api/calendar/import-preview -> dry-run merge of an uploaded .ics/.json file
  POST /api/calendar/import  -> apply the uploaded file's merge (after preview)
  POST /api/calendar/clear   -> remove the calendar config (programme data kept)
  GET  /api/calendar/oauth/status -> OAuth credentials status (masked) + push status
  POST /api/calendar/oauth/credentials -> save {client_id, client_secret} (server-side only)
  POST /api/calendar/oauth/clear-credentials -> revoke + delete the stored OAuth credentials
  GET  /api/calendar/oauth/auth-url -> the Google sign-in URL (opened by the browser)
  GET  /oauth/callback        -> Google OAuth redirect: exchanges the code, stores tokens
  POST /api/calendar/oauth/disconnect -> revoke the token at Google, clear stored tokens
  POST /api/calendar/push     -> push app-side box changes to Google Calendar now
  GET  /api/calendar/push-status -> pending push count, last push result, conflicts
  GET  /api/boxes            -> effective boxes (programme + edits + custom), sorted by date/time
  POST /api/boxes/create     -> {title, date, start, end, subject?, topic?, note?, is_test?, tests_total?, type?} new custom box
  POST /api/boxes/update     -> {id, title?, subject?, topic?, date?, start?, end?, note?, is_test?, tests_total?, type?} edit/move a box
  POST /api/boxes/delete     -> {id} delete a box (programme or custom -> state.deleted; the push deletes its Google event only if the app created it)
  GET  /api/update/status     -> {version, backups:[code-backup metas]} (code backups live in the data dir)
  POST /api/update/upload     -> raw .zip bytes in the body; validate, back up current code, install, restart
  POST /api/update/url        -> {url} download a .zip, then the same install flow
  POST /api/update/rollback   -> {backup?} restore the newest (or named) code backup, then restart
  GET  /api/update/auto       -> auto-update status: manifest URL, last check result, live install state
  GET  /api/update/auto-progress -> live download/install progress {phase, percent, ...}
  POST /api/update/check      -> fetch the release manifest now and compare (never installs)
  POST /api/update/auto-config -> save {manifest_url} (empty resets to the default)
  POST /api/update/install-auto -> start a background download (SHA-256 verified) + install + restart
  An update NEVER touches the data dir (state.json, testbook.json, gemini_key.txt,
  gemini_model.txt, b2_config.json, google_oauth.json, google_push_state.json,
  calendar_config.json, calendar_data.json) — it only replaces the code/app folder, after
  copying the current code to a versioned backup inside the data dir.
"""
import base64
# (difflib was used only by the v1.11.7 title-similarity matcher, removed in
# v1.11.9 — the merge never links by similarity any more.)
import hashlib
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from datetime import datetime, timedelta, timezone
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
try:
    from zoneinfo import ZoneInfo
except Exception:  # very old Python without zoneinfo
    ZoneInfo = None

try:
    import b2 as b2mod
except Exception:
    b2mod = None

BASE = os.path.dirname(os.path.abspath(__file__))
PUBLIC = os.path.join(BASE, "public")
PORT = 8765
GEMINI_API_BASE = "https://generativelanguage.googleapis.com/v1beta"
DEFAULT_GEMINI_MODEL = "gemini-2.5-flash"

# ---------- Layer 0: data directory (outside the app folder) ----------
APP_STATE_FILE = os.path.join(BASE, "state.json")          # legacy: migration source only
APP_TESTBOOK_FILE = os.path.join(BASE, "testbook.json")    # legacy: migration source only
APP_KEY_FILE = os.path.join(BASE, "gemini_key.txt")        # legacy: migration source only


def resolve_data_dir():
    override = os.environ.get("KONKUR_DATA_DIR")
    if override:
        return override
    appdata = os.environ.get("APPDATA")
    if appdata:
        return os.path.join(appdata, "KonkurApp")
    home = os.path.expanduser("~")
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", "KonkurApp")
    return os.path.join(home, ".local", "share", "KonkurApp")


DATA_DIR = resolve_data_dir()
STATE_FILE = os.path.join(DATA_DIR, "state.json")
TESTBOOK_FILE = os.path.join(DATA_DIR, "testbook.json")
KEY_FILE = os.path.join(DATA_DIR, "gemini_key.txt")
# The selected Gemini model is stored server-side (data dir) and used by /api/gemini.
MODEL_FILE = os.path.join(DATA_DIR, "gemini_model.txt")
B2_CONFIG_FILE = os.path.join(DATA_DIR, "b2_config.json")
BACKUP_DIR = os.path.join(DATA_DIR, "backups")
BACKUP_META_FILE = os.path.join(DATA_DIR, "backup_meta.json")
MAX_BACKUPS_PER_KIND = 30
CLOUD_PREFIX = "konkur-backup/"
CLOUD_MANIFEST_KEY = "latest.json"

DEFAULT_STATE = {
    "done": {},
    "tests": {},
    "tests_total": {},
    "subjects": ["گسسته", "شیمی", "حسابان", "فیزیک", "هندسه", "عربی", "دینی", "ادبیات", "زبان انگلیسی"],
    "theme": "dark",
    "lang": "fa",
    "custom_boxes": [],
    "deleted": [],
    "edits": {},
    # Backlog view (v1.11.7): per-item hidden flags for the overdue list
    # only — hiding a box here never deletes it from the programme,
    # history or review-past; the flag is the only thing stored.
    "backlogHidden": {},
    # Backlog pins (v1.11.9): the user explicitly moved a box to the
    # backlog via its three-dot menu. Pinned boxes show in the backlog
    # view alongside the done past parts (the v1.6.0 rule is unchanged
    # except for explicitly pinned items); the flag is the only thing
    # stored, the box itself is never copied or moved.
    "backlogPinned": {},
    "daysDone": {},
    "topicLinks": {},
    "assignments": None,
    "assignmentsRemoved": [],
    # Real study time (v1.8.0): actualMinutes[boxId] = finished seconds
    # (timer stops + manual entries); timerSessions = the session records
    # behind that total; activeTimer = the running/paused session, stored
    # server-side so a restart resumes it honestly from its stored start.
    "actualMinutes": {},
    "timerSessions": [],
    "activeTimer": None,
    # Exams (state.exams): three independent stores {maz, zoodbist, school}.
    # Null = not migrated yet; the app seeds from public/exams.json on first
    # load and folds the old examResults into each exam's result field.
    "exams": None,
    "examsRemoved": [],
    # Seed exams already offered to the user (by id). ensureExams() only
    # seeds ids NOT in this list, so a Reset (which clears state.exams)
    # does not resurrect the seed exams, while a future version's NEW
    # seed exams still seed on first load.
    "examsSeededIds": [],
    # Exam results (state.examResults): only Maz stage 4 is pre-filled — the
    # user's verified result. Every other exam starts empty. Kept for the
    # migration into state.exams; new results live on the exam objects.
    "examResults": {"maz-4": {"taraz": 7411, "rank": 17664, "rankTotal": 52614,
                              "correct": 17, "wrong": 10, "unanswered": 68, "note": ""}},
}


# ---------- Small helpers ----------
def sha256_bytes(raw):
    return hashlib.sha256(raw).hexdigest()


def now_ts():
    return int(time.time())


def iso_now():
    return datetime.now(tz=TEHRAN).isoformat(timespec="seconds")


def ensure_data_dir():
    os.makedirs(BACKUP_DIR, exist_ok=True)


# One lock for every load-modify-save sequence on server-side data
# (ThreadingHTTPServer serves each request on its own thread). RLock:
# save_state() is called from inside locked sequences (merge, box API),
# so the same thread must be able to re-enter it.
STATE_LOCK = threading.RLock()


def _with_lock(fn):
    """Decorator: run a load-modify-save function under STATE_LOCK."""
    def wrapper(*args, **kwargs):
        with STATE_LOCK:
            return fn(*args, **kwargs)
    wrapper.__name__ = fn.__name__
    return wrapper


def atomic_write(path, raw):
    """Write bytes atomically: unique temp file in the same dir + os.replace.
    The temp name is unique per call (tempfile.mkstemp) — a shared
    '{path}.{pid}.tmp' let two threads write the same temp file and
    corrupt each other's data."""
    ensure_data_dir()
    fd, tmp = tempfile.mkstemp(prefix=".tmp-", dir=os.path.dirname(path) or ".")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(raw)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        try:
            os.chmod(tmp, 0o644)
        except OSError:
            pass
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


def atomic_write_json(path, obj):
    atomic_write(path, json.dumps(obj, ensure_ascii=False, indent=2).encode("utf-8"))


def read_json_file(path):
    """Returns (obj or None, error or None)."""
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f), None
    except Exception as exc:
        return None, exc


def valid_state(data):
    return isinstance(data, dict)


def valid_testbook(data):
    return isinstance(data, dict) and isinstance(data.get("books"), list)


def merge_state(data):
    merged = dict(DEFAULT_STATE)
    merged.update(data or {})
    return merged


# ---------- Layer 0: one-time migration out of the app folder ----------
def migrate_legacy_files():
    """Move app-folder data files into the data dir — only when the data-dir
    file does not exist yet. The app folder becomes replaceable code."""
    ensure_data_dir()
    for app_path, data_path in ((APP_STATE_FILE, STATE_FILE),
                                (APP_TESTBOOK_FILE, TESTBOOK_FILE),
                                (APP_KEY_FILE, KEY_FILE)):
        if os.path.exists(data_path) or not os.path.exists(app_path):
            continue
        try:
            if app_path.endswith(".json"):
                data, err = read_json_file(app_path)
                if data is None:
                    print("Migration skipped (unreadable): {}".format(app_path))
                    continue
            shutil.move(app_path, data_path)
            print("Migrated {} -> {}".format(app_path, data_path))
            # Snapshot the migrated file at once, so the pre-migration
            # content is preserved as the first backup version.
            if app_path.endswith(".json"):
                kind = "state" if "state" in os.path.basename(app_path) else "testbook"
                create_backup(kind, force=True)
        except Exception as exc:
            print("Migration failed for {}: {}".format(app_path, exc))


# ---------- Layer 1: versioned local backups ----------
def load_backup_meta():
    data, _ = read_json_file(BACKUP_META_FILE)
    if isinstance(data, dict) and isinstance(data.get("versions"), list):
        return data
    return {"versions": []}


def save_backup_meta(meta):
    try:
        atomic_write_json(BACKUP_META_FILE, meta)
    except Exception as exc:
        print("Could not save backup meta: {}".format(exc))


def list_local_versions(kind=None):
    meta = load_backup_meta()
    versions = meta.get("versions", [])
    if kind:
        versions = [v for v in versions if v.get("kind") == kind]
    return sorted(versions, key=lambda v: v.get("ts", 0), reverse=True)


def verify_backup_entry(entry):
    """Verify one backup version: file exists, SHA-256 matches, JSON parses,
    schema is valid. Returns the parsed data or None."""
    if not entry or not entry.get("file"):
        return None
    path = os.path.join(BACKUP_DIR, entry["file"])
    if not os.path.exists(path):
        return None
    try:
        with open(path, "rb") as f:
            raw = f.read()
    except Exception:
        return None
    if sha256_bytes(raw) != entry.get("sha256"):
        return None
    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception:
        return None
    if entry.get("kind") == "state" and not valid_state(data):
        return None
    if entry.get("kind") == "testbook" and not valid_testbook(data):
        return None
    if entry.get("kind") == "programme" and not (
            isinstance(data, dict) and isinstance(data.get("boxes"), list)):
        return None
    return data


_VERIFY_BOOL_CACHE = {}


def backup_entry_verified(entry):
    """Cached verified? check for the backup list: backup files are
    immutable (versioned filenames carry their hash), so a (file, sha,
    size) key stays valid. Avoids re-reading + re-hashing + re-parsing
    every backup on every GET /api/backup/list."""
    key = (entry.get("file"), entry.get("sha256"), entry.get("size"))
    if key in _VERIFY_BOOL_CACHE:
        return _VERIFY_BOOL_CACHE[key]
    ok = verify_backup_entry(entry) is not None
    if len(_VERIFY_BOOL_CACHE) > 500:
        _VERIFY_BOOL_CACHE.clear()
    _VERIFY_BOOL_CACHE[key] = ok
    return ok


def create_backup(kind, force=False):
    """Snapshot the current data file into backups/. Skips when the content
    is identical to the newest backup of that kind (unless force=True).
    Returns the version entry or None."""
    src = {"state": STATE_FILE, "testbook": TESTBOOK_FILE,
           "programme": CALENDAR_DATA_FILE}.get(kind, STATE_FILE)
    if not os.path.exists(src):
        return None
    try:
        with open(src, "rb") as f:
            raw = f.read()
    except Exception as exc:
        print("Backup failed (read {}): {}".format(src, exc))
        return None
    digest = sha256_bytes(raw)
    meta = load_backup_meta()
    existing = [v for v in meta.get("versions", []) if v.get("kind") == kind]
    existing.sort(key=lambda v: v.get("ts", 0), reverse=True)
    if not force and existing and existing[0].get("sha256") == digest:
        return existing[0]
    ts = now_ts()
    fname = "{}-{}-{}.json".format(
        kind, datetime.fromtimestamp(ts).strftime("%Y%m%d-%H%M%S"), digest[:8])
    try:
        atomic_write(os.path.join(BACKUP_DIR, fname), raw)
    except Exception as exc:
        print("Backup failed (write {}): {}".format(fname, exc))
        return None
    entry = {"kind": kind, "file": fname, "ts": ts, "ts_iso": iso_now(),
             "sha256": digest, "size": len(raw), "source": "local"}
    versions = [entry] + [v for v in meta.get("versions", []) if v != entry]
    # Prune to MAX_BACKUPS_PER_KIND per kind (oldest first), deleting files.
    kept = []
    counts = {}
    for v in versions:
        k = v.get("kind")
        counts[k] = counts.get(k, 0) + 1
        if counts[k] <= MAX_BACKUPS_PER_KIND:
            kept.append(v)
        else:
            try:
                os.remove(os.path.join(BACKUP_DIR, v["file"]))
            except Exception:
                pass
    meta["versions"] = kept
    save_backup_meta(meta)
    return entry


def newest_verified_backup(kind):
    for entry in list_local_versions(kind):
        data = verify_backup_entry(entry)
        if data is not None:
            return entry, data
    return None, None


# ---------- Layer 2: Backblaze B2 cloud sync ----------
def load_b2_config():
    data, _ = read_json_file(B2_CONFIG_FILE)
    if isinstance(data, dict):
        return data
    return None


def save_b2_config(cfg):
    atomic_write_json(B2_CONFIG_FILE, cfg)


def masked_b2_config(cfg):
    if not cfg:
        return {"configured": False, "enabled": False, "bucket": None,
                "endpoint": None, "key_id_masked": ""}
    kid = str(cfg.get("key_id") or "")
    return {"configured": bool(cfg.get("key_id") and cfg.get("application_key")),
            "enabled": bool(cfg.get("enabled")),
            "bucket": cfg.get("bucket") or "konkur-backup",
            "endpoint": cfg.get("endpoint") or b2mod.DEFAULT_ENDPOINT if b2mod else None,
            "key_id_masked": (kid[:4] + "••••" + kid[-2:]) if len(kid) > 6 else "••••"}


def cloud_restore_latest(kind):
    """Last-resort restore: download the newest cloud snapshot for `kind`,
    verify SHA-256 + JSON + schema. Returns parsed data or None."""
    if not b2mod:
        return None
    cfg = load_b2_config()
    if not cfg or not cfg.get("enabled"):
        return None
    try:
        client = b2mod.B2Client(cfg)
        manifest = client.get_json(CLOUD_MANIFEST_KEY)
        if not manifest or kind not in manifest:
            return None
        entry = manifest[kind]
        raw = client.get_object(entry["key"])
        if sha256_bytes(raw) != entry.get("sha256"):
            print("Cloud restore rejected: SHA mismatch for {}".format(entry["key"]))
            return None
        data = json.loads(raw.decode("utf-8"))
        if kind == "state" and not valid_state(data):
            return None
        if kind == "testbook" and not valid_testbook(data):
            return None
        print("Restored {} from cloud snapshot {}".format(kind, entry["key"]))
        return data
    except Exception as exc:
        print("Cloud restore failed: {}".format(exc))
        return None


class CloudSync:
    """Background sync thread: uploads versioned snapshots + latest.json
    manifest to B2. Never overwrites a newer remote version — on conflict it
    keeps BOTH and records the conflict for the UI to resolve."""

    def __init__(self):
        self._event = threading.Event()
        self._immediate = threading.Event()
        self._lock = threading.Lock()
        self.last_sync = None          # {"ts", "ts_iso", "ok", "error"}
        self.last_synced_sha = {"state": None, "testbook": None,
                                "programme": None}
        self.conflict = None           # {"kind", "remote_ts", "remote_key", "remote_sha256"}

    def request(self, immediate=False):
        self._event.set()
        if immediate:
            self._immediate.set()

    def run(self):
        while True:
            self._event.wait(timeout=60)
            self._event.clear()
            if self._immediate.is_set():
                self._immediate.clear()
            else:
                # Debounce: wait a little in case more saves arrive.
                time.sleep(15)
            try:
                self.sync_once()
            except Exception as exc:
                with self._lock:
                    self.last_sync = {"ts": now_ts(), "ts_iso": iso_now(),
                                      "ok": False, "error": str(exc)}
                print("Cloud sync error: {}".format(exc))

    def sync_once(self):
        if not b2mod:
            return
        cfg = load_b2_config()
        if not cfg or not cfg.get("enabled"):
            return
        client = b2mod.B2Client(cfg)
        try:
            manifest = client.get_json(CLOUD_MANIFEST_KEY) or {}
        except Exception as exc:
            raise b2mod.B2Error("Could not read cloud manifest: {}".format(exc))
        changed = False
        uploaded = {}  # kinds uploaded this run; marked synced only after the manifest lands
        for kind, path in (("state", STATE_FILE), ("testbook", TESTBOOK_FILE),
                           ("programme", CALENDAR_DATA_FILE)):
            if not os.path.exists(path):
                continue
            with open(path, "rb") as f:
                raw = f.read()
            digest = sha256_bytes(raw)
            if self.last_synced_sha.get(kind) == digest:
                continue
            remote = manifest.get(kind) or {}
            if remote.get("sha256") and remote.get("sha256") != digest:
                # Remote holds different content. If it is NEWER than the
                # local file, do not overwrite it — record the conflict and
                # keep both versions; the user resolves it in the UI.
                if remote.get("ts", 0) > int(os.path.getmtime(path)):
                    with self._lock:
                        self.conflict = {"kind": kind,
                                         "remote_ts": remote.get("ts"),
                                         "remote_key": remote.get("key"),
                                         "remote_sha256": remote.get("sha256")}
                    print("Cloud sync conflict on {}: remote is newer, keeping both".format(kind))
                    continue
            ts = now_ts()
            key = "{}-{}-{}.json".format(
                kind, datetime.fromtimestamp(ts).strftime("%Y%m%d-%H%M%S"), digest[:8])
            client.put_object(CLOUD_PREFIX + key, raw, "application/json")
            manifest[kind] = {"key": CLOUD_PREFIX + key, "sha256": digest, "ts": ts}
            manifest["updated_ts"] = ts
            changed = True
            # Record the upload only AFTER the manifest below is written:
            # marking it synced here would orphan the object if the
            # manifest upload then failed (never retried until the
            # content changed again or the server restarted).
            uploaded[kind] = digest
            if self.conflict and self.conflict.get("kind") == kind:
                with self._lock:
                    self.conflict = None
        if changed:
            client.put_object(CLOUD_MANIFEST_KEY,
                              json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8"),
                              "application/json")
            with self._lock:
                for k, d in uploaded.items():
                    self.last_synced_sha[k] = d
        with self._lock:
            self.last_sync = {"ts": now_ts(), "ts_iso": iso_now(), "ok": True, "error": None}


CLOUD_SYNC = CloudSync()


def cloud_status():
    cfg = load_b2_config()
    masked = masked_b2_config(cfg)
    with CLOUD_SYNC._lock:
        last_sync = CLOUD_SYNC.last_sync
        conflict = CLOUD_SYNC.conflict
        last_synced = dict(CLOUD_SYNC.last_synced_sha)
    return {"configured": masked["configured"], "enabled": masked["enabled"],
            "bucket": masked["bucket"], "endpoint": masked["endpoint"],
            "key_id_masked": masked["key_id_masked"],
            "last_sync": last_sync, "conflict": conflict,
            "last_synced": last_synced}


# ---------- State / testbook load & save (with auto-restore) ----------
def load_testbook():
    data, _ = read_json_file(TESTBOOK_FILE)
    if data is not None and valid_testbook(data):
        return data
    if data is not None:
        print("testbook.json is corrupt — restoring from backup")
    entry, backup = newest_verified_backup("testbook")
    if backup is not None:
        atomic_write_json(TESTBOOK_FILE, backup)
        print("Restored testbook.json from backup {}".format(entry["file"]))
        return backup
    data, _ = read_json_file(APP_TESTBOOK_FILE)
    if data is not None and valid_testbook(data):
        atomic_write_json(TESTBOOK_FILE, data)
        return data
    data = cloud_restore_latest("testbook")
    if data is not None:
        atomic_write_json(TESTBOOK_FILE, data)
        return data
    return {"books": []}


def save_testbook(data):
    with STATE_LOCK:
        atomic_write_json(TESTBOOK_FILE, data)
        create_backup("testbook")
        CLOUD_SYNC.request()
    return data


def load_state():
    data, _ = read_json_file(STATE_FILE)
    if data is not None and valid_state(data):
        return merge_state(data)
    if data is not None:
        print("state.json is corrupt — restoring from backup")
    entry, backup = newest_verified_backup("state")
    if backup is not None:
        atomic_write_json(STATE_FILE, backup)
        print("Restored state.json from backup {}".format(entry["file"]))
        return merge_state(backup)
    data, _ = read_json_file(APP_STATE_FILE)
    if data is not None and valid_state(data):
        atomic_write_json(STATE_FILE, data)
        return merge_state(data)
    data = cloud_restore_latest("state")
    if data is not None:
        atomic_write_json(STATE_FILE, data)
        return merge_state(data)
    return dict(DEFAULT_STATE)


def save_state(data):
    with STATE_LOCK:
        merged = merge_state(data)
        atomic_write_json(STATE_FILE, merged)
        create_backup("state")
        CLOUD_SYNC.request()
    return merged


def read_key():
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE, encoding="utf-8") as f:
            return f.read().strip()
    return ""


# Gemini model names are used inside a URL path, so only the characters
# Google allows in a model id may pass (letters, digits, dot, dash, _).
MODEL_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$")


def read_model():
    if os.path.exists(MODEL_FILE):
        try:
            with open(MODEL_FILE, encoding="utf-8") as f:
                m = f.read().strip()
            if MODEL_RE.match(m):
                return m
        except Exception:
            pass
    return DEFAULT_GEMINI_MODEL


def valid_model(name):
    return bool(name) and bool(MODEL_RE.match(name))


def masked_key(key):
    if not key:
        return ""
    if len(key) <= 8:
        return "••••••••"
    return key[:4] + "••••••••" + key[-4:]


# ---------- Gemini request core (shared by /api/gemini and /api/gemini-test) ----------
# The stored key is NEVER logged and NEVER returned to the browser; only the
# masked form (first/last 4 chars) ever leaves the server. Error messages from
# Google do not contain the key.
TEST_PROMPT = "Reply with exactly this word: OK"
TEST_MAX_TOKENS = 8


def _gemini_request(model, prompt, timeout=60, max_tokens=None):
    """One generateContent call with the stored key.

    Returns a dict: {"ok", "text", "kind", "code", "message"}.
    kind is None on success, else one of: auth | rate_limit | not_found |
    network | model | unknown. "message" is the exact upstream error text
    (or a local message for network/empty-response failures).
    """
    key = read_key()
    if not key:
        return {"ok": False, "text": "", "kind": "auth", "code": None,
                "message": "کلید API جمینای معتبر نیست"}
    body = {"contents": [{"parts": [{"text": prompt}]}]}
    if max_tokens:
        body["generationConfig"] = {"maxOutputTokens": max_tokens}
    payload = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        GEMINI_API_BASE + "/models/" + model + ":generateContent?key=" + key,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            result = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail_msg = ""
        try:
            detail = json.loads(exc.read().decode("utf-8", "replace"))
            detail_msg = str(((detail.get("error") or {}).get("message") or "")).strip()
        except Exception:
            pass
        if exc.code in (400, 401, 403):
            kind = "auth"
        elif exc.code == 404:
            kind = "not_found"
        elif exc.code == 429:
            kind = "rate_limit"
        elif exc.code >= 500:
            kind = "model"
        else:
            kind = "unknown"
        if not detail_msg:
            detail_msg = "خطای سرور جمینای: HTTP " + str(exc.code)
        return {"ok": False, "text": "", "kind": kind, "code": exc.code,
                "message": detail_msg}
    except Exception as exc:
        return {"ok": False, "text": "", "kind": "network", "code": None,
                "message": "ارتباط با جمینای برقرار نشد: " + str(exc)}
    cands = result.get("candidates") or [{}]
    parts = cands[0].get("content", {}).get("parts", [])
    text = "".join(p.get("text", "") for p in parts).strip()
    if not text:
        return {"ok": False, "text": "", "kind": "model", "code": None,
                "message": "جمینای پاسخی نداد"}
    return {"ok": True, "text": text, "kind": None, "code": None, "message": ""}


def backup_status_payload():
    state_versions = list_local_versions("state")
    tb_versions = list_local_versions("testbook")
    prog_versions = list_local_versions("programme")
    all_versions = list_local_versions()
    last = all_versions[0] if all_versions else None
    return {
        "data_dir": DATA_DIR,
        "local": {
            "state_backups": len(state_versions),
            "testbook_backups": len(tb_versions),
            "programme_backups": len(prog_versions),
            "last_backup": last,
        },
        "cloud": cloud_status(),
    }


# ---------- In-app self-update (Part 5) ----------
# The app folder holds ONLY code. User data (state.json, testbook.json,
# gemini_key.txt, gemini_model.txt, b2_config.json) lives in the data dir and
# is never touched by an update. Before every install the current code folder
# is copied to a versioned backup inside the data dir, so a bad update can be
# rolled back from the UI.
VERSION_FILE = os.path.join(BASE, "version.json")
CODE_BACKUP_DIR = os.path.join(DATA_DIR, "code-backups")
UPDATE_STAGING_DIR = os.path.join(DATA_DIR, "update-staging")
MAX_UPDATE_ZIP_BYTES = 50 * 1024 * 1024
MAX_CODE_BACKUPS = 3
UPDATE_REQUIRED = ("server.py", "public/index.html", "public/app.js")
# Data files that must never be overwritten or deleted inside the app folder,
# even if an update zip (or an old install) contains them there.
PROTECTED_APP_FILES = ("state.json", "testbook.json", "gemini_key.txt",
                       "gemini_model.txt", "b2_config.json",
                       "google_oauth.json", "google_push_state.json",
                       "calendar_config.json", "calendar_data.json")
# Top-level files/dirs an update must never DELETE. They are NOT in the
# release zip (which only restores code), so wiping them would lose them
# for good. Deliberately separate from PROTECTED_APP_FILES: the pre-wipe
# move loop in install_update_zip() relocates protected files into the
# data dir, where nothing reads data.json (the programme seed the server
# falls back to) or tools/ (the release builder).
KEEP_APP_FILES = ("data.json", "exams.json", "tools")


def read_version():
    data, _ = read_json_file(VERSION_FILE)
    if isinstance(data, dict) and data.get("version"):
        return {"version": str(data["version"]),
                "build_date": str(data.get("build_date") or "")}
    return {"version": "dev", "build_date": ""}


def validate_update_zip(path):
    """Returns (version_dict, error_str). error_str is None when valid."""
    if not os.path.exists(path) or not zipfile.is_zipfile(path):
        return None, "فایل zip معتبر نیست"
    try:
        with zipfile.ZipFile(path) as zf:
            names = zf.namelist()
            for n in names:
                parts = n.replace("\\", "/").split("/")
                if n.startswith("/") or n.startswith("\\") or ".." in parts \
                        or (len(n) > 1 and n[1] == ":"):
                    return None, "فایل zip مسیرهای غیرمجاز دارد"
            missing = [r for r in UPDATE_REQUIRED if r not in names]
            if missing:
                return None, "این فایل zip کامل نیست — کم دارد: " + ", ".join(missing)
            if zf.testzip() is not None:
                return None, "فایل zip خراب است"
            version = {"version": "dev", "build_date": ""}
            if "version.json" in names:
                try:
                    v = json.loads(zf.read("version.json").decode("utf-8"))
                    if isinstance(v, dict) and v.get("version"):
                        version = {"version": str(v["version"]),
                                   "build_date": str(v.get("build_date") or "")}
                except Exception:
                    pass
            return version, None
    except Exception as exc:
        return None, "خواندن فایل zip ممکن نشد: " + str(exc)


def _wipe_app_folder():
    """Delete everything in the app folder except protected data files
    and the KEEP list (data.json seed, tools/). Missing-file errors are
    ignored (a running server.py may be locked on Windows — extraction
    overwrites it anyway)."""
    for entry in os.listdir(BASE):
        if entry in PROTECTED_APP_FILES or entry in KEEP_APP_FILES:
            continue
        p = os.path.join(BASE, entry)
        try:
            if os.path.isdir(p):
                shutil.rmtree(p, ignore_errors=True)
            else:
                os.remove(p)
        except Exception:
            pass


def _verify_app_tree():
    return [r for r in UPDATE_REQUIRED
            if not os.path.exists(os.path.join(BASE, r))]


def create_code_backup():
    ensure_data_dir()
    os.makedirs(CODE_BACKUP_DIR, exist_ok=True)
    v = read_version()
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    safe_v = re.sub(r"[^A-Za-z0-9._-]+", "_", v["version"]) or "dev"
    name = "code-backup-{}-{}".format(ts, safe_v)
    dest = os.path.join(CODE_BACKUP_DIR, name)
    # Two installs in the same second with the same version must not collide.
    n = 2
    while os.path.exists(dest):
        name = "code-backup-{}-{}-{}".format(ts, safe_v, n)
        dest = os.path.join(CODE_BACKUP_DIR, name)
        n += 1

    def _ignore(d, names):
        return [n for n in names if n == "__pycache__" or n.endswith(".pyc")]

    shutil.copytree(BASE, dest, ignore=_ignore)
    meta = {"name": name, "version": v["version"], "build_date": v["build_date"],
            "ts": now_ts(), "ts_iso": iso_now()}
    try:
        with open(os.path.join(dest, "code-backup-meta.json"),
                  "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)
    except Exception:
        pass
    prune_code_backups()
    return meta


def list_code_backups():
    if not os.path.isdir(CODE_BACKUP_DIR):
        return []
    out = []
    for name in sorted(os.listdir(CODE_BACKUP_DIR), reverse=True):
        p = os.path.join(CODE_BACKUP_DIR, name)
        if not os.path.isdir(p):
            continue
        meta = None
        try:
            with open(os.path.join(p, "code-backup-meta.json"),
                      encoding="utf-8") as f:
                meta = json.load(f)
        except Exception:
            pass
        out.append(meta if isinstance(meta, dict) and meta.get("name")
                   else {"name": name, "version": "?", "build_date": "",
                         "ts": 0, "ts_iso": ""})
    return out


def prune_code_backups():
    for b in list_code_backups()[MAX_CODE_BACKUPS:]:
        shutil.rmtree(os.path.join(CODE_BACKUP_DIR, b["name"]),
                      ignore_errors=True)


def restore_code_backup(name):
    """Copy a code backup over the app folder. Returns (ok, error_str)."""
    src = os.path.join(CODE_BACKUP_DIR, name)
    if not os.path.isdir(src):
        return False, "پشتیبان کد پیدا نشد"
    _wipe_app_folder()

    def _ignore(d, names):
        return [n for n in names if n == "code-backup-meta.json"]

    try:
        shutil.copytree(src, BASE, dirs_exist_ok=True, ignore=_ignore)
    except Exception as exc:
        return False, "بازگردانی ممکن نشد: " + str(exc)
    missing = _verify_app_tree()
    if missing:
        return False, "پس از بازگشت، این فایل‌ها پیدا نشدند: " + ", ".join(missing)
    return True, None


def install_update_zip(zip_path):
    """Validate, back up current code, extract over the app folder.
    Returns (new_version_dict, backup_meta, error_str). On any failure
    after the wipe, the code backup is restored immediately — the server
    is never left half-installed and never restarts into a broken tree."""
    version, err = validate_update_zip(zip_path)
    if err:
        return None, None, err
    ensure_data_dir()
    # Legacy data files still sitting in the app folder (pre-backup builds):
    # move them to the data dir first so the wipe cannot touch them.
    for fname in PROTECTED_APP_FILES:
        app_path = os.path.join(BASE, fname)
        data_path = os.path.join(DATA_DIR, fname)
        if os.path.exists(app_path) and not os.path.exists(data_path):
            try:
                shutil.move(app_path, data_path)
            except Exception:
                pass
    backup = None
    try:
        backup = create_code_backup()
    except Exception as exc:
        return None, None, "ساخت پشتیبان کد ممکن نشد: " + str(exc)
    try:
        _wipe_app_folder()
        with zipfile.ZipFile(zip_path) as zf:
            for info in zf.infolist():
                if info.is_dir():
                    continue
                parts = info.filename.replace("\\", "/").split("/")
                if "__pycache__" in parts:
                    continue
                if len(parts) == 1 and parts[0] in PROTECTED_APP_FILES:
                    continue  # never extract a data file into the app folder
                zf.extract(info, BASE)
    except Exception as exc:
        restore_code_backup(backup["name"])
        return None, backup, "نصب ناتمام ماند و نسخه‌ی قبل برگردانده شد: " + str(exc)
    missing = _verify_app_tree()
    if missing:
        restore_code_backup(backup["name"])
        return None, backup, "پس از استخراج، این فایل‌ها پیدا نشدند: " + ", ".join(missing)
    return version, backup, None


def schedule_restart():
    """Spawn a detached helper that waits for this process to exit, then
    re-launches the server (same interpreter, same data dir via the
    inherited environment). The current process exits ~1s later, after the
    HTTP response has reached the browser."""
    ensure_data_dir()
    py = sys.executable or "python"
    if sys.platform == "win32":
        helper = os.path.join(DATA_DIR, "restart-helper.bat")
        content = ("@echo off\r\n"
                   "timeout /t 3 /nobreak >nul\r\n"
                   "cd /d \"" + BASE + "\"\r\n"
                   "start \"\" /min \"" + py + "\" -u server.py\r\n")
        try:
            with open(helper, "w", encoding="utf-8", newline="") as f:
                f.write(content)
            subprocess.Popen(
                ["cmd", "/c", helper],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                creationflags=getattr(subprocess, "DETACHED_PROCESS", 0)
                | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
                close_fds=True)
        except Exception as exc:
            print("Restart helper failed: {}".format(exc))
            return
    else:
        helper = os.path.join(DATA_DIR, "restart-helper.sh")
        log_path = os.path.join(DATA_DIR, "server.log")
        content = ("#!/bin/sh\nsleep 3\ncd \"" + BASE + "\"\n"
                   "nohup \"" + py + "\" -u server.py >> \"" + log_path + "\" 2>&1 &\n")
        try:
            with open(helper, "w", encoding="utf-8") as f:
                f.write(content)
            os.chmod(helper, 0o755)
            subprocess.Popen(["/bin/sh", helper],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             stdin=subprocess.DEVNULL, start_new_session=True,
                             close_fds=True)
        except Exception as exc:
            print("Restart helper failed: {}".format(exc))
            return

    def _exit_later():
        time.sleep(1)
        os._exit(0)

    threading.Thread(target=_exit_later, daemon=True).start()


# ---------- One-click auto-update (v1.10.0) ----------
# The release channel is a public GitHub repo (ParhammPm/studyflow) with a
# manifest (latest.json) at its root:
#   {"version": "1.10.0",
#    "zip_url": "https://raw.githubusercontent.com/ParhammPm/studyflow/main/releases/studyflow-v1.10.0.zip",
#    "sha256": "<hex>", "notes": "...", "min_version": "1.5.0"}
# The app NEVER auto-installs: one check runs shortly after server start and
# only records the result (the Backup tab shows the notice); installing
# always needs the user's click on «دانلود و نصب». The download is streamed
# (<=50 MB), its SHA-256 is verified against the manifest (a mismatch refuses
# the install and leaves the current version untouched), and the install then
# reuses install_update_zip + schedule_restart from Part 5 exactly — the
# manual file-upload and pasted-URL paths stay as fallbacks.
# The manifest URL is configurable (update_config.json in the data dir);
# the default is the StudyFlow repo above.
DEFAULT_MANIFEST_URL = ("https://raw.githubusercontent.com/ParhammPm/"
                        "studyflow/main/latest.json")
UPDATE_CONFIG_FILE = os.path.join(DATA_DIR, "update_config.json")
UPDATE_MANIFEST_TIMEOUT = 15
UPDATE_DOWNLOAD_TIMEOUT = 60


def load_update_config():
    data, _ = read_json_file(UPDATE_CONFIG_FILE)
    if isinstance(data, dict):
        return {"manifest_url": str(data.get("manifest_url") or DEFAULT_MANIFEST_URL),
                "last_check": data.get("last_check"),
                "last_result": data.get("last_result") if isinstance(data.get("last_result"), dict) else None,
                "last_error": data.get("last_error")}
    return {"manifest_url": DEFAULT_MANIFEST_URL, "last_check": None,
            "last_result": None, "last_error": None}


def save_update_config(cfg):
    atomic_write_json(UPDATE_CONFIG_FILE, cfg)


def _version_tuple(v):
    parts = []
    for piece in str(v or "").strip().split("."):
        m = re.match(r"(\d+)", piece)
        parts.append(int(m.group(1)) if m else 0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:4])


def compare_versions(a, b):
    """-1 when a<b, 0 when equal, 1 when a>b (numeric dotted versions)."""
    ta, tb = _version_tuple(a), _version_tuple(b)
    return (ta > tb) - (ta < tb)


def validate_manifest(obj):
    """Returns (manifest_dict, error_str). error_str is None when valid."""
    if not isinstance(obj, dict):
        return None, "مانیفست معتبر نیست — فایل JSON یک آبجکت نیست"
    version = str(obj.get("version") or "").strip()
    if not version:
        return None, "مانیفست نسخه ندارد"
    zip_url = str(obj.get("zip_url") or "").strip()
    # HTTPS only, and the zip must come from the official release channel:
    # an http:// manifest (or a MITM-rewritten one) could otherwise point
    # the updater at an attacker zip with a matching sha256.
    if not zip_url.startswith("https://"):
        return None, "مانیفست لینک zip معتبر ندارد"
    if urllib.parse.urlparse(zip_url).netloc != "raw.githubusercontent.com":
        return None, "مانیفست لینک zip معتبر ندارد"
    sha256 = str(obj.get("sha256") or "").strip().lower()
    if not re.fullmatch(r"[0-9a-f]{64}", sha256):
        return None, "مانیفست هش SHA-256 معتبر ندارد"
    return {"version": version, "zip_url": zip_url, "sha256": sha256,
            "notes": str(obj.get("notes") or ""),
            "min_version": str(obj.get("min_version") or "").strip()}, None


def fetch_manifest(url):
    """Returns (manifest_dict, error_str)."""
    if not str(url or "").strip().startswith("https://"):
        return None, "آدرس مانیفست باید با https:// شروع شود"
    try:
        req = urllib.request.Request(
            url, headers={"User-Agent": "StudyFlow-Updater"}, method="GET")
        with urllib.request.urlopen(req, timeout=UPDATE_MANIFEST_TIMEOUT) as resp:
            raw = resp.read(1024 * 1024)
    except urllib.error.HTTPError as exc:
        return None, "دریافت مانیفست ممکن نشد: HTTP {}".format(exc.code)
    except Exception as exc:
        return None, "دریافت مانیفست ممکن نشد: {}".format(exc)
    try:
        obj = json.loads(raw.decode("utf-8"))
    except Exception:
        return None, "مانیفست خوانده نشد — فایل JSON معتبر نیست"
    return validate_manifest(obj)


def run_update_check():
    """Fetch the manifest, compare with the installed version, remember the
    result. Never installs anything. Returns a result dict."""
    cfg = load_update_config()
    url = (cfg.get("manifest_url") or DEFAULT_MANIFEST_URL).strip()
    manifest, err = fetch_manifest(url)
    now = iso_now()
    if err:
        cfg["last_check"] = now
        cfg["last_error"] = err
        cfg["last_result"] = None
        try:
            save_update_config(cfg)
        except Exception:
            pass
        return {"ok": False, "error": err, "checked_at": now}
    current = read_version()
    available = compare_versions(manifest["version"], current["version"]) > 0
    blocked_min = None
    if available and manifest.get("min_version"):
        if compare_versions(current["version"], manifest["min_version"]) < 0:
            blocked_min = manifest["min_version"]
    result = {"ok": True,
              "update_available": available and not blocked_min,
              "blocked_min_version": blocked_min,
              "current_version": current["version"],
              "version": manifest["version"],
              "notes": manifest["notes"],
              "zip_url": manifest["zip_url"],
              "sha256": manifest["sha256"],
              "checked_at": now}
    cfg["last_check"] = now
    cfg["last_error"] = None
    cfg["last_result"] = {k: v for k, v in result.items() if k != "ok"}
    try:
        save_update_config(cfg)
    except Exception:
        pass
    return result


AUTO_UPDATE_STATE = {"phase": "idle", "percent": 0, "downloaded": 0,
                     "total": None, "version": None, "error": None}
AUTO_UPDATE_LOCK = threading.Lock()
AUTO_UPDATE_ACTIVE = {"running": False}


def _auto_update_set(**kw):
    with AUTO_UPDATE_LOCK:
        AUTO_UPDATE_STATE.update(kw)


def auto_update_status():
    with AUTO_UPDATE_LOCK:
        return dict(AUTO_UPDATE_STATE)


def download_and_install_auto(manifest):
    """Background thread: stream the release zip, verify its SHA-256 against
    the manifest, then run the standard install + restart flow. A hash
    mismatch (or any failure) refuses the install and leaves the current
    version untouched. Never runs twice at once (guarded by the caller)."""
    version = manifest["version"]
    _auto_update_set(phase="downloading", percent=0, downloaded=0,
                     total=None, version=version, error=None)
    ensure_data_dir()
    os.makedirs(UPDATE_STAGING_DIR, exist_ok=True)
    staged = os.path.join(
        UPDATE_STAGING_DIR,
        "auto-update-{}.zip".format(datetime.now().strftime("%Y%m%d-%H%M%S")))
    digest = hashlib.sha256()
    try:
        req = urllib.request.Request(
            manifest["zip_url"],
            headers={"User-Agent": "StudyFlow-Updater"}, method="GET")
        with urllib.request.urlopen(req, timeout=UPDATE_DOWNLOAD_TIMEOUT) as resp:
            try:
                expected = int(resp.headers.get("Content-Length") or 0) or None
            except Exception:
                expected = None
            if expected and expected > MAX_UPDATE_ZIP_BYTES:
                raise ValueError("فایل به‌روزرسانی خیلی بزرگ است")
            _auto_update_set(total=expected)
            downloaded = 0
            with open(staged, "wb") as f:
                while True:
                    chunk = resp.read(65536)
                    if not chunk:
                        break
                    downloaded += len(chunk)
                    if downloaded > MAX_UPDATE_ZIP_BYTES:
                        raise ValueError("فایل به‌روزرسانی خیلی بزرگ است")
                    digest.update(chunk)
                    f.write(chunk)
                    pct = int(downloaded * 100 / expected) if expected else 0
                    _auto_update_set(downloaded=downloaded,
                                     percent=min(99, pct))
        _auto_update_set(phase="verifying", percent=100)
        if digest.hexdigest() != manifest["sha256"]:
            raise ValueError("هش فایل دانلودشده با مانیفست مطابقت ندارد — نصب انجام نشد")
        _auto_update_set(phase="installing", percent=100)
        new_version, backup, err = install_update_zip(staged)
        if err:
            raise ValueError(err)
        _auto_update_set(phase="done", percent=100,
                         version=new_version["version"])
        schedule_restart()
    except Exception as exc:
        _auto_update_set(phase="error", error=str(exc))
    finally:
        try:
            os.remove(staged)
        except Exception:
            pass
        AUTO_UPDATE_ACTIVE["running"] = False


def update_startup_check():
    """One manifest check shortly after server start. Records the result
    only — installing always needs the user's click."""
    time.sleep(10)
    try:
        run_update_check()
    except Exception as exc:
        print("Update startup check failed: {}".format(exc))


# ---------- Calendar sync (Part A, v1.8.0; two-way since v1.11.0) ----------
# Google Calendar sync. The merged programme lives in the DATA DIR
# (calendar_data.json), never in the shipped data.json, because the app folder
# is replaceable code (self-update wipes it). The shipped data.json stays the
# seed: the first sync matches its 318 boxes to feed events and persists the
# UID -> boxId mapping, so later syncs are stable.
#
# PULL (read path, unchanged): the private ICS feed, or a manually imported
# .ics/.json file. Google Calendar is ALWAYS the plan's source of truth (he
# plans with Muse + Gemini and the changes land in Google Calendar), so a
# pull applies Google's changes to the app's calendar UNCONDITIONALLY: if
# the same box was edited in the app AND changed in Google since the last
# pull, GOOGLE WINS — the app's conflicting local edit is dropped (never
# pushed over Google's version) and the dropped edit is noted in the sync
# log and the conflicts list, so nothing disappears silently.
#
# PUSH (write path, v1.11.0): OAuth 2.0 with a Desktop-app client. Client ID
# is pre-filled (the StudyFlow client, a public identifier); the Client
# Secret is pasted once by the user in settings and, like the tokens, lives
# ONLY in the data dir (google_oauth.json); the browser never sees them.
# The sign-in uses PKCE (RFC 8252, S256). The push compares the EFFECTIVE
# boxes (programme + state.edits overlay + custom boxes) with the
# last-pushed snapshot and only calls the API for what changed — and only
# when Google has not changed that box since the last pull: before PATCHing,
# the push reads the event's CURRENT values from Google and skips the box
# (leaving it for the next pull to resolve) if Google moved first.
# Deletions only ever touch Google events the app itself created. A
# debounced auto-push runs ~15s after any state save that changed a box
# (title/time/new/delete); a manual «ارسال تغییرات به گوگل» button pushes
# immediately. Push errors are recorded in Persian and nothing is lost
# locally.
#
# Sources (all parsed server-side, stdlib only):
#   * Auto sync: the private ICS ("Secret address in iCal format") the user
#     pastes once. Fetched on demand, on server start, and on a schedule.
#   * Manual import: an uploaded .ics file, or a JSON export in the Google
#     Calendar API shape ({items: [...]} — the shape the programme was built
#     from) or a plain array of {date, start, end, title} events. Works
#     offline, with no ICS URL configured.
# Both paths run the SAME merge (merge_calendar_events). Imports first run a
# dry-run preview; applying needs a second, explicit call.
#
# Merge rules (never lose his work):
#   * New event -> new box, fresh id continuing after the highest bNNN,
#     tests_total 0, subject/topic/is_test derived from the title.
#   * Moved/renamed event -> the matching box gets the new date/time/title,
#     but state is NEVER touched (done, tests, tests_total, edits, notes,
#     daysDone all live in state.json and the merge never writes there).
#   * Cancelled/missing event -> the box is removed ONLY if it was never
#     touched in the app (no tick, no tests, no edit, no tests_total). A
#     touched box is kept and unlinked instead. Removals are scoped to the
#     feed's own date span, so a partial export (e.g. 23 Nov-18 Dec) can
#     never delete boxes outside its range. For file imports, mere absence
#     never removes (the file may be partial) — only events the file marks
#     cancelled do; the live sync (the feed IS the whole calendar) also
#     removes events that disappeared from the feed.
#   * A box the user deleted in the app (state.deleted) tombstones its UID:
#     the event is never recreated by a later sync, and the UID stays in
#     tombstone_uids in the data dir.
#   * CONFLICT (Google always wins, 2026-11-24): if a box was edited in the
#     app after the last pull AND Google changed it too, the pull applies
#     Google's title/date/time unconditionally, the app's conflicting edit
#     is dropped (overlay reconciled to Google's values, app_edited_at
#     cleared, last_pushed set to Google's values so the push never
#     re-sends it), and the dropped edit is noted in the sync log and the
#     conflicts list. An app edit with NO Google change is untouched by the
#     pull and is pushed to Google as before.
# Every applied sync appends a summary + decision lines to the sync log
# (calendar_config.json, last 100 entries).
TEHRAN = timezone(timedelta(hours=3, minutes=30))
CALENDAR_CONFIG_FILE = os.path.join(DATA_DIR, "calendar_config.json")
CALENDAR_DATA_FILE = os.path.join(DATA_DIR, "calendar_data.json")
CALENDAR_LOG_MAX = 100
CALENDAR_FETCH_TIMEOUT = 25
CALENDAR_MAX_BYTES = 5 * 1024 * 1024
SLEEP_MARKER = "گوشی رو بذار کنار"
KNOWN_SUBJECTS = ["تحلیل آزمون", "مرور دفترچه خطا", "مرور و جمع‌بندی آزمون",
                  "جلسه مشاور درسی", "زبان انگلیسی", "حسابان", "شیمی", "فیزیک",
                  "هندسه", "گسسته", "عربی", "دینی", "ادبیات", "آزمون"]


def _split_outside_parens(text):
    """Last ': ' outside any parentheses, or None (so '(پارت ۲: …)' never
    splits a topic but 'دیدن جلسه: §۸' does)."""
    depth = 0
    last = None
    i = 0
    while i < len(text) - 1:
        ch = text[i]
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth = max(0, depth - 1)
        elif ch == ":" and text[i + 1] == " " and depth == 0:
            last = i
        i += 1
    return last


def clean_event_title(title):
    t = (title or "").strip()
    t = re.sub(r"\s*\(مفید:[^)]*\)\s*$", "", t)
    t = re.sub(r"\s*\(انجام شد\)\s*$", "", t)
    return t.strip()


def derive_subject_topic(title):
    """Subject/topic for a calendar summary, matching how the shipped 318
    boxes were derived from their summaries (verified against data.json:
    'X: rest' -> subject X; 'X — rest' -> subject X; 'کلاس X …' and
    'X آفلاین پایه' -> subject X with the full cleaned title as topic;
    'X دهم/دوازدهم (آزمون) — rest' -> subject X, topic rest)."""
    t = clean_event_title(title)
    if not t:
        return ("", "")
    # 'تست آزمون ۷: <rest>' / 'تست آزمون ۲ (هفته ۳): <rest>' — the original
    # build stripped that planning prefix: topic is the whole remainder,
    # subject is derived from the remainder ('آزمون' when it names none).
    m = re.match(r"^تست آزمون\s*\d*\s*(\([^)]*\))?\s*:\s*(.+)$", t)
    if m:
        rest = m.group(2).strip()
        s2, _ = derive_subject_topic(rest)
        return (rest if s2 == rest else s2, rest) if s2 != rest else ("آزمون", rest)
    for special in ("مرور دفترچه خطا", "جلسه مشاور درسی", "مرور و جمع‌بندی آزمون"):
        if t == special:
            return (special, t)
        if t.startswith(special + " — "):
            return (special, t.split(" — ", 1)[1].strip())
        if t.startswith(special + " "):
            return (special, t)
    if t.startswith("تحلیل آزمون"):
        if " — " in t:
            return ("تحلیل آزمون", t.split(" — ", 1)[1].strip())
        return ("تحلیل آزمون", t)
    if t.startswith("آزمون"):
        return ("آزمون", t)
    if ":" in t:
        left, right = t.split(":", 1)
        if left.strip() in KNOWN_SUBJECTS:
            return (left.strip(), right.strip())
    if " — " in t:
        left, right = t.split(" — ", 1)
        left = left.strip()
        right = right.strip()
        if left in KNOWN_SUBJECTS:
            ci = _split_outside_parens(right)
            return (left, right[ci + 2:] if ci is not None else right)
        # 'کلاس [زنده|آفلاین] <subject> … — <rest>' -> topic is
        # 'کلاس <subject> — <rest>' with a trailing parenthetical dropped.
        mc = re.match(r"^کلاس\s+(?:زنده|آفلاین)?\s*"
                      r"(حسابان|شیمی|فیزیک|هندسه|گسسته|عربی|دینی|ادبیات|زبان انگلیسی)\b", left)
        if mc:
            r2 = re.sub(r"\s*\([^)]*\)\s*$", "", right).strip()
            return (mc.group(1), "کلاس " + mc.group(1) + (" — " + r2 if r2 else ""))
        for s in KNOWN_SUBJECTS:
            if s in left:
                # Left is only the subject + grade words / a parenthetical
                # qualifier (e.g. 'هندسه دوازدهم', 'حسابان (آزمون)',
                # 'هندسه دوازدهم و دهم (تکلیف و آزمون)') -> topic = right.
                rest = left.replace(s, "", 1).strip()
                if re.fullmatch(r"((دهم|یازدهم|دوازدهم)(\s+و\s+(دهم|یازدهم|دوازدهم))?)?"
                                r"\s*(\([^)]*\))?", rest):
                    ci = _split_outside_parens(right)
                    return (s, right[ci + 2:] if ci is not None else right)
                return (s, t)
    # 'کلاس [زنده|آفلاین] <subject> …' -> topic is 'کلاس <subject>'.
    m = re.match(r"^کلاس\s+(?:زنده|آفلاین)?\s*"
                 r"(حسابان|شیمی|فیزیک|هندسه|گسسته|عربی|دینی|ادبیات|زبان انگلیسی)\b", t)
    if m:
        return (m.group(1), "کلاس " + m.group(1))
    for s in KNOWN_SUBJECTS:
        if s in t:
            return (s, t)
    return (t, t)


def event_is_test(title):
    """Test box? The shipped boxes are test boxes when the title carries
    تست / تکلیف / آزمون — except a parenthesised '(آزمون)' qualifier, a
    'بدون تکلیف' class, or the 'کلاس جبرانی … + آزمون + دوره' class.
    (Checked against all 318 shipped boxes: 0 mismatches.)"""
    t = clean_event_title(title)
    # A parenthetical qualifier naming an exam ('(آزمون)',
    # '(پارت ۵: آزمون ۱ ساعته)') does not make the box a test box — but
    # '(آمادگی آزمون)' (preparation FOR an exam) and '(تست آزمون)' do count.
    def _strip_qualifier(m):
        inner = m.group(1)
        if "آزمون" in inner and "تست" not in inner and "آمادگی" not in inner:
            return ""
        return m.group(0)
    t2 = re.sub(r"\(([^)]*)\)", _strip_qualifier, t)
    if "بدون تکلیف" in t or t.startswith("کلاس جبرانی") \
            or t.startswith("مرور و جمع‌بندی آزمون"):
        return False
    return bool(re.search(r"تست|تکلیف|آزمون", t2))


# ---------- ICS parsing (stdlib only) ----------
def _ics_unfold(text):
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    out = []
    for ln in lines:
        if ln[:1] in (" ", "\t") and out:
            out[-1] += ln[1:]
        else:
            out.append(ln)
    return out


def _ics_split(line):
    """'DTSTART;TZID=Asia/Tehran:20261124T090000' -> ({'TZID': ...}, value)."""
    if ":" not in line:
        return {}, line
    head, value = line.split(":", 1)
    parts = head.split(";")
    params = {}
    for p in parts[1:]:
        if "=" in p:
            k, v = p.split("=", 1)
            params[k.strip().upper()] = v.strip()
    return params, value.strip()


def _parse_ics_dt(value, params):
    """Returns (aware datetime in Tehran, is_all_day) or (None, False)."""
    value = (value or "").strip()
    if not value:
        return None, False
    if params.get("VALUE", "").upper() == "DATE" or re.match(r"^\d{8}$", value):
        try:
            d = datetime.strptime(value[:8], "%Y%m%d").date()
        except Exception:
            return None, False
        return datetime(d.year, d.month, d.day, tzinfo=TEHRAN), True
    m = re.match(r"^(\d{8})T(\d{6})(Z)?$", value)
    if not m:
        try:
            dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=TEHRAN)
            return dt.astimezone(TEHRAN), False
        except Exception:
            return None, False
    base = datetime.strptime(m.group(1) + m.group(2), "%Y%m%d%H%M%S")
    if m.group(3) == "Z":
        return base.replace(tzinfo=timezone.utc).astimezone(TEHRAN), False
    tzid = (params.get("TZID") or "").upper()
    if tzid in ("UTC", "GMT", "ETC/UTC"):
        return base.replace(tzinfo=timezone.utc).astimezone(TEHRAN), False
    # A known TZID (e.g. Asia/Dubai, Europe/London) resolves through
    # zoneinfo; unknown/custom zone names and floating times fall back
    # to Tehran local (the previous behaviour for every non-UTC TZID).
    tzid_raw = (params.get("TZID") or "").strip()
    if tzid_raw and ZoneInfo is not None:
        try:
            return base.replace(tzinfo=ZoneInfo(tzid_raw)).astimezone(TEHRAN), False
        except Exception:
            pass
    return base.replace(tzinfo=TEHRAN), False


def _parse_rrule(value):
    out = {}
    for part in (value or "").split(";"):
        if "=" in part:
            k, v = part.split("=", 1)
            out[k.strip().upper()] = v.strip()
    return out


def _nth_weekday_of_month(year, month, weekday, n):
    """Date of the nth weekday (n >= 1) or the last one (n == -1) in a
    month, or None when that nth weekday does not exist (e.g. 5th Monday)."""
    first = datetime(year, month, 1).date()
    offset = (weekday - first.weekday()) % 7
    if n >= 1:
        try:
            return datetime(year, month, 1 + offset + (n - 1) * 7).date()
        except ValueError:
            return None
    if month == 12:
        nxt = datetime(year + 1, 1, 1).date()
    else:
        nxt = datetime(year, month + 1, 1).date()
    last = nxt - timedelta(days=1)
    return last - timedelta(days=(last.weekday() - weekday) % 7)


def _expand_rrule(start_dt, end_dt, rrule, exdates, range_start, range_end):
    """Expand one recurring master into (start, end) instances inside the
    date range. Day-by-day walk: simple, and correct for DAILY / WEEKLY /
    MONTHLY / YEARLY with INTERVAL, COUNT, UNTIL, BYDAY and EXDATE.
    HOURLY / MINUTELY walk in time steps (bounded). COUNT always counts
    from the recurrence start, never from the programme-range start, and
    UNTIL is compared as a datetime, not a date."""
    freq = (rrule.get("FREQ") or "").upper()
    if freq not in ("DAILY", "WEEKLY", "MONTHLY", "YEARLY", "HOURLY", "MINUTELY"):
        return [(start_dt, end_dt)]
    try:
        interval = max(1, int(rrule.get("INTERVAL") or 1))
    except Exception:
        interval = 1
    count = None
    try:
        if rrule.get("COUNT"):
            count = int(rrule["COUNT"])
    except Exception:
        count = None
    until_dt = None
    if rrule.get("UNTIL"):
        u, _ = _parse_ics_dt(rrule["UNTIL"], {})
        if u is not None:
            until_dt = u
    days = {"MO": 0, "TU": 1, "WE": 2, "TH": 3, "FR": 4, "SA": 5, "SU": 6}
    byday = None
    byday_ord = []
    if rrule.get("BYDAY"):
        for part in rrule["BYDAY"].split(","):
            m = re.fullmatch(r"(-?\d+)?(MO|TU|WE|TH|FR|SA|SU)", part.strip())
            if not m:
                continue
            if m.group(1):
                byday_ord.append((days[m.group(2)], int(m.group(1))))
            else:
                byday = byday or []
                byday.append(days[m.group(2)])
        if byday:
            byday = sorted(set(byday))
    duration = end_dt - start_dt
    start_date = start_dt.date()
    ex = set()
    for e in exdates or []:
        ex.add(e.date() if hasattr(e, "date") else e)
        if hasattr(e, "hour"):
            ex.add(e)
    out = []
    if freq in ("HOURLY", "MINUTELY"):
        step = timedelta(hours=interval) if freq == "HOURLY" \
            else timedelta(minutes=interval)
        range_end_dt = datetime(range_end.year, range_end.month, range_end.day,
                                23, 59, 59, tzinfo=TEHRAN)
        t = start_dt
        made = 0
        while t <= range_end_dt and made < 5000:
            if until_dt is not None and t > until_dt:
                break
            if count is not None and made >= count:
                break
            if t.date() >= range_start and t not in ex and t.date() not in ex:
                out.append((t, t + duration))
            made += 1
            t += step
        return out
    made = 0
    d = start_date
    while d <= range_end:
        if count is not None and made >= count:
            break
        ok = False
        delta_days = (d - start_date).days
        if freq == "DAILY":
            ok = delta_days % interval == 0
        elif freq == "WEEKLY":
            wanted = byday if byday else [start_dt.weekday()]
            ok = d.weekday() in wanted and (delta_days // 7) % interval == 0
        elif freq == "MONTHLY":
            months = (d.year - start_date.year) * 12 + (d.month - start_date.month)
            if months % interval != 0:
                ok = False
            elif byday_ord or byday:
                ok = any(_nth_weekday_of_month(d.year, d.month, wd, n) == d
                         for wd, n in byday_ord) or (bool(byday) and d.weekday() in byday)
            else:
                ok = d.day == start_date.day
        elif freq == "YEARLY":
            ok = (d.month == start_date.month and d.day == start_date.day
                  and (d.year - start_date.year) % interval == 0)
        if ok:
            inst_start = datetime(d.year, d.month, d.day, start_dt.hour,
                                  start_dt.minute, start_dt.second, tzinfo=TEHRAN)
            if until_dt is not None and inst_start > until_dt:
                break
            if inst_start not in ex and d not in ex:
                if d >= range_start:
                    out.append((inst_start, inst_start + duration))
                made += 1
            elif count is not None:
                made += 1
        d += timedelta(days=1)
    return out


def parse_ics(text):
    """Parse ICS text into raw events: {uid, title, start_dt, end_dt,
    status, all_day}. Recurring masters are expanded into instances
    (uid suffixed with the instance start); a cancelled master cancels
    all its instances. A VEVENT with RECURRENCE-ID is an exception for
    ONE instance of its master (moved or cancelled): it replaces that
    instance in place, keeping the instance UID, so the merge updates
    (or deletes) the same box instead of duplicating it."""
    raw = []
    exceptions = []
    rng = None  # programme range, read once (not per recurring master)
    cur = None
    for ln in _ics_unfold(text or ""):
        line = ln.strip()
        if line == "BEGIN:VEVENT":
            cur = {"props": []}
        elif line == "END:VEVENT" and cur is not None:
            props = {}
            for name, params, value in cur["props"]:
                props.setdefault(name, []).append((params, value))
            uid = ""
            for params, value in props.get("UID", []):
                uid = value
                break
            title = ""
            for params, value in props.get("SUMMARY", []):
                title = value
                break
            status = "confirmed"
            for params, value in props.get("STATUS", []):
                status = value.strip().lower()
                break
            s_dt, s_all = None, False
            e_dt = None
            for params, value in props.get("DTSTART", []):
                s_dt, s_all = _parse_ics_dt(value, params)
                break
            for params, value in props.get("DTEND", []):
                e_dt, _ = _parse_ics_dt(value, params)
                break
            if uid and title and s_dt is not None:
                if e_dt is None:
                    e_dt = s_dt + timedelta(hours=1)
                exdates = []
                for params, value in props.get("EXDATE", []):
                    for piece in value.split(","):
                        ed, _ = _parse_ics_dt(piece.strip(), params)
                        if ed is not None:
                            exdates.append(ed)
                rrules = [v for _, v in props.get("RRULE", [])]
                rec_id = None
                for params, value in props.get("RECURRENCE-ID", []):
                    rec_id, _ = _parse_ics_dt(value, params)
                    break
                if rec_id is not None:
                    # Exception for one instance of the master: apply it
                    # after the masters are expanded (below).
                    exceptions.append({"uid": uid, "rec_id": rec_id,
                                       "title": title, "start_dt": s_dt,
                                       "end_dt": e_dt, "status": status,
                                       "all_day": s_all})
                elif rrules:
                    if rng is None:
                        rng = _programme_range()
                    for inst_s, inst_e in _expand_rrule(
                            s_dt, e_dt, _parse_rrule(rrules[0]), exdates,
                            rng[0], rng[1]):
                        raw.append({"uid": uid + "#" + inst_s.strftime("%Y%m%dT%H%M"),
                                    "title": title, "start_dt": inst_s,
                                    "end_dt": inst_e, "status": status,
                                    "all_day": s_all})
                else:
                    raw.append({"uid": uid, "title": title, "start_dt": s_dt,
                                "end_dt": e_dt, "status": status,
                                "all_day": s_all})
            cur = None
        elif cur is not None and ":" in line:
            name = line.split(":", 1)[0].split(";", 1)[0].strip().upper()
            params, value = _ics_split(line)
            cur["props"].append((name, params, value))
    # Apply RECURRENCE-ID exceptions onto the expanded instances.
    for exc in exceptions:
        target_uid = exc["uid"] + "#" + exc["rec_id"].strftime("%Y%m%dT%H%M")
        replaced = False
        for ev in raw:
            if ev["uid"] == target_uid:
                # Keep the original instance UID so the merge updates
                # (or, when cancelled, deletes) the same box.
                ev["title"] = exc["title"]
                ev["start_dt"] = exc["start_dt"]
                ev["end_dt"] = exc["end_dt"]
                ev["status"] = exc["status"]
                ev["all_day"] = exc["all_day"]
                replaced = True
                break
        if not replaced:
            # Master instance outside the programme range (or an
            # unexpanded master): keep the exception under the instance
            # UID so a moved instance is not lost.
            raw.append({"uid": target_uid, "title": exc["title"],
                        "start_dt": exc["start_dt"], "end_dt": exc["end_dt"],
                        "status": exc["status"], "all_day": exc["all_day"]})
    return raw


# ---------- JSON export parsing ----------
def _iso_to_tehran(value):
    """ISO datetime (with offset, Z, or floating) -> Tehran datetime."""
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except Exception:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=TEHRAN)
    return dt.astimezone(TEHRAN)


def _hhmm(value):
    """HH:MM (or HHMM, e.g. "0900") -> (hour, minute)."""
    s = str(value or "").strip()
    if re.fullmatch(r"\d{4}", s):
        return int(s[:2]), int(s[2:])
    parts = (s.split(":") + ["0", "0"])[:2]
    return int(parts[0]), int(parts[1])


def parse_calendar_json(text):
    """Parse a calendar JSON export into the same raw-event shape as
    parse_ics. Accepts: (a) the Google Calendar API export
    ({items: [{id, iCalUID, summary, start: {dateTime}, end: {dateTime},
    status, recurringEventId}]}); (b) a plain array of events
    ({date, start, end, title}); (c) {boxes: [...]} in the same shape."""
    try:
        data = json.loads(text)
    except Exception as exc:
        raise ValueError("فایل JSON معتبر نیست: {}".format(exc))
    items = None
    if isinstance(data, dict) and isinstance(data.get("items"), list):
        items = data["items"]
    elif isinstance(data, list):
        items = data
    elif isinstance(data, dict) and isinstance(data.get("boxes"), list):
        items = data["boxes"]
    else:
        raise ValueError("ساختار JSON شناخته نشد — باید {items: [...]} یا آرایه‌ای از رویدادها باشد")
    raw = []
    rng = None
    # Explicit instances of a recurring master (Google API exports list
    # them with recurringEventId + originalStartTime): the master
    # expansion must skip those original times, or every instance is
    # counted twice (once expanded, once explicit).
    explicit = {}
    for it in items:
        if not isinstance(it, dict) or not it.get("recurringEventId"):
            continue
        orig = it.get("originalStartTime") or {}
        odt = _iso_to_tehran(orig.get("dateTime")) if orig.get("dateTime") else None
        if odt is None:
            s = it.get("start") or {}
            odt = _iso_to_tehran(s.get("dateTime")) if isinstance(s, dict) and s.get("dateTime") else None
        if odt is not None:
            explicit.setdefault(str(it["recurringEventId"]), set()).add(odt)
    for it in items:
        if not isinstance(it, dict):
            continue
        title = it.get("summary") or it.get("title") or ""
        status = str(it.get("status") or "confirmed").lower()
        uid = it.get("iCalUID") or it.get("uid") or it.get("id") or ""
        if it.get("recurringEventId"):
            uid = str(it.get("id") or uid)  # instances are unique by id
        start = it.get("start")
        end = it.get("end")
        s_dt = e_dt = None
        all_day = False
        if isinstance(start, dict):
            if start.get("dateTime"):
                s_dt = _iso_to_tehran(start["dateTime"])
            elif start.get("date"):
                all_day = True
                try:
                    d = datetime.strptime(start["date"][:10], "%Y-%m-%d").date()
                    s_dt = datetime(d.year, d.month, d.day, tzinfo=TEHRAN)
                except Exception:
                    s_dt = None
        elif isinstance(start, str):
            if "T" in start:
                s_dt = _iso_to_tehran(start)
            elif it.get("date"):
                try:
                    d = datetime.strptime(str(it["date"])[:10], "%Y-%m-%d").date()
                    hh, mm = _hhmm(start)
                    s_dt = datetime(d.year, d.month, d.day, hh, mm, tzinfo=TEHRAN)
                except Exception:
                    s_dt = None
        if isinstance(end, dict):
            if end.get("dateTime"):
                e_dt = _iso_to_tehran(end["dateTime"])
            elif end.get("date"):
                try:
                    d = datetime.strptime(end["date"][:10], "%Y-%m-%d").date()
                    e_dt = datetime(d.year, d.month, d.day, tzinfo=TEHRAN)
                except Exception:
                    e_dt = None
        elif isinstance(end, str):
            if "T" in end:
                e_dt = _iso_to_tehran(end)
            elif s_dt is not None:
                try:
                    hh, mm = _hhmm(end)
                    e_dt = datetime(s_dt.year, s_dt.month, s_dt.day, hh, mm, tzinfo=TEHRAN)
                except Exception:
                    e_dt = None
        if not title or s_dt is None:
            continue
        if e_dt is None:
            e_dt = s_dt + timedelta(hours=1)
        if not uid:
            uid = "manual-" + sha256_bytes(
                (s_dt.strftime("%Y-%m-%d %H:%M") + "|" + title).encode("utf-8"))[:12]
        # A Google item carrying its own RRULE (no expanded instances in
        # the file): expand it the same way as an ICS master.
        recurrence = it.get("recurrence") or []
        rrule = None
        for r in recurrence:
            if isinstance(r, str) and r.startswith("RRULE:"):
                rrule = _parse_rrule(r[len("RRULE:"):])
                break
        if rrule:
            if rng is None:
                rng = _programme_range()
            skip = explicit.get(str(it.get("id") or uid), set())
            for inst_s, inst_e in _expand_rrule(s_dt, e_dt, rrule, [], rng[0], rng[1]):
                if inst_s in skip:
                    continue
                raw.append({"uid": str(uid) + "#" + inst_s.strftime("%Y%m%dT%H%M"),
                            "title": title, "start_dt": inst_s, "end_dt": inst_e,
                            "status": status, "all_day": all_day})
        else:
            raw.append({"uid": str(uid), "title": title, "start_dt": s_dt,
                        "end_dt": e_dt, "status": status, "all_day": all_day})
    return raw


def normalize_events(raw):
    """Raw events -> present events [{uid, title, date, start, end}],
    cancelled uids, and skip counts. Filters the nightly sleep reminder
    and zero-duration events (the same filter the original build used),
    skips all-day events, and dedupes by UID."""
    events = []
    cancelled = set()
    counts = {"skipped_sleep": 0, "skipped_zero": 0, "skipped_allday": 0,
              "cancelled": 0, "duplicates": 0}
    seen = {}
    for ev in raw or []:
        uid = str(ev.get("uid") or "")
        title = (ev.get("title") or "").strip()
        s_dt = ev.get("start_dt")
        e_dt = ev.get("end_dt")
        if not uid or not title or s_dt is None or e_dt is None:
            continue
        if str(ev.get("status") or "").lower() in ("cancelled", "canceled"):
            cancelled.add(uid)
            counts["cancelled"] += 1
            continue
        if SLEEP_MARKER in title:
            counts["skipped_sleep"] += 1
            continue
        if e_dt <= s_dt:
            counts["skipped_zero"] += 1
            continue
        if ev.get("all_day"):
            counts["skipped_allday"] += 1
            continue
        key = uid
        if key in seen and (seen[key]["date"], seen[key]["start"]) != (
                s_dt.strftime("%Y-%m-%d"), s_dt.strftime("%H:%M")):
            key = uid + "#" + s_dt.strftime("%Y%m%dT%H%M")
        if key in seen:
            counts["duplicates"] += 1
            continue
        item = {"uid": key, "title": title, "date": s_dt.strftime("%Y-%m-%d"),
                "start": s_dt.strftime("%H:%M"), "end": e_dt.strftime("%H:%M")}
        seen[key] = item
        events.append(item)
    events.sort(key=lambda e: (e["date"], e["start"], e["title"]))
    return events, cancelled, counts


# ---------- Programme store (data dir) ----------
def _programme_range():
    """(first, last) programme dates, for recurring-event expansion."""
    data, _ = read_json_file(CALENDAR_DATA_FILE)
    boxes = []
    if isinstance(data, dict) and isinstance(data.get("boxes"), list):
        boxes = data["boxes"]
    else:
        shipped, _ = read_json_file(os.path.join(BASE, "data.json"))
        if isinstance(shipped, dict) and isinstance(shipped.get("boxes"), list):
            boxes = shipped["boxes"]
    if boxes:
        dates = sorted(b["date"] for b in boxes if b.get("date"))
        if dates:
            return (datetime.strptime(dates[0], "%Y-%m-%d").date(),
                    datetime.strptime(dates[-1], "%Y-%m-%d").date())
    today = datetime.now(tz=TEHRAN).date()
    return (today, today + timedelta(days=180))


def load_programme():
    data, _ = read_json_file(CALENDAR_DATA_FILE)
    if isinstance(data, dict) and isinstance(data.get("boxes"), list):
        data.setdefault("uid_map", {})
        data.setdefault("tombstone_uids", [])
        data.setdefault("tombstone_box_ids", [])
        data.setdefault("meta", {})
        return data
    entry, backup = newest_verified_backup("programme")
    if backup is not None:
        atomic_write_json(CALENDAR_DATA_FILE, backup)
        print("Restored calendar programme from backup {}".format(entry["file"]))
        return backup
    shipped, _ = read_json_file(os.path.join(BASE, "data.json"))
    if isinstance(shipped, dict) and isinstance(shipped.get("boxes"), list):
        return {"meta": dict(shipped.get("meta") or {}),
                "boxes": shipped["boxes"], "uid_map": {},
                "tombstone_uids": [], "tombstone_box_ids": []}
    return {"meta": {}, "boxes": [], "uid_map": {},
            "tombstone_uids": [], "tombstone_box_ids": []}


def save_programme(prog):
    with STATE_LOCK:
        atomic_write_json(CALENDAR_DATA_FILE, prog)
        create_backup("programme")
        CLOUD_SYNC.request()
    return prog


def _box_touched(state, box_id):
    """Was this box ever touched in the app? (tick, tests, edit, total)."""
    if (state.get("done") or {}).get(box_id):
        return True
    tr = (state.get("tests") or {}).get(box_id) or {}
    if (tr.get("completed") or 0) > 0:
        return True
    if box_id in (state.get("edits") or {}):
        return True
    if box_id in (state.get("tests_total") or {}):
        return True
    return False


def _hhmm_to_min(value):
    """'HH:MM' -> minutes since midnight, or None when unparsable."""
    try:
        h, m = str(value or "").split(":")
        h, m = int(h), int(m)
    except (ValueError, AttributeError):
        return None
    if not (0 <= h <= 23 and 0 <= m <= 59):
        return None
    return h * 60 + m


def _intervals_overlap(a_start, a_end, b_start, b_end):
    """Do two 'HH:MM' intervals overlap? An end <= start is an overnight
    interval (past midnight), so that end is read as +24h."""
    a0, a1 = _hhmm_to_min(a_start), _hhmm_to_min(a_end)
    b0, b1 = _hhmm_to_min(b_start), _hhmm_to_min(b_end)
    if a0 is None or a1 is None or b0 is None or b1 is None:
        return False
    if a1 <= a0:
        a1 += 1440
    if b1 <= b0:
        b1 += 1440
    return a0 < b1 and b0 < a1


# (v1.11.9: _title_similarity was removed with the title-similarity
# matcher — the merge never links by similarity any more. Only the UID
# or an exact (date+start+title) match links a feed event to a box.)
@_with_lock
def merge_calendar_events(events, cancelled_uids, source_label, apply=True,
                          remove_missing=True):
    """The single merge used by auto sync AND manual import. With
    apply=False it is a dry run (preview): nothing is written, no log.
    remove_missing: True for the live auto/manual sync (the ICS feed IS
    the whole calendar, so an absent event was deleted in Google);
    False for file imports (a file may be a partial export — there only
    events explicitly marked cancelled in the file unlink boxes).
    A box is NEVER deleted by a pull (rules 2/5): a box whose Google
    event is gone is unlinked and flagged `orphaned`, so its record stays
    where it was — the dashboard is the primary source of task data and
    the calendar is only an external link (v1.11.9). The box stays in
    its section with no connection badge; only the user moves or deletes
    it, by hand. A later pull (or a manual reconnect) re-links it and
    clears the flag. Linking is by UID first, else by an exact
    (date+start+title) triple — and only when that triple is unambiguous.
    No similarity of any kind is ever used to link (v1.11.9, spec §4).
    Returns a summary dict with counts and capped title lists."""
    prog = load_programme()
    boxes = prog["boxes"]
    uid_map = dict(prog.get("uid_map") or {})
    tomb_uids = set(prog.get("tombstone_uids") or [])
    tomb_box = set(prog.get("tombstone_box_ids") or [])
    state = load_state()
    deleted = set(state.get("deleted") or [])
    edits = state.get("edits") or {}
    # Two-way bookkeeping (v1.11.0): Google is ALWAYS the authority for
    # programme content. last_pull_ts is an epoch float stored in prog
    # meta (see the apply block below). A box edited in the app AFTER the
    # last successful pull AND changed in Google too is a conflict — the
    # pull applies Google's values unconditionally and the app's edit is
    # dropped (see the conflict branch below); it is never pushed over
    # Google's version. An app edit with no Google change is untouched
    # by the pull and is pushed as before.
    pstate = load_push_state()
    last_pull_ts = (prog.get("meta") or {}).get("last_pull_ts") or 0
    push_last_updates = {}
    overlay_updates = {}
    conflict_notes = []
    push_forget = set()   # drop last_pushed + app_edited_at (keep event_map)
    push_unmap = set()    # also drop event_map (the Google event is gone)
    pstate_dirty = False
    # Boxes deleted in the app tombstone their UID: never resurrected.
    for uid, bid in list(uid_map.items()):
        if bid in deleted:
            tomb_uids.add(uid)
            tomb_box.add(bid)
            del uid_map[uid]
    tomb_box |= deleted
    by_id = {b["id"]: b for b in boxes}
    dates = sorted({e["date"] for e in events})
    span = (dates[0], dates[-1]) if dates else (None, None)
    log = []
    added, updated, removed, unlinked = [], [], [], []
    skipped_tomb = 0
    kept_touched = 0
    next_num = 318
    for b in boxes:
        m = re.match(r"^b(\d+)$", b.get("id") or "")
        if m:
            next_num = max(next_num, int(m.group(1)))

    def find_exact_matches(date, start, title):
        # v1.11.9: the ONLY first-time linking mechanism besides the UID.
        # An exact (date + start time + title) triple — how the 318 seed
        # boxes get their Event IDs on the first pull. Returns EVERY
        # match; the caller links only when there is exactly one, so an
        # ambiguous triple links nothing and waits for manual reconnect.
        # No similarity of any kind is ever used to link (user spec §4).
        out = []
        for b in boxes:
            if b["id"] in deleted or b["id"] in uid_map.values():
                continue
            if b["date"] == date and b["start"] == start and b["title"] == title:
                out.append(b)
        return out

    def find_deleted_match(date, start, title):
        # A box the user already deleted in the app: match it ONLY to
        # tombstone the UID — its event must never be recreated as a new box.
        for b in boxes:
            if b["id"] in deleted and b["date"] == date \
                    and b["start"] == start and b["title"] == title:
                return b
        return None

    seen_uids = set()
    for ev in events:
        uid = ev["uid"]
        seen_uids.add(uid)
        if uid in tomb_uids:
            skipped_tomb += 1
            log.append("رد شد (حذف‌شده در برنامه): {}".format(ev["title"]))
            continue
        bid = uid_map.get(uid)
        box = by_id.get(bid) if bid else None
        if bid and box is None:
            del uid_map[uid]
            bid = None
        if box is None:
            dm = find_deleted_match(ev["date"], ev["start"], ev["title"])
            if dm is not None:
                tomb_uids.add(uid)
                tomb_box.add(dm["id"])
                skipped_tomb += 1
                log.append("رد شد (حذف‌شده در برنامه): {}".format(ev["title"]))
                continue
            ms = find_exact_matches(ev["date"], ev["start"], ev["title"])
            if len(ms) == 1:
                m = ms[0]
                uid_map[uid] = m["id"]
                box = m
                bid = m["id"]
                log.append("تطبیق اول: {} -> {}".format(ev["title"], bid))
            elif len(ms) > 1:
                # Ambiguous exact triple: link NOTHING — the user reconnects
                # manually (spec §4). The event becomes a new box and the
                # old boxes stay disconnected for review.
                log.append("تطبیق دقیق مبهم ({} نامزد) — بدون پیوند: {}".format(
                    len(ms), ev["title"]))
        if box is not None:
            if bid in deleted:
                tomb_uids.add(uid)
                uid_map.pop(uid, None)
                skipped_tomb += 1
                log.append("رد شد (حذف‌شده در برنامه): {}".format(ev["title"]))
                continue
            # Re-linked: the Google event exists again, so the box is no
            # longer orphaned — it returns to the current programme.
            if box.pop("orphaned", None) is not None:
                log.append("وصل شد دوباره: {} ({})".format(ev["title"], bid))
            subj, topic = derive_subject_topic(ev["title"])
            # Effective values: what the user actually sees (programme box
            # + the state.edits overlay). The pull compares against these.
            ov = edits.get(bid) or {}
            eff = {"title": ov.get("title", box.get("title")),
                   "date": ov.get("date", box.get("date")),
                   "start": ov.get("start", box.get("start")),
                   "end": ov.get("end", box.get("end"))}
            evv = {"title": ev["title"], "date": ev["date"],
                   "start": ev["start"], "end": ev["end"]}
            if eff == evv:
                # Fully in sync with Google: any pending app edit is done.
                if (pstate.get("app_edited_at") or {}).pop(bid, None) is not None:
                    pstate_dirty = True
                if apply:
                    push_last_updates[bid] = evv
                continue
            edited_after_pull = (pstate.get("app_edited_at") or {}).get(bid, 0) > (last_pull_ts or 0)
            if edited_after_pull:
                last_google = (pstate.get("last_pushed") or {}).get(bid)
                if isinstance(last_google, dict) and last_google == evv:
                    # Google has NOT changed since the last pull — the
                    # only difference is the app's own edit. Keep it:
                    # the pending push sends it to Google. (Previously
                    # this was misread as a conflict and the app edit
                    # was dropped even when Google was byte-identical.)
                    log.append("حفظ شد (ویرایش برنامه؛ تقویم تغییری نکرده): {}".format(ov.get("title") or ev["title"]))
                    continue
                # CONFLICT (Google always wins, 2026-11-24): the box was
                # edited in the app after the last pull AND Google changed
                # it too. The app's edit is DROPPED — it is never pushed
                # over Google's version. Fall through to the Google-wins
                # application below, which overwrites the programme box
                # and reconciles the overlay to Google's values (so the
                # next push cannot re-send the dropped edit); this log
                # line and the conflicts list are the only trace of it.
                dropped_title = ov.get("title") or ev["title"]
                log.append("تعارض — نسخه‌ی تقویم اعمال شد؛ ویرایش برنامه برای «{}» کنار گذاشته شد".format(dropped_title))
                conflict_notes.append({"box_id": bid, "title": dropped_title, "ts": iso_now()})
            # Google wins: apply the event to the programme box AND to the
            # app-edit overlay (otherwise the overlay would mask the pull
            # and the next push would send the old values back to Google).
            changes = {k: v for k, v in evv.items() if box.get(k) != v}
            ov_changes = {k: v for k, v in evv.items()
                          if bid in edits and ov.get(k) != v}
            if changes or ov_changes:
                for k, v in changes.items():
                    box[k] = v
                if "title" in changes:
                    box["subject"] = subj
                    box["topic"] = topic
                    box["is_test"] = event_is_test(ev["title"])
                if ov_changes:
                    overlay_updates[bid] = evv
                if apply:
                    push_last_updates[bid] = evv
                if (pstate.get("app_edited_at") or {}).pop(bid, None) is not None:
                    pstate_dirty = True
                updated.append(ev["title"])
                log.append("به‌روز شد: {} ({})".format(ev["title"], bid))
            continue
        # Brand-new event -> brand-new box.
        next_num += 1
        nid = "b{}".format(next_num)
        subj, topic = derive_subject_topic(ev["title"])
        nb = {"id": nid, "date": ev["date"], "start": ev["start"],
              "end": ev["end"], "subject": subj, "topic": topic,
              "title": ev["title"], "is_test": event_is_test(ev["title"]),
              "tests_total": 0, "note": ""}
        boxes.append(nb)
        by_id[nid] = nb
        uid_map[uid] = nid
        added.append(ev["title"])
        if apply:
            push_last_updates[nid] = {"title": ev["title"], "date": ev["date"],
                                      "start": ev["start"], "end": ev["end"]}
        log.append("اضافه شد: {} ({})".format(ev["title"], nid))
    # Orphaned boxes (v1.11.7, kept in v1.11.9): a programme box with no
    # UID link that falls inside the feed's date span and has no feed
    # event claiming it is stale — Google deleted it or replaced it with
    # a renamed/moved event (which the loop above created anew, since the
    # merge never links by similarity). After the event loop every live
    # feed event is linked to exactly one box, so "unmapped" already means
    # "no event claims this box". The record is NEVER deleted (rules 2/5):
    # it is only flagged `orphaned`. v1.11.9: the box STAYS in its section
    # (dashboard / programme / review-past) with no connection badge —
    # only the user moves or deletes it, by hand. A later pull re-links
    # it and clears the flag. Live sync only: file imports never orphan
    # unmapped boxes (remove_missing=False) — a file may be a partial
    # export. Custom boxes live in state.custom_boxes and are untouched
    # here. This pass runs BEFORE the mapped loop below: a box the mapped
    # loop unlinks (touched) must not be counted a second time here.
    if remove_missing:
        for b in list(boxes):
            bid = b["id"]
            if bid in uid_map.values():
                continue
            if bid in deleted or bid in tomb_box:
                continue
            if b.get("orphaned"):
                continue
            if span[0] and not (span[0] <= b.get("date", "") <= span[1]):
                continue
            b["orphaned"] = True
            if _box_touched(state, bid):
                kept_touched += 1
            push_unmap.add(bid)
            unlinked.append(b.get("title") or bid)
            log.append("حفظ شد (رویداد از تقویم حذف شده): {} ({})".format(
                b.get("title"), bid))
    # Unlinking (v1.11.7): mapped UIDs absent from the feed, scoped to the
    # feed's own date span (a partial export never unlinks outside its
    # range). With remove_missing=False (file imports) only events the
    # file marks cancelled are unlink candidates — mere absence means
    # nothing there. No box is ever deleted here (rules 2/5): the link is
    # dropped and the box is flagged orphaned, so its record stays in
    # history / review-past.
    for uid, bid in list(uid_map.items()):
        if uid in seen_uids:
            continue
        if not remove_missing and uid not in (cancelled_uids or set()):
            continue
        box = by_id.get(bid)
        if box is None:
            del uid_map[uid]
            continue
        if span[0] and not (span[0] <= box.get("date", "") <= span[1]):
            continue
        if bid in deleted:
            tomb_uids.add(uid)
            del uid_map[uid]
            push_forget.add(bid)
            continue
        if _box_touched(state, bid):
            del uid_map[uid]  # orphan: keep the box, drop the link
            box["orphaned"] = True
            kept_touched += 1
            push_unmap.add(bid)
            unlinked.append(box.get("title") or bid)
            log.append("حفظ شد (در برنامه لمس شده): {} ({})".format(box.get("title"), bid))
            continue
        # Never delete a box because Google deleted its event (rules 2/5):
        # keep the record in place, drop only the link, and flag it
        # orphaned — the box stays in its section with no connection badge
        # (v1.11.9: no hiding, no auto-move; the user decides by hand).
        del uid_map[uid]
        box["orphaned"] = True
        push_unmap.add(bid)
        unlinked.append(box.get("title") or bid)
        log.append("حفظ شد (رویداد از تقویم حذف شده): {} ({})".format(box.get("title"), bid))
    summary = {"added": len(added), "updated": len(updated),
               "removed": len(removed), "unlinked": len(unlinked),
               "skipped_tombstone": skipped_tomb,
               "kept_touched": kept_touched,
               "cancelled": len(cancelled_uids or []),
               "conflicts": len(conflict_notes),
               "dropped_titles": [c.get("title") for c in conflict_notes][:20],
               "span_from": span[0], "span_to": span[1],
               "box_count": len(boxes),
               "added_titles": added[:20], "updated_titles": updated[:20],
               "removed_titles": removed[:20],
               "unlinked_titles": unlinked[:20]}
    if apply:
        prog["boxes"] = boxes
        prog["uid_map"] = uid_map
        prog["tombstone_uids"] = sorted(tomb_uids)
        prog["tombstone_box_ids"] = sorted(tomb_box)
        meta = dict(prog.get("meta") or {})
        meta["last_sync"] = iso_now()
        meta["last_source"] = source_label
        meta["last_pull_ts"] = now_ts()
        # v1.11.9: remember the last successful pull's feed (uid/title/
        # date/start/end per event) so the reconnect picker can list the
        # currently-unlinked Google events without re-fetching. This is
        # feed data, not user data — it is replaced on every pull.
        meta["last_feed"] = [{"uid": e["uid"], "title": e["title"],
                              "date": e["date"], "start": e["start"],
                              "end": e["end"]} for e in events]
        meta["last_feed_ts"] = iso_now()
        prog["meta"] = meta
        # Push-state bookkeeping from this pull: boxes now in sync with
        # Google, conflicts to push, overlay reconciliation, and cleanup
        # for boxes that left the programme.
        if push_last_updates:
            lp = dict(pstate.get("last_pushed") or {})
            lp.update(push_last_updates)
            pstate["last_pushed"] = lp
            pstate_dirty = True
        if conflict_notes:
            # Dropped local edits are recorded for the UI, but they are
            # RESOLVED — never queued for push (Google's version stands).
            conf = list(pstate.get("conflicts") or [])
            seen_c = {c.get("box_id") for c in conf}
            for c in conflict_notes:
                if c["box_id"] not in seen_c:
                    conf.append(c)
            pstate["conflicts"] = conf[-20:]
            pend = set(pstate.get("pending") or [])
            pend -= {c["box_id"] for c in conflict_notes}
            pstate["pending"] = sorted(pend)
            pstate_dirty = True
        if push_forget or push_unmap:
            lp = dict(pstate.get("last_pushed") or {})
            em = dict(pstate.get("event_map") or {})
            ae = dict(pstate.get("app_edited_at") or {})
            for bid in push_forget:
                lp.pop(bid, None)
                ae.pop(bid, None)
            for bid in push_unmap:
                lp.pop(bid, None)
                ae.pop(bid, None)
                em.pop(bid, None)
            pstate["last_pushed"] = lp
            pstate["event_map"] = em
            pstate["app_edited_at"] = ae
            pstate_dirty = True
        if overlay_updates:
            st = load_state()
            ed = st.get("edits") or {}
            for bid, vals in overlay_updates.items():
                if bid in ed:
                    ed[bid].update(vals)
            st["edits"] = ed
            save_state(st)
        if pstate_dirty:
            save_push_state(pstate)
        save_programme(prog)
        append_calendar_log(source_label, summary, log)
    return summary


# ---------- Calendar config + log ----------
def load_calendar_config():
    data, _ = read_json_file(CALENDAR_CONFIG_FILE)
    if isinstance(data, dict):
        data.setdefault("log", [])
        return data
    return {"ics_url": "", "interval_minutes": 30, "enabled": False,
            "last_sync": None, "last_error": None, "last_summary": None,
            "log": []}


def save_calendar_config(cfg):
    atomic_write_json(CALENDAR_CONFIG_FILE, cfg)


def masked_ics_url(url):
    url = (url or "").strip()
    if not url:
        return ""
    m = re.match(r"^(https?://[^/]+/).*$", url)
    if not m:
        return "•••"
    # Only the scheme + host: the path carries the private token, and
    # even its last 8 characters are part of that secret.
    return m.group(1) + "•••"


def masked_calendar_config(cfg):
    return {"configured": bool((cfg.get("ics_url") or "").strip()),
            "enabled": bool(cfg.get("enabled")),
            "ics_url_masked": masked_ics_url(cfg.get("ics_url") or ""),
            "interval_minutes": int(cfg.get("interval_minutes") or 30),
            "last_sync": cfg.get("last_sync"),
            "last_error": cfg.get("last_error"),
            "last_summary": cfg.get("last_summary")}


def append_calendar_log(source, summary, lines):
    cfg = load_calendar_config()
    log = cfg.get("log") or []
    log.append({"ts": iso_now(), "source": source, "summary": summary,
                "lines": (lines or [])[:60]})
    cfg["log"] = log[-CALENDAR_LOG_MAX:]
    try:
        save_calendar_config(cfg)
    except Exception as exc:
        print("Could not save calendar log: {}".format(exc))


def calendar_status_payload():
    cfg = load_calendar_config()
    prog = load_programme()
    return {"config": masked_calendar_config(cfg),
            "programme": {"box_count": len(prog.get("boxes") or []),
                          "mapped": len(prog.get("uid_map") or {}),
                          "tombstones": len(prog.get("tombstone_uids") or []),
                          "last_source": (prog.get("meta") or {}).get("last_source")},
            "log": (cfg.get("log") or [])[-20:],
            "oauth": masked_oauth_status(),
            "push": push_status_payload()}


# ---------- Google Calendar two-way sync (Part B, v1.11.0) ----------
# OAuth 2.0 (Desktop-app client «StudyFlow Desktop», Google Cloud project
# «StudyFlow»). The Client ID is pre-filled as a default (a public
# identifier, not a secret); the Client Secret is pasted once by the user in
# settings. The secret is REQUIRED for this client: verified 2026-11-24
# against the real token endpoint — without it Google answers 400
# invalid_request «client_secret is missing». The sign-in uses PKCE
# (RFC 8252, code_challenge_method=S256) on top of the secret.
# Client Secret + access/refresh tokens live ONLY in the data dir
# (google_oauth.json) and are never sent to the browser; the UI only ever
# sees masked values. Google endpoints are overridable through env vars
# (GOOGLE_OAUTH_AUTH_URL / GOOGLE_OAUTH_TOKEN_URL / GOOGLE_OAUTH_REVOKE_URL /
# GOOGLE_CALENDAR_API_BASE) so tests can point the server at a local fake
# Google; production defaults are the real Google URLs.
GOOGLE_OAUTH_FILE = os.path.join(DATA_DIR, "google_oauth.json")
GOOGLE_PUSH_FILE = os.path.join(DATA_DIR, "google_push_state.json")
GOOGLE_AUTH_URL = os.environ.get(
    "GOOGLE_OAUTH_AUTH_URL", "https://accounts.google.com/o/oauth2/v2/auth")
GOOGLE_TOKEN_URL = os.environ.get(
    "GOOGLE_OAUTH_TOKEN_URL", "https://oauth2.googleapis.com/token")
GOOGLE_REVOKE_URL = os.environ.get(
    "GOOGLE_OAUTH_REVOKE_URL", "https://oauth2.googleapis.com/revoke")
GOOGLE_API_BASE = os.environ.get(
    "GOOGLE_CALENDAR_API_BASE", "https://www.googleapis.com/calendar/v3")
GOOGLE_REDIRECT_URI = "http://127.0.0.1:8765/oauth/callback"
GOOGLE_SCOPE = "https://www.googleapis.com/auth/calendar.events"
# The StudyFlow Desktop OAuth client (Google Cloud project «StudyFlow»).
# A client ID is a public identifier, not a secret, so it ships as the
# default — the user only ever has to paste the Client Secret once.
DEFAULT_GOOGLE_CLIENT_ID = ("695272599724-cv1g08aem3ajt079bj11dfdb96c1ibsg"
                            ".apps.googleusercontent.com")


class GoogleNotFound(ValueError):
    """A Google event that no longer exists (404/410)."""


def load_oauth():
    data, _ = read_json_file(GOOGLE_OAUTH_FILE)
    if isinstance(data, dict):
        # Backfill the default Client ID for installs that saved an empty
        # one before it existed (e.g. a cleared-credentials file).
        if not (data.get("client_id") or "").strip():
            data["client_id"] = DEFAULT_GOOGLE_CLIENT_ID
        return data
    return {"client_id": DEFAULT_GOOGLE_CLIENT_ID, "client_secret": "",
            "access_token": "", "refresh_token": "", "expires_at": 0,
            "account_email": "", "connected_at": "", "last_error": None,
            "pending_state": "", "pending_state_ts": 0,
            "pending_verifier": ""}


def save_oauth(cfg):
    atomic_write_json(GOOGLE_OAUTH_FILE, cfg)


def masked_oauth_status():
    cfg = load_oauth()
    cid = (cfg.get("client_id") or "").strip()
    return {"credentials_set": bool(cid and (cfg.get("client_secret") or "").strip()),
            "client_id_masked": masked_key(cid) if cid else "",
            "connected": bool((cfg.get("access_token") or "").strip()),
            "email": cfg.get("account_email") or "",
            "expires_at": int(cfg.get("expires_at") or 0),
            "connected_at": cfg.get("connected_at") or "",
            "last_error": cfg.get("last_error")}


def load_push_state():
    data, _ = read_json_file(GOOGLE_PUSH_FILE)
    if isinstance(data, dict):
        data.setdefault("event_map", {})
        data.setdefault("ical_map", {})
        data.setdefault("created_event_ids", [])
        data.setdefault("app_edited_at", {})
        data.setdefault("last_pushed", {})
        data.setdefault("pending", [])
        data.setdefault("conflicts", [])
        data.setdefault("last_push", None)
        # done_synced (v1.11.7): boxId -> the done value Google last had
        # (True/False). The loop-prevention record for the two-way done
        # sync: a push PATCHes only when local != done_synced, and a pull
        # applies Google's flag only when local == done_synced (or the
        # box was never synced — first sync, Google wins).
        data.setdefault("done_synced", {})
        return data
    return {"event_map": {}, "ical_map": {}, "created_event_ids": [],
            "app_edited_at": {}, "last_pushed": {}, "pending": [],
            "conflicts": [], "last_push": None, "done_synced": {}}


def save_push_state(ps):
    with STATE_LOCK:
        atomic_write_json(GOOGLE_PUSH_FILE, ps)


def _invalidate_push_tracking():
    """After a state/programme restore the push bookkeeping (what Google
    last had, what the app edited, what is pending) describes content
    that no longer exists — clear it so the next push re-syncs from the
    restored values instead of PATCHing stale ones. The event map
    (box -> Google event id) is kept: box ids survive a restore."""
    with STATE_LOCK:
        ps = load_push_state()
        ps["last_pushed"] = {}
        ps["app_edited_at"] = {}
        ps["pending"] = []
        save_push_state(ps)


def push_status_payload():
    ps = load_push_state()
    cfg = load_oauth()
    return {"connected": bool((cfg.get("access_token") or "").strip()),
            "pending_count": len(ps.get("pending") or []),
            "pending": (ps.get("pending") or [])[:20],
            "last_push": ps.get("last_push"),
            "conflicts": (ps.get("conflicts") or [])[-5:],
            "mapped_events": len(ps.get("event_map") or {})}


def _google_request(method, url, headers=None, data=None):
    """One raw HTTPS call to Google. Returns (status, parsed_json).
    Network failures raise ValueError with a Persian message."""
    req = urllib.request.Request(url, data=data, headers=headers or {}, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read()
            if not raw:
                return resp.status, {}
            try:
                return resp.status, json.loads(raw.decode("utf-8"))
            except Exception:
                return resp.status, {"_raw": raw.decode("utf-8", "replace")}
    except urllib.error.HTTPError as exc:
        raw = exc.read()
        try:
            body = json.loads(raw.decode("utf-8"))
        except Exception:
            body = {"error": {"message": raw.decode("utf-8", "replace")[:300]}}
        return exc.code, body
    except Exception as exc:
        raise ValueError("ارتباط با گوگل ممکن نشد: {}".format(exc))


def _google_error_message(data, status):
    msg = ""
    err = data.get("error") if isinstance(data, dict) else None
    if isinstance(err, dict):
        msg = str(err.get("message") or "")
    elif isinstance(err, str):
        msg = err
    if not msg:
        msg = str(data)[:200]
    return "خطای گوگل ({}): {}".format(status, msg)


def _token_expired(cfg):
    if not (cfg.get("access_token") or "").strip():
        return True
    exp = int(cfg.get("expires_at") or 0)
    if not exp:
        return True
    return exp - 60 < int(time.time())


def refresh_access_token():
    """Exchange the stored refresh token for a fresh access token."""
    cfg = load_oauth()
    rt = (cfg.get("refresh_token") or "").strip()
    cid = (cfg.get("client_id") or "").strip()
    csec = (cfg.get("client_secret") or "").strip()
    if not rt or not cid or not csec:
        raise ValueError("توکن گوگل منقضی شده و توکن تمدید نیست — دوباره متصل شو")
    body = urllib.parse.urlencode({
        "grant_type": "refresh_token", "refresh_token": rt,
        "client_id": cid, "client_secret": csec}).encode("utf-8")
    status, data = _google_request(
        "POST", GOOGLE_TOKEN_URL,
        {"Content-Type": "application/x-www-form-urlencoded"}, body)
    if status >= 400:
        raise ValueError(_google_error_message(data, status))
    cfg["access_token"] = str(data.get("access_token") or "")
    if data.get("refresh_token"):
        cfg["refresh_token"] = str(data.get("refresh_token"))
    cfg["expires_at"] = int(time.time()) + int(data.get("expires_in") or 3600) - 30
    cfg["last_error"] = None
    save_oauth(cfg)
    return cfg


def google_api(method, path, body=None):
    """One Calendar API call with automatic token refresh on 401.
    Raises ValueError (Persian) or GoogleNotFound on failure."""
    cfg = load_oauth()
    if not (cfg.get("access_token") or "").strip():
        raise ValueError("گوگل متصل نیست — اول «اتصال به گوگل» را بزن")
    if _token_expired(cfg):
        cfg = refresh_access_token()
    token = (cfg.get("access_token") or "").strip()
    payload = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
    headers = {"Authorization": "Bearer " + token}
    if payload is not None:
        headers["Content-Type"] = "application/json; charset=utf-8"
    status, data = _google_request(method, GOOGLE_API_BASE + path, headers, payload)
    if status == 401:
        cfg = refresh_access_token()
        token = (cfg.get("access_token") or "").strip()
        headers["Authorization"] = "Bearer " + token
        status, data = _google_request(method, GOOGLE_API_BASE + path, headers, payload)
        if status == 401:
            raise ValueError("توکن گوگل رد شد — دوباره متصل شو")
    if status in (404, 410):
        raise GoogleNotFound(_google_error_message(data, status))
    if status >= 400:
        raise ValueError(_google_error_message(data, status))
    return data


def _pkce_verifier():
    """RFC 7636 code_verifier: 43 URL-safe chars from 32 random bytes."""
    return base64.urlsafe_b64encode(
        secrets.token_bytes(32)).rstrip(b"=").decode("ascii")


def _pkce_challenge(verifier):
    """RFC 7636 S256 code_challenge for a verifier."""
    return base64.urlsafe_b64encode(
        hashlib.sha256(verifier.encode("ascii")).digest()
        ).rstrip(b"=").decode("ascii")


def build_auth_url():
    """The Google sign-in URL the browser opens. The random state and the
    PKCE verifier are stored server-side and checked/sent in
    /oauth/callback. Google requires the Client Secret for this Desktop
    client even with PKCE, so connecting needs it saved first."""
    cfg = load_oauth()
    cid = (cfg.get("client_id") or "").strip()
    csec = (cfg.get("client_secret") or "").strip()
    if not cid or not csec:
        raise ValueError("اول Client Secret را ذخیره کن")
    state = secrets.token_urlsafe(24)
    verifier = _pkce_verifier()
    cfg["pending_state"] = state
    cfg["pending_state_ts"] = int(time.time())
    cfg["pending_verifier"] = verifier
    save_oauth(cfg)
    q = urllib.parse.urlencode({
        "client_id": cid, "redirect_uri": GOOGLE_REDIRECT_URI,
        "response_type": "code", "scope": GOOGLE_SCOPE,
        "access_type": "offline", "prompt": "consent",
        "include_granted_scopes": "true", "state": state,
        "code_challenge": _pkce_challenge(verifier),
        "code_challenge_method": "S256"})
    return GOOGLE_AUTH_URL + "?" + q


def exchange_code(code, state):
    """Exchange the callback code for tokens and remember the account email
    (the primary calendar's id IS the Google account email). Sends both
    the PKCE code_verifier and the Client Secret: Google enforces the
    secret for Desktop-app clients (verified 2026-11-24: without it the
    token endpoint answers 400 invalid_request «client_secret is missing»)."""
    cfg = load_oauth()
    pending = cfg.get("pending_state") or ""
    pts = int(cfg.get("pending_state_ts") or 0)
    if not pending or state != pending or time.time() - pts > 600:
        raise ValueError("درخواست ورود معتبر نیست یا منقضی شده — دوباره «اتصال به گوگل» را بزن")
    cid = (cfg.get("client_id") or "").strip()
    csec = (cfg.get("client_secret") or "").strip()
    verifier = (cfg.get("pending_verifier") or "").strip()
    body = urllib.parse.urlencode({
        "grant_type": "authorization_code", "code": code,
        "redirect_uri": GOOGLE_REDIRECT_URI,
        "client_id": cid, "client_secret": csec,
        "code_verifier": verifier}).encode("utf-8")
    status, data = _google_request(
        "POST", GOOGLE_TOKEN_URL,
        {"Content-Type": "application/x-www-form-urlencoded"}, body)
    if status >= 400:
        raise ValueError(_google_error_message(data, status))
    cfg["access_token"] = str(data.get("access_token") or "")
    cfg["refresh_token"] = str(data.get("refresh_token") or "")
    cfg["expires_at"] = int(time.time()) + int(data.get("expires_in") or 3600) - 30
    cfg["pending_state"] = ""
    cfg["pending_state_ts"] = 0
    cfg["pending_verifier"] = ""
    cfg["connected_at"] = iso_now()
    cfg["last_error"] = None
    save_oauth(cfg)
    try:
        me = google_api("GET", "/users/me/calendarList/primary")
        cfg = load_oauth()
        cfg["account_email"] = str(me.get("id") or "")
        save_oauth(cfg)
    except Exception as exc:
        print("Could not fetch Google account email: {}".format(exc))
    return cfg


def revoke_google_tokens():
    """Revoke the token at Google (best effort) and clear stored tokens.
    Client ID/secret are kept so reconnecting is one click."""
    cfg = load_oauth()
    token = (cfg.get("refresh_token") or cfg.get("access_token") or "").strip()
    if token:
        try:
            body = urllib.parse.urlencode({"token": token}).encode("utf-8")
            _google_request("POST", GOOGLE_REVOKE_URL,
                            {"Content-Type": "application/x-www-form-urlencoded"}, body)
        except Exception as exc:
            print("Google revoke failed (ignored): {}".format(exc))
    cfg["access_token"] = ""
    cfg["refresh_token"] = ""
    cfg["expires_at"] = 0
    cfg["account_email"] = ""
    cfg["connected_at"] = ""
    save_oauth(cfg)


def _next_day_iso(d):
    return (datetime.strptime(d, "%Y-%m-%d").date() + timedelta(days=1)).isoformat()


def _api_event_date(part):
    """Jalali-free date (YYYY-MM-DD) from a Calendar API start/end part."""
    dt = str(part.get("dateTime") or "")
    if dt:
        return dt[:10]
    return str(part.get("date") or "")


def _api_event_time(part):
    """HH:MM from a Calendar API start/end part ('' for all-day events)."""
    dt = str(part.get("dateTime") or "")
    return dt[11:16] if dt else ""


def _api_event_done(item):
    """Done flag from the event's extended properties
    (studyflow.done = "1"/"0"), or None when the event carries none —
    no flag means "no information", never "not done"."""
    props = item.get("extendedProperties") or {}
    priv = props.get("private") or {}
    val = str(priv.get("studyflow.done") or "").strip().lower()
    if val in ("1", "true"):
        return True
    if val in ("0", "false"):
        return False
    return None


def _list_google_events(time_min, time_max):
    """List Google events in a window via the Calendar API (all pages).
    Returns {iCalUID: {id, title, date, start, end, done}} — the same
    shape the app's boxes use, so a live event can be compared with
    last_pushed; `done` is the studyflow.done extended property
    (True/False, or None when the event carries none)."""
    out = {}
    params = {"singleEvents": "true", "maxResults": 2500,
              "timeMin": time_min, "timeMax": time_max}
    page_token = None
    seen_tokens = set()
    for _ in range(20):  # capped: a runaway nextPageToken must end
        q = dict(params)
        if page_token:
            q["pageToken"] = page_token
        path = "/calendars/primary/events?" + urllib.parse.urlencode(q)
        data = google_api("GET", path)
        for item in data.get("items") or []:
            uid = str(item.get("iCalUID") or "")
            eid = str(item.get("id") or "")
            if not uid or not eid:
                continue
            out[uid] = {"id": eid, "title": str(item.get("summary") or ""),
                        "date": _api_event_date(item.get("start") or {}),
                        "start": _api_event_time(item.get("start") or {}),
                        "end": _api_event_time(item.get("end") or {}),
                        "done": _api_event_done(item)}
        page_token = data.get("nextPageToken")
        if not page_token or page_token in seen_tokens:
            break
        seen_tokens.add(page_token)
    return out


def refresh_event_id_map(time_min, time_max, base=None):
    """List events in a window and record iCalUID -> API event id.
    `base` (when given) is merged in first, so in-memory entries made
    earlier in the same push run are never lost. Returns the full map."""
    ps = load_push_state()
    imap = dict(base) if base is not None else dict(ps.get("ical_map") or {})
    for uid, ev in _list_google_events(time_min, time_max).items():
        imap[uid] = ev["id"]
    ps["ical_map"] = imap
    save_push_state(ps)
    return imap


@_with_lock
def sync_done_from_google():
    """Pull done flags from Google (extendedProperties studyflow.done) and
    apply them to state.done. Loop-safe: a local change since the last
    sync is never silently overwritten — when both sides changed, Google
    wins (the house rule) and the conflict is recorded; when the local
    side is unchanged since the last sync, Google's value is applied.
    Events with no flag carry no information and are skipped, so a box
    Google never heard about keeps its local status. Changing done status
    never deletes the event or its history. No-op when not connected.
    Returns (applied, conflicts)."""
    cfg = load_oauth()
    if not (cfg.get("access_token") or "").strip() \
            and not (cfg.get("refresh_token") or "").strip():
        return 0, 0
    try:
        first, last = _programme_range()
        live = _list_google_events(
            first.isoformat() + "T00:00:00+03:30",
            (last + timedelta(days=1)).isoformat() + "T00:00:00+03:30")
    except Exception as exc:
        print("Done-status pull failed: {}".format(exc))
        return 0, 0
    prog = load_programme()
    uid_map = dict(prog.get("uid_map") or {})
    state = load_state()
    ps = load_push_state()
    done = dict(state.get("done") or {})
    done_synced = dict(ps.get("done_synced") or {})
    applied = 0
    conflicts = 0
    conf_notes = []
    for uid, ev in live.items():
        bid = uid_map.get(uid)
        if not bid:
            continue
        gdone = ev.get("done")
        if gdone is None:
            continue
        # A local change waiting to be pushed (the box is in pending)
        # wins for now: the pull must not revert a tick the user just
        # made before the debounced push has sent it to Google.
        if bid in (ps.get("pending") or []):
            continue
        ldone = bool(done.get(bid))
        synced = done_synced.get(bid)
        if gdone == ldone:
            if synced != ldone:
                done_synced[bid] = ldone
            continue
        if synced is not None and ldone != synced:
            # Both sides changed since the last sync: Google wins.
            conflicts += 1
            conf_notes.append({"box_id": bid, "title": ev.get("title") or bid,
                               "ts": iso_now()})
        if gdone:
            done[bid] = True
        else:
            done.pop(bid, None)
        done_synced[bid] = gdone
        applied += 1
    if applied:
        state["done"] = done
        save_state(state)
    if applied or conf_notes or done_synced != (ps.get("done_synced") or {}):
        ps["done_synced"] = done_synced
        if conf_notes:
            conf = list(ps.get("conflicts") or [])
            seen_c = {c.get("box_id") for c in conf}
            for c in conf_notes:
                if c["box_id"] not in seen_c:
                    conf.append(c)
            ps["conflicts"] = conf[-20:]
        save_push_state(ps)
    return applied, conflicts


def seed_push_state_after_connect():
    """First-time setup after OAuth: build the iCalUID -> event-id map for
    the whole programme range and seed last_pushed from the PROGRAMME box
    values (raw, no app overlay) — so boxes the app never edited are not
    re-pushed, while app-edited boxes still differ from the seed and get
    pushed on the next push run."""
    try:
        first, last = _programme_range()
        refresh_event_id_map(first.isoformat() + "T00:00:00+03:30",
                             (last + timedelta(days=1)).isoformat() + "T00:00:00+03:30")
        prog = load_programme()
        ps = load_push_state()
        lp = dict(ps.get("last_pushed") or {})
        for b in prog.get("boxes") or []:
            bid = b.get("id")
            if bid and bid not in lp:
                lp[bid] = {"title": b.get("title"), "date": b.get("date"),
                           "start": b.get("start"), "end": b.get("end")}
        ps["last_pushed"] = lp
        save_push_state(ps)
    except Exception as exc:
        print("Push seed after connect failed: {}".format(exc))
        ps = load_push_state()
        ps["last_push"] = {"ts": iso_now(), "ok": False,
                           "error": "آماده‌سازی همگام‌سازی دوطرفه ممکن نشد: {}".format(exc),
                           "summary": None}
        save_push_state(ps)


def effective_boxes(prog, state):
    """{boxId: {title, date, start, end, uid, is_custom}} — what the user
    actually sees: programme boxes with the state.edits overlay, plus
    custom boxes. Deleted boxes are excluded."""
    deleted = set(state.get("deleted") or [])
    edits = state.get("edits") or {}
    uid_by_box = {}
    for uid, bid in (prog.get("uid_map") or {}).items():
        uid_by_box[bid] = uid
    out = {}
    for b in prog.get("boxes") or []:
        bid = b.get("id")
        if not bid or bid in deleted:
            continue
        ov = edits.get(bid) or {}
        out[bid] = {"title": ov.get("title", b.get("title")),
                    "date": ov.get("date", b.get("date")),
                    "start": ov.get("start", b.get("start")),
                    "end": ov.get("end", b.get("end")),
                    "uid": uid_by_box.get(bid), "is_custom": False}
    for cb in state.get("custom_boxes") or []:
        bid = cb.get("id")
        if not bid or bid in deleted:
            continue
        out[bid] = {"title": cb.get("title"), "date": cb.get("date"),
                    "start": cb.get("start"), "end": cb.get("end"),
                    "uid": None, "is_custom": True}
    return out


def _box_event_times(box):
    """(start_iso, end_iso) for a box, Asia/Tehran. An end at/before the
    start (e.g. 23:30-01:00) rolls to the next calendar day."""
    s = datetime.strptime("{} {}".format(box["date"], box["start"]),
                          "%Y-%m-%d %H:%M").replace(tzinfo=TEHRAN)
    e = datetime.strptime("{} {}".format(box["date"], box["end"]),
                          "%Y-%m-%d %H:%M").replace(tzinfo=TEHRAN)
    if e <= s:
        e += timedelta(days=1)
    return s.isoformat(timespec="seconds"), e.isoformat(timespec="seconds")


def _google_event_body(eff, done=None):
    """Event body for a create/PATCH. `done` (True/False) adds the
    studyflow.done extended property; None leaves it untouched."""
    s_iso, e_iso = _box_event_times(eff)
    body = {"summary": eff["title"],
            "start": {"dateTime": s_iso, "timeZone": "Asia/Tehran"},
            "end": {"dateTime": e_iso, "timeZone": "Asia/Tehran"}}
    if done is not None:
        body["extendedProperties"] = {"private": {"studyflow.done": "1" if done else "0"}}
    return body


def _resolve_event_id(imap, eff):
    """Google API event id for a mapped box, or None. Tries the stored map,
    then a one-day list refresh, then the iCalUID convention (Google-created
    events use <eventId>@google.com)."""
    uid = eff.get("uid")
    if not uid:
        return None
    if imap.get(uid):
        return imap[uid]
    try:
        d = eff["date"]
        fresh = refresh_event_id_map(d + "T00:00:00+03:30",
                                     _next_day_iso(d) + "T00:00:00+03:30",
                                     base=imap)
        imap.update(fresh)
        if imap.get(uid):
            return imap[uid]
    except Exception as exc:
        print("Event-id map refresh failed: {}".format(exc))
    if uid.endswith("@google.com"):
        return uid[:-len("@google.com")]
    return None


# ---------- Internal box API (v1.11.0) ----------
# Targeted endpoints for changing the programme calendar (create / update
# incl. move / delete a box). They mutate state EXACTLY the way the UI
# does — programme boxes via the state.edits overlay, new boxes via
# state.custom_boxes, deletions via state.deleted — then save through
# save_state + note_app_edits, so the debounced auto-push sees them just
# like a UI edit. The pull-sync path (merge_calendar_events) is NOT used
# here: it writes programme values FROM Google, and a bare programme edit
# would be overwritten by the next pull. Same localhost-only server
# (127.0.0.1), no auth change: anything that can reach the port can call
# these, exactly like /api/state.
_BOX_TIME_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")
_BOX_TEST_RE = re.compile(r"تست|تکلیف|آزمون")


def _box_field_error(date, start, end):
    if date is not None:
        try:
            datetime.strptime(date or "", "%Y-%m-%d")
        except Exception:
            return "تاریخ باید به شکل YYYY-MM-DD باشد"
    for t in (start, end):
        if t is not None and not _BOX_TIME_RE.match(t or ""):
            return "ساعت باید به شکل HH:MM باشد"
    return None


def _programme_box(prog, bid):
    for b in prog.get("boxes") or []:
        if b.get("id") == bid:
            return b
    return None


def _box_type(stored, title):
    """Effective activity type (v1.11.5): an explicit stored "class" /
    "normal" wins; otherwise the v1.8.0 title rule backfills it (title
    contains «کلاس» -> "class", else "normal"). Same rule as the client's
    boxIsClass() — the server and the UI must agree on every box."""
    if stored in ("class", "normal"):
        return stored
    return "class" if "کلاس" in (title or "") else "normal"


def _box_uid(prog, bid):
    """Stored Google Event ID (ICS uid) for a programme box, or None.
    This is the ONLY connection signal the UI may use — never a
    title/date guess (v1.11.9, spec §4)."""
    for u, b in (prog.get("uid_map") or {}).items():
        if b == bid:
            return u
    return None


def _public_box(prog, state, bid):
    """The box as the UI shows it: programme values + overlay, or the
    custom-box entry. None if the box does not exist or is deleted."""
    if bid in (state.get("deleted") or []):
        return None
    cb = next((b for b in (state.get("custom_boxes") or [])
               if b.get("id") == bid), None)
    if cb is not None:
        return {"id": cb.get("id"), "title": cb.get("title"),
                "subject": cb.get("subject"), "topic": cb.get("topic"),
                "date": cb.get("date"), "start": cb.get("start"),
                "end": cb.get("end"), "is_test": bool(cb.get("is_test")),
                "tests_total": cb.get("tests_total") or 0,
                "note": cb.get("note") or "", "is_custom": True,
                "uid": None, "connected": False,
                "type": _box_type(cb.get("type"), cb.get("title"))}
    pb = _programme_box(prog, bid)
    if pb is None:
        return None
    ov = (state.get("edits") or {}).get(bid) or {}
    uid = _box_uid(prog, bid)
    return {"id": pb.get("id"),
            "title": ov.get("title", pb.get("title")),
            "subject": ov.get("subject", pb.get("subject")),
            "topic": pb.get("topic"),
            "date": ov.get("date", pb.get("date")),
            "start": ov.get("start", pb.get("start")),
            "end": ov.get("end", pb.get("end")),
            "is_test": bool(pb.get("is_test")),
            "tests_total": (state.get("tests_total") or {}).get(
                bid, pb.get("tests_total") or 0),
            "note": ov.get("note", pb.get("note") or ""),
            "is_custom": False,
            "uid": uid, "connected": bool(uid) and not pb.get("orphaned"),
            "type": _box_type(ov.get("type", pb.get("type")),
                              ov.get("title", pb.get("title")))}


def _public_boxes_list(prog, state):
    """All public boxes in one pass (same shape as _public_box): the
    GET /api/boxes handler used to call _public_box per box, which
    re-scanned the programme + custom lists for every one of the 318."""
    eff = effective_boxes(prog, state)
    by_id = {b.get("id"): b for b in prog.get("boxes") or [] if b.get("id")}
    cb_by_id = {b.get("id"): b for b in (state.get("custom_boxes") or [])
                if b.get("id")}
    tests_total = state.get("tests_total") or {}
    edits = state.get("edits") or {}
    boxes = []
    for bid in sorted(eff, key=lambda b: (eff[b]["date"] or "",
                                          eff[b]["start"] or "", b)):
        e = eff[bid]
        if bid in cb_by_id:
            cb = cb_by_id[bid]
            boxes.append({"id": bid, "title": cb.get("title"),
                          "subject": cb.get("subject"), "topic": cb.get("topic"),
                          "date": cb.get("date"), "start": cb.get("start"),
                          "end": cb.get("end"), "is_test": bool(cb.get("is_test")),
                          "tests_total": cb.get("tests_total") or 0,
                          "note": cb.get("note") or "", "is_custom": True,
                          "uid": None, "connected": False,
                          "type": _box_type(cb.get("type"), cb.get("title"))})
        else:
            pb = by_id.get(bid)
            if pb is None:
                continue
            ov = edits.get(bid) or {}
            boxes.append({"id": bid,
                          "title": ov.get("title", pb.get("title")),
                          "subject": ov.get("subject", pb.get("subject")),
                          "topic": pb.get("topic"),
                          "date": ov.get("date", pb.get("date")),
                          "start": ov.get("start", pb.get("start")),
                          "end": ov.get("end", pb.get("end")),
                          "is_test": bool(pb.get("is_test")),
                          "tests_total": tests_total.get(
                              bid, pb.get("tests_total") or 0),
                          "note": ov.get("note", pb.get("note") or ""),
                          "is_custom": False,
                          "uid": e.get("uid"),
                          "connected": bool(e.get("uid")) and not pb.get("orphaned"),
                          "type": _box_type(ov.get("type", pb.get("type")),
                                            ov.get("title", pb.get("title")))})
    return boxes


def _box_api_note(old_state, saved):
    try:
        note_app_edits(old_state, saved)
    except Exception as exc:
        print("note_app_edits failed: {}".format(exc))


@_with_lock
def box_api_create(payload):
    """Create a custom box. Returns (http_status, payload)."""
    title = str(payload.get("title") or "").strip()
    if not title:
        return 400, {"error": "عنوان باکس خالی است"}
    date = str(payload.get("date") or "").strip()
    start = str(payload.get("start") or "09:00").strip()
    end = str(payload.get("end") or "10:30").strip()
    if not date:
        return 400, {"error": "تاریخ باکس خالی است"}
    err = _box_field_error(date, start, end)
    if err:
        return 400, {"error": err}
    subject = str(payload.get("subject") or "").strip()
    if not subject:
        subject = title.split(":")[0].split("—")[0].strip() or "عمومی"
    topic = str(payload.get("topic") or "").strip() or title
    is_test = payload.get("is_test")
    is_test = bool(_BOX_TEST_RE.search(title)) if is_test is None else bool(is_test)
    try:
        total = max(0, int(payload.get("tests_total") or 0))
    except Exception:
        return 400, {"error": "tests_total باید عدد باشد"}
    note = str(payload.get("note") or "")
    box_type = "class" if str(payload.get("type") or "").strip() == "class" else "normal"
    state = load_state()
    old_state = json.loads(json.dumps(state))
    nid = "custom-" + str(int(time.time() * 1000))
    existing = {b.get("id") for b in (state.get("custom_boxes") or [])}
    while nid in existing:
        nid += "x"
    nb = {"id": nid, "date": date, "start": start, "end": end,
          "subject": subject, "topic": topic, "title": title,
          "is_test": is_test, "tests_total": total, "note": note,
          "type": box_type}
    cbs = list(state.get("custom_boxes") or [])
    cbs.append(nb)
    state["custom_boxes"] = cbs
    saved = save_state(state)
    _box_api_note(old_state, saved)
    return 200, {"ok": True, "box": _public_box(load_programme(), saved, nid)}


@_with_lock
def box_api_update(payload):
    """Edit a box (title/subject/date/start/end/note/type); a new date/time
    IS the move. Programme boxes go through the edits overlay (same keys
    the UI's edit form writes); custom boxes are edited in place.
    Returns (http_status, payload)."""
    bid = str(payload.get("id") or "").strip()
    if not bid:
        return 400, {"error": "شناسه‌ی باکس خالی است"}
    prog = load_programme()
    state = load_state()
    if bid in (state.get("deleted") or []):
        return 404, {"error": "این باکس حذف شده است"}
    cb = next((b for b in (state.get("custom_boxes") or [])
               if b.get("id") == bid), None)
    pb = _programme_box(prog, bid) if cb is None else None
    if cb is None and pb is None:
        return 404, {"error": "باکسی با این شناسه پیدا نشد"}
    fields = {}
    for k in ("title", "subject", "note"):
        if payload.get(k) is not None:
            fields[k] = str(payload.get(k))
    for k in ("date", "start", "end"):
        if payload.get(k) is not None:
            fields[k] = str(payload.get(k)).strip()
    if "title" in fields and not fields["title"].strip():
        return 400, {"error": "عنوان باکس خالی است"}
    err = _box_field_error(fields.get("date"), fields.get("start"),
                           fields.get("end"))
    if err:
        return 400, {"error": err}
    if not fields and "is_test" not in payload \
            and "tests_total" not in payload and "topic" not in payload \
            and "type" not in payload:
        return 400, {"error": "هیچ فیلدی برای تغییر داده نشده است"}
    if cb is None and not fields and "tests_total" not in payload \
            and "type" not in payload:
        # Programme box: topic / is_test live on the programme box and
        # cannot change through the overlay — saying 200 while changing
        # nothing would lie to the caller.
        return 400, {"error": "topic و is_test برای باکس برنامه قابل تغییر نیستند"}
    old_state = json.loads(json.dumps(state))
    if cb is not None:
        for k in ("title", "subject", "topic", "date", "start", "end", "note"):
            if k in fields:
                cb[k] = fields[k]
        if payload.get("topic") is not None:
            cb["topic"] = str(payload.get("topic"))
        if "is_test" in payload:
            cb["is_test"] = bool(payload.get("is_test"))
        if "type" in payload:
            cb["type"] = "class" if str(payload.get("type") or "").strip() == "class" else "normal"
        if "tests_total" in payload:
            try:
                cb["tests_total"] = max(0, int(payload.get("tests_total")))
            except Exception:
                return 400, {"error": "tests_total باید عدد باشد"}
    else:
        # Programme box: the overlay carries exactly the keys the UI's
        # edit form writes (topic/is_test stay on the programme box).
        ov = dict((state.get("edits") or {}).get(bid) or {})
        for k in ("title", "subject", "date", "start", "end", "note"):
            if k in fields:
                ov[k] = fields[k]
        if "type" in payload:
            ov["type"] = "class" if str(payload.get("type") or "").strip() == "class" else "normal"
        state.setdefault("edits", {})[bid] = ov
        if "tests_total" in payload:
            try:
                state.setdefault("tests_total", {})[bid] = max(
                    0, int(payload.get("tests_total")))
            except Exception:
                return 400, {"error": "tests_total باید عدد باشد"}
    saved = save_state(state)
    _box_api_note(old_state, saved)
    return 200, {"ok": True, "box": _public_box(prog, saved, bid)}


@_with_lock
def box_api_delete(payload):
    """Delete a box: it goes to state.deleted (programme or custom —
    exactly like the UI's delete, and like the T7 e2e case). The push
    then deletes its Google event only if the app itself created it,
    and the merge tombstones its UID so the next pull never resurrects
    it. Returns (http_status, payload)."""
    bid = str(payload.get("id") or "").strip()
    if not bid:
        return 400, {"error": "شناسه‌ی باکس خالی است"}
    prog = load_programme()
    state = load_state()
    is_custom = any(b.get("id") == bid
                    for b in (state.get("custom_boxes") or []))
    if not is_custom and _programme_box(prog, bid) is None:
        return 404, {"error": "باکسی با این شناسه پیدا نشد"}
    deleted = list(state.get("deleted") or [])
    if bid in deleted:
        return 200, {"ok": True, "id": bid}
    old_state = json.loads(json.dumps(state))
    deleted.append(bid)
    state["deleted"] = deleted
    saved = save_state(state)
    _box_api_note(old_state, saved)
    return 200, {"ok": True, "id": bid}


def _box_has_user_data(state, bid):
    """Does this box hold any user data (ticks, tests, edits, minutes,
    links, assignments)? Used by reconnect: a duplicate box holding user
    data must NEVER be absorbed automatically (409 — the user chooses)."""
    if (state.get("done") or {}).get(bid):
        return True
    tr = (state.get("tests") or {}).get(bid) or {}
    if (tr.get("completed") or 0) > 0 or (tr.get("correct") or 0) > 0:
        return True
    if bid in (state.get("edits") or {}):
        return True
    if bid in (state.get("tests_total") or {}):
        return True
    if (state.get("actualMinutes") or {}).get(bid):
        return True
    if bid in (state.get("topicLinks") or {}):
        return True
    if bid in (state.get("boxBookLinks") or {}):
        return True
    if any((a or {}).get("boxId") == bid
           for a in (state.get("assignments") or [])):
        return True
    return False


def unlinked_calendar_payload():
    """Reconnect picker data: Google events from the last successful pull
    that no box is linked to, plus programme boxes with no Event ID.
    Both lists come from stored link data only — never from title/date
    similarity (v1.11.9, spec §4). Empty when no pull has run yet."""
    prog = load_programme()
    state = load_state()
    uid_map = prog.get("uid_map") or {}
    tomb_uids = set(prog.get("tombstone_uids") or [])
    deleted = set(state.get("deleted") or [])
    feed = ((prog.get("meta") or {}).get("last_feed") or [])
    linked = set(uid_map)
    unlinked_events = [dict(e) for e in feed
                       if e.get("uid") not in linked
                       and e.get("uid") not in tomb_uids]
    unlinked_boxes = [{"id": b.get("id"), "title": b.get("title"),
                       "date": b.get("date"), "start": b.get("start"),
                       "end": b.get("end"), "subject": b.get("subject"),
                       "orphaned": bool(b.get("orphaned"))}
                      for b in (prog.get("boxes") or [])
                      if b.get("id") not in deleted
                      and b.get("id") not in uid_map.values()]
    return {"unlinked_events": unlinked_events,
            "unlinked_boxes": unlinked_boxes,
            "last_feed_ts": (prog.get("meta") or {}).get("last_feed_ts")}


@_with_lock
def box_api_reconnect(payload):
    """Manually reconnect a programme box to an existing Google event
    (spec §3.4). The user picks the event — the server never guesses.
    The box takes the event's values (title/date/time), the orphaned
    flag clears, and the UID is stored. If another box already holds
    that UID: absorb it ONLY when it holds no user data (it was created
    by a pull); when it holds user data, refuse with 409 and let the
    user choose. Reconnecting the same box+uid twice is a no-op.
    A verified programme backup is taken BEFORE any mutation."""
    bid = str(payload.get("boxId") or "").strip()
    uid = str(payload.get("uid") or "").strip()
    if not bid:
        return 400, {"error": "شناسه‌ی باکس خالی است"}
    if not uid:
        return 400, {"error": "شناسه‌ی رویداد خالی است"}
    prog = load_programme()
    state = load_state()
    if bid in (state.get("deleted") or []):
        return 404, {"error": "این باکس حذف شده است"}
    if any(b.get("id") == bid for b in (state.get("custom_boxes") or [])):
        return 400, {"error": "باکس دستی به رویداد تقویم وصل نمی‌شود"}
    box = _programme_box(prog, bid)
    if box is None:
        return 404, {"error": "باکسی با این شناسه پیدا نشد"}
    feed = ((prog.get("meta") or {}).get("last_feed") or [])
    ev = next((e for e in feed if e.get("uid") == uid), None)
    if ev is None:
        return 400, {"error": "رویدادی با این شناسه در آخرین سینک پیدا نشد"}
    uid_map = dict(prog.get("uid_map") or {})
    if uid in (prog.get("tombstone_uids") or []):
        return 400, {"error": "این رویداد قبلاً در برنامه حذف شده است"}
    if uid_map.get(uid) == bid:
        # Idempotent: already linked — just make sure the flag is clear.
        changed = box.pop("orphaned", None) is not None
        if changed:
            save_programme(prog)
        return 200, {"ok": True, "already": True,
                     "box": _public_box(load_programme(), load_state(), bid)}
    # Backup BEFORE any mutation, and verify it (spec §7).
    entry = create_backup("programme", force=True)
    if entry is None or verify_backup_entry(entry) is None:
        return 500, {"error": "پشتیبان‌گیری قبل از اتصال ممکن نشد — هیچ تغییری اعمال نشد"}
    absorbed = None
    other_bid = uid_map.get(uid)
    if other_bid and other_bid != bid:
        other = _programme_box(prog, other_bid)
        if other is None:
            del uid_map[uid]  # stale mapping, drop it
        elif other_bid in (state.get("deleted") or []):
            # Already deleted by the user: absorb unconditionally.
            prog["boxes"] = [b for b in prog["boxes"]
                             if b.get("id") != other_bid]
            absorbed = other_bid
        elif _box_has_user_data(state, other_bid):
            return 409, {"error": "این رویداد به باکس «{}» وصل است که داده‌ی کاربر دارد — اول آن را حذف یا جابه‌جا کن".format(
                other.get("title") or other_bid),
                "other_box": {"id": other_bid, "title": other.get("title")}}
        else:
            # Duplicate created by a pull, no user data: absorb it.
            prog["boxes"] = [b for b in prog["boxes"]
                             if b.get("id") != other_bid]
            for k in ("done", "tests", "actualMinutes", "edits",
                      "tests_total", "topicLinks", "boxBookLinks"):
                if isinstance(state.get(k), dict):
                    state[k].pop(other_bid, None)
            if isinstance(state.get("assignments"), list):
                state["assignments"] = [a for a in state["assignments"]
                                        if (a or {}).get("boxId") != other_bid]
            absorbed = other_bid
    # Drop the box's previous link, if any (the old event is gone — that
    # is why the box was disconnected).
    for u, b in list(uid_map.items()):
        if b == bid and u != uid:
            del uid_map[u]
    # Apply the event's values to the box (the event is the authority;
    # the user explicitly chose this link) and clear the orphaned flag.
    subj, topic = derive_subject_topic(ev["title"])
    box["title"] = ev["title"]
    box["date"] = ev["date"]
    box["start"] = ev["start"]
    box["end"] = ev["end"]
    box["subject"] = subj
    box["topic"] = topic
    box["is_test"] = event_is_test(ev["title"])
    box.pop("orphaned", None)
    uid_map[uid] = bid
    prog["uid_map"] = uid_map
    # Reconcile the app-edit overlay, so it cannot mask the reconnect.
    ed = state.get("edits") or {}
    if bid in ed:
        ed[bid].update({"title": ev["title"], "date": ev["date"],
                        "start": ev["start"], "end": ev["end"]})
        state["edits"] = ed
    # Push bookkeeping: the box now matches the event, so the next push
    # has nothing to send for it; drop the old event-id mapping (it
    # resolves on demand) and the old done baseline.
    ps = load_push_state()
    lp = dict(ps.get("last_pushed") or {})
    lp[bid] = {"title": ev["title"], "date": ev["date"],
               "start": ev["start"], "end": ev["end"]}
    ps["last_pushed"] = lp
    ae = dict(ps.get("app_edited_at") or {})
    ae.pop(bid, None)
    ps["app_edited_at"] = ae
    em = dict(ps.get("event_map") or {})
    em.pop(bid, None)
    ps["event_map"] = em
    ds = dict(ps.get("done_synced") or {})
    ds.pop(bid, None)
    ps["done_synced"] = ds
    save_push_state(ps)
    save_state(state)
    save_programme(prog)
    return 200, {"ok": True, "absorbed": absorbed,
                 "box": _public_box(load_programme(), load_state(), bid)}


def push_to_google(manual=False):
    """Push app-side box changes to Google Calendar. Compares the effective
    boxes (programme + app edits + custom boxes) against last_pushed and
    only calls the API for what actually changed — and only when Google
    has not changed that box since the last pull: before PATCHing, the
    event's CURRENT values are read from Google, and a box Google moved
    first is skipped (the next pull then applies Google's version and
    drops the local edit, with a note). Deletions only touch Google
    events the app itself created. On any failure nothing is lost
    locally: the error is recorded in Persian and the push can be retried."""
    cfg = load_oauth()
    if not (cfg.get("access_token") or "").strip() \
            and not (cfg.get("refresh_token") or "").strip():
        return {"ok": False, "error": "گوگل متصل نیست — اول «اتصال به گوگل» را بزن"}
    try:
        prog = load_programme()
        state = load_state()
        ps = load_push_state()
        eff = effective_boxes(prog, state)
        deleted = set(state.get("deleted") or [])
        emap = dict(ps.get("event_map") or {})
        imap = dict(ps.get("ical_map") or {})
        created_ids = set(ps.get("created_event_ids") or [])
        last_pushed = dict(ps.get("last_pushed") or {})
        app_edited = dict(ps.get("app_edited_at") or {})
        pending = set(ps.get("pending") or [])
        done_synced = dict(ps.get("done_synced") or {})
        # Prune tracking for boxes that no longer exist anywhere.
        pending &= (set(eff) | deleted)
        for bid in list(app_edited):
            if bid not in eff and bid not in deleted:
                del app_edited[bid]
        created, updated, removed = 0, 0, 0
        errors = []
        prog_dirty = False
        uid_map = dict(prog.get("uid_map") or {})

        def eff_sig(e):
            return {"title": e["title"], "date": e["date"],
                    "start": e["start"], "end": e["end"]}

        # --- deletions: only events the app itself created ---
        for bid in sorted(deleted):
            if bid not in emap:
                last_pushed.pop(bid, None)
                app_edited.pop(bid, None)
                pending.discard(bid)
                done_synced.pop(bid, None)
                continue
            eid = emap[bid]
            if eid in created_ids:
                try:
                    google_api("DELETE", "/calendars/primary/events/"
                               + urllib.parse.quote(eid, safe=""))
                    removed += 1
                except GoogleNotFound:
                    removed += 1  # already gone on Google
                except Exception as exc:
                    errors.append("حذف «{}»: {}".format(bid, exc))
                    continue
                created_ids.discard(eid)
            emap.pop(bid, None)
            last_pushed.pop(bid, None)
            app_edited.pop(bid, None)
            pending.discard(bid)
            done_synced.pop(bid, None)

        # Live Google check (Google-wins rule): before PATCHing a box,
        # read the events' CURRENT values from Google. An app edit is
        # pushed only if Google has not changed that box since the last
        # pull. Fetched lazily — only when a real update is about to be
        # pushed — and only once per push run. If the live read fails,
        # updates are DEFERRED (kept pending for the next push) instead
        # of PATCHing blind on the last_pushed comparison.
        live = None  # None = not fetched yet, False = fetch failed

        def ensure_live():
            """Fetch the live event list once per push run (or False)."""
            nonlocal live
            if live is None:
                try:
                    first, last = _programme_range()
                    live = _list_google_events(
                        first.isoformat() + "T00:00:00+03:30",
                        (last + timedelta(days=1)).isoformat() + "T00:00:00+03:30")
                except Exception as exc:
                    print("Live Google check failed, pushing on last_pushed: {}".format(exc))
                    live = False
            return live

        def live_sig(uid):
            """Current Google {title, date, start, end} for a UID, or
            None if the event is not in the live list, or "unknown" if
            the live read failed."""
            lv = ensure_live()
            if not lv:
                return "unknown"
            ev = lv.get(uid)
            if not ev:
                return None
            return {"title": ev["title"], "date": ev["date"],
                    "start": ev["start"], "end": ev["end"]}

        def live_done(uid):
            """Current Google done flag for a UID (True/False), or None
            when the event is not in the live list or the live read
            failed. Used as the first-sync baseline for the done push."""
            lv = ensure_live()
            if not lv:
                return None
            ev = lv.get(uid)
            if not ev:
                return None
            return ev.get("done")

        def google_moved_first(bid, sig, uid):
            """True if Google changed this box after the last pull: the
            live event differs from BOTH last_pushed and the app's edit.
            No UID, an event missing from the live list, or a failed live
            read all mean 'cannot tell' -> False (push as before)."""
            if not uid:
                return False
            ls = live_sig(uid)
            if ls == "unknown" or ls is None:
                return False
            return ls != last_pushed.get(bid) and ls != sig

        # --- creates + updates ---
        for bid in sorted(eff):
            e = eff[bid]
            sig = eff_sig(e)
            done_local = bool((state.get("done") or {}).get(bid))
            if bid in emap:
                if last_pushed.get(bid) == sig:
                    pending.discard(bid)
                    continue
                eid = emap[bid]
                if e.get("uid") and live_sig(e.get("uid")) == "unknown":
                    # The live read failed: cannot tell whether Google
                    # moved this box first — defer the update (it stays
                    # pending) instead of PATCHing blind over Google.
                    errors.append("بررسی زنده‌ی تقویم ممکن نشد — ویرایش «{}» فرستاده نشد؛ در همگام‌سازی بعدی دوباره تلاش می‌شود".format(e["title"]))
                    continue
                if google_moved_first(bid, sig, e.get("uid")):
                    # Google changed this box after the last pull: do NOT
                    # overwrite it. The next pull applies Google's version
                    # and drops this local edit (with a note). Keep it
                    # pending so the push retries until the pull resolves it.
                    errors.append("«{}» در تقویم عوض شده بود — ویرایش برنامه فرستاده نشد؛ در همگام‌سازی بعدی نسخه‌ی تقویم اعمال می‌شود".format(e["title"]))
                    continue
                try:
                    google_api("PATCH", "/calendars/primary/events/"
                               + urllib.parse.quote(eid, safe=""),
                               _google_event_body(e, done=done_local))
                    updated += 1
                    done_synced[bid] = done_local
                except GoogleNotFound:
                    # Event vanished on Google: drop the mapping; the next
                    # pull re-adds the box if the event still exists.
                    emap.pop(bid, None)
                    last_pushed.pop(bid, None)
                    done_synced.pop(bid, None)
                    errors.append("رویداد «{}» در گوگل پیدا نشد — پیوندش برداشته شد".format(e["title"]))
                    continue
                except Exception as exc:
                    errors.append("به‌روز «{}»: {}".format(e["title"], exc))
                    continue
                last_pushed[bid] = sig
                app_edited.pop(bid, None)
                pending.discard(bid)
                continue
            if e["is_custom"]:
                # A box made in the app -> a brand-new Google event.
                try:
                    data = google_api("POST", "/calendars/primary/events",
                                      _google_event_body(e, done=done_local))
                except Exception as exc:
                    errors.append("ساخت «{}»: {}".format(e["title"], exc))
                    continue
                eid = str(data.get("id") or "")
                ical_uid = str(data.get("iCalUID") or "")
                if eid:
                    emap[bid] = eid
                    created_ids.add(eid)
                    if ical_uid:
                        imap[ical_uid] = eid
                        uid_map[ical_uid] = bid
                        prog_dirty = True
                    last_pushed[bid] = sig
                    done_synced[bid] = done_local
                    app_edited.pop(bid, None)
                    pending.discard(bid)
                    created += 1
                continue
            # A mapped programme box with no stored event id (e.g. mapped
            # before the OAuth connection): resolve it, then update.
            eid = _resolve_event_id(imap, e)
            if not eid:
                errors.append("رویداد «{}» در گوگل پیدا نشد".format(e["title"]))
                continue
            emap[bid] = eid
            if last_pushed.get(bid) == sig:
                pending.discard(bid)
                continue
            if google_moved_first(bid, sig, e.get("uid")):
                errors.append("«{}» در تقویم عوض شده بود — ویرایش برنامه فرستاده نشد؛ در همگام‌سازی بعدی نسخه‌ی تقویم اعمال می‌شود".format(e["title"]))
                continue
            try:
                google_api("PATCH", "/calendars/primary/events/"
                           + urllib.parse.quote(eid, safe=""),
                           _google_event_body(e, done=done_local))
                updated += 1
                done_synced[bid] = done_local
            except GoogleNotFound:
                emap.pop(bid, None)
                last_pushed.pop(bid, None)
                done_synced.pop(bid, None)
                errors.append("رویداد «{}» در گوگل پیدا نشد — پیوندش برداشته شد".format(e["title"]))
                continue
            except Exception as exc:
                errors.append("به‌روز «{}»: {}".format(e["title"], exc))
                continue
            last_pushed[bid] = sig
            app_edited.pop(bid, None)
            pending.discard(bid)

        # --- done-status push (v1.11.7): a tick/untick is not a shape
        # change, so the loop above never PATCHes it. Boxes whose local
        # done differs from what Google last had get their
        # extendedProperties patched (no other field touched). A box never
        # synced before uses Google's live flag as the baseline — no flag
        # means not done, so an unticked box needs no PATCH at all.
        # Loop-safe: a successful PATCH records the value in done_synced,
        # so the next pull (Google == local) applies nothing and the next
        # push PATCHes nothing.
        done_updated = 0
        for bid in sorted(eff):
            e = eff[bid]
            eid = emap.get(bid)
            if not eid:
                continue
            done_local = bool((state.get("done") or {}).get(bid))
            synced = done_synced.get(bid)
            if synced is None:
                ld = live_done(e.get("uid")) if e.get("uid") else None
                synced = ld if ld is not None else False
            if synced == done_local:
                done_synced[bid] = done_local
                continue
            try:
                google_api("PATCH", "/calendars/primary/events/"
                           + urllib.parse.quote(eid, safe=""),
                           {"extendedProperties": {"private": {"studyflow.done": "1" if done_local else "0"}}})
                done_synced[bid] = done_local
                done_updated += 1
                pending.discard(bid)
            except GoogleNotFound:
                emap.pop(bid, None)
                last_pushed.pop(bid, None)
                done_synced.pop(bid, None)
                errors.append("رویداد «{}» در گوگل پیدا نشد — پیوندش برداشته شد".format(e["title"]))
                continue
            except Exception as exc:
                pending.add(bid)
                errors.append("به‌روز وضعیت «{}»: {}".format(e["title"], exc))
                continue

        ps["event_map"] = emap
        ps["ical_map"] = imap
        ps["created_event_ids"] = sorted(created_ids)
        ps["last_pushed"] = last_pushed
        ps["app_edited_at"] = app_edited
        ps["pending"] = sorted(pending)
        ps["done_synced"] = done_synced
        summary = {"created": created, "updated": updated, "removed": removed,
                   "done_updated": done_updated,
                   "errors": errors[:10], "error_count": len(errors)}
        ps["last_push"] = {"ts": iso_now(), "ok": not errors, "summary": summary,
                           "error": errors[0] if errors else None}
        save_push_state(ps)
        if prog_dirty:
            prog["uid_map"] = uid_map
            save_programme(prog)
        return {"ok": not errors, "summary": summary}
    except Exception as exc:
        ps = load_push_state()
        ps["last_push"] = {"ts": iso_now(), "ok": False, "summary": None,
                           "error": str(exc)}
        save_push_state(ps)
        return {"ok": False, "error": str(exc)}


def note_app_edits(old_state, new_state):
    """After a state save: record which boxes changed (edit / custom box /
    delete / tick) with a timestamp, and queue a debounced auto-push.
    Ticks reach here too (a tick/untick queues a done-status push);
    test counts and real minutes never do — only box-shape changes and
    done changes do."""
    changed = set()
    old_edits = old_state.get("edits") or {}
    new_edits = new_state.get("edits") or {}
    for bid in set(old_edits) | set(new_edits):
        if old_edits.get(bid) != new_edits.get(bid):
            changed.add(bid)
    # Ticks (v1.11.7): a tick/untick is a done change — queue the box so
    # the debounced auto-push PATCHes its extendedProperties.
    old_done = old_state.get("done") or {}
    new_done = new_state.get("done") or {}
    for bid in set(old_done) | set(new_done):
        if bool(old_done.get(bid)) != bool(new_done.get(bid)):
            changed.add(bid)
    old_cb = {b["id"]: b for b in (old_state.get("custom_boxes") or []) if b.get("id")}
    new_cb = {b["id"]: b for b in (new_state.get("custom_boxes") or []) if b.get("id")}
    for bid in set(old_cb) | set(new_cb):
        if old_cb.get(bid) != new_cb.get(bid):
            changed.add(bid)
    changed |= (set(new_state.get("deleted") or []) - set(old_state.get("deleted") or []))
    if not changed:
        return
    with STATE_LOCK:
        ps = load_push_state()
        ea = dict(ps.get("app_edited_at") or {})
        now = time.time()
        for bid in changed:
            ea[bid] = now
        ps["app_edited_at"] = ea
        pend = set(ps.get("pending") or [])
        pend |= changed
        ps["pending"] = sorted(pend)
        save_push_state(ps)
    PUSH_SYNC.request()


class PushSync:
    """Debounced auto-push: runs ~15s after a state save that changed a box,
    so a burst of edits becomes one push. Same shape as the B2 CloudSync."""

    def __init__(self):
        self._event = threading.Event()
        self._immediate = threading.Event()

    def request(self, immediate=False):
        self._event.set()
        if immediate:
            self._immediate.set()

    def run(self):
        while True:
            self._event.wait(timeout=3600)
            self._event.clear()
            if self._immediate.is_set():
                self._immediate.clear()
            else:
                time.sleep(15)
            try:
                cfg = load_oauth()
                if not ((cfg.get("access_token") or "").strip()
                        or (cfg.get("refresh_token") or "").strip()):
                    continue
                # Nothing pending: the hourly wake is a no-op (pushing
                # with no changes only re-reads Google for nothing).
                if not (load_push_state().get("pending") or []):
                    continue
                push_to_google(manual=False)
            except Exception as exc:
                print("Calendar auto-push error: {}".format(exc))


PUSH_SYNC = PushSync()


# ---------- ICS fetch + sync runs ----------
def fetch_ics(url):
    # HTTPS only: the ICS URL carries the calendar's private token.
    if not str(url or "").strip().startswith("https://"):
        raise ValueError("آدرس ICS باید با https:// شروع شود")
    req = urllib.request.Request(
        url, headers={"User-Agent": "KonkurApp-CalendarSync/1.8"}, method="GET")
    with urllib.request.urlopen(req, timeout=CALENDAR_FETCH_TIMEOUT) as resp:
        raw = resp.read(CALENDAR_MAX_BYTES + 1)
    if len(raw) > CALENDAR_MAX_BYTES:
        raise ValueError("فایل ICS خیلی بزرگ است")
    return raw.decode("utf-8", "replace")


def run_calendar_sync(source_label):
    """Fetch the configured ICS URL and merge it. On any failure the last
    good programme is kept untouched and the error is recorded."""
    cfg = load_calendar_config()
    url = (cfg.get("ics_url") or "").strip()
    if not url:
        return {"ok": False, "error": "آدرس ICS تنظیم نشده است"}
    try:
        text = fetch_ics(url)
    except Exception as exc:
        err = "دریافت ICS ممکن نشد: {}".format(exc)
        cfg["last_error"] = err
        save_calendar_config(cfg)
        append_calendar_log(source_label, {"added": 0, "updated": 0, "removed": 0,
                                           "error": err}, [err])
        return {"ok": False, "error": err}
    try:
        raw = parse_ics(text)
    except Exception as exc:
        err = "خواندن ICS ممکن نشد: {}".format(exc)
        cfg["last_error"] = err
        save_calendar_config(cfg)
        return {"ok": False, "error": err}
    events, cancelled, counts = normalize_events(raw)
    if not events and not cancelled:
        err = "در فید هیچ رویداد درسی پیدا نشد — داده‌ی قبلی حفظ شد"
        cfg["last_error"] = err
        save_calendar_config(cfg)
        append_calendar_log(source_label, {"added": 0, "updated": 0, "removed": 0,
                                           "error": err}, [err])
        return {"ok": False, "error": err}
    summary = merge_calendar_events(events, cancelled, source_label, apply=True)
    summary["skipped"] = counts
    # Two-way done-status sync (v1.11.7): pull the done flags Google
    # carries (extendedProperties) and apply them to the dashboard.
    # Best-effort — a failed done pull never fails the ICS sync itself.
    try:
        done_applied, done_conflicts = sync_done_from_google()
        summary["done_applied"] = done_applied
        summary["done_conflicts"] = done_conflicts
    except Exception as exc:
        print("Done-status pull failed: {}".format(exc))
        summary["done_applied"] = 0
        summary["done_conflicts"] = 0
    cfg = load_calendar_config()
    cfg["last_sync"] = iso_now()
    cfg["last_error"] = None
    cfg["last_summary"] = summary
    save_calendar_config(cfg)
    return {"ok": True, "summary": summary, "counts": counts}


def run_calendar_import(content, filename, source_label, apply):
    """Parse uploaded file content (ICS or JSON) and merge it. With
    apply=False this is the preview: nothing is written and nothing is
    logged. Returns (ok, payload)."""
    name = (filename or "").lower()
    text = content or ""
    try:
        if name.endswith(".json") or text.lstrip()[:1] in ("{", "["):
            raw = parse_calendar_json(text)
            fmt = "json"
        else:
            raw = parse_ics(text)
            fmt = "ics"
    except ValueError as exc:
        return False, {"error": str(exc)}
    except Exception as exc:
        return False, {"error": "خواندن فایل ممکن نشد: {}".format(exc)}
    events, cancelled, counts = normalize_events(raw)
    if not events and not cancelled:
        return False, {"error": "در فایل هیچ رویداد درسی پیدا نشد"}
    summary = merge_calendar_events(events, cancelled, source_label, apply=apply,
                                   remove_missing=False)
    summary["skipped"] = counts
    if apply:
        cfg = load_calendar_config()
        cfg["last_sync"] = iso_now()
        cfg["last_error"] = None
        cfg["last_summary"] = summary
        save_calendar_config(cfg)
    return True, {"format": fmt, "summary": summary, "counts": counts}


CAL_SYNC_STATE = {"last_attempt": 0.0}


def calendar_sync_loop():
    """Background thread: auto-sync on the configured interval, plus one
    sync shortly after server start when a URL is configured."""
    time.sleep(5)
    while True:
        try:
            cfg = load_calendar_config()
            if cfg.get("enabled") and (cfg.get("ics_url") or "").strip():
                interval = max(5, int(cfg.get("interval_minutes") or 30)) * 60
                now = time.time()
                if now - CAL_SYNC_STATE["last_attempt"] >= interval:
                    CAL_SYNC_STATE["last_attempt"] = now
                    run_calendar_sync("auto")
        except Exception as exc:
            print("Calendar auto-sync error: {}".format(exc))
        time.sleep(60)



class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=PUBLIC, **kwargs)

    def log_message(self, fmt, *args):
        pass  # keep the console quiet

    def end_headers(self):
        # v1.11.4 — never let the browser cache app files: a stale
        # cached app.js after an update leaves buttons in fresh HTML
        # without handlers (and a stale i18n.js shows raw keys).
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def _send_json(self, status, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self):
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except Exception:
            return {}
        if length <= 0 or length > 10 * 1024 * 1024:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path  # match routes without the query string
        if parsed.path == "/oauth/callback":
            self._handle_oauth_callback(parsed)
            return
        if path in ("/api/health", "/api/health/"):
            self._send_json(200, {"ok": True, "port": PORT})
            return
        if path in ("/api/state", "/api/state/"):
            self._send_json(200, load_state())
            return
        if path in ("/api/testbook", "/api/testbook/"):
            self._send_json(200, load_testbook())
            return
        if path in ("/api/gemini-key", "/api/gemini-key/"):
            key = read_key()
            self._send_json(200, {"has_key": bool(key), "masked": masked_key(key)})
            return
        if path in ("/api/gemini-model", "/api/gemini-model/"):
            self._send_json(200, {"model": read_model()})
            return
        if path in ("/api/gemini-models", "/api/gemini-models/"):
            # Diagnostic for the 404: list the models THIS key can actually use.
            key = read_key()
            if not key:
                self._send_json(400, {"error": "کلید API جمینای معتبر نیست"})
                return
            req = urllib.request.Request(
                GEMINI_API_BASE + "/models?pageSize=100&key=" + key, method="GET")
            try:
                with urllib.request.urlopen(req, timeout=30) as resp:
                    result = json.loads(resp.read().decode("utf-8"))
            except urllib.error.HTTPError as exc:
                if exc.code in (400, 401, 403):
                    self._send_json(400, {"error": "کلید API جمینای معتبر نیست"})
                else:
                    self._send_json(502, {"error": "خطای سرور جمینای: HTTP " + str(exc.code)})
                return
            except Exception as exc:
                self._send_json(502, {"error": "ارتباط با جمینای برقرار نشد: " + str(exc)})
                return
            models = []
            for m in result.get("models", []) or []:
                name = str(m.get("name") or "")
                if name.startswith("models/"):
                    name = name[len("models/"):]
                methods = m.get("supportedGenerationMethods") or []
                if name and "generateContent" in methods:
                    # Full API metadata: the test panel shows the exact id,
                    # display name, version and context limits from Google.
                    models.append({
                        "id": name,
                        "displayName": str(m.get("displayName") or name),
                        "description": str(m.get("description") or ""),
                        "version": str(m.get("version") or ""),
                        "inputTokenLimit": m.get("inputTokenLimit"),
                        "outputTokenLimit": m.get("outputTokenLimit"),
                        "methods": methods,
                    })
            models.sort(key=lambda x: x["id"])
            self._send_json(200, {"models": models})
            return
        if path in ("/api/backup", "/api/backup/"):
            self._send_json(200, backup_status_payload())
            return
        if path in ("/api/backup/list", "/api/backup/list/"):
            versions = []
            for v in list_local_versions():
                versions.append(dict(v, verified=backup_entry_verified(v)))
            cloud = None
            cfg = load_b2_config()
            if cfg and cfg.get("enabled") and b2mod:
                try:
                    client = b2mod.B2Client(cfg)
                    manifest = client.get_json(CLOUD_MANIFEST_KEY) or {}
                    cloud = {"manifest": manifest}
                except Exception as exc:
                    cloud = {"error": str(exc)}
            self._send_json(200, {"versions": versions, "cloud": cloud})
            return
        if path in ("/api/backup/b2-config", "/api/backup/b2-config/"):
            self._send_json(200, masked_b2_config(load_b2_config()))
            return
        if path in ("/api/version", "/api/version/"):
            self._send_json(200, read_version())
            return
        if path in ("/api/update/status", "/api/update/status/"):
            self._send_json(200, {"version": read_version(),
                                  "backups": list_code_backups()})
            return
        if path in ("/api/update/auto", "/api/update/auto/"):
            cfg = load_update_config()
            self._send_json(200, {
                "config": {"manifest_url": cfg.get("manifest_url") or DEFAULT_MANIFEST_URL},
                "current": read_version(),
                "last_check": cfg.get("last_check"),
                "last_result": cfg.get("last_result"),
                "last_error": cfg.get("last_error"),
                "state": auto_update_status()})
            return
        if path in ("/api/update/auto-progress", "/api/update/auto-progress/"):
            self._send_json(200, auto_update_status())
            return
        if path in ("/data.json", "/data.json/"):
            try:
                prog, _ = read_json_file(CALENDAR_DATA_FILE)
                if isinstance(prog, dict) and isinstance(prog.get("boxes"), list):
                    # v1.11.9: attach the stored Google Event ID (uid) to
                    # each box, so the UI can show the REAL connection
                    # status (connected = has a uid and is not orphaned).
                    # uid_map is the only source of truth — never a
                    # title/date guess.
                    uid_by_box = {}
                    for u, bid in (prog.get("uid_map") or {}).items():
                        uid_by_box[bid] = u
                    boxes = []
                    for b in prog["boxes"]:
                        nb = dict(b)
                        nb["uid"] = uid_by_box.get(b.get("id"))
                        boxes.append(nb)
                    self._send_json(200, {"meta": prog.get("meta") or {},
                                          "boxes": boxes})
                    return
                with open(os.path.join(BASE, "data.json"), encoding="utf-8") as f:
                    data = json.load(f)
                self._send_json(200, data)
            except Exception as exc:
                self._send_json(500, {"error": str(exc)})
            return
        if path in ("/api/calendar/unlinked", "/api/calendar/unlinked/"):
            self._send_json(200, unlinked_calendar_payload())
            return
        if path in ("/api/calendar/status", "/api/calendar/status/"):
            self._send_json(200, calendar_status_payload())
            return
        if path in ("/api/calendar/config", "/api/calendar/config/"):
            self._send_json(200, masked_calendar_config(load_calendar_config()))
            return
        if path in ("/api/calendar/oauth/status", "/api/calendar/oauth/status/"):
            self._send_json(200, {"oauth": masked_oauth_status(),
                                  "push": push_status_payload()})
            return
        if path in ("/api/calendar/push-status", "/api/calendar/push-status/"):
            self._send_json(200, push_status_payload())
            return
        if path in ("/api/boxes", "/api/boxes/"):
            boxes = _public_boxes_list(load_programme(), load_state())
            self._send_json(200, {"boxes": boxes, "count": len(boxes)})
            return
        if path in ("/api/calendar/oauth/auth-url", "/api/calendar/oauth/auth-url/"):
            try:
                self._send_json(200, {"url": build_auth_url()})
            except Exception as exc:
                self._send_json(400, {"error": str(exc)})
            return
        super().do_GET()

    def _esc_html(self, s):
        return (str(s).replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace('"', "&quot;"))

    def _handle_oauth_callback(self, parsed):
        """Google redirects here after sign-in. Exchanges the code for
        tokens (server-side only) and shows a plain Persian result page."""
        qs = urllib.parse.parse_qs(parsed.query)
        code = (qs.get("code") or [""])[0]
        state = (qs.get("state") or [""])[0]
        err = (qs.get("error") or [""])[0]
        if err:
            ok, msg = False, "گوگل ورود را رد کرد: {}".format(err)
        elif not code:
            ok, msg = False, "کد ورود از گوگل نرسید — دوباره تلاش کن"
        else:
            try:
                cfg = exchange_code(code, state)
                email = cfg.get("account_email") or ""
                msg = "اتصال به گوگل برقرار شد" + (" ({})".format(email) if email else "") \
                    + " — می‌توانی این برگه را ببندی و به برنامه برگردی."
                ok = True
                threading.Thread(target=seed_push_state_after_connect, daemon=True).start()
            except Exception as exc:
                ok, msg = False, str(exc)
        heading = "اتصال برقرار شد" if ok else "اتصال ممکن نشد"
        page = ("<!DOCTYPE html><html lang=\"fa\" dir=\"rtl\"><head><meta charset=\"utf-8\">"
                "<title>StudyFlow — اتصال به گوگل</title>"
                "<style>body{font-family:tahoma,sans-serif;max-width:560px;margin:60px auto;"
                "padding:0 20px}h1{font-size:20px}p{line-height:1.9}</style></head><body>"
                "<h1>" + ("✅ " if ok else "⚠ ") + heading + "</h1><p>"
                + self._esc_html(msg) + "</p>"
                "<p><a href=\"/\">بازگشت به برنامه</a></p></body></html>")
        raw = page.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        # Match routes without the query string (a "?..." suffix used to
        # break every POST route that compared against self.path).
        path = urllib.parse.urlparse(self.path).path
        if path in ("/api/state", "/api/state/"):
            data = self._read_json()
            if not data:
                # Never let an empty/unreadable body wipe real data to defaults.
                self._send_json(400, {"error": "empty body"})
                return
            if not isinstance(data, dict):
                self._send_json(400, {"error": "bad body"})
                return
            with STATE_LOCK:
                old_state = load_state()
                # Merge onto the CURRENT state at top level only: a
                # partial body must never wipe progress (done/tests/...)
                # the client did not send. Nested objects are replaced
                # wholesale by the body (the client sends them whole;
                # an un-tick deletes keys, so no deep merge).
                merged = dict(old_state)
                merged.update(data)
                saved = save_state(merged)
                try:
                    note_app_edits(old_state, saved)
                except Exception as exc:
                    print("note_app_edits failed: {}".format(exc))
            self._send_json(200, saved)
            return
        if path in ("/api/boxes/create", "/api/boxes/create/"):
            data = self._read_json()
            status, payload = box_api_create(data or {})
            self._send_json(status, payload)
            return
        if path in ("/api/boxes/update", "/api/boxes/update/"):
            data = self._read_json()
            status, payload = box_api_update(data or {})
            self._send_json(status, payload)
            return
        if path in ("/api/boxes/delete", "/api/boxes/delete/"):
            data = self._read_json()
            status, payload = box_api_delete(data or {})
            self._send_json(status, payload)
            return
        if path in ("/api/boxes/reconnect", "/api/boxes/reconnect/"):
            data = self._read_json()
            status, payload = box_api_reconnect(data or {})
            self._send_json(status, payload)
            return
        if path in ("/api/testbook", "/api/testbook/"):
            data = self._read_json()
            if not data:
                self._send_json(400, {"error": "empty body"})
                return
            if not valid_testbook(data):
                self._send_json(400, {"error": "testbook نامعتبر است"})
                return
            saved = save_testbook(data)
            self._send_json(200, saved)
            return
        if path in ("/api/gemini-key", "/api/gemini-key/"):
            data = self._read_json()
            key = str(data.get("key") or "").strip()
            if not key:
                self._send_json(400, {"error": "کلید خالی است"})
                return
            atomic_write(KEY_FILE, key.encode("utf-8"))
            self._send_json(200, {"has_key": True, "masked": masked_key(key)})
            return
        if path in ("/api/gemini-model", "/api/gemini-model/"):
            data = self._read_json()
            model = str(data.get("model") or "").strip()
            if not valid_model(model):
                self._send_json(400, {"error": "نام مدل معتبر نیست"})
                return
            atomic_write(MODEL_FILE, model.encode("utf-8"))
            self._send_json(200, {"model": model})
            return
        if path in ("/api/backup/now", "/api/backup/now/"):
            create_backup("state", force=True)
            create_backup("testbook", force=True)
            create_backup("programme", force=True)
            CLOUD_SYNC.request(immediate=True)
            self._send_json(200, backup_status_payload())
            return
        if path in ("/api/backup/restore", "/api/backup/restore/"):
            data = self._read_json()
            kind = data.get("kind")
            fname = data.get("file") or ""
            if kind not in ("state", "testbook", "programme") or "/" in fname or "\\" in fname:
                self._send_json(400, {"error": "bad request"})
                return
            entry = None
            for v in list_local_versions(kind):
                if v.get("file") == fname:
                    entry = v
                    break
            if entry is None:
                self._send_json(404, {"error": "version not found"})
                return
            restored = verify_backup_entry(entry)
            if restored is None:
                self._send_json(400, {"error": "backup failed verification"})
                return
            if kind == "state":
                atomic_write_json(STATE_FILE, restored)
                with CLOUD_SYNC._lock:
                    CLOUD_SYNC.last_synced_sha["state"] = None
                _invalidate_push_tracking()
            elif kind == "programme":
                atomic_write_json(CALENDAR_DATA_FILE, restored)
                with CLOUD_SYNC._lock:
                    CLOUD_SYNC.last_synced_sha["programme"] = None
                _invalidate_push_tracking()
            else:
                atomic_write_json(TESTBOOK_FILE, restored)
                with CLOUD_SYNC._lock:
                    CLOUD_SYNC.last_synced_sha["testbook"] = None
            self._send_json(200, {"ok": True, "restored": entry["file"]})
            return
        if path in ("/api/backup/resolve-conflict", "/api/backup/resolve-conflict/"):
            # Explicit user choice after a cloud conflict: upload the LOCAL
            # version as the newest cloud snapshot. The remote versioned
            # object is never deleted, so both versions stay in the cloud.
            data = self._read_json()
            kind = data.get("kind")
            if kind not in ("state", "testbook"):
                self._send_json(400, {"error": "bad request"})
                return
            with CLOUD_SYNC._lock:
                if CLOUD_SYNC.conflict and CLOUD_SYNC.conflict.get("kind") == kind:
                    CLOUD_SYNC.conflict = None
                CLOUD_SYNC.last_synced_sha[kind] = None
            # Force the manifest to accept ours next sync: temporarily clear
            # the remote-newer check by uploading now, directly.
            if b2mod:
                cfg = load_b2_config()
                if cfg and cfg.get("enabled"):
                    try:
                        client = b2mod.B2Client(cfg)
                        manifest = client.get_json(CLOUD_MANIFEST_KEY) or {}
                        path = STATE_FILE if kind == "state" else TESTBOOK_FILE
                        with open(path, "rb") as f:
                            raw = f.read()
                        digest = sha256_bytes(raw)
                        ts = now_ts()
                        key = "{}-{}-{}.json".format(
                            kind, datetime.fromtimestamp(ts).strftime("%Y%m%d-%H%M%S"), digest[:8])
                        client.put_object(CLOUD_PREFIX + key, raw, "application/json")
                        manifest[kind] = {"key": CLOUD_PREFIX + key, "sha256": digest, "ts": ts}
                        manifest["updated_ts"] = ts
                        client.put_object(CLOUD_MANIFEST_KEY,
                                          json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8"),
                                          "application/json")
                        with CLOUD_SYNC._lock:
                            CLOUD_SYNC.last_synced_sha[kind] = digest
                            CLOUD_SYNC.last_sync = {"ts": now_ts(), "ts_iso": iso_now(),
                                                  "ok": True, "error": None}
                        self._send_json(200, {"ok": True, "uploaded": key})
                        return
                    except Exception as exc:
                        self._send_json(502, {"error": str(exc)})
                        return
            self._send_json(200, {"ok": True, "uploaded": None})
            return
        if path in ("/api/backup/restore-cloud", "/api/backup/restore-cloud/"):
            data = self._read_json()
            kind = data.get("kind")
            key = data.get("key") or ""
            if kind not in ("state", "testbook", "programme") or not key.startswith(CLOUD_PREFIX):
                self._send_json(400, {"error": "bad request"})
                return
            if not b2mod:
                self._send_json(500, {"error": "cloud module unavailable"})
                return
            cfg = load_b2_config()
            if not cfg or not cfg.get("enabled"):
                self._send_json(400, {"error": "cloud not configured"})
                return
            try:
                client = b2mod.B2Client(cfg)
                manifest = client.get_json(CLOUD_MANIFEST_KEY) or {}
                entry = manifest.get(kind) or {}
                if entry.get("key") != key:
                    self._send_json(404, {"error": "cloud version not found"})
                    return
                raw = client.get_object(key)
                if sha256_bytes(raw) != entry.get("sha256"):
                    self._send_json(400, {"error": "cloud version failed verification"})
                    return
                parsed = json.loads(raw.decode("utf-8"))
                if kind == "state" and not valid_state(parsed):
                    self._send_json(400, {"error": "cloud version failed verification"})
                    return
                if kind == "testbook" and not valid_testbook(parsed):
                    self._send_json(400, {"error": "cloud version failed verification"})
                    return
                if kind == "programme" and not (
                        isinstance(parsed, dict) and isinstance(parsed.get("boxes"), list)):
                    self._send_json(400, {"error": "cloud version failed verification"})
                    return
                if kind == "state":
                    atomic_write_json(STATE_FILE, parsed)
                    _invalidate_push_tracking()
                elif kind == "programme":
                    atomic_write_json(CALENDAR_DATA_FILE, parsed)
                    _invalidate_push_tracking()
                else:
                    atomic_write_json(TESTBOOK_FILE, parsed)
                with CLOUD_SYNC._lock:
                    CLOUD_SYNC.last_synced_sha[kind] = None
                    CLOUD_SYNC.conflict = None
                self._send_json(200, {"ok": True, "restored": key})
            except Exception as exc:
                self._send_json(502, {"error": str(exc)})
            return
        if path in ("/api/backup/b2-config", "/api/backup/b2-config/"):
            data = self._read_json()
            cfg = load_b2_config() or {}
            endpoint = str(data.get("endpoint") or cfg.get("endpoint") or
                           (b2mod.DEFAULT_ENDPOINT if b2mod else "")).strip()
            endpoint = re.sub(r"^https?://", "", endpoint).strip("/ ")
            key_id = str(data.get("key_id") or "").strip()
            app_key = str(data.get("application_key") or "").strip()
            bucket = str(data.get("bucket") or cfg.get("bucket") or "konkur-backup").strip()
            enabled = bool(data.get("enabled"))
            # Keep existing secrets when the form sends them back masked/empty.
            if not key_id and cfg.get("key_id"):
                key_id = cfg["key_id"]
            if not app_key and cfg.get("application_key"):
                app_key = cfg["application_key"]
            if enabled and (not key_id or not app_key):
                self._send_json(400, {"error": "key_id و application_key لازم است"})
                return
            new_cfg = {"endpoint": endpoint, "key_id": key_id,
                       "application_key": app_key, "bucket": bucket,
                       "enabled": enabled}
            save_b2_config(new_cfg)
            with CLOUD_SYNC._lock:
                CLOUD_SYNC.conflict = None
                CLOUD_SYNC.last_synced_sha = {"state": None, "testbook": None, "programme": None}
            if enabled:
                CLOUD_SYNC.request(immediate=True)
            self._send_json(200, masked_b2_config(new_cfg))
            return
        if path in ("/api/backup/b2-test", "/api/backup/b2-test/"):
            if not b2mod:
                self._send_json(500, {"error": "cloud module unavailable"})
                return
            cfg = load_b2_config()
            if not cfg or not cfg.get("key_id"):
                self._send_json(400, {"error": "B2 تنظیم نشده است"})
                return
            try:
                client = b2mod.B2Client(cfg)
                ok, err = client.test_connection()
                self._send_json(200, {"ok": ok, "error": err})
            except Exception as exc:
                self._send_json(200, {"ok": False, "error": str(exc)})
            return
        if path in ("/api/backup/b2-clear", "/api/backup/b2-clear/"):
            try:
                if os.path.exists(B2_CONFIG_FILE):
                    os.remove(B2_CONFIG_FILE)
            except Exception:
                pass
            with CLOUD_SYNC._lock:
                CLOUD_SYNC.conflict = None
                CLOUD_SYNC.last_synced_sha = {"state": None, "testbook": None, "programme": None}
            self._send_json(200, {"ok": True})
            return
        if path in ("/api/gemini", "/api/gemini/"):
            key = read_key()
            if not key:
                self._send_json(400, {"error": "کلید API جمینای معتبر نیست"})
                return
            data = self._read_json()
            prompt = str(data.get("prompt") or "").strip()
            if not prompt:
                self._send_json(400, {"error": "متن خالی است"})
                return
            r = _gemini_request(read_model(), prompt, timeout=60)
            if not r["ok"]:
                # Response shapes preserved exactly (the client checks for
                # "معتبر نیست" and "HTTP 404" in the error text).
                if r["kind"] == "auth":
                    self._send_json(400, {"error": "کلید API جمینای معتبر نیست"})
                elif r["kind"] == "network":
                    self._send_json(502, {"error": r["message"]})
                elif r["kind"] == "model" and r["code"] is None:
                    self._send_json(502, {"error": "جمینای پاسخی نداد"})
                elif r["code"]:
                    self._send_json(502, {"error": "خطای سرور جمینای: HTTP " + str(r["code"])})
                else:
                    self._send_json(502, {"error": r["message"]})
                return
            self._send_json(200, {"text": r["text"]})
            return
        if path in ("/api/gemini-test", "/api/gemini-test/"):
            # Live per-model test: one tiny, cheap request (max 8 output
            # tokens) to the named model with the stored key. Never changes
            # the default selected model. Returns latency + classified error.
            data = self._read_json()
            model = str(data.get("model") or "").strip()
            if not valid_model(model):
                self._send_json(400, {"error": "نام مدل معتبر نیست"})
                return
            t0 = time.time()
            r = _gemini_request(model, TEST_PROMPT, timeout=30,
                                max_tokens=TEST_MAX_TOKENS)
            latency_ms = int(round((time.time() - t0) * 1000))
            self._send_json(200, {
                "ok": r["ok"],
                "model": model,
                "latencyMs": latency_ms,
                "errorKind": r["kind"] or "",
                "errorMessage": "" if r["ok"] else r["message"],
            })
            return
        if path in ("/api/update/upload", "/api/update/upload/"):
            # Raw .zip bytes in the body (Content-Type: application/zip).
            try:
                length = int(self.headers.get("Content-Length") or 0)
            except Exception:
                length = 0
            if length <= 0 or length > MAX_UPDATE_ZIP_BYTES:
                self._send_json(400, {"error": "فایل zip خالی است یا خیلی بزرگ است"})
                return
            ensure_data_dir()
            os.makedirs(UPDATE_STAGING_DIR, exist_ok=True)
            staged = os.path.join(
                UPDATE_STAGING_DIR,
                "update-{}.zip".format(datetime.now().strftime("%Y%m%d-%H%M%S")))
            try:
                with open(staged, "wb") as f:
                    remaining = length
                    while remaining > 0:
                        chunk = self.rfile.read(min(65536, remaining))
                        if not chunk:
                            break
                        f.write(chunk)
                        remaining -= len(chunk)
            except Exception as exc:
                self._send_json(400, {"error": "دریافت فایل ممکن نشد: " + str(exc)})
                return
            version, backup, err = install_update_zip(staged)
            try:
                os.remove(staged)
            except Exception:
                pass
            if err:
                self._send_json(400, {"error": err})
                return
            self._send_json(200, {"ok": True, "version": version, "backup": backup})
            try:
                self.wfile.flush()
            except Exception:
                pass
            schedule_restart()
            return
        if path in ("/api/update/url", "/api/update/url/"):
            data = self._read_json()
            url = str(data.get("url") or "").strip()
            if not url.startswith("https://"):
                self._send_json(400, {"error": "لینک باید با https:// شروع شود"})
                return
            ensure_data_dir()
            os.makedirs(UPDATE_STAGING_DIR, exist_ok=True)
            staged = os.path.join(
                UPDATE_STAGING_DIR,
                "update-{}.zip".format(datetime.now().strftime("%Y%m%d-%H%M%S")))
            try:
                req = urllib.request.Request(url, method="GET",
                                             headers={"User-Agent": "KonkurApp-Updater"})
                with urllib.request.urlopen(req, timeout=60) as resp:
                    total = 0
                    with open(staged, "wb") as f:
                        while True:
                            chunk = resp.read(65536)
                            if not chunk:
                                break
                            total += len(chunk)
                            if total > MAX_UPDATE_ZIP_BYTES:
                                raise ValueError("فایل zip خیلی بزرگ است")
                            f.write(chunk)
            except ValueError as exc:
                self._send_json(400, {"error": str(exc)})
                return
            except Exception as exc:
                self._send_json(502, {"error": "دانلود فایل ممکن نشد: " + str(exc)})
                return
            version, backup, err = install_update_zip(staged)
            try:
                os.remove(staged)
            except Exception:
                pass
            if err:
                self._send_json(400, {"error": err})
                return
            self._send_json(200, {"ok": True, "version": version, "backup": backup})
            try:
                self.wfile.flush()
            except Exception:
                pass
            schedule_restart()
            return
        if path in ("/api/update/rollback", "/api/update/rollback/"):
            data = self._read_json()
            backups = list_code_backups()
            name = str(data.get("backup") or "").strip()
            if not name:
                if not backups:
                    self._send_json(400, {"error": "نسخه‌ی قبلی برای بازگشت وجود ندارد"})
                    return
                name = backups[0]["name"]
            ok, err = restore_code_backup(name)
            if not ok:
                self._send_json(400, {"error": err})
                return
            restored = None
            for b in backups:
                if b["name"] == name:
                    restored = b
                    break
            self._send_json(200, {"ok": True, "version": {
                "version": (restored or {}).get("version", "dev"),
                "build_date": (restored or {}).get("build_date", "")},
                "backup": restored})
            try:
                self.wfile.flush()
            except Exception:
                pass
            schedule_restart()
            return
        if path in ("/api/update/check", "/api/update/check/"):
            result = run_update_check()
            self._send_json(200 if result.get("ok") else 502, result)
            return
        if path in ("/api/update/auto-config", "/api/update/auto-config/"):
            data = self._read_json()
            url = str(data.get("manifest_url") or "").strip()
            if not url:
                url = DEFAULT_MANIFEST_URL
            if not url.startswith("https://"):
                self._send_json(400, {"error": "آدرس مانیفست باید با https:// شروع شود"})
                return
            cfg = load_update_config()
            cfg["manifest_url"] = url
            cfg["last_check"] = None
            cfg["last_result"] = None
            cfg["last_error"] = None
            save_update_config(cfg)
            self._send_json(200, {"manifest_url": url})
            return
        if path in ("/api/update/install-auto", "/api/update/install-auto/"):
            # The manifest is re-fetched fresh here — the client never
            # supplies the zip URL or hash, so a stale or tampered claim
            # cannot steer the install.
            if AUTO_UPDATE_ACTIVE["running"]:
                self._send_json(409, {"error": "یک به‌روزرسانی در حال انجام است"})
                return
            result = run_update_check()
            if not result.get("ok"):
                self._send_json(502, {"error": result.get("error") or "بررسی ممکن نشد"})
                return
            if result.get("blocked_min_version"):
                self._send_json(400, {"error": "این نسخه به نسخه‌ی {} یا جدیدتر نیاز دارد؛ اول به‌صورت دستی به‌روز کن".format(result["blocked_min_version"])})
                return
            if not result.get("update_available"):
                self._send_json(400, {"error": "به‌روز هستید"})
                return
            manifest = {"version": result["version"],
                        "zip_url": result["zip_url"],
                        "sha256": result["sha256"],
                        "notes": result.get("notes") or ""}
            AUTO_UPDATE_ACTIVE["running"] = True
            _auto_update_set(phase="downloading", percent=0, downloaded=0,
                             total=None, version=manifest["version"], error=None)
            threading.Thread(target=download_and_install_auto,
                             args=(manifest,), daemon=True).start()
            self._send_json(200, {"ok": True, "started": True,
                                  "version": manifest["version"]})
            return
        if path in ("/api/calendar/config", "/api/calendar/config/"):
            data = self._read_json()
            cfg = load_calendar_config()
            url = str(data.get("ics_url") or "").strip()
            if url and not url.startswith("https://"):
                self._send_json(400, {"error": "آدرس ICS باید با https:// شروع شود"})
                return
            try:
                interval = int(data.get("interval_minutes") or cfg.get("interval_minutes") or 30)
            except Exception:
                interval = 30
            interval = max(5, min(1440, interval))
            enabled = bool(data.get("enabled")) if "enabled" in data else bool(cfg.get("enabled"))
            if url:
                cfg["ics_url"] = url
            elif "ics_url" in data:
                cfg["ics_url"] = ""
            cfg["interval_minutes"] = interval
            cfg["enabled"] = enabled and bool(cfg.get("ics_url"))
            save_calendar_config(cfg)
            self._send_json(200, masked_calendar_config(cfg))
            return
        if path in ("/api/calendar/oauth/credentials", "/api/calendar/oauth/credentials/"):
            data = self._read_json()
            cfg = load_oauth()
            cid = str(data.get("client_id") or "").strip()
            csec = str(data.get("client_secret") or "").strip()
            if cid:
                cfg["client_id"] = cid
            if csec:
                cfg["client_secret"] = csec
            if not (cfg.get("client_id") or "").strip():
                self._send_json(400, {"error": "Client ID خالی است"})
                return
            save_oauth(cfg)
            self._send_json(200, masked_oauth_status())
            return
        if path in ("/api/calendar/oauth/clear-credentials", "/api/calendar/oauth/clear-credentials/"):
            try:
                revoke_google_tokens()
            except Exception:
                pass
            try:
                if os.path.exists(GOOGLE_OAUTH_FILE):
                    os.remove(GOOGLE_OAUTH_FILE)
            except Exception:
                pass
            self._send_json(200, masked_oauth_status())
            return
        if path in ("/api/calendar/oauth/disconnect", "/api/calendar/oauth/disconnect/"):
            revoke_google_tokens()
            self._send_json(200, masked_oauth_status())
            return
        if path in ("/api/calendar/push", "/api/calendar/push/"):
            result = push_to_google(manual=True)
            self._send_json(200 if result.get("ok") else 502, result)
            return
        if path in ("/api/calendar/sync", "/api/calendar/sync/"):
            result = run_calendar_sync("manual")
            self._send_json(200 if result.get("ok") else 502, result)
            return
        if path in ("/api/calendar/import-preview", "/api/calendar/import-preview/"):
            data = self._read_json()
            content = str(data.get("content") or "")
            if not content.strip():
                self._send_json(400, {"error": "فایل خالی است"})
                return
            ok, payload = run_calendar_import(
                content, str(data.get("filename") or ""), "import-preview", apply=False)
            self._send_json(200 if ok else 400, payload)
            return
        if path in ("/api/calendar/import", "/api/calendar/import/"):
            data = self._read_json()
            content = str(data.get("content") or "")
            if not content.strip():
                self._send_json(400, {"error": "فایل خالی است"})
                return
            ok, payload = run_calendar_import(
                content, str(data.get("filename") or ""), "import", apply=True)
            self._send_json(200 if ok else 400, payload)
            return
        if path in ("/api/calendar/clear", "/api/calendar/clear/"):
            try:
                if os.path.exists(CALENDAR_CONFIG_FILE):
                    os.remove(CALENDAR_CONFIG_FILE)
            except Exception:
                pass
            self._send_json(200, {"ok": True})
            return
        self._send_json(404, {"error": "not found"})


if __name__ == "__main__":
    ensure_data_dir()
    migrate_legacy_files()
    sync_thread = threading.Thread(target=CLOUD_SYNC.run, daemon=True)
    sync_thread.start()
    cal_thread = threading.Thread(target=calendar_sync_loop, daemon=True)
    cal_thread.start()
    push_thread = threading.Thread(target=PUSH_SYNC.run, daemon=True)
    push_thread.start()
    upd_check_thread = threading.Thread(target=update_startup_check, daemon=True)
    upd_check_thread.start()
    # Retry the bind: after a self-update restart the old process may still
    # be releasing the port when the new one starts.
    server = None
    last_exc = None
    for attempt in range(12):
        try:
            server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
            break
        except OSError as exc:
            last_exc = exc
            time.sleep(1)
    if server is None:
        print("Could not bind port {}: {}".format(PORT, last_exc))
        raise SystemExit(1)
    print("Konkur local site running at http://localhost:8765")
    print("Data directory: {}".format(DATA_DIR))
    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
