// Konkur local site — frontend logic.
// Data: data.json (318 real boxes). Test books: /api/testbook (v2: the four
// REAL books from the user's own TOCs — شیمی بتمن، حسابان IQ، فیزیک الگو،
// گسسته IQ — plus TESTBOOK.legacy for old topics with no new counterpart).
// State: /api/state on the local server (ticks, test counts, edits, subjects,
// theme, daysDone, topicLinks) saved to state.json on disk — in the DATA
// directory outside the app folder (%APPDATA%\KonkurApp on Windows), with
// automatic versioned backups + optional B2 cloud sync (see server.py).
// ONE source of truth: book topic numbers are COMPUTED at render time from
// state.tests (daily boxes) + testbook manual_solved. Nothing is stored twice.
// Exam-topic -> book-section links are MANUAL only: topic.bookLinks inside
// state.exams, set by the user in the exam budget view, never guessed.
"use strict";

const FA = (n) => fmtNum(n);
const FA_PCT = (x) => fmtPct(x);
// v1.11.43 (audit §16 item 21): Persian digits everywhere in the UI
// (except technical IDs). faDigits converts the Latin digits inside a
// DISPLAY string in fa mode (a no-op in en); fmtTimeFa formats a
// "HH:MM" clock time the same way. Input values and stored data are
// never passed through either — time inputs keep Latin "HH:MM".
const faDigits = (s) => LANG === "fa" ? String(s == null ? "" : s).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[+d]) : String(s == null ? "" : s);
const fmtTimeFa = (hm) => faDigits(hm);
// Short "H:MM" duration ("۴:۱۵") for the mini-hero and the week strip.
function fmtDurShort(mins) {
  mins = Math.max(0, Math.round(mins || 0));
  const h = Math.floor(mins / 60), m = mins % 60;
  return faDigits(h + ":" + String(m).padStart(2, "0"));
}

// Jalali: 1 Aban 1405 = 2026-10-23 (Friday); 1 Azar 1405 = 2026-11-22 (Sunday).
// Aban and Azar have 30 days each.
// v1.11.38 (P3-12): one Jalali reference — jalaliParts in i18n.js.
// gregToJalali is only a delegate to jalaliLabel (same {day, month,
// text} shape, full-range for every month); the old inline arithmetic
// is gone. examDateText still calls jalaliParts directly (v1.11.18).
function gregToJalali(dateStr) {
  return jalaliLabel(dateStr);
}
// ---------- Jalali text inputs (v1.11.41, UI-audit batch 1) ----------
// The form inputs show Jalali dates ("1405/09/04", Latin digits, LTR)
// and 24-hour times ("09:00") — the old Gregorian date / 12-hour time
// inputs forced the user to convert "۴ آذر" to "11/26/2026" by hand.
// Storage stays Gregorian ISO internally; only the input/display
// changes. Persian digits are accepted on input too.
function enDigits(s) {
  return String(s == null ? "" : s).replace(/[۰-۹]/g, d => "۰۱۲۳۴۵۶۷۸۹".indexOf(d))
    .replace(/[٠-٩]/g, d => "٠١٢٣٤٥٦٧٨٩".indexOf(d));
}
function jalaliInputText(iso) {
  if (!iso) return "";
  try {
    const p = jalaliParts(iso);
    return p.jy + "/" + String(p.jm).padStart(2, "0") + "/" + String(p.jd).padStart(2, "0");
  } catch (e) { return ""; }
}
function parseJalaliInput(str) {
  const s = enDigits(str).trim().replace(/[.\- ]/g, "/");
  const m = /^(\d{4})\/(\d{1,2})\/(\d{1,2})$/.exec(s);
  if (!m) return null;
  const jy = +m[1], jm = +m[2], jd = +m[3];
  if (jy < 1300 || jy > 1500 || jm < 1 || jm > 12) return null;
  if (jd < 1 || jd > jalaliMonthLength(jy, jm)) return null;
  try { return gregorianFromJalali(jy, jm, jd); } catch (e) { return null; }
}
function parseTime24(str) {
  const s = enDigits(str).trim();
  const m = /^(\d{1,2})(?::(\d{1,2}))?$/.exec(s);
  if (!m) return null;
  const h = +m[1], mi = m[2] == null ? 0 : +m[2];
  if (h < 0 || h > 23 || mi < 0 || mi > 59) return null;
  return String(h).padStart(2, "0") + ":" + String(mi).padStart(2, "0");
}
function weekdayFa(dateStr) { return weekdayName(dateStr); }
function isoOf(d) {
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}
function addDays(iso, n) {
  const d = new Date(iso + "T12:00:00"); d.setDate(d.getDate() + n); return isoOf(d);
}
// ---------- Study day (v1.9.0) ----------
// A study day runs 03:30:00 -> 03:29:59 the next day, Asia/Tehran.
// EVERY date-dependent part of the app goes through these helpers —
// nothing computes "today" or a day bucket on its own. (The one
// deliberate exception is the exam countdown: exams are calendar events
// with a clock time, so they count down from the real calendar date —
// see realTodayIso() below. No system clock or timezone is changed;
// this is application logic only, via Intl with timeZone Asia/Tehran.)
const STUDY_DAY_START_MIN = 3 * 60 + 30; // 03:30
function tehranParts(d) {
  const fmt = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Tehran", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" });
  const p = {};
  fmt.formatToParts(d).forEach(x => { p[x.type] = x.value; });
  return { iso: p.year + "-" + p.month + "-" + p.day, hh: +p.hour, mm: +p.minute };
}
// Study day of a timestamp: its Tehran calendar date when the time is
// >= 03:30, else the previous Tehran calendar date. Verified against the
// user's examples: 24 Aban 03:29 -> 23 Aban; 24 Aban 03:30 -> 24 Aban;
// 25 Aban 02:00 / 03:29 -> 24 Aban; 25 Aban 03:30 -> 25 Aban.
function studyDayOf(d) {
  const dt = d instanceof Date ? d : new Date(d);
  const p = tehranParts(dt);
  return (p.hh * 60 + p.mm) >= STUDY_DAY_START_MIN ? p.iso : addDays(p.iso, -1);
}
function timeToMinutes(t) {
  const parts = String(t || "00:00").split(":");
  return (parseInt(parts[0], 10) || 0) * 60 + (parseInt(parts[1], 10) || 0);
}
// v1.11.60 (M-DATA3): custom-box date/time validity — mirrors the
// server create path (strptime date + HH:MM regex). strptime accepts
// non-padded dates ("2026-2-3"), so the JS check accepts 1-2 digit
// month/day too — but the date must be a real calendar date.
function isValidBoxDate(s) {
  if (typeof s !== "string") return false;
  const m = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(s);
  if (!m) return false;
  const d = new Date(+m[1], +m[2] - 1, +m[3]);
  return d.getFullYear() === +m[1] && d.getMonth() === +m[2] - 1 && d.getDate() === +m[3];
}
function isValidBoxTime(s) {
  return typeof s === "string" && /^([01]\d|2[0-3]):[0-5]\d$/.test(s);
}
// Study day of a box: boxes carry a stored calendar date + start time.
// A box starting at/after 03:30 belongs to its calendar date; a box
// starting before 03:30 (e.g. 25 Aban 00:30) belongs to the day before
// (study day 24 Aban) — so it renders in that study day's view.
function boxStudyDay(b) {
  if (!b || !b.date) return null;
  return timeToMinutes(b.start) >= STUDY_DAY_START_MIN ? b.date : addDays(b.date, -1);
}
// Position of a clock time inside its STUDY day: 03:30 -> 0, 23:00 ->
// 1170, 00:30 -> 1260, 03:29 -> 1439. A box starting after midnight
// belongs to the END of its study day, not the beginning (v1.11.11:
// the old raw-clock sorts put a 00:30 box FIRST in its study day).
function studyDayMinutes(t) {
  return (timeToMinutes(t) - STUDY_DAY_START_MIN + 1440) % 1440;
}
// Canonical box order: study day first, then position inside the study
// day. Grouping is unchanged — boxStudyDay still decides which day a
// box belongs to; this only orders boxes within (and across) study days.
function compareBoxOrder(a, b) {
  const da = boxStudyDay(a) || a.date || "";
  const db = boxStudyDay(b) || b.date || "";
  return da.localeCompare(db) || studyDayMinutes(a.start) - studyDayMinutes(b.start);
}
// State defaults (declared before todayIso: todayIso() reads the
// programme range from state, and TODAY is initialized right below).
let state = { version: 1,
              // Programme range (audit §5 item 1.7): state fields, not
              // hardcoded constants — ends 2026-12-18 today, extendable
              // to next year when the user enters more programme.
              programme_start: "2026-10-24", programme_end: "2026-12-18",
              done: {}, tests: {}, tests_total: {}, subjects: [], theme: "dark", lang: "fa",
              custom_boxes: [], deleted: [], edits: {}, daysDone: {}, topicLinks: {},
              examResults: {},
              exams: null, examsRemoved: [], examsSeededIds: [],
              assignments: null, assignmentsRemoved: [],
              boxBookLinks: {},
              actualMinutes: {}, timerSessions: [], activeTimer: null,
              // v1.11.55 (F5): a running exam simulation, persisted so a
              // refresh resumes it — {examId, endsAt, rows} or null.
              sim: null,
              // v1.11.21: useful time (seconds, like actualMinutes) —
              // absent means "not recorded", never 0, never invented.
              usefulMinutes: {},
              // v1.11.20 (audit §5 items 3.2–3.4, 3.6b): timestamped test
              // entries, error notebook, spaced repetition, Gemini history.
              testLog: [], errorNotebook: {}, errorLog: [], chapterSR: {},
              geminiHistory: [],
              // v1.11.38 (P3-9): daily goal — the user's own target,
              // display-only (never changes the programme, never blocks
              // a box). kind "useful" counts useful minutes, kind
              // "boxes" counts ticked boxes. Default: 8 useful hours.
              dailyGoal: { kind: "useful", minutes: 480 } };
// ---------- v1.11.50: client-side state normalizer ----------
// The server sanitizes on load/save, but a shape that never
// round-trips (an old file, a stale tab, a legacy entry) must never
// crash the renderer: repair in memory only, never invent data.
// Bad maps become {}, bad entries are dropped (exactly the server's
// sanitize_nested_state rules, mirrored here so the page survives
// even before the next server round-trip). Called on every state
// load, every refresh, and at the top of renderAll (cheap no-op on
// clean state). Save paths ALSO guard their own writes — a write
// must not throw before the next render runs this.
function stateMap(key) {
  if (!state[key] || typeof state[key] !== "object" || Array.isArray(state[key])) state[key] = {};
  return state[key];
}
function stateList(key) {
  if (!Array.isArray(state[key])) state[key] = [];
  return state[key];
}
function ensureStateMaps() {
  ["done", "tests", "tests_total", "edits", "actualMinutes", "usefulMinutes",
   "topicLinks", "daysDone", "boxBookLinks", "backlogHidden", "backlogPinned",
   "nudgeHidden", "nextBoxReminded", "chapterSR", "errorNotebook", "examResults",
   "examPack", "sleepLog", "sleepReminded", "examTargets", "classLinks"].forEach(k => stateMap(k));
  ["custom_boxes", "deleted", "timerSessions", "testLog", "errorLog",
   "geminiHistory", "assignmentsRemoved", "examsRemoved", "examsSeededIds"].forEach(k => stateList(k));
  // v1.11.60 (M-DATA3): drop custom boxes without a real YYYY-MM-DD
  // date or valid HH:MM start/end — same rules as the server
  // _sanitize_custom_boxes (a null-date box renders nowhere and a bad
  // time NaNs the day total). Runs on every load/refresh, like the
  // other ensureStateMaps cleanups.
  state.custom_boxes = state.custom_boxes.filter(b =>
    b && typeof b === "object" && isValidBoxDate(b.date) && isValidBoxTime(b.start) && isValidBoxTime(b.end));
  // tests entries: {completed, correct} dicts only — a number/string
  // entry throws in strict mode on the next save (app.js:13).
  Object.keys(state.tests).forEach(id => {
    const tr = state.tests[id];
    if (!tr || typeof tr !== "object" || Array.isArray(tr)) { delete state.tests[id]; return; }
    ["completed", "correct"].forEach(f => { if (typeof tr[f] !== "number" || tr[f] < 0) delete tr[f]; });
  });
  // Numeric maps: numbers only, never negative.
  ["tests_total", "actualMinutes", "usefulMinutes"].forEach(k => {
    Object.keys(state[k]).forEach(id => { const v = state[k][id]; if (typeof v !== "number" || v < 0) delete state[k][id]; });
  });
  // Done ticks: false / legacy true / {d: YYYY-MM-DD} only.
  Object.keys(state.done).forEach(id => {
    const v = state.done[id];
    if (typeof v === "boolean") return;
    if (v && typeof v === "object" && typeof v.d === "string" && /^\d{4}-\d{2}-\d{2}$/.test(v.d)) { state.done[id] = { d: v.d }; return; }
    delete state.done[id];
  });
  // Logs: dict entries only — a null entry crashes chapterFreshness.
  ["testLog", "errorLog", "timerSessions"].forEach(k => {
    state[k] = state[k].filter(e => e && typeof e === "object");
  });
  Object.keys(state.chapterSR).forEach(id => { if (!state.chapterSR[id] || typeof state.chapterSR[id] !== "object") delete state.chapterSR[id]; });
  // v1.11.62 (Batch 3, م-۳/ب-۵): sleep log — {date: {sleep, wake}}
  // HH:MM strings only; lastErrorReview an ISO date or null.
  Object.keys(state.sleepLog).forEach(d => {
    const v = state.sleepLog[d];
    if (!v || typeof v !== "object" || Array.isArray(v)) { delete state.sleepLog[d]; return; }
    ["sleep", "wake"].forEach(f => { if (f in v && !isValidBoxTime(v[f])) delete v[f]; });
    if (!v.sleep && !v.wake) delete state.sleepLog[d];
  });
  if (state.lastErrorReview != null && (typeof state.lastErrorReview !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(state.lastErrorReview))) state.lastErrorReview = null;
  // v1.11.63 (Batch 4, م-۵/م-۷): stage targets (0-100 numbers) and
  // live-class links (http(s) URLs only) — bad entries dropped.
  Object.keys(state.examTargets).forEach(id => {
    const m = state.examTargets[id];
    if (!m || typeof m !== "object" || Array.isArray(m)) { delete state.examTargets[id]; return; }
    Object.keys(m).forEach(s => { if (typeof m[s] !== "number" || m[s] < 0 || m[s] > 100) delete m[s]; });
    if (!Object.keys(m).length) delete state.examTargets[id];
  });
  Object.keys(state.classLinks).forEach(id => {
    const v = state.classLinks[id];
    if (typeof v !== "string" || !/^https?:\/\//.test(v.trim())) delete state.classLinks[id];
    else state.classLinks[id] = v.trim();
  });
  // v1.11.55 (F5): the persisted sim — {examId: str, endsAt: number,
  // rows: {subject: {correct, wrong, unanswered: non-negative numbers}}}.
  // Anything else drops the whole sim (a stale sim is rebuilt by
  // starting a new run, never repaired).
  const sm = state.sim;
  if (sm != null) {
    let ok = typeof sm === "object" && !Array.isArray(sm) && typeof sm.examId === "string" && sm.examId &&
      typeof sm.endsAt === "number" && sm.rows && typeof sm.rows === "object" && !Array.isArray(sm.rows);
    if (ok) {
      const clean = {};
      Object.keys(sm.rows).forEach(subj => {
        const r = sm.rows[subj];
        if (!r || typeof r !== "object") return;
        clean[subj] = { correct: numOr0(r.correct), wrong: numOr0(r.wrong), unanswered: numOr0(r.unanswered) };
      });
      if (!Object.keys(clean).length) ok = false; else sm.rows = clean;
    }
    if (!ok) state.sim = null;
  }
}
function numOr0(v) { return (typeof v === "number" && v >= 0) ? v : 0; }
// Programme range (audit §5 item 1.7): state fields, NOT hardcoded
// constants. Defaults cover the programme as entered so far
// (2026-10-24 .. 2026-12-18); syncProgrammeRange() extends them when
// the programme itself grows (Google pull / new boxes), never shrinks.
// "Today" is the STUDY day, NOT clamped to the programme end: after the
// range ends the app shows the real today (post-programme mode) instead
// of freezing the date at 2026-12-18. Before the range starts, today
// still clamps to the start (no programme before it exists).
function programmeStart() {
  const s = state.programme_start;
  return (typeof s === "string" && /^\d{4}-\d{2}-\d{2}$/.test(s)) ? s : "2026-10-24";
}
function programmeEnd() {
  const s = state.programme_end;
  return (typeof s === "string" && /^\d{4}-\d{2}-\d{2}$/.test(s)) ? s : "2026-12-18";
}
function isPostProgramme() { return TODAY > programmeEnd(); }
function syncProgrammeRange() {
  // Extend the stored range to cover the programme as it actually is
  // (a pull from Google, an imported file, a new box past the end).
  // Never shrinks: deleting programme must not hide the range.
  const boxes = (DATA.boxes || []);
  if (!boxes.length || !stateLoaded) return;
  let mn = null, mx = null;
  boxes.forEach(b => {
    if (!b || !b.date) return;
    if (!mn || b.date < mn) mn = b.date;
    if (!mx || b.date > mx) mx = b.date;
  });
  if (!mn || !mx) return;
  let changed = false;
  if (mn < programmeStart()) { state.programme_start = mn; changed = true; }
  if (mx > programmeEnd()) { state.programme_end = mx; changed = true; }
  if (changed) saveState();
}
function todayIso() {
  const s = studyDayOf(new Date());
  if (s < programmeStart()) return programmeStart();
  return s; // no upper clamp (1.7): after the programme ends, today is real
}
let TODAY = todayIso(); // the STUDY day; refreshToday() re-reads it
function refreshToday() {
  // The tab can stay open past the 03:30 rollover: re-read the study
  // day on every renderAll() and in the 60 s interval, or the whole app
  // keeps showing yesterday until reload.
  TODAY = todayIso();
}
function minutesBetween(start, end) {
  // v1.11.50: a box with a null/missing start or end (an old custom
  // box, a pull without times) used to throw here on every render
  // (null.split) — coerce like timeToMinutes does.
  // v1.11.60 (M-DATA3): Number("xx") is NaN, and NaN used to poison
  // the whole day total — parseInt(...) || 0 coerces garbage to 0,
  // and a still-negative result (garbage times like 99:99) clamps
  // to 0; no valid HH:MM pair can go negative after the overnight
  // adjustment, so this only touches garbage input.
  const [sh, sm] = String(start || "00:00").split(":").map(v => parseInt(v, 10) || 0);
  const [eh, em] = String(end || "00:00").split(":").map(v => parseInt(v, 10) || 0);
  // (eh || 0) / (em || 0): a one-segment string ("xx") splits to a
  // single element, so the second destructure is undefined and the
  // subtraction would NaN without the fallback.
  let mins = ((eh || 0) * 60 + (em || 0)) - ((sh || 0) * 60 + (sm || 0));
  if (mins === 0) return 0; // a zero-length box is 0 minutes, not a full day
  if (mins < 0) mins += 24 * 60; // overnight box (e.g. 23:00–01:00)
  if (mins < 0) mins = 0;
  return mins;
}
// v1.11.26 (QA BUG-036): end < start is only genuine for overnight
// boxes — the programme has 7, all starting 23:00–23:35 and ending
// 00:15–01:00. Anything else is almost certainly a typo (16:00→14:00
// would silently become a 22-hour box), so ask first and show the
// overnight length the save would create.
function confirmOvernight(start, end) {
  if (end >= start) return true;
  return confirm(t("edOvernightConfirm", { start: fmtTimeFa(start), end: fmtTimeFa(end), dur: fmtDurationFa(minutesBetween(start, end)) }));
}
function fmtDuration(mins) {
  mins = Math.round(mins || 0); // actual minutes arrive as floats (seconds/60)
  if (LANG === "en") return fmtDurationEn(mins);
  const h = Math.floor(mins / 60), m = mins % 60;
  // v1.11.43 (audit §16 item 21): Persian digits, like everywhere
  // else in the UI now — the v1.11.28 (QA BUG-049) Western-digit
  // exception for Analytics is retired; fmtDurationFa stays as the
  // alias its Dashboard / box-card / calendar callers already use.
  if (h === 0) return FA(m) + " دقیقه";
  if (m === 0) return FA(h) + " ساعت";
  return FA(h) + " ساعت و " + FA(m) + " دقیقه";
}
function fmtDurationEn(mins) {
  const h = Math.floor(mins / 60), m = mins % 60;
  if (h === 0) return m + "m";
  if (m === 0) return h + "h";
  return h + "h " + m + "m";
}
// v1.11.28 (QA BUG-049): fmtDuration() used to keep Western digits
// in fa mode ("2 ساعت و 40 دقیقه"); v1.11.43 (audit §16 item 21)
// retired that exception — fmtDuration now reads Persian digits too,
// and this function stays as the alias its Dashboard / box-card /
// calendar callers already use. English is identical in both.
function fmtDurationFa(mins) {
  if (LANG === "en") return fmtDurationEn(Math.round(mins || 0));
  mins = Math.round(mins || 0);
  const h = Math.floor(mins / 60), m = mins % 60;
  if (h === 0) return FA(m) + " دقیقه";
  if (m === 0) return FA(h) + " ساعت";
  return FA(h) + " ساعت و " + FA(m) + " دقیقه";
}
// Fixed per-subject colours (Design System v1.9.0): the same subject
// always gets the same colour on every surface — box side bars, book
// cards/chips, subject cards, Overview bars, analytics chips and chart
// fills. Unknown subjects fall back to the neutral "other" colour.
const SUBJECT_CLASS = {
  "حسابان": "subj-math", "ریاضی": "subj-math", "ریاضیات": "subj-math",
  "فیزیک": "subj-physics",
  "شیمی": "subj-chemistry",
  "هندسه": "subj-geometry",
  "گسسته": "subj-discrete",
  "ادبیات": "subj-literature", "فارسی": "subj-literature",
  "عربی": "subj-arabic",
  "دینی": "subj-dini",
  "زبان": "subj-english", "زبان انگلیسی": "subj-english",
};
function colorClass(subject) {
  return SUBJECT_CLASS[subject] || "subj-other";
}
function esc(s) {
  return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

let DATA = { meta: {}, boxes: [] };
let TESTBOOK = { books: [] };
let EXAMS = { exams: [] };
// A failed fetch must never let a save overwrite real data with these
// empty defaults (A-C1): the flags are set only on a successful load,
// and saveState()/saveTestbook() refuse until then.
let stateLoaded = false;
let testbookLoaded = false;
let selectedDay = TODAY;
let openBookId = null;
let saveTimer = null;
let tbTimer = null;
// v1.11.48 (F2): a debounced save is pending when its 400 ms timer has
// not fired yet. flushSaves()/flushTestbook() run it immediately.
let savePending = false;
let tbPending = false;
let tbSavePromise = null;
// v1.11.61 (L-PERF2): the serial queue for testbook saves — the same
// shape as saveQueue for state. tbSavePromise used to be overwritten
// per call, so two concurrent POSTs could arrive reversed and stale
// content win; now a second save only starts after the first POST
// completes, and its body is stringified at send time, so it always
// carries the latest TESTBOOK. (The two save paths stay separate
// helpers — the parallel-save-paths guardrail — only the queue pattern
// is shared.)
let tbSaveQueue = Promise.resolve();

// ---------- Language (i18n): FA / EN, RTL / LTR, persisted ----------
// Static texts are marked with data-i18n / data-i18n-ph in index.html.
// Dynamic strings are rendered through t() everywhere below.
function applyStaticI18n() {
  document.getElementById("pageTitle").textContent = t("appTitle");
  document.getElementById("savedPill").textContent = t("savedAuto");
  const syncPill = document.getElementById("calSyncPill");
  if (syncPill && !calSyncBusy) syncPill.textContent = t("calSyncBtnTop");
  // Topbar backup pill: re-render from the cached backup status so a
  // language switch re-labels it (refreshBackupStatus only runs on fetch).
  if (typeof renderBackupPill === "function") renderBackupPill(backupStatusCache);
  document.getElementById("resetBtn").textContent = t("resetAll");
  document.getElementById("resetBtn").title = t("resetAll");
  document.getElementById("statsBtn").title = t("statsTitle");
  document.getElementById("themeBtn").title = t("themeTitle");
  document.getElementById("langBtn").title = t("langTitle");
  document.getElementById("langBtn").innerHTML =
    '<span class="' + (LANG === "fa" ? "on" : "off") + '">FA</span> | <span class="' +
    (LANG === "en" ? "on" : "off") + '">EN</span>';
  document.querySelectorAll("[data-i18n]").forEach(el => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll("[data-i18n-ph]").forEach(el => { el.placeholder = t(el.dataset.i18nPh); });
  document.querySelectorAll("[data-i18n-title]").forEach(el => { el.title = t(el.dataset.i18nTitle); });
  document.querySelectorAll("[data-i18n-aria]").forEach(el => { el.setAttribute("aria-label", t(el.dataset.i18nAria)); });
  document.getElementById("keyStatus").textContent = t("keyStatusChecking");
  const bkPill = document.getElementById("backupPill");
  if (bkPill && !bkPill.dataset.live) bkPill.textContent = t("bkPillLocal");
  refreshAsgFormLabels();
  if (typeof refreshKeyStatus === "function") refreshKeyStatus();
  if (typeof refreshGeminiModel === "function") refreshGeminiModel();
  if (typeof refreshGmTestPanel === "function") refreshGmTestPanel();
}
function applyLang(lang, save) {
  // v1.11.25 (QA BUG-029): an open three-dot box menu is built once with
  // the current language's labels and does NOT re-render on language
  // switch — it would stay Persian inside an English UI (or the reverse).
  // Closing it is the safe fix: the menu is one tap away, and a stale
  // menu with the wrong language is worse than a closed one.
  closeBoxMenu();
  const l = setLang(lang);
  state.lang = l;
  try { localStorage.setItem("konkur-lang", l); } catch (e) {}
  applyStaticI18n();
  if (save) saveState();
  renderAll();
}
function toggleLang() { applyLang(LANG === "fa" ? "en" : "fa", true); }
document.getElementById("langBtn").addEventListener("click", toggleLang);
document.getElementById("calSyncPill").addEventListener("click", topbarSync);
// Re-label the assignment-form selects after a language switch. Values stay
// Persian (they are data keys); only the visible option text translates.
function refreshAsgFormLabels() {
  const subjSel = document.getElementById("asgSubject");
  if (subjSel && subjSel.options.length) {
    Array.from(subjSel.options).forEach(o => { o.textContent = subjName(o.value); });
  }
  if (typeof asgFillCascade === "function") asgFillCascade();
}

// ---------- Test-book mapping (daily box -> book topic) ----------
// Leaves are the real TOC sections (مبحث / بخش / پنجره). Legacy entries are
// old v1 topics with no counterpart in the new books (e.g. فیزیک دهم/یازدهم):
// they live in TESTBOOK.legacy so their solved counts are never lost.
function topicById(id) {
  for (const book of TESTBOOK.books || []) {
    for (const ch of book.chapters || []) {
      for (const t of ch.topics || []) {
        if (t.id === id) return { book, chapter: ch, topic: t, legacy: false };
      }
    }
  }
  const lg = (TESTBOOK.legacy || {})[id];
  if (lg) {
    const book = (TESTBOOK.books || []).find(b => b.id === lg.bookId) || null;
    return { book, chapter: null, topic: lg, legacy: true };
  }
  return null;
}
// Daily box -> first leaf of the matching section (درس / فصل). Order matters:
// ترمودینامیک is checked before دینامیک, pH/اسید before the generic فصل rules.
// Returns a leaf id, a legacy id (فیزیک دهم/یازدهم has no book here), or null.
function autoTopicId(b) {
  const text = (b.subject || "") + " " + (b.title || "") + " " + (b.topic || "");
  const has = (re) => re.test(text);
  if (b.subject === "شیمی" || has(/شیمی/)) {
    if (has(/pH|اسید|باز|خورندگی/)) return "chem-c7-s3";
    if (has(/برقکافت|آبکاری|الکترون|گالوانی|سلول سوختی|الکتروشیمی/)) return "chem-c8-s1";
    if (has(/فصل ۳.*آب|آب، آهنگ|فصل ۳ دهم/)) return "chem-c3-s1";
    if (has(/فصل ۱.*دهم|کیهان/)) return "chem-c1-s1";
    if (has(/فصل ۲.*دهم|ردپای گاز/)) return "chem-c2-s1";
    if (has(/فصل ۳.*دوازدهم|جلوه‌ای از هنر/)) return "chem-c9-s1";
    if (has(/فصل ۴.*دوازدهم|آینده/)) return "chem-c10-s1";
    if (has(/فصل ۱.*یازدهم|قدر هدایای/)) return "chem-c4-s1";
    if (has(/فصل ۲.*یازدهم|غذای سالم/)) return "chem-c5-s1";
    if (has(/فصل ۳.*یازدهم|پوشاک/)) return "chem-c6-s1";
    // No bare «فصل ۱/۲/۳/۴» fallback: without a grade the chapter is
    // ambiguous (دهم/یازدهم/دوازدهم all have one) and guessing links a
    // box to the wrong book section. Return null instead.
    return null;
  }
  if (b.subject === "حسابان" || has(/حسابان/)) {
    if (has(/مشتق/)) return "calc-c8-l80";
    if (has(/مثلثات/)) return "calc-c6-l51";
    if (has(/حدهای نامتناهی|حد در بی‌نهایت/)) return "calc-c7-l72";
    if (has(/حد/)) return "calc-c7-l67";
    if (has(/معادلات گویا|رادیکالی/)) return "calc-c3-l24";
    if (has(/نمایی|لگاریتم/)) return "calc-c5-l38";
    if (has(/الگو|دنباله/)) return "calc-c10-l104";
    if (has(/توان گویا/)) return "calc-c11-l110";
    if (has(/تابع/)) return "calc-c1-l1";
    return null;
  }
  if (b.subject === "فیزیک" || has(/فیزیک/)) {
    if (has(/ترمودینامیک/)) return "legacy-phys-thermo"; // before دینامیک: ترمودینامیک contains دینامیک
    if (has(/دینامیک|حرکت دایره‌ای/)) return "phys-c2-w1";
    if (has(/برهم‌کنش‌های موج/)) return "phys-c4-w1";
    if (has(/شتاب ثابت|سقوط آزاد|حرکت‌شناسی|حرکت بر خط|جمع‌بندی حرکت/)) return "phys-c1-w1";
    if (has(/دما و گرما|گرما/)) return "legacy-phys-heat";
    if (has(/الکتریسیته ساکن/)) return "legacy-phys-static";
    if (has(/جریان الکتریکی|مدار/)) return "legacy-phys-circuit";
    if (has(/مغناطیس/)) return "legacy-phys-magnet";
    if (has(/القا/)) return "legacy-phys-induction";
    if (has(/نوسان|موج/)) return "phys-c3-w1";
    if (has(/اتمی/)) return "phys-c5-w1";
    if (has(/هسته‌ای/)) return "phys-c6-w1";
    if (has(/فشار|ویژگی.*مواد/)) return "legacy-phys-materials";
    if (has(/کار و انرژی|کار، انرژی/)) return "legacy-phys-work";
    return null;
  }
  if (b.subject === "گسسته" || has(/گسسته/)) {
    if (has(/نظریه اعداد/)) return "disc-c1-s1";
    if (has(/گراف/)) return "disc-c2-s1";
    if (has(/ترکیبیات|شمارش/)) return "disc-c3-s1";
    return null; // احتمال / آمار live in pending chapters 4–8 (no sections yet)
  }
  return null;
}
function linkedTopicId(b) {
  const override = (state.topicLinks || {})[b.id];
  if (override === "none") return null;
  if (override) return override;
  return autoTopicId(b);
}
// Per-render cache of box -> linked topic id: autoTopicId() runs ~20
// regexes per box, and topic stats re-scan all boxes per topic. The
// cache is rebuilt on every renderAll() (any state change re-renders),
// so it can never go stale.
let LINKED_CACHE = null;
// v1.11.24 (QA BUG-018): per-render memoization for allBoxes() +
// topicAgg() (see renderAll). Null outside a render — then both
// functions behave exactly as before (fresh computation each call).
let RENDER_CACHE = null;
function linkedTopicIdCached(b) {
  // v1.11.50: save paths used to pass a bare box-id string — b.id is
  // undefined for a string, so every string call shared cache key
  // undefined and always logged topic: null (the per-chapter trends
  // lost the topic attribution for box saves). Accept both shapes;
  // a bare id can still resolve a manual topicLinks override.
  if (!b) return null;
  const box = typeof b === "string" ? { id: b } : b;
  if (!box.id) return null;
  if (!LINKED_CACHE) LINKED_CACHE = new Map();
  if (!LINKED_CACHE.has(box.id)) LINKED_CACHE.set(box.id, linkedTopicId(box));
  return LINKED_CACHE.get(box.id);
}
// One scan per topic: solved + correct + wrong together (the old
// one-line wrappers each scanned all boxes).
// Audit §3.3 item 18 (fixed here, 1.11.18 — 2.5 depends on correct
// counts): the manual book counts and the linked daily-box tests are
// two records of the SAME tests — summing both double-counts whenever
// the user records a test both on its box and in the book. Manual wins
// when the user entered any manual count for the section (the book is
// the record they maintain); box tests are the fallback only when
// nothing was entered manually. `source` says which one fed the count.
function topicAgg(topicId) {
  // v1.11.24 (QA BUG-018): memoized per render (see renderAll).
  if (RENDER_CACHE && RENDER_CACHE.topicAgg.has(topicId)) return RENDER_CACHE.topicAgg.get(topicId);
  const found = topicById(topicId);
  const manualSolved = found ? (found.topic.manual_solved || 0) : 0;
  const manualCorrect = found ? (found.topic.manual_correct || 0) : 0;
  const manualWrong = found ? (found.topic.manual_wrong || 0) : 0;
  // v1.11.24 (QA BUG-017): the linked-box sums are computed ALWAYS,
  // even when a manual count wins — the row needs them to say the box
  // tests are excluded from the total. The manual count still wins by
  // design (1.11.18 anti-double-count): the two are never added.
  let boxSolved = 0, boxCorrect = 0, boxWrong = 0;
  allBoxes().forEach(b => {
    if (linkedTopicIdCached(b) === topicId) {
      const tr = testOf(b);
      boxSolved += tr.completed || 0;
      boxCorrect += tr.correct || 0;
      boxWrong += Math.max(0, (tr.completed || 0) - (tr.correct || 0));
    }
  });
  let result;
  if (manualSolved > 0 || manualCorrect > 0 || manualWrong > 0) {
    result = { solved: manualSolved, correct: manualCorrect, wrong: manualWrong,
               source: "manual", boxSolved, boxCorrect, boxWrong };
  } else {
    result = { solved: boxSolved, correct: boxCorrect, wrong: boxWrong,
               source: boxSolved ? "boxes" : "none",
               boxSolved, boxCorrect, boxWrong };
  }
  if (RENDER_CACHE) RENDER_CACHE.topicAgg.set(topicId, result);
  return result;
}
function topicStats(topic) {
  const a = topicAgg(topic.id);
  const total = topic.tests_total || 0;
  return { solved: a.solved, total, correct: a.correct, wrong: a.wrong,
           boxSolved: a.boxSolved, boxSource: a.source,
           unanswered: total ? Math.max(0, total - a.correct - a.wrong) : null,
           remaining: total ? Math.max(0, total - a.solved) : null,
           pct: total ? Math.min(100, Math.round(a.solved / total * 100)) : null,
           acc: a.solved ? Math.round(a.correct / a.solved * 100) : null };
}
function bookStats(book) {
  let solved = 0, total = 0;
  (book.chapters || []).forEach(ch => (ch.topics || []).forEach(t => {
    const s = topicStats(t); solved += s.solved; total += s.total;
  }));
  // Legacy topics of this book (old v1 topics with no new chapter) count too.
  Object.values(TESTBOOK.legacy || {}).forEach(lg => {
    if (lg.bookId !== book.id) return;
    const s = topicStats(lg); solved += s.solved; total += s.total;
  });
  return { solved, total, remaining: total ? Math.max(0, total - solved) : null,
           pct: total ? Math.min(100, Math.round(solved / total * 100)) : null };
}

// v1.11.32 (P2-5c): infer tests_total from an explicit number in the
// title («۳۰ تست», "30 tests" — Persian/Arabic digits included) when
// no total was ever entered. Only a literal number in the title;
// never a guess. An explicit stored total (state or seed) always
// wins, and a «پارت X از N تست» title does NOT infer N — that is
// the whole series' total, not this part's. Multiple «N تست»
// mentions add up (e.g. «۳۰ تست دوازدهم + ۳۰ تست دهم» = 60).
function inferTestsTotalFromTitle(title) {
  const t = String(title || "");
  if (/پارت\s*[۰-۹0-9]+\s*از\s*[۰-۹0-9]+\s*تست/.test(t)) return 0;
  let sum = 0;
  const re = /([۰-۹0-9]+)\s*(?:تست|test)/gi;
  let m;
  while ((m = re.exec(t))) {
    const n = parseInt(String(m[1]).replace(/[۰-۹]/g, d => "۰۱۲۳۴۵۶۷۸۹".indexOf(d)), 10);
    if (n > 0) sum += n;
  }
  return sum;
}

// ---------- Boxes / state ----------
function allBoxes() {
  // v1.11.24 (QA BUG-018): memoized per render (see renderAll) — the
  // list was rebuilt ~1,889× per render. Safe: no caller mutates the
  // returned array or its box objects in place (only .filter/.find
  // reads), and the cache is cleared when the render finishes.
  if (RENDER_CACHE && RENDER_CACHE.boxes) return RENDER_CACHE.boxes;
  const deleted = new Set(state.deleted || []);
  const orphaned = new Set(CAL_LINKS.orphaned || []);
  const list = DATA.boxes.filter(b => !deleted.has(b.id)).map(b => {
    const edit = (state.edits || {})[b.id] || {};
    // v1.11.10: stamp the REAL calendar link data onto the copy (uid
    // from the server's uid_map, orphaned flag from the status payload).
    // The stamp runs AFTER the edit merge so a stale edit can never
    // fake a link; the seed/state themselves are never mutated.
    const box = Object.assign({}, b, edit, {
      tests_total: (state.tests_total && state.tests_total[b.id] != null)
        ? state.tests_total[b.id] : (b.tests_total || inferTestsTotalFromTitle(b.title)),
      // v1.11.72 (Batch 5, L31): the STORED total (state, else the
      // seed field) — without the title inference — so the
      // data-completeness meter can count only user-entered data.
      tests_total_stored: (state.tests_total && state.tests_total[b.id] != null)
        ? state.tests_total[b.id] : (b.tests_total || 0)
    });
    box.uid = CAL_LINKS.byBox[b.id] || null;
    box.orphaned = orphaned.has(b.id);
    return box;
  });
  // Custom boxes get the same stamp: a custom box pushed to Google
  // (v1.11.0 bulk push / v1.11.11 push-one) carries a uid_map entry
  // too, and stamping uid:null here would leave its corner box stuck
  // on «در تقویم نیست» forever.
  const out = list.concat((state.custom_boxes || []).map(cb =>
    Object.assign({}, cb, { uid: CAL_LINKS.byBox[cb.id] || null,
                            orphaned: orphaned.has(cb.id),
                            // v1.11.32 (P2-5a/c): a custom box's total
                            // edited in the card (state.tests_total)
                            // used to be lost on re-render — the merge
                            // now applies it, and the title inference
                            // applies when nothing was ever entered.
                            tests_total: (state.tests_total && state.tests_total[cb.id] != null)
                              ? state.tests_total[cb.id] : (cb.tests_total || inferTestsTotalFromTitle(cb.title)),
                            // v1.11.72 (Batch 5, L31): the STORED total
                            // (see the programme branch above).
                            tests_total_stored: (state.tests_total && state.tests_total[cb.id] != null)
                              ? state.tests_total[cb.id] : (cb.tests_total || 0) })));
  if (RENDER_CACHE) RENDER_CACHE.boxes = out;
  return out;
}
// ---------- Explicit activity type «class» (v1.11.5) ----------
// A box carries an explicit stored type ("class" | "normal") once the user
// (un)checks «کلاس» in the create/edit form. For old boxes without the
// field, the v1.8.0 title rule backfills it: title contains «کلاس» -> class,
// else normal — so past classes stay visible and nothing needs a data
// migration. An explicit stored "normal" ALWAYS wins over the title rule
// (unchecking «کلاس» on a title-«کلاس» box really un-classes it).
function boxStoredType(b) {
  return (b && (b.type === "class" || b.type === "normal")) ? b.type : null;
}
function boxIsClass(b) {
  const st = boxStoredType(b);
  if (st) return st === "class";
  return (b.title || "").indexOf("کلاس") >= 0;
}
// v1.11.63 (Batch 4, م-۷): the live-class join link is ONLY what the
// user himself entered in the box edit modal (state.classLinks) —
// never guessed, never pre-filled; the field starts empty.
function boxClassLink(b) {
  const v = (state.classLinks || {})[b.id];
  return (typeof v === "string" && v) ? v : null;
}
function classJoinVisible(b) {
  // «ورود به کلاس» shows from 15 minutes before the class starts
  // until it ends — today only (a future day's box never matches
  // today's clock, and a past day's box never does either).
  if (!boxIsClass(b) || (boxStudyDay(b) || b.date) !== TODAY) return false;
  const info = nowBoxInfo();
  const s0 = studyDayMinutes(b.start || "00:00");
  const s1 = s0 + minutesBetween(b.start || "00:00", b.end || "00:00");
  return info.nowMin >= s0 - 15 && info.nowMin < s1;
}
// 5-way activity type for the History/Analytics filter (shared mapping,
// see analytics.js anActivityType): class wins over everything, then
// homework (title «تکلیف»/«تکالیف»), then test (is_test), then study
// (study keywords), then other. Real counts: class 104, homework 18,
// test 125, study 69, other 2 = 318.
function boxActivityType(b) {
  if (boxIsClass(b)) return "class";
  const t = b.title || "";
  if (t.indexOf("تکلیف") >= 0 || t.indexOf("تکالیف") >= 0) return "homework";
  if (b.is_test) return "test";
  if (/(مطالعه|مرور|دیدن|تماشا|ویدیو|پیش‌خوانی|درسنامه|جزوه|تمرین|اتمام|خواندن|خلاصه|جبران|امتحان|آفلاین)/.test(t) ||
      /(^|\s)درس(\s|$)/.test(t)) return "study";
  return "other";
}
// ---------- Prerequisite chain (v1.11.37, P3-7) ----------
// view → homework → test → review. A test box is "ready" only when
// its chapter's viewing box is ticked; anything else (homework, study,
// a test with no identifiable chapter) is never judged. This is a
// MARK, never a block: the tick, timer and test inputs all work
// whether the pill says ready or not, and a hand-placed box is never
// moved or hidden by it. Only the readiness pill and the compensation
// suggestions read it (backlogSuggestions never suggests an unready
// test), plus one warning kind in dayIssues.
// A "viewing" box is a live class or a box whose title says watching:
// دیدن / تماشا / مشاهده / ویدیو / پیش‌خوانی. A test box is never a
// viewing box, even when its title says «جلسه تست».
function isViewingBox(b) {
  if (!b || b.is_test) return false;
  if (boxIsClass(b)) return true;
  return /دیدن|تماشا|مشاهده|ویدیو|پیش‌خوانی/.test(b.title || "");
}
// The testbook chapter a box belongs to: the budget-topic link first,
// then the first manual book-section link. Null = no identifiable
// chapter (legacy topics have none) — readiness is then unjudged.
function boxChapterId(b) {
  const tid = linkedTopicIdCached(b);
  if (tid) {
    const f = topicById(tid);
    if (f && f.chapter) return f.chapter.id;
  }
  const links = boxBookLinks(b.id) || [];
  for (const l of links) {
    const f = topicById(l.sectionId);
    if (f && f.chapter) return f.chapter.id;
  }
  return null;
}
// Per-render set of chapters with a ticked viewing box (rebuilt on
// every renderAll, like LINKED_CACHE — it can never go stale).
let VIEWED_CHAPTERS = null;
function viewedChapters() {
  if (!VIEWED_CHAPTERS) {
    VIEWED_CHAPTERS = new Set();
    allBoxes().forEach(b => {
      if (isDone(b) && isViewingBox(b)) {
        const ch = boxChapterId(b);
        if (ch) VIEWED_CHAPTERS.add(ch);
      }
    });
  }
  return VIEWED_CHAPTERS;
}
// null = not a test box, or no identifiable chapter (nothing to judge);
// true/false = ready / chapter not watched yet.
function testBoxReady(b) {
  const tr = testOf(b);
  // v1.11.45 (E-19): a test box is is_test / activity "test" (or has
  // tests actually logged) — NOT a plain study box whose title
  // happens to contain a test count ("مرور ۳۰ تست …"), whose
  // tests_total is only INFERRED from the title.
  const isTestBox = !!(b.is_test || boxActivityType(b) === "test" || (tr.completed || 0) > 0);
  if (!isTestBox) return null;
  const ch = boxChapterId(b);
  if (!ch) return null;
  return viewedChapters().has(ch);
}
/* v1.11.6: the topic shown next to a box title only when it adds information —
   hidden when empty, equal to the title (trimmed), or already contained in it,
   so the title never renders twice (e.g. «مرور دفترچه خطا مرور دفترچه خطا»). */
function boxTopicShown(b) {
  const tp = String((b && b.topic) || "").trim();
  if (!tp) return "";
  const ti = String(b.title || "").trim();
  if (!ti || ti === tp || ti.indexOf(tp) >= 0) return "";
  return tp;
}
function isDone(b) { return !!(state.done && state.done[b.id]); }
// v1.11.30 (P1-1): state.done[boxId] is a tick with a date —
//   { d: "YYYY-MM-DD" } — the STUDY day the box was ticked, or the
//   legacy `true` (done before dates were recorded: done, date
//   unknown — never fabricated, never dropped), or `false`
//   (explicitly unticked; BUG-002: false, never delete). isDone()
//   reads truthiness, so every existing consumer works unchanged;
//   doneDate() is the accessor for the new history (trends/streaks
//   in later batches read the date, never the box's study day).
function doneDate(b) {
  const v = (state.done || {})[b.id];
  if (v && typeof v === "object" && typeof v.d === "string") return v.d;
  return null; // false / absent / legacy true (unknown date)
}
// Stamp a NEW tick with the current study day; a re-save of an
// already-ticked box keeps its original date (re-ticking must not
// move history). Un-tick writes false, never deletes the key.
// v1.11.41 (UI-audit batch 1): ticking a box to done shows a toast —
// the tick used to be silent, so the user got no "done" feedback.
function setDone(b, on) {
  // v1.11.50: guard the write — state.done could be null in an old
  // in-memory state before the normalizer ran.
  state.done = state.done || {};
  if (on) {
    if (!isDone(b)) {
      state.done[b.id] = { d: TODAY }; showToast(t("toastBoxDone"));
      // v1.11.53: useful default 100% — ticking a box done with real
      // time recorded and no useful yet records useful = real in full.
      // An explicit useful (already recorded) is never overwritten;
      // no real time stays «ثبت نشده»; boxes completed before this
      // version keep whatever they have (no backfill — this runs only
      // on the false -> true transition, and a later untick -> retick
      // finds useful already recorded).
      if (timerTotalSeconds(b.id) > 0 && usefulTotalSeconds(b.id) <= 0) {
        timerAddUsefulSecs(b.id, timerTotalSeconds(b.id));
      }
    }
  } else state.done[b.id] = false;
}
// v1.11.9: a box whose Google event vanished (orphaned) STAYS in the
// current programme — the dashboard is the primary source of task data
// and the calendar is only an external link. Disconnecting removes only
// the connection badge; it never hides, moves or deletes the box. The
// user decides about disconnected tasks by hand (three-dot menu).
// (v1.11.7 hid orphaned+undone boxes from current views — reverted.)
function isCurrentBox(b) { return true; }
// --- Calendar connection status (v1.11.9, spec §1/§4; v1.11.10 fix) ---
// Connected = the box carries a stored Google Event ID (uid, from the
// server's uid_map) and is not orphaned. This is REAL link data — never
// a title/date guess. Custom boxes have no uid and are never connected.
//
// v1.11.10 BUG (user-reported, 24 Nov 20:09 — no badge on any card even
// after a successful sync): the dashboard renders boxes from allBoxes(),
// built from the data.json seed + state.edits, neither of which carries
// a uid; the uid_map lived ONLY on the server and the frontend never
// fetched it (GET /api/boxes is never called; /api/calendar/status
// returned counts only). So boxConnected() was false for every box.
// Fix: the status payload now ships uid_map + orphaned ids (server.py
// calendar_status_payload) and the frontend keeps them in CAL_LINKS;
// allBoxes() stamps them onto every box copy before rendering, so the
// badge sees the real link data on every load and after every sync.
let CAL_LINKS = { byBox: {}, orphaned: [] };
function applyCalendarLinks(st) {
  const p = (st && st.programme) || {};
  // The server's uid_map is Event ID -> boxId; the frontend needs the
  // inverse (boxId -> Event ID) to stamp boxes, so invert it here.
  const raw = (p.uid_map && typeof p.uid_map === "object") ? p.uid_map : {};
  const byBox = {};
  for (const uid in raw) { const bid = raw[uid]; if (bid) byBox[bid] = uid; }
  CAL_LINKS = {
    byBox,
    orphaned: Array.isArray(p.orphaned) ? p.orphaned : [],
  };
}
// v1.11.55 (PERF-01): ONE shared calendar-status fetch. The 60 s tick
// used to fire two identical /api/calendar/status requests
// (renderCalendarPanel + renderConnHealth), plus refreshCalendarLinks
// on load. In-flight calls share one promise; a fresh result (5 s TTL)
// is reused, so a tick costs at most one request. invalidateCalStatus()
// clears the cache on any mutation (sync/push/save/connect) so the next
// read is fresh — callers keep their offline fallback (null = keep the
// last known links / show «unreachable»).
let _calStatusCache = null; // {at, data}
let _calStatusInflight = null;
async function getCalStatus() {
  const now = Date.now();
  if (_calStatusCache && now - _calStatusCache.at < 5000) return _calStatusCache.data;
  if (_calStatusInflight) return _calStatusInflight;
  _calStatusInflight = (async () => {
    try {
      const r = await fetch("/api/calendar/status");
      if (!r.ok) return null;
      const j = await r.json();
      _calStatusCache = { at: Date.now(), data: j };
      return j;
    } catch (e) { return null; }
  })();
  const res = await _calStatusInflight;
  _calStatusInflight = null;
  return res;
}
function invalidateCalStatus() { _calStatusCache = null; _calStatusInflight = null; }
// v1.11.65 (Batch 6, L-PERF3): the Gemini key/model GETs were fired
// 4×/2× per boot with no cache or dedupe — the same getCalStatus
// pattern (PERF-01) applies here: one shared getter each, 5 s TTL +
// in-flight dedupe. The POSTs (save key / save model) invalidate the
// cache, so the next read is fresh. A failed read returns null and
// caches nothing — callers keep their offline fallback.
let _gmKeyCache = null, _gmKeyInflight = null;
async function getGeminiKeyStatus() {
  const now = Date.now();
  if (_gmKeyCache && now - _gmKeyCache.at < 5000) return _gmKeyCache.data;
  if (_gmKeyInflight) return _gmKeyInflight;
  _gmKeyInflight = (async () => {
    try {
      const r = await fetch("/api/gemini-key");
      if (!r.ok) return null;
      const j = await r.json();
      _gmKeyCache = { at: Date.now(), data: j };
      return j;
    } catch (e) { return null; }
  })();
  const res = await _gmKeyInflight;
  _gmKeyInflight = null;
  return res;
}
function invalidateGeminiKeyStatus() { _gmKeyCache = null; _gmKeyInflight = null; }
let _gmModelCache = null, _gmModelInflight = null;
async function getGeminiModel() {
  const now = Date.now();
  if (_gmModelCache && now - _gmModelCache.at < 5000) return _gmModelCache.data;
  if (_gmModelInflight) return _gmModelInflight;
  _gmModelInflight = (async () => {
    try {
      const r = await fetch("/api/gemini-model");
      if (!r.ok) return null;
      const j = await r.json();
      _gmModelCache = { at: Date.now(), data: j };
      return j;
    } catch (e) { return null; }
  })();
  const res = await _gmModelInflight;
  _gmModelInflight = null;
  return res;
}
function invalidateGeminiModel() { _gmModelCache = null; _gmModelInflight = null; }
async function refreshCalendarLinks() {
  const st = await getCalStatus();
  if (st) applyCalendarLinks(st);
}
function boxConnected(b) { return !!(b && b.uid) && !b.orphaned; }
// --- Calendar status corner box (v1.11.10, replaces the v1.11.9 inline
// «متصل» badge) — ONE shared helper for every task card/row: a small
// box in the card's PHYSICAL top-right corner (CSS `right`, never
// inline-start, so RTL and LTR look the same). Connected = real stored
// Event ID; anything else shows «در تقویم نیست». Display-only: it never
// deletes or moves a task. The edit modal keeps its own status line.
// The box is always rendered (both states), so a disconnected task is
// visibly disconnected instead of silently badge-less.
function connStatusBoxHtml(b) {
  const on = boxConnected(b);
  return '<span class="conn-corner' + (on ? " on" : " off") + '">' +
    esc(t(on ? "calInCal" : "calNotInCal")) + '</span>';
}
// Per-box «افزودن به تقویم» (v1.11.11): ONE shared helper, rendered
// right after the corner box at every site that renders it (partCard —
// dashboard + calendar day programme — backlog, assignments, and the
// archive / review-past tables in analytics.js). Only disconnected
// boxes get the button; connected boxes show nothing. The button
// creates ONE Google event for THAT box (POST /api/boxes/push-one);
// the three-dot «reconnect» (pick an existing event) is untouched —
// this is the other direction (create a NEW event).
function calAddToCalBtnHtml(b) {
  if (boxConnected(b)) return "";
  return '<button type="button" class="cal-add-btn" data-cal-add="' + esc(b.id) + '">' + esc(t("calAddToCal")) + '</button>';
}
// One delegated handler for every render site (cards are re-rendered,
// so per-button listeners would not survive a renderAll). Disabled
// while the push is in flight; on success the links refresh and the
// card re-renders with «در تقویم ✓» and no button; on error the short
// readable error shows right under the button and it stays clickable.
document.addEventListener("click", async (e) => {
  const btn = e.target && e.target.closest ? e.target.closest("[data-cal-add]") : null;
  if (!btn || btn.disabled) return;
  const bid = btn.getAttribute("data-cal-add");
  btn.disabled = true;
  try {
    const r = await fetch("/api/boxes/push-one", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ box_id: bid }),
    });
    const j = await r.json();
    if (r.ok && j.ok) {
      // Fresh link data first, then re-render: the corner flips to
      // «در تقویم ✓» and the button disappears.
      invalidateCalStatus(); // v1.11.55 (PERF-01): the push changed links
      await refreshCalendarLinks();
      renderAll();
      return;
    }
    throw new Error(errText(j && j.error) || t("calError"));
  } catch (err) {
    btn.disabled = false;
    // v1.11.28 (QA BUG-044): the old code built a selector from the
    // raw box id — a tampered id could break out of the attribute
    // and inject a selector. The error span carries the cal-add-err
    // class, so select by that instead.
    const old = btn.parentElement && btn.parentElement.querySelector(".cal-add-err");
    if (old) old.remove();
    const span = document.createElement("span");
    span.className = "cal-add-err";
    span.setAttribute("data-cal-add-err", bid);
    span.textContent = "⚠ " + shortErr(err.message || String(err));
    btn.insertAdjacentElement("afterend", span);
  }
});
// --- Three-dot manual task menu (v1.11.9, spec §3) ---
// One shared popup, built on demand. The dashboard never moves or
// deletes a task on its own: every decision about a disconnected task
// is the user's, through this menu.
//  - Delete task: confirm first, then the existing delete path
//    (tombstones the UID, so the next pull never resurrects it).
//  - Move to backlog: a per-box flag (state.backlogPinned) — view only,
//    no duplicate record, reversible.
//  - Keep in programme: clears any backlog pin.
//  - Reconnect to calendar: only when a real reconnection is possible
//    (programme box + at least one unlinked event in the cache).
// The state mutation of a box deletion, shared by the per-box path and
// the v1.11.56 bulk delete: custom boxes leave state.custom_boxes,
// programme boxes are recorded in state.deleted (the server's push then
// deletes their Google events too, v1.11.12), and every per-box record
// is purged. No confirm, no save, no render — the caller owns those, so
// a bulk delete is one state POST, not one per box.
function applyBoxDeletion(b) {
  if (b.id.startsWith("custom-")) {
    state.custom_boxes = (state.custom_boxes || []).filter(x => x.id !== b.id);
  } else if (!(state.deleted || []).includes(b.id)) {
    state.deleted = (state.deleted || []).concat([b.id]);
  }
  purgeBoxState(b.id);
}
function deleteBoxById(b) {
  if (!confirm(t("delBoxConfirm"))) return false;
  // v1.11.31 (P1-6): a pending useful prompt for a deleted box dies with it.
  if (state.usefulPrompt && state.usefulPrompt.boxId === b.id) state.usefulPrompt = null;
  applyBoxDeletion(b);
  saveState(); renderAll();
  return true;
}
function isPinned(b) { return !!(state.backlogPinned || {})[b.id]; }
function pinToBacklog(b) {
  state.backlogPinned = state.backlogPinned || {};
  state.backlogPinned[b.id] = true;
  saveState(); renderAll();
}
function unpinFromBacklog(b) {
  if (state.backlogPinned) delete state.backlogPinned[b.id];
  saveState(); renderAll();
}
function boxSuggestion(b) {
  // v1.11.25 (QA BUG-021): the server pre-matches an orphaned box with
  // the recreated event (linked to the empty duplicate the pull just
  // created). Returns the unlinked-box entry carrying the suggestion,
  // or null.
  const ub = (UNLINKED.unlinked_boxes || []).find(x => x.id === b.id);
  return ub && ub.suggested_event_uid ? ub : null;
}
function canReconnect(b) {
  return !b.is_custom && ((UNLINKED.unlinked_events || []).length > 0 || !!boxSuggestion(b));
}
let boxMenuEl = null;
function closeBoxMenu() {
  if (boxMenuEl) { boxMenuEl.remove(); boxMenuEl = null; }
  document.removeEventListener("click", boxMenuOutside, true);
}
function boxMenuOutside(e) {
  if (boxMenuEl && !boxMenuEl.contains(e.target)) closeBoxMenu();
}
function openBoxMenu(b, anchorBtn) {
  closeBoxMenu();
  const pinned = isPinned(b);
  const recon = canReconnect(b);
  const menu = document.createElement("div");
  menu.className = "box-menu";
  menu.innerHTML =
    '<button data-act="del">' + esc(t("menuDeleteTask")) + '</button>' +
    (pinned
      ? '<button data-act="unpin">' + esc(t("menuUnpinBacklog")) + '</button>'
      : '<button data-act="pin">' + esc(t("menuMoveBacklog")) + '</button>') +
    '<button data-act="keep">' + esc(t("menuKeepProgram")) + '</button>' +
    '<button data-act="reconnect"' + (recon ? "" : " disabled") + '>' + esc(t("menuReconnectCal")) + '</button>';
  document.body.appendChild(menu);
  const r = anchorBtn.getBoundingClientRect();
  menu.style.top = (r.bottom + window.scrollY + 4) + "px";
  menu.style.left = Math.max(8, Math.min(window.innerWidth - 230, r.left + window.scrollX)) + "px";
  boxMenuEl = menu;
  menu.querySelector('[data-act="del"]').addEventListener("click", () => { closeBoxMenu(); deleteBoxById(b); });
  const pinBtn = menu.querySelector('[data-act="pin"]') || menu.querySelector('[data-act="unpin"]');
  pinBtn.addEventListener("click", () => { closeBoxMenu(); if (pinned) unpinFromBacklog(b); else pinToBacklog(b); });
  menu.querySelector('[data-act="keep"]').addEventListener("click", () => { closeBoxMenu(); unpinFromBacklog(b); });
  menu.querySelector('[data-act="reconnect"]').addEventListener("click", () => { closeBoxMenu(); openReconnectPicker(b); });
  setTimeout(() => document.addEventListener("click", boxMenuOutside, true), 0);
}
// The ⋮ button itself (one per card/row); wire it to the shared menu.
function boxMenuBtnHtml() {
  return '<button class="menu-btn" aria-label="' + esc(t("boxMenuLbl")) + '">⋮</button>';
}
function wireBoxMenuBtn(el, b) {
  el.addEventListener("click", (e) => { e.stopPropagation(); openBoxMenu(b, e.currentTarget); });
}
// --- Reconnect picker (v1.11.9, spec §3.4) ---
// Lists the currently-unlinked Google events (from the server cache);
// picking one POSTs /api/boxes/reconnect. A 409 means the event is
// linked to a box holding user data — the user must choose by hand.
let reconnectBoxId = null;
function openReconnectPicker(b) {
  reconnectBoxId = b.id;
  document.getElementById("reconnectTitle").textContent = t("reconnectTitle");
  document.getElementById("reconnectHint").textContent = t("reconnectHint");
  const list = document.getElementById("reconnectList");
  const err = document.getElementById("reconnectError");
  err.hidden = true;
  const evs = (UNLINKED.unlinked_events || []).slice();
  // v1.11.25 (QA BUG-021): an unlinked event the server pre-matched to
  // THIS box (same date+start, exactly one orphaned candidate) sorts
  // first and is marked, so the user spots the likely match.
  evs.sort((a, c) => ((c.suggested_box_id === b.id) ? 1 : 0) - ((a.suggested_box_id === b.id) ? 1 : 0));
  // The one-click suggestion: the recreated event is linked to the
  // empty duplicate the pull created, so it is NOT in the unlinked
  // list below — this row is the only way to reach it. Tapping it
  // calls the same doReconnect path; the server absorbs the empty
  // duplicate into this box (its ticks/tests/minutes survive).
  const sugg = boxSuggestion(b);
  const suggHtml = sugg
    ? '<button class="btn reconnect-item rc-suggest" data-uid="' + esc(sugg.suggested_event_uid) + '">' +
      esc(t("reconnectSuggest", { title: sugg.suggested_event_title || "" })) +
      '<br><span class="muted">' + esc(gregToJalali(sugg.date).text) + ' · ' + fmtTimeFa(sugg.start) + '–' + fmtTimeFa(sugg.end) + '</span></button>'
    : "";
  list.innerHTML = suggHtml + (evs.length ? evs.map(e =>
    '<button class="btn reconnect-item" data-uid="' + esc(e.uid) + '">' +
    esc(e.title) + '<br><span class="muted">' + esc(gregToJalali(e.date).text) + ' · ' + fmtTimeFa(e.start) + '–' + fmtTimeFa(e.end) +
    (e.suggested_box_id === b.id ? ' · ' + esc(t("reconnectMatchHint")) : '') + '</span></button>').join("")
    : (sugg ? "" : '<p class="muted">' + esc(t("reconnectEmpty")) + '</p>'));
  list.querySelectorAll(".reconnect-item").forEach(btn => btn.addEventListener("click", () => doReconnect(reconnectBoxId, btn.dataset.uid)));
  // v1.11.29 (PI-04): tombstone clearing — shown only when deleted-event
  // IDs are stored. Clearing lets a restored event with the same ID be
  // pulled again as a box instead of being skipped forever.
  const tombRow = document.getElementById("reconnectTombRow");
  const tombBtn = document.getElementById("reconnectClearTombBtn");
  const tombN = (UNLINKED.tombstones || 0);
  if (tombRow && tombBtn) {
    tombRow.hidden = !(tombN > 0);
    if (tombN > 0) {
      tombBtn.textContent = t("reconnectClearTombstones", { n: FA(tombN) });
      tombBtn.onclick = () => doClearTombstones(b);
    }
  }
  document.getElementById("reconnectModal").classList.add("open");
}
async function doClearTombstones(box) {
  const err = document.getElementById("reconnectError");
  if (!confirm(t("reconnectClearTombstonesConfirm"))) return;
  try {
    const r = await fetch("/api/calendar/tombstones/clear", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
    const j = await r.json();
    if (r.ok) {
      await refreshUnlinked();
      if (box) openReconnectPicker(box);
      else document.getElementById("reconnectModal").classList.remove("open");
    } else {
      err.hidden = false;
      err.textContent = errText(j.error) || t("calError");
    }
  } catch (e) { err.hidden = false; err.textContent = t("serverUnreachable"); }
}
async function doReconnect(boxId, uid) {
  const err = document.getElementById("reconnectError");
  try {
    const r = await fetch("/api/boxes/reconnect", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ boxId, uid }) });
    const j = await r.json();
    if (r.ok) {
      document.getElementById("reconnectModal").classList.remove("open");
      // v1.11.10: links first, then the re-render (same ordering as sync).
      await renderCalendarPanel();
      await refreshDataFromServer();
      await refreshUnlinked();
    } else {
      err.hidden = false;
      err.textContent = errText(j.error) || t("calError");
    }
  } catch (e) { err.hidden = false; err.textContent = t("serverUnreachable"); }
}
// Single shared counter: setting a box's completed/correct tests here is the
// ONLY place the number is stored. Assignments and book topics only READ it.
function setBoxTests(boxId, field, val) {
  // v1.11.50: a tests entry that is a number/string (not a dict)
  // threw here in strict mode (assigning a property to a primitive),
  // and a null state.tests map threw on the write — normalize first.
  state.tests = state.tests || {};
  let cur = state.tests[boxId];
  if (!cur || typeof cur !== "object" || Array.isArray(cur)) cur = { completed: 0, correct: 0 };
  const oldC = cur.completed || 0, oldR = cur.correct || 0;
  cur[field] = Math.max(0, parseInt(val, 10) || 0);
  if (cur.correct > cur.completed) cur.correct = cur.completed;
  // Never more completed tests than the box total (when a total is set).
  const box = allBoxes().find(b => b.id === boxId);
  const total = box ? (box.tests_total || 0) : 0;
  if (total > 0 && cur.completed > total) {
    cur.completed = total;
    if (cur.correct > cur.completed) cur.correct = cur.completed;
  }
  state.tests[boxId] = cur;
  // 3.2: log the dated delta (the totals above stay the source of truth).
  const d = testDeltaFrom(oldC, oldR, cur.completed, cur.correct);
  if (d.solved || d.correct || d.wrong) {
    logTestDelta(Object.assign({ box: boxId, topic: linkedTopicIdCached(box || { id: boxId }), src: "box" }, d));
  }
  saveState(); renderAll();
}
function testOf(b) { return (state.tests || {})[b.id] || { completed: 0, correct: 0 }; }
function accuracy(b) {
  const tr = testOf(b);
  if (!tr.completed) return null;
  return (tr.correct / tr.completed) * 100;
}

// ---------- v1.11.33 (P2-6): speed metric ----------
// Speed is computed ONLY from real stored data: solved tests (state.tests
// totals / testLog deltas) and real minutes (timer seconds / manual
// entries). Both inputs must be positive, otherwise there is no speed —
// never a fabricated one, never a target from nothing.
function speedOf(tests, actualMinutes) {
  if (!(tests > 0) || !(actualMinutes > 0)) return null;
  return { perHour: tests / (actualMinutes / 60), minPerTest: actualMinutes / tests };
}
function speedText(sp) {
  if (!sp) return "—";
  return t("spTestsPerHour", { n: FA(Math.round(sp.perHour * 10) / 10) }) + " · " +
    t("spMinPerTest", { n: FA(Math.round(sp.minPerTest * 10) / 10) });
}

// ---------- Timestamped test entries (audit §5 item 3.2) ----------
// state.testLog is an APPEND-ONLY list of dated deltas:
// {d (study-day ISO), box?, topic?, solved, correct, wrong, src}.
// Totals stay where they always were (state.tests for boxes, the book
// manual counts for sections) — the log exists ONLY for per-chapter
// accuracy trends. Old totals are NEVER converted into dated entries:
// that would fabricate history. The log starts empty and records only
// changes made from now on; a chapter with no dated entries simply has
// no trend yet.
function logTestDelta(entry) {
  if (!entry) return;
  const solved = entry.solved || 0, correct = entry.correct || 0, wrong = entry.wrong || 0;
  if (!solved && !correct && !wrong) return;
  state.testLog = state.testLog || [];
  state.testLog.push({ d: TODAY, box: entry.box || null, topic: entry.topic || null,
    solved, correct, wrong, src: entry.src || "box" });
  if (state.testLog.length > 2000) state.testLog.splice(0, state.testLog.length - 2000);
}
function testDeltaFrom(oldC, oldR, newC, newR) {
  const solved = (newC || 0) - (oldC || 0);
  const correct = (newR || 0) - (oldR || 0);
  return { solved, correct, wrong: solved - correct };
}
// Dated entries for one section (its own book entries + linked box entries).
function topicTestLog(topicId) {
  // v1.11.50: skip non-dict entries — a null testLog entry used to
  // throw here (e.topic) and kill the whole render.
  return (state.testLog || []).filter(e => e && e.topic === topicId && e.d);
}
// Per-date accuracy from the deltas, sorted by date. A date whose solved
// delta is not positive is skipped (a downward correction, not an attempt).
function topicTestTrend(topicId) {
  const byDate = {};
  topicTestLog(topicId).forEach(e => {
    const r = byDate[e.d] = byDate[e.d] || { solved: 0, correct: 0 };
    r.solved += e.solved || 0; r.correct += e.correct || 0;
  });
  return Object.keys(byDate).sort().map(d => {
    const r = byDate[d];
    return { d, solved: r.solved, correct: r.correct, acc: r.solved > 0 ? r.correct / r.solved : null };
  }).filter(r => r.solved > 0);
}
// First-vs-last accuracy over the dated entries. Needs two dated points;
// returns null when there is no trend to speak of yet.
function topicTrendLabel(topicId) {
  const s = topicTestTrend(topicId);
  if (s.length < 2) return null;
  const first = s[0].acc, last = s[s.length - 1].acc;
  if (first == null || last == null) return null;
  const diff = last - first;
  return { dir: diff > 0.05 ? "improving" : diff < -0.05 ? "declining" : "stable",
           first, last, n: s.length };
}
function chapterTestTrend(chapter) {
  const ids = new Set((chapter.topics || []).map(t => t.id));
  const byDate = {};
  (state.testLog || []).forEach(e => {
    if (!e || !e.d || !ids.has(e.topic)) return;
    const r = byDate[e.d] = byDate[e.d] || { solved: 0, correct: 0 };
    r.solved += e.solved || 0; r.correct += e.correct || 0;
  });
  return Object.keys(byDate).sort().map(d => {
    const r = byDate[d];
    return { d, solved: r.solved, correct: r.correct, acc: r.solved > 0 ? r.correct / r.solved : null };
  }).filter(r => r.solved > 0);
}
function chapterTrendLabel(chapter) {
  const s = chapterTestTrend(chapter);
  if (s.length < 2) return null;
  const first = s[0].acc, last = s[s.length - 1].acc;
  if (first == null || last == null) return null;
  const diff = last - first;
  return { dir: diff > 0.05 ? "improving" : diff < -0.05 ? "declining" : "stable",
           first, last, n: s.length };
}

// ---------- Spaced repetition (audit §5 item 3.4) ----------
// Per chapter: {last (study-day ISO), interval (days), ease} in
// state.chapterSR. First review sets interval 1; later reviews multiply
// by ease (2.5, capped at 60 days). A chapter never reviewed is NOT due
// — it shows as "never reviewed" in the book view instead of flooding
// the daily suggestions with every untouched chapter.
const SR_EASE_DEFAULT = 2.5, SR_EASE_MIN = 1.3, SR_EASE_MAX = 3.0, SR_MAX_INTERVAL = 60;
// A chapter studied but never explicitly reviewed is due 7 days after
// its last touch (see dueChapters) — it used to never appear at all.
const SR_UNREVIEWED_DUE_DAYS = 7;
function chapterSR(chapterId) { return (state.chapterSR || {})[chapterId] || null; }
function chapterById(chapterId) {
  for (const book of TESTBOOK.books || []) {
    for (const ch of book.chapters || []) if (ch.id === chapterId) return { book, chapter: ch };
  }
  return null;
}
// One grade step, shared by book chapters and budget topics (v1.11.37,
// P3-6 — adaptive spaced repetition). The grade moves the ease factor
// and the ease moves the interval; the chapter's test accuracy then
// nudges the ease for the NEXT interval (≥80% a little easier, <50%
// a little harder). acc is null when the chapter has no test data —
// then no nudge, never a fabricated one. Returns {interval, ease, grade}.
function srApplyGrade(cur, grade, acc) {
  let ease = (cur && cur.ease) || SR_EASE_DEFAULT;
  let interval;
  if (grade === "forgot") {
    ease = Math.max(SR_EASE_MIN, ease - 0.2);
    interval = 1;
  } else if (grade === "hard") {
    ease = Math.max(SR_EASE_MIN, ease - 0.05);
    interval = cur ? Math.min(SR_MAX_INTERVAL, Math.max(1, Math.round(cur.interval * ease * 0.6))) : 1;
  } else { // "remembered" (default — old callers pass no grade)
    ease = Math.min(SR_EASE_MAX, ease + 0.15);
    interval = cur ? Math.min(SR_MAX_INTERVAL, Math.max(1, Math.round(cur.interval * ease))) : 1;
  }
  if (acc != null) {
    if (acc >= 0.8) ease = Math.min(SR_EASE_MAX, ease + 0.05);
    else if (acc < 0.5) ease = Math.max(SR_EASE_MIN, ease - 0.1);
  }
  ease = Math.min(SR_EASE_MAX, Math.max(SR_EASE_MIN, ease));
  return { interval, ease, grade: grade || "remembered" };
}
// Overall accuracy of one book chapter from its dated test entries
// (all dates pooled — the trend helper is first-vs-last, this is the
// level the ease adapts to). Null when the chapter has no solved tests.
function chapterAccuracy(chapter) {
  const s = chapterTestTrend(chapter);
  let solved = 0, correct = 0;
  s.forEach(r => { solved += r.solved || 0; correct += r.correct || 0; });
  return solved > 0 ? correct / solved : null;
}
function markChapterReviewed(chapterId, grade) {
  state.chapterSR = state.chapterSR || {};
  const cur = state.chapterSR[chapterId];
  const found = chapterById(chapterId);
  const acc = found ? chapterAccuracy(found.chapter) : null;
  const next = srApplyGrade(cur, grade, acc);
  state.chapterSR[chapterId] = { last: TODAY, interval: next.interval, ease: next.ease, grade: next.grade };
  saveState(); renderAll();
}
// ---------- Budget-topic SR (v1.11.37, P3-6) ----------
// Geometry and general subjects have no testbook chapter, so their SR
// lives at budget-topic level. The key is "budget:" + subject + "|" +
// topic name — stable as long as the exam seed's subject/name don't
// change — in the same chapterSR map, same record shape and same grade
// math as book chapters. The subject/name are stored IN the record so
// dueChapters can find due budget topics without enumerating exams.
function budgetSrKey(subject, name) { return "budget:" + (subject || "") + "|" + (name || ""); }
function budgetSrRecord(subject, name) { return chapterSR(budgetSrKey(subject, name)); }
// Accuracy of a budget topic from its linked book sections (the same
// topicAgg the progress pill reads). Null when nothing solved yet.
function budgetTopicAccuracy(subject, name) {
  let solved = 0, correct = 0;
  budgetTopicLinks(subject, name).forEach(id => {
    const a = topicAgg(id);
    solved += a.solved || 0; correct += a.correct || 0;
  });
  return solved > 0 ? correct / solved : null;
}
function markBudgetTopicReviewed(subject, name, grade) {
  state.chapterSR = state.chapterSR || {};
  const key = budgetSrKey(subject, name);
  const cur = state.chapterSR[key];
  const next = srApplyGrade(cur, grade, budgetTopicAccuracy(subject, name));
  state.chapterSR[key] = { last: TODAY, interval: next.interval, ease: next.ease, grade: next.grade, subject, name };
  saveState(); renderAll();
}
// Due budget topics: only topics with an SR record can be due (there
// is no dated touch log for budget topics). Shaped like dueChapters
// entries, with budgetSubject/budgetName instead of book/chapter.
function budgetSrDue() {
  const out = [];
  Object.keys(state.chapterSR || {}).forEach(key => {
    if (key.indexOf("budget:") !== 0) return;
    const rec = state.chapterSR[key];
    if (!rec || !rec.last || !rec.subject) return;
    const nr = addDays(rec.last, rec.interval || 1);
    if (nr <= TODAY) {
      const overdue = Math.max(0, Math.round((new Date(TODAY + "T12:00:00") - new Date(nr + "T12:00:00")) / 86400000));
      out.push({ budgetSubject: rec.subject, budgetName: rec.name, nextReview: nr, overdue, neverReviewed: false });
    }
  });
  return out;
}
function chapterNextReview(chapterId) {
  const sr = chapterSR(chapterId);
  if (!sr || !sr.last) return null;
  return addDays(sr.last, sr.interval || 1);
}
// Days since the last touch: last review, or the last dated test entry
// on any of the chapter's sections — whichever is later. Null = untouched.
function chapterFreshness(chapterId, chapter) {
  let last = (chapterSR(chapterId) || {}).last || null;
  const ids = new Set((chapter.topics || []).map(t => t.id));
  (state.testLog || []).forEach(e => {
    // v1.11.50: skip non-dict entries (a null entry threw here).
    if (e && e.d && ids.has(e.topic) && (!last || e.d > last)) last = e.d;
  });
  return last;
}
function dueChapters() {
  const out = [];
  (TESTBOOK.books || []).forEach(book => (book.chapters || []).forEach(ch => {
    const nr = chapterNextReview(ch.id);
    if (nr && nr <= TODAY) {
      const overdue = Math.max(0, Math.round((new Date(TODAY + "T12:00:00") - new Date(nr + "T12:00:00")) / 86400000));
      out.push({ book, chapter: ch, nextReview: nr, overdue, neverReviewed: false });
      return;
    }
    // v1.11.37 (P3-6): a chapter studied but never explicitly reviewed
    // is due 7 days after its last touch (a test entry) — it used to
    // never appear at all. A chapter never touched at all is still
    // NOT due (no flooding the list with untouched chapters).
    if (!chapterSR(ch.id)) {
      const last = chapterFreshness(ch.id, ch);
      if (last) {
        const dueDate = addDays(last, SR_UNREVIEWED_DUE_DAYS);
        if (dueDate <= TODAY) {
          const overdue = Math.max(0, Math.round((new Date(TODAY + "T12:00:00") - new Date(dueDate + "T12:00:00")) / 86400000));
          out.push({ book, chapter: ch, nextReview: dueDate, overdue, neverReviewed: true });
        }
      }
    }
  }));
  // v1.11.37 (P3-6): due budget topics (geometry + general subjects).
  budgetSrDue().forEach(d => out.push(d));
  return out.sort((a, b) => b.overdue - a.overdue);
}
// One chapter's SR line for the book view: freshness, next review,
// interval, accuracy trend, and the "reviewed" button.
function srChapterLine(book, ch) {
  const wrap = document.createElement("div");
  wrap.className = "ch-sr-line";
  const sr = chapterSR(ch.id);
  const last = chapterFreshness(ch.id, ch);
  const nr = chapterNextReview(ch.id);
  const tr = chapterTrendLabel(ch);
  const daysAgo = last ? Math.max(0, Math.round((new Date(TODAY + "T12:00:00") - new Date(last + "T12:00:00")) / 86400000)) : null;
  // v1.11.37 (P3-6): a never-reviewed chapter with a last touch has an
  // implicit next review (last touch + 7 days, see dueChapters).
  const implicitNr = (!nr && last) ? addDays(last, SR_UNREVIEWED_DUE_DAYS) : null;
  wrap.innerHTML = '<span class="muted">' + esc(t("srFreshness")) + ': ' +
    (daysAgo == null ? esc(t("srNeverReviewed")) : esc(t("srDaysAgo", { n: FA(daysAgo) }))) +
    ((nr || implicitNr) ? ' · ' + esc(t("srNextReview", { d: gregToJalali(nr || implicitNr).text })) : '') +
    (sr ? ' · ' + esc(t("srInterval", { n: FA(sr.interval || 1) })) + ' · ' + esc(t("srEase", { n: FA(Math.round((sr.ease || SR_EASE_DEFAULT) * 100) / 100) })) : '') +
    (tr ? ' · ' + esc(t("tlTitle")) + ': ' + esc(t("tlFirst")) + ' ' + FA_PCT(tr.first * 100) + ' · ' + esc(t("tlLast")) + ' ' + FA_PCT(tr.last * 100) + ' · ' + esc(t(tr.dir === "improving" ? "tlImproving" : tr.dir === "declining" ? "tlDeclining" : "tlStable")) : '') +
    '</span>';
  // v1.11.37 (P3-6): three recall grades instead of one "reviewed"
  // button — the grade moves the ease factor (see srApplyGrade).
  const gradeRow = document.createElement("div");
  gradeRow.className = "sr-grade-row";
  [["remembered", "srGradeRemembered"], ["hard", "srGradeHard"], ["forgot", "srGradeForgot"]].forEach(([grade, key]) => {
    const gb = document.createElement("button");
    gb.className = "btn sr-grade-btn";
    gb.dataset.srGrade = grade;
    gb.textContent = t(key);
    gb.addEventListener("click", () => markChapterReviewed(ch.id, grade));
    gradeRow.appendChild(gb);
  });
  wrap.appendChild(gradeRow);
  return wrap;
}
// Dashboard block (3.4): chapters due for review today, with a quick
// "reviewed" button each. Error-notebook items due today (3.3) get one
// compact line with a jump to the testbook tab. Rebuilt on every render.
function renderSRDue() {
  const anchor = document.getElementById("todayBoxes");
  if (!anchor || !anchor.parentNode) return;
  const old = document.getElementById("dashSRDue");
  if (old) old.remove();
  const wrap = document.createElement("div");
  wrap.id = "dashSRDue";
  wrap.className = "sr-block";
  const title = document.createElement("h3");
  title.textContent = t("srTitle");
  wrap.appendChild(title);
  const due = dueChapters();
  if (!due.length) {
    const p = document.createElement("p");
    p.className = "muted";
    p.textContent = t("srNone");
    wrap.appendChild(p);
  } else {
    due.forEach(d => {
      const row = document.createElement("div");
      row.className = "trow topic sr-row";
      // v1.11.37 (P3-6): due budget topics (geometry + general subjects)
      // render with their subject + topic name instead of book/chapter.
      const label = d.budgetSubject
        ? esc(subjName(d.budgetSubject)) + ' — ' + esc(d.budgetName || "")
        : esc(bookName(d.book)) + ' — ' + esc(chapterTitle(d.chapter));
      row.innerHTML = '<span>' + label +
        ' <span class="muted">(' + (d.overdue > 0 ? esc(t("srOverdue", { n: FA(d.overdue) })) : esc(t("srDueToday"))) + ')</span></span>';
      // v1.11.37 (P3-6): three recall grades (book chapters and budget
      // topics alike) — the grade moves the ease factor.
      const gradeRow = document.createElement("div");
      gradeRow.className = "sr-grade-row";
      [["remembered", "srGradeRemembered"], ["hard", "srGradeHard"], ["forgot", "srGradeForgot"]].forEach(([grade, key]) => {
        const gb = document.createElement("button");
        gb.className = "btn sr-grade-btn";
        gb.dataset.srGrade = grade;
        gb.textContent = t(key);
        gb.addEventListener("click", () => {
          if (d.budgetSubject) markBudgetTopicReviewed(d.budgetSubject, d.budgetName, grade);
          else markChapterReviewed(d.chapter.id, grade);
        });
        gradeRow.appendChild(gb);
      });
      row.appendChild(gradeRow);
      wrap.appendChild(row);
    });
  }
  const dueErr = errNbDue();
  if (dueErr.length) {
    const p = document.createElement("p");
    p.className = "muted sr-err-line";
    p.innerHTML = esc(t("errNbTitle")) + ': ' + FA(dueErr.length) + ' ' + esc(t("errNbDue")) + ' ';
    const jump = document.createElement("button");
    jump.className = "btn";
    jump.textContent = t("tabTestbook");
    jump.addEventListener("click", () => navigate({ tab: "testbook" }));
    p.appendChild(jump);
    wrap.appendChild(p);
  }
  anchor.parentNode.insertBefore(wrap, anchor);
}

// ---------- Error notebook 2.0 (audit §5 item 3.3) ----------
// Wrong-question log: {id, d, subject, source, q, type, note, step,
// nextReview, reviews}. OPTIONAL — per-subject opt-in in
// state.errorNotebook, default OFF for every subject: a subject with no
// entry there is disabled, and its errors never appear in any reminder
// (the dashboard only ever mentions enabled subjects). Disabling a
// subject later hides its reminders but never deletes its entries.
// Review steps: 1, 3, 7, 14, 30 days — marking an entry reviewed
// advances it one step.
const ERR_TYPES = ["concept", "careless", "time"];
const ERR_REVIEW_STEPS = [1, 3, 7, 14, 30];
const ERR_TYPE_KEY = { concept: "errTypeConcept", careless: "errTypeCareless", time: "errTypeTime" };
function errNbEnabled(subject) { return !!((state.errorNotebook || {})[subject]); }
function errNbEnabledSubjects() { return (state.subjects || []).filter(s => errNbEnabled(s)); }
function errNbDue() {
  // Due = next review today or past, and only for enabled subjects.
  return (state.errorLog || []).filter(e => e.nextReview && e.nextReview <= TODAY && errNbEnabled(e.subject));
}
function errNbAdd(subject, source, q, type, note) {
  state.errorLog = state.errorLog || [];
  const d = TODAY;
  state.errorLog.unshift({ id: "err-" + Date.now(), d, subject, source: source || "",
    q: q || "", type, note: note || "", step: 0,
    nextReview: addDays(d, ERR_REVIEW_STEPS[0]), reviews: 0 });
  // v1.11.52 (CQ-02): cap the log at 2000, like testLog (app.js:1104)
  // and timerSessions (500) — the notebook used to grow without bound.
  if (state.errorLog.length > 2000) state.errorLog.length = 2000;
  saveState();
}
// v1.11.35 (P2-11): bulk-add n wrong questions from one box — the same
// entry shape as errNbAdd, one entry per question, unique ids (the
// Date.now() + index + random suffix avoids same-millisecond clashes).
function errNbAddMany(subject, source, count, type) {
  state.errorLog = state.errorLog || [];
  const d = TODAY;
  for (let i = 0; i < count; i++) {
    state.errorLog.unshift({ id: "err-" + Date.now() + "-" + i + "-" + Math.floor(Math.random() * 1000),
      d, subject, source: source || "", q: "", type, note: "", step: 0,
      nextReview: addDays(d, ERR_REVIEW_STEPS[0]), reviews: 0 });
  }
  // v1.11.52 (CQ-02): cap the log at 2000 (see errNbAdd above).
  if (state.errorLog.length > 2000) state.errorLog.length = 2000;
  saveState();
}
// v1.11.35 (P2-11): the transient "take the wrong answers to the
// notebook?" offer — boxId -> { subject, source, wrongAt }. Transient
// only (module-level, never persisted): a reload drops the offer, the
// wrong counts stay in state. wrongAt is the wrong total when the
// offer was first made, so the shown count is always the current
// wrong total minus wrongAt.
const ERRNB_PROMPT = {};
function errNbPromptCount(b) {
  const p = ERRNB_PROMPT[b.id];
  if (!p) return 0;
  const tr = testOf(b);
  return Math.max(0, ((tr.completed || 0) - (tr.correct || 0)) - p.wrongAt);
}
function wireErrNbPrompt(slot, b) {
  slot.innerHTML = "";
  const n = errNbPromptCount(b);
  if (!n) { delete ERRNB_PROMPT[b.id]; return; }
  const p = ERRNB_PROMPT[b.id];
  const wrap = document.createElement("div");
  wrap.className = "errnb-prompt";
  wrap.innerHTML = '<div class="muted">' + esc(t("errNbPromptTitle")) + ' (' + FA(n) + ')</div>' +
    '<div class="form-row">' +
    '<label>' + esc(t("errNbPromptCount")) + ' <input type="number" min="1" max="' + n + '" class="errnb-prompt-n" value="' + n + '"></label>' +
    '<label>' + esc(t("errNbType")) + ' <select class="errnb-prompt-type">' +
    ERR_TYPES.map(ty => '<option value="' + ty + '">' + esc(t(ERR_TYPE_KEY[ty])) + '</option>').join("") +
    '</select></label>' +
    '<button class="btn btn-primary errnb-prompt-add">' + esc(t("errNbPromptAdd")) + '</button>' +
    '<button class="btn errnb-prompt-skip">' + esc(t("cancelBtn")) + '</button>' +
    '</div>';
  wrap.querySelector(".errnb-prompt-add").addEventListener("click", () => {
    const inp = wrap.querySelector(".errnb-prompt-n");
    const count = Math.max(1, Math.min(n, parseInt(inp.value, 10) || n));
    errNbAddMany(p.subject, p.source, count, wrap.querySelector(".errnb-prompt-type").value);
    delete ERRNB_PROMPT[b.id];
    renderAll();
  });
  wrap.querySelector(".errnb-prompt-skip").addEventListener("click", () => {
    delete ERRNB_PROMPT[b.id];
    renderAll();
  });
  slot.appendChild(wrap);
}
// v1.11.35 (P2-11): due errors get a review box via findGapDay — one
// 60-minute box for the subject with the most due entries. Explicit
// button only; nothing is created automatically, and a second box for
// the same subject is never created while one is still undone.
async function createErrNbReviewBox(due) {
  if (!due || !due.length) return;
  const bySubj = {};
  due.forEach(e => { bySubj[e.subject] = (bySubj[e.subject] || 0) + 1; });
  const subject = Object.keys(bySubj).sort((a, b) => bySubj[b] - bySubj[a])[0];
  const title = "مرور دفترچه خطا — " + subjName(subject);
  const existing = allBoxes().find(b => !isDone(b) && (b.title || "").indexOf("مرور دفترچه خطا") === 0 && b.subject === subject);
  if (existing) { alert(t("errNbReviewBoxExists")); return; }
  const gap = findGapDay({ subject, start: "09:00", end: "10:00" });
  if (!gap) { alert(t("errNbReviewBoxNoGap")); return; }
  // Same create path as the program tab's add-box button: POST
  // /api/boxes/create, local fallback on an unreachable server.
  // v1.11.52 (F3): idempotent create — a lost response adopts the
  // server box by client_id instead of duplicating it.
  const created = await createBoxIdempotent({ title, date: gap.date, start: gap.start, end: gap.end, subject, topic: title, is_test: false, tests_total: 0, note: "", type: "normal" });
  let box = created.box, serverErr = created.serverErr;
  if (serverErr) { alert(errText(serverErr)); return; }
  if (!box) {
    box = { id: localBoxId(), date: gap.date, start: gap.start, end: gap.end, subject, topic: title, title, is_test: false, tests_total: 0, note: "", type: "normal" };
  }
  (state.custom_boxes = state.custom_boxes || []).push(box);
  saveState(); renderAll();
  alert(t("errNbReviewBoxDone"));
}
function errNbReview(id) {
  const e = (state.errorLog || []).find(x => x.id === id);
  if (!e) return;
  e.reviews = (e.reviews || 0) + 1;
  e.step = Math.min((e.step || 0) + 1, ERR_REVIEW_STEPS.length - 1);
  e.nextReview = addDays(TODAY, ERR_REVIEW_STEPS[e.step]);
  saveState(); renderAll();
}
function errNbDelete(id) {
  if (!confirm(t("errNbDeleteConfirm"))) return;
  state.errorLog = (state.errorLog || []).filter(x => x.id !== id);
  saveState(); renderAll();
}
function errNbRow(e) {
  const row = document.createElement("div");
  row.className = "trow topic err-row";
  row.id = "err-row-" + e.id; // v1.11.52 (P-6): search jumps here
  row.innerHTML = '<span>' + esc(subjName(e.subject)) + ' — ' + esc(e.source || "") +
    (e.q ? ' · ' + t("errNbQ") + ' ' + esc(String(e.q)) : '') +
    ' <span class="err-type">' + esc(t(ERR_TYPE_KEY[e.type] || "errTypeConcept")) + '</span>' +
    (e.note ? ' · ' + esc(e.note) : '') +
    ' <span class="muted">(' + esc(gregToJalali(e.d).text) +
    (e.nextReview ? ' · ' + esc(t("errNbNextReview")) + ': ' + esc(gregToJalali(e.nextReview).text) : '') + ')</span></span>';
  const rb = document.createElement("button");
  rb.className = "btn sr-review-btn";
  rb.textContent = t("errNbReviewed");
  rb.addEventListener("click", () => errNbReview(e.id));
  row.appendChild(rb);
  const db = document.createElement("button");
  db.className = "btn";
  db.textContent = t("errNbDelete");
  db.addEventListener("click", () => errNbDelete(e.id));
  row.appendChild(db);
  return row;
}
// The section appended at the end of the testbook tab (renderTestbookTab).
function renderErrorNotebook() {
  const wrap = document.createElement("div");
  wrap.id = "errNbBlock";
  wrap.className = "errnb-block";
  const title = document.createElement("h3");
  title.textContent = t("errNbTitle");
  wrap.appendChild(title);
  const sub = document.createElement("p");
  sub.className = "muted";
  sub.textContent = t("errNbSub");
  wrap.appendChild(sub);
  // Per-subject opt-in toggles (default off).
  const tg = document.createElement("div");
  tg.className = "errnb-toggles";
  const tgLab = document.createElement("span");
  tgLab.className = "muted";
  tgLab.textContent = t("errNbEnable") + ": ";
  tg.appendChild(tgLab);
  (state.subjects || []).forEach(s => {
    const lab = document.createElement("label");
    lab.className = "errnb-toggle";
    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.checked = errNbEnabled(s);
    cb.addEventListener("change", () => {
      state.errorNotebook = state.errorNotebook || {};
      if (cb.checked) state.errorNotebook[s] = true; else delete state.errorNotebook[s];
      saveState(); renderAll();
    });
    lab.appendChild(cb);
    lab.appendChild(document.createTextNode(" " + subjName(s)));
    tg.appendChild(lab);
  });
  wrap.appendChild(tg);
  // Add form (enabled subjects only; disabled when none are enabled).
  const enabled = errNbEnabledSubjects();
  const form = document.createElement("div");
  form.className = "errnb-form";
  const selS = document.createElement("select");
  selS.className = "errnb-subject";
  selS.setAttribute("aria-label", t("errNbEnable"));
  enabled.forEach(s => {
    const o = document.createElement("option");
    o.value = s; o.textContent = subjName(s);
    selS.appendChild(o);
  });
  const inpSrc = document.createElement("input");
  inpSrc.type = "text"; inpSrc.className = "errnb-source";
  inpSrc.placeholder = t("errNbSourcePh");
  inpSrc.setAttribute("aria-label", t("errNbSource"));
  const inpQ = document.createElement("input");
  inpQ.type = "text"; inpQ.className = "errnb-q";
  inpQ.placeholder = t("errNbQ");
  inpQ.setAttribute("aria-label", t("errNbQ"));
  const selT = document.createElement("select");
  selT.className = "errnb-type";
  selT.setAttribute("aria-label", t("errNbType"));
  ERR_TYPES.forEach(ty => {
    const o = document.createElement("option");
    o.value = ty; o.textContent = t(ERR_TYPE_KEY[ty]);
    selT.appendChild(o);
  });
  const inpNote = document.createElement("input");
  inpNote.type = "text"; inpNote.className = "errnb-note";
  inpNote.placeholder = t("errNbNotePh");
  inpNote.setAttribute("aria-label", t("errNbNote"));
  const addBtn = document.createElement("button");
  addBtn.className = "btn btn-primary";
  addBtn.textContent = t("errNbAdd");
  addBtn.addEventListener("click", () => {
    if (!enabled.length) return;
    errNbAdd(selS.value, inpSrc.value.trim(), inpQ.value.trim(), selT.value, inpNote.value.trim());
    renderAll();
  });
  if (!enabled.length) {
    [selS, inpSrc, inpQ, selT, inpNote, addBtn].forEach(el => { el.disabled = true; });
    const need = document.createElement("p");
    need.className = "muted";
    need.textContent = t("errNbNeedSubject");
    form.appendChild(need);
  }
  [selS, inpSrc, inpQ, selT, inpNote, addBtn].forEach(el => form.appendChild(el));
  wrap.appendChild(form);
  // Due-for-review list first, then the full log (newest first).
  const due = errNbDue();
  if (due.length) {
    const dh = document.createElement("h4");
    dh.textContent = t("errNbDue");
    wrap.appendChild(dh);
    due.forEach(e => wrap.appendChild(errNbRow(e)));
    // v1.11.35 (P2-11): due errors get a review box via findGapDay.
    const rbBtn = document.createElement("button");
    rbBtn.className = "btn";
    rbBtn.textContent = t("errNbReviewBoxBtn");
    rbBtn.addEventListener("click", () => createErrNbReviewBox(due));
    wrap.appendChild(rbBtn);
  } else if (enabled.length) {
    const p = document.createElement("p");
    p.className = "muted";
    p.textContent = t("errNbDueNone");
    wrap.appendChild(p);
  }
  const all = (state.errorLog || []).slice().sort((a, b) => (b.d || "").localeCompare(a.d || ""));
  if (!all.length) {
    const p = document.createElement("p");
    p.className = "muted";
    p.textContent = t("errNbEmpty");
    wrap.appendChild(p);
  } else {
    all.forEach(e => wrap.appendChild(errNbRow(e)));
  }
  return wrap;
}
function isDayDone(date) {
  const boxes = allBoxes().filter(b => boxStudyDay(b) === date && isCurrentBox(b));
  if ((state.daysDone || {})[date]) {
    // v1.11.45 (F-03): the flag alone is not proof — a box unticked
    // after close-day must un-complete the day. Validate against the
    // live boxes (hidden ones do not count, as in applyCloseDay);
    // read-only here: never mutate state.
    const remaining = boxes.filter(b => !(state.backlogHidden || {})[b.id]);
    return remaining.length > 0 && remaining.every(isDone);
  }
  return boxes.length > 0 && boxes.every(isDone);
}
// v1.11.32 (P2-1): the «روز کامل شد» flag is written ONLY by the
// close-day flow (applyCloseDay), which computes it from the boxes
// after the user's choices. The manual setter is gone — a hand tick
// could claim a day complete while boxes were still undone.

// ---------- Test-book v1 -> v2 migration (one-time, on first load) ----------
// v1 had 3 books with syllabus-derived chapter-level topics; v2 has the four
// real books with leaf sections. Non-zero counts are carried over:
// chapter-level calc/chem counts -> the first leaf of the matching section,
// فیزیک دهم/یازدهم topics (no book here) -> TESTBOOK.legacy so nothing is lost.
// The v2 seed lives in public/testbook-seed.json; after migration the v2
// file is saved back to testbook.json immediately.
const V1_LEAF_MAP = {
  "calc-function": "calc-c1-l1", "calc-trig": "calc-c6-l51",
  "calc-limit": "calc-c7-l67", "calc-limit12": "calc-c7-l72",
  "calc-equation": "calc-c3-l24", "calc-exp": "calc-c5-l38",
  "calc-sequence": "calc-c10-l104", "calc-power": "calc-c11-l110",
  "calc-derivative": "calc-c8-l80",
  "chem1-ch1": "chem-c1-s1", "chem1-ch2": "chem-c2-s1", "chem1-ch3": "chem-c3-s1",
  "chem2-ch1": "chem-c4-s1", "chem2-ch2": "chem-c5-s1", "chem2-ch3": "chem-c6-s1",
  "chem3-ch1": "chem-c7-s1", "chem3-ch2": "chem-c8-s1",
  "chem3-ch3": "chem-c9-s1", "chem3-ch4": "chem-c10-s1"
};
const V1_LEGACY = {
  "phys-thermo": "ترمودینامیک (دهم)", "phys-heat": "دما و گرما (دهم)",
  "phys-static": "الکتریسیته ساکن (یازدهم)", "phys-circuit": "مدار و جریان الکتریکی (یازدهم)",
  "phys-magnet": "مغناطیس (یازدهم)", "phys-induction": "القای الکترومغناطیسی (یازدهم)",
  "phys-materials": "فشار و ویژگی‌های مواد (دهم)", "phys-work": "کار و انرژی (دهم)",
  "phys-measure": "اندازه‌گیری (دهم)"
};
function migrateTestbookV1(old, seed) {
  const out = JSON.parse(JSON.stringify(seed));
  out.legacy = out.legacy || {};
  const leafById = {};
  (out.books || []).forEach(b => (b.chapters || []).forEach(ch =>
    (ch.topics || []).forEach(tp => { leafById[tp.id] = tp; })));
  (old.books || []).forEach(b => (b.chapters || []).forEach(ch =>
    (ch.topics || []).forEach(tp => {
      const counts = {
        tests_total: tp.tests_total || 0, manual_solved: tp.manual_solved || 0,
        manual_correct: tp.manual_correct || 0, manual_wrong: tp.manual_wrong || 0
      };
      if (!counts.tests_total && !counts.manual_solved && !counts.manual_correct && !counts.manual_wrong) return;
      const leafId = V1_LEAF_MAP[tp.id];
      if (leafId && leafById[leafId]) {
        const leaf = leafById[leafId];
        leaf.tests_total += counts.tests_total;
        leaf.manual_solved += counts.manual_solved;
        leaf.manual_correct += counts.manual_correct;
        leaf.manual_wrong += counts.manual_wrong;
        return;
      }
      const lid = "legacy-" + String(tp.id || "").replace(/^legacy-/, "");
      out.legacy[lid] = {
        id: lid, bookId: b.id || "", title: V1_LEGACY[tp.id] || tp.title || tp.id,
        tests_total: counts.tests_total, manual_solved: counts.manual_solved,
        manual_correct: counts.manual_correct, manual_wrong: counts.manual_wrong,
        mastery: "", status: "", note: ""
      };
    })));
  return out;
}

// ---- v1.11.31 (P1-10): the box-edit path goes through the server box
// API (POST /api/boxes/*) — the server is the single validation
// reference (length caps, zero-length, class/test/type rules). The
// dashboard DELETE path is untouched (deleteBoxById -> state.deleted ->
// POST /api/state -> auto-push; v1.11.27 delete-retry).
// Degraded mode: when the server answers OK but returns no box (or the
// fetch fails outright), the edit is applied locally exactly as before,
// so the user's input is never lost. Only an explicit server error
// (!ok) aborts with the server's message and applies nothing.
async function boxApiPost(path, payload) {
  const res = await fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
  let j = null;
  try { j = await res.json(); } catch (e) {}
  return { ok: res.ok, data: j };
}
// v1.11.52 (F3): idempotent box creation. One client_id per attempt is
// generated here and sent with the create; the server stores it on the
// box and returns the existing box on a repeat of the same key. If the
// POST throws (the response was lost — the box may already exist on
// the server), the client re-GETs /api/boxes and adopts the server box
// with the same client_id instead of inventing a second local box
// (which used to duplicate the box AND its Google event on the next
// push). Returns { box, serverErr }: box is null only when no server
// box exists and the caller must fall back to a local box; an explicit
// server error is returned as serverErr and creates nothing.
// v1.11.61 (L-DATA5): local fallback ids carry a random suffix — a
// bare `custom-<Date.now()>` collided on same-millisecond creates
// (two boxes made in one tick shared an id). The server's own ids
// are unaffected; this is only the offline-fallback path.
function localBoxId() {
  return "custom-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8);
}
async function createBoxIdempotent(payload) {
  const clientId = "cid-" + Date.now().toString(36) + "-" +
    Math.random().toString(36).slice(2, 8);
  try {
    const r = await boxApiPost("/api/boxes/create",
      Object.assign({}, payload, { client_id: clientId }));
    if (r.ok && r.data && r.data.box) return { box: r.data.box, serverErr: null };
    if (!r.ok) return { box: null, serverErr: (r.data && r.data.error) || "" };
    return { box: null, serverErr: null };
  } catch (e) {
    // Lost response: adopt the server-created box with this client_id.
    // v1.11.61 (L-DATA5): retry the recovery GET once after 500 ms —
    // the first GET can run before the server finished writing the
    // box, or fail transiently; without the retry the caller invents
    // a local box and the next saveState replaces the server box
    // with it (custom_boxes whole-replaces).
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const res = await fetch("/api/boxes");
        if (res.ok) {
          const j = await res.json();
          const hit = (j && Array.isArray(j.boxes))
            ? j.boxes.find(b => b.client_id === clientId) : null;
          if (hit) return { box: hit, serverErr: null };
        }
      } catch (e2) {}
      if (attempt === 0) await new Promise(r => setTimeout(r, 500));
    }
    return { box: null, serverErr: null };
  }
}
// Apply a server-returned public box to the local state (edits overlay
// for programme boxes, custom_boxes for custom ones). The values are
// the effective ones the server computed, so this is idempotent with
// the local overlay the same edit would write.
function applyServerBox(box) {
  if (!box || !box.id) return false;
  if (String(box.id).startsWith("custom-")) {
    const cb = (state.custom_boxes || []).find(x => x.id === box.id);
    const fields = { title: box.title, subject: box.subject, topic: box.topic, date: box.date, start: box.start, end: box.end, note: box.note || "", tests_total: box.tests_total || 0, is_test: !!box.is_test, type: box.type || "normal" };
    if (cb) Object.assign(cb, fields);
    else (state.custom_boxes = state.custom_boxes || []).push(Object.assign({ id: box.id }, fields));
  } else {
    // v1.11.50: guard the overlay writes (a null map threw here).
    state.edits = state.edits || {};
    state.tests_total = state.tests_total || {};
    state.edits[box.id] = Object.assign({}, state.edits[box.id], { title: box.title, subject: box.subject, date: box.date, start: box.start, end: box.end, note: box.note || "", type: box.type || "normal" });
    if (box.tests_total != null) state.tests_total[box.id] = box.tests_total;
  }
  return true;
}
// v1.11.31 (P1-10): the single box-loading path — GET /api/boxes is
// the source of the programme boxes (effective: seed + edits + custom,
// as the server sees them). The static data.json seed is only a
// fallback when the server cannot answer (a broken server, or an old
// jsdom harness whose fetch stub returns no boxes) — it is never a
// parallel source. Custom boxes are filtered out here: they arrive
// via /api/state and allBoxes() would double them. Returns true when
// DATA.boxes came from the server.
async function loadProgrammeBoxes() {
  try {
    const res = await fetch("/api/boxes");
    if (res.ok) {
      const j = await res.json();
      if (j && Array.isArray(j.boxes)) {
        DATA = { meta: {}, boxes: j.boxes.filter(b => !b.is_custom) };
        return true;
      }
    }
  } catch (e) {}
  try {
    const dRes = await fetch("data.json");
    if (dRes.ok) { DATA = await dRes.json(); return false; }
  } catch (e) {}
  return false;
}
// v1.11.64 (Batch 5, L-DATA4): the testbook seed merge, extracted
// from loadAll so the jsdom harness can pin it directly (verify1164).
// v1.11.49: a new seed book (e.g. هندسه جامع) must reach an EXISTING
// v2 testbook.json too — the seed was previously only consulted for
// the v1 migration, so a user whose file is already v2 would never
// see the new book. v1.11.51: a new seed CHAPTER (e.g. «تکالیف
// انصاری» in disc) must reach an EXISTING book too — the book-level
// merge only adds whole books, so a chapter added to a book that
// already exists would never arrive.
// Appends seed books / chapters / TOPICS that are missing by id into
// an EXISTING v2 testbook; existing books, chapters and topics — and
// all of the user's counts in them — are never touched. Books and
// chapters cannot be deleted in the app, so a missing id can only mean
// "not yet delivered", never "deliberately removed" (v1.11.49 book
// level, v1.11.51 chapter level; v1.11.64 adds the topic level — a new
// seed exam inside an existing chapter used to never reach existing
// installs). Returns true when anything was added; the caller then
// persists via saveTestbook() (the flag must be set BEFORE that call,
// which refuses while !testbookLoaded).
function mergeTestbookSeed(tb, seed) {
  tb.books = tb.books || [];
  const have = new Set(tb.books.map(b => b.id));
  let added = false;
  (seed.books || []).forEach(sb => {
    if (!have.has(sb.id)) {
      tb.books.push(JSON.parse(JSON.stringify(sb)));
      added = true;
      return;
    }
    const book = tb.books.find(b => b.id === sb.id);
    if (!book) return;
    book.chapters = book.chapters || [];
    const haveCh = new Set(book.chapters.map(c => c.id));
    (sb.chapters || []).forEach(sc => {
      if (!haveCh.has(sc.id)) {
        book.chapters.push(JSON.parse(JSON.stringify(sc)));
        added = true;
        return;
      }
      const ch = book.chapters.find(c => c.id === sc.id);
      if (!ch) return;
      ch.topics = ch.topics || [];
      const haveTp = new Set(ch.topics.map(tp => tp.id));
      (sc.topics || []).forEach(st => {
        if (!haveTp.has(st.id)) {
          ch.topics.push(JSON.parse(JSON.stringify(st)));
          added = true;
        }
      });
    });
  });
  return added;
}
async function loadAll() {
  const [, sRes, tRes, eRes] = await Promise.all([
    loadProgrammeBoxes(), fetch("/api/state"), fetch("/api/testbook"), fetch("exams.json")
  ]);
  // A failed fetch must leave the previous value in place (never the
  // empty defaults) — saveState()/saveTestbook() refuse until their
  // flag is set, so a failed load can never wipe real data (A-C1).
  if (sRes.ok) { _captureStateSeq(sRes); state = Object.assign(state, await sRes.json()); stateLoaded = true; _snapshotState(); }
  ensureStateMaps(); // v1.11.50: a malformed state must be repaired
  // in memory before any render reads it (never crash on old data).
  syncProgrammeRange(); // 1.7: extend the stored range to the programme as loaded
  state.daysDone = state.daysDone || {};
  state.topicLinks = state.topicLinks || {};
  state.examResults = state.examResults || {};
  if (tRes.ok) {
    const tb = await tRes.json();
    // v1.11.67 (PR1): capture the testbook seq + snapshot the LOADED
    // testbook (before the v1 migration / seed merge below mutate it
    // — those mutations are local changes, sent with the next save).
    _captureTbSeq(tRes);
    try { lastSyncedTestbook = JSON.parse(JSON.stringify(tb)); } catch (e) { lastSyncedTestbook = null; }
    if (!tb.version || tb.version < 2) {
      // A v1 testbook.json is on disk (the user's own counts): migrate it
      // against the v2 seed and save the migrated file back at once.
      try {
        const seedRes = await fetch("testbook-seed.json");
        if (seedRes.ok) {
          TESTBOOK = migrateTestbookV1(tb, await seedRes.json());
          testbookLoaded = true;
          saveTestbook();
        } else TESTBOOK = tb;
      } catch (e) { TESTBOOK = tb; }
    } else {
      TESTBOOK = tb;
      // v1.11.49 + v1.11.51 + v1.11.64 (L-DATA4): a new seed book,
      // chapter or TOPIC must reach an EXISTING v2 testbook too — the
      // seed was previously only consulted for the v1 migration, so a
      // user whose file is already v2 would never see new content.
      // mergeTestbookSeed appends only what is missing by id; existing
      // books/chapters/topics (and all of the user's counts in them)
      // are never touched. A failed seed fetch leaves TESTBOOK exactly
      // as loaded.
      try {
        const seedRes = await fetch("testbook-seed.json");
        if (seedRes.ok) {
          const seed = await seedRes.json();
          if (mergeTestbookSeed(TESTBOOK, seed)) { testbookLoaded = true; saveTestbook(); }
        }
      } catch (e) {}
    }
    testbookLoaded = true;
  }
  if (eRes.ok) EXAMS = await eRes.json();
  ensureExams();
  if (normalizeExamLinks() | normalizeBoxBookLinks() | normalizeAssignmentLinks()) saveState(); // persist a legacy-link migration at once
  migrateAssignments();
  state.assignmentsRemoved = state.assignmentsRemoved || [];
  document.documentElement.setAttribute("data-theme", state.theme || "dark");
  const savedLang = state.lang || (() => { try { return localStorage.getItem("konkur-lang"); } catch (e) { return null; } })() || "fa";
  applyLang(savedLang);
  refreshKeyStatus();
  refreshGeminiModel();
  refreshTelegramStatus(); // v1.11.64 (Batch 5, م-۸)
  refreshBackupStatus();
  refreshUnlinked();
  // v1.11.10: fetch the real calendar link data BEFORE the first
  // render, so the connection corner boxes are correct on first paint
  // (without this, every card renders unlinked until the 60 s tick).
  await refreshCalendarLinks();
  checkStaleTimer(); // v1.11.28 (QA BUG-040): pause + ask about a forgotten running timer
  _startMinuteTick(); // v1.11.65 (Batch 6, L-PERF5): the 60 s tick, started once here
  asgInitForm();
  resumeSim(); // v1.11.55 (F5): a stored run resumes before first paint
  initRouting();
}
// v1.11.65 (Batch 6, L-PERF5): the 60 s tick fetches /api/backup and
// toasts reminders the user never sees while the tab sits hidden for
// hours — stop it when hidden, refresh once on return. The 1 s tick
// stays: updateTimerDisplays is a cheap early-return with no timer
// running. The 30 s sleep-reminder tick is untouched (its own scope).
// v1.11.45 (F-02): the tick caps a stale timer while the page stays
// open — checkStaleTimer pauses it itself on first fire, so repeats
// are safe.
function _minuteTick() { refreshToday(); refreshBackupStatus(); renderCalendarPanel(); renderNowNext(); renderConnHealth(); checkStaleTimer(); checkNextBoxReminder(); }
let _minuteTickId = null;
function _startMinuteTick() { if (_minuteTickId == null) _minuteTickId = setInterval(_minuteTick, 60000); }
function _stopMinuteTick() { if (_minuteTickId != null) { clearInterval(_minuteTickId); _minuteTickId = null; } }
document.addEventListener("visibilitychange", () => {
  if (document.hidden) _stopMinuteTick();
  else { _startMinuteTick(); _minuteTick(); } // refresh once on return
});
// ---------- v1.11.67 (PR1, seq/ETag): save sequencing ----------
// The server assigns a monotonic sequence per save (seq.json — one
// counter for state, one for testbook). Every save sends the
// last-seen seq (X-State-Seq / X-Testbook-Seq header on fetch, _seq
// in the body on sendBeacon, which cannot set headers); a stale full
// save is REJECTED (409) with the current server state/testbook, and
// the client rebases its own changes onto it and retries (max 3
// attempts, in runSaveState / runSaveTestbook). A genuine deletion is
// NEVER resurrected: the rebase only takes the server's value for a
// key/entry the client did NOT touch since its last sync
// (lastSyncedState / lastSyncedTestbook — the state as last fetched
// or successfully saved). The two save paths stay separate (state
// and testbook), as before. The old per-tab saveSeq counter (1.11.17,
// only logged server-side) is gone: the header now carries the
// SERVER-assigned seq.
let serverSeq = null;        // last server state seq seen (null = unknown)
let lastSyncedState = null;  // deep copy of the state as last synced
let tbServerSeq = null;      // last server testbook seq seen
let lastSyncedTestbook = null;
function _jeq1167(a, b) { return JSON.stringify(a) === JSON.stringify(b); }
function _isObj1167(v) { return v !== null && typeof v === "object" && !Array.isArray(v); }
function _arrKey1167(el) {
  if (_isObj1167(el) && typeof el.id === "string" && el.id) return "id:" + el.id;
  return "json:" + JSON.stringify(el);
}
// Recursive 3-way value merge: base = the last state both sides
// agreed on, mine = this tab's value, theirs = the server's value.
// Unchanged-in-mine takes theirs; unchanged-in-theirs takes mine;
// changed-in-both takes mine (last-writer-wins per value — the
// saving tab). DELETIONS: deleted-in-mine stays deleted (my deletion
// wins, so a genuine deletion is never resurrected); deleted-in-
// theirs wins when mine did NOT touch the entry (the server's
// deletion stands — this is what keeps a book another tab deleted
// from coming back); deleted-in-theirs LOSES only when mine changed
// the entry (a delete/modify conflict, last-writer-wins). Dicts merge
// per entry, arrays per element (id-bearing elements match by id, the
// rest by JSON — so two tabs creating different boxes both survive,
// and an append-only log keeps both sides' additions).
function _threeWayValue1167(base, mine, theirs) {
  if (Array.isArray(mine) && Array.isArray(theirs) && Array.isArray(base)) {
    const bMap = new Map(), mMap = new Map(), tMap = new Map();
    for (const el of base) bMap.set(_arrKey1167(el), el);
    for (const el of mine) mMap.set(_arrKey1167(el), el);
    for (const el of theirs) tMap.set(_arrKey1167(el), el);
    const out = [], seen = new Set();
    const push = (k, el) => { if (!seen.has(k)) { seen.add(k); out.push(el); } };
    for (const [k, bEl] of bMap) {
      if (!mMap.has(k)) continue;              // I deleted it -> stays deleted
      if (!tMap.has(k)) { if (!_jeq1167(mMap.get(k), bEl)) push(k, mMap.get(k)); continue; }  // server deleted it: unchanged-in-mine -> the deletion wins; changed-in-mine -> keep mine
      push(k, _threeWayValue1167(bEl, mMap.get(k), tMap.get(k)));
    }
    for (const [k, el] of mMap) if (!bMap.has(k)) push(k, el);   // my additions
    for (const [k, el] of tMap) if (!bMap.has(k)) push(k, el);   // their additions
    return out;
  }
  if (_isObj1167(mine) && _isObj1167(theirs) && _isObj1167(base)) {
    const out = {};
    const keys = new Set([...Object.keys(base), ...Object.keys(mine), ...Object.keys(theirs)]);
    for (const k of keys) {
      const bHas = Object.prototype.hasOwnProperty.call(base, k);
      const mHas = Object.prototype.hasOwnProperty.call(mine, k);
      const tHas = Object.prototype.hasOwnProperty.call(theirs, k);
      if (!mHas && !tHas) continue;            // deleted on both sides
      if (!mHas) { if (!bHas && tHas) out[k] = theirs[k]; continue; }  // I deleted it -> stays deleted; server added it -> take theirs
      if (!tHas) { if (!_jeq1167(mine[k], base[k])) out[k] = mine[k]; continue; }  // server deleted it: unchanged-in-mine -> the deletion wins; changed-in-mine -> keep mine
      out[k] = _threeWayValue1167(base[k], mine[k], theirs[k]);
    }
    return out;
  }
  return _jeq1167(mine, base) ? theirs : mine;
}
const MERGED_STATE_KEYS_1167 = ["done", "tests", "edits", "actualMinutes", "tests_total"];
// 3-way merge of this tab's state onto the server's after a 409.
// Merged keys take mine wholesale — the retry POST goes through the
// server's per-box deep merge, which unions both tabs' per-box
// entries, so the other tab's ticks still survive. activeTimer is
// whole-object (its fields must not mix across tabs); the server's
// PR3 startedAt guard still applies on the retry.
function threeWayMergeState(base, mine, theirs) {
  const out = {};
  const keys = new Set([...Object.keys(base || {}), ...Object.keys(mine || {}), ...Object.keys(theirs || {})]);
  for (const k of keys) {
    const b = (base || {})[k], m = (mine || {})[k], t = (theirs || {})[k];
    const bHas = base && Object.prototype.hasOwnProperty.call(base, k);
    const mHas = mine && Object.prototype.hasOwnProperty.call(mine, k);
    const tHas = theirs && Object.prototype.hasOwnProperty.call(theirs, k);
    if (!mHas && !tHas) continue;
    if (!mHas) { if (!bHas && tHas) out[k] = t; continue; }
    if (!tHas) { if (!_jeq1167(m, b)) out[k] = m; continue; }
    if (MERGED_STATE_KEYS_1167.indexOf(k) !== -1) { out[k] = m; continue; }
    if (k === "activeTimer") { out[k] = _jeq1167(m, b) ? t : m; continue; }
    out[k] = _threeWayValue1167(b, m, t);
  }
  return out;
}
// 3-way merge of this tab's testbook onto the server's after a 409.
// Books nest chapters nest topics, all id-bearing arrays, so the
// generic recursive merge handles every level: a book/chapter/topic
// the client deleted (present in base, absent in mine) stays deleted
// — a deliberately deleted book is never resurrected — and counts
// changed on one side only take that side's value.
function threeWayMergeTestbook(base, mine, theirs) {
  return _threeWayValue1167(base || {}, mine || {}, theirs || {});
}
function _captureStateSeq(res) {
  try {
    const h = res && res.headers && res.headers.get ? res.headers.get("X-State-Seq") : null;
    if (h !== null && h !== "") { const n = parseInt(h, 10); if (!isNaN(n)) serverSeq = n; }
  } catch (e) {}
}
function _captureTbSeq(res) {
  try {
    const h = res && res.headers && res.headers.get ? res.headers.get("X-Testbook-Seq") : null;
    if (h !== null && h !== "") { const n = parseInt(h, 10); if (!isNaN(n)) tbServerSeq = n; }
  } catch (e) {}
}
function _snapshotState() { try { lastSyncedState = JSON.parse(JSON.stringify(state)); } catch (e) { lastSyncedState = null; } }
function _snapshotTestbook() { try { lastSyncedTestbook = JSON.parse(JSON.stringify(TESTBOOK)); } catch (e) { lastSyncedTestbook = null; } }
// Save queue (audit §5 item 1.9): state saves are serialized — each
// POST waits for the previous one to finish, so rapid successive saves
// can never overlap and arrive out of order (the 400 ms debounce
// collapses bursts; the queue orders what remains).
let saveQueue = Promise.resolve();
// v1.11.67 (PR1): saveSeq is gone — X-State-Seq now carries the
// SERVER-assigned seq (serverSeq above), not a per-tab counter.
// v1.11.60 (L-PERF1): a state/testbook POST fetch currently on the
// wire. flushSavesBeacon reads these: a beacon sent while the same
// kind of POST is in flight can overtake it on the threaded server
// (last-writer-wins) and the newer edit is lost.
let savePostInFlight = false;
let tbPostInFlight = false;
// ---------- Toast feedback (v1.11.41, UI-audit batch 1) ----------
// A small bottom-centre toast (~2 s) for the common actions — tick,
// explicit save, backup, sync — plus a distinct error toast when a
// save fails. The topbar "saved" pill stays as it was; the toast is
// additional feedback, not a replacement. At most 3 toasts at once.
function showToast(msg, opts) {
  const wrap = document.getElementById("toastWrap");
  if (!wrap) return null;
  const o = opts || {};
  while (wrap.children.length >= 3) wrap.removeChild(wrap.firstChild);
  const el = document.createElement("div");
  el.className = "toast" + (o.kind === "err" ? " err" : "");
  el.textContent = msg;
  let gone = false;
  const close = () => { if (!gone) { gone = true; el.remove(); } };
  if (o.action) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "toast-undo";
    btn.textContent = o.action.label;
    btn.addEventListener("click", () => { close(); o.action.fn(); });
    el.appendChild(btn);
  }
  // v1.11.48 (P-4): an optional whole-toast click (e.g. the next-box
  // reminder jumps to Today + the box). The action button above keeps
  // its own handler; clicks on it must NOT also fire onClick.
  if (o.onClick) {
    el.style.cursor = "pointer";
    el.addEventListener("click", (ev) => { if (ev.target.closest("button")) return; close(); o.onClick(); });
  }
  wrap.appendChild(el);
  setTimeout(close, o.ms || 2000);
  return close;
}
// ---------- Shared empty state (v1.11.52, I-5) ----------
// One component for every empty view: title + one hint line + a
// next-step button. Gradual replacement — starting with Today with
// no boxes and Analytics with no data — so the empty states stop
// drifting apart (bare <p class="muted"> lines, each worded
// differently). opts: { title, hint, actionLabel, onAction } — hint
// and action are optional; a title-only state is still one component.
// emptyState() returns an element (for DOM appends); emptyStateHtml()
// the same markup as a string (for innerHTML renders), wired after
// insertion with wireEmptyState(container, onAction).
function emptyStateHtml(o) {
  o = o || {};
  return '<div class="empty-state"><div class="es-title">' + esc(o.title || "") + '</div>' +
    (o.hint ? '<div class="es-hint muted">' + esc(o.hint) + '</div>' : "") +
    (o.actionLabel ? '<button type="button" class="btn btn-primary es-action">' + esc(o.actionLabel) + '</button>' : "") + '</div>';
}
function emptyState(o) {
  const div = document.createElement("div");
  div.innerHTML = emptyStateHtml(o);
  const el = div.firstChild;
  const btn = el.querySelector(".es-action");
  if (btn && o && o.onAction) btn.addEventListener("click", o.onAction);
  return el;
}
function wireEmptyState(container, onAction) {
  if (!container || !onAction) return;
  const btn = container.querySelector(".es-action");
  if (btn) btn.addEventListener("click", onAction);
}
// ---------- Bulk-apply undo point (v1.11.52, I-6) ----------
// Before a bulk apply, remember the newest verified local "state"
// backup; after the apply, a toast offers «بازگردانی» for 30 s.
// Undo restores that backup and reloads from the server. A backup
// restore is used (not a client snapshot) because a snapshot could
// NOT undo edits-overlay moves of previously-unedited boxes —
// merge_state_update deep-merges `edits` per box (srv/common.py),
// so only a whole-file restore is a true undo. The restore handler
// snapshots the current file first, so the apply stays recoverable.
// flushSaves() runs first so the remembered entry is the pre-apply
// state even when a debounced save was still pending.
// Returns the remembered entry ({ kind: "state", file }) or null
// when no backup exists / the server is unreachable — the apply
// still runs, it just has no undo toast.
async function bulkUndoPoint() {
  try {
    await flushSaves();
    const res = await fetch("/api/backup/list");
    if (!res.ok) return null;
    const j = await res.json();
    // v1.11.61 (F8): the server returns `versions` as a FLAT ARRAY of
    // {kind, file, ...} entries — the same shape renderBackup consumes
    // with `.filter(v => v.kind === "state")`. The old code read it as
    // an object (`.versions.state`), which is undefined on an array,
    // so this always returned null and the undo toast never appeared.
    const entries = (Array.isArray(j && j.versions) ? j.versions : [])
      .filter(v => v && v.kind === "state" && v.verified !== false);
    if (!entries.length) return null;
    return { kind: "state", file: entries[0].file };
  } catch (e) { return null; }
}
function bulkUndoToast(point, doneMsg) {
  if (!point) { if (doneMsg) showToast(doneMsg); return; }
  showToast(doneMsg || t("bulkApplied"), { ms: 30000, action: { label: t("bulkUndo"), fn: async () => {
    // v1.11.65 (Batch 6, ب-۷): a failed undo restore says why and
    // offers a retry — the plain failure toast never did.
    const doUndoRestore = async () => {
      try {
        const res = await fetch("/api/backup/restore", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ kind: point.kind, file: point.file })
        });
        if (!res.ok) {
          let reason = "";
          try { const ej = await res.json(); reason = errText(ej.error) || ej.error || ""; } catch (e2) {}
          showToast(t("bkRestoreFailedReason", { e: reason || ("HTTP " + res.status) }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: doUndoRestore } });
          return;
        }
        await refreshDataFromServer();
        renderAll();
        showToast(t("bulkUndone"));
      } catch (e) { showToast(t("bkRestoreFailedReason", { e: t("serverUnreachable") }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: doUndoRestore } }); }
    };
    await doUndoRestore();
  } } });
}
function saveState() {
  const pill = document.getElementById("savedPill");
  if (!stateLoaded) {
    // The state never loaded (server error): do NOT POST the empty
    // defaults over the user's real data — show the failure instead.
    pill.textContent = t("saveFailedServer");
    if (pill) pill.classList.add("pill-err");
    showToast(t("saveFailedServer"), { kind: "err", ms: 4000 });
    return;
  }
  pill.textContent = t("saving");
  clearTimeout(saveTimer);
  savePending = true;
  saveTimer = setTimeout(() => { savePending = false; runSaveState(); }, 400);
}
// The debounced save itself, extracted so flushSaves() can run it
// immediately (v1.11.48, F2). Appends one POST to the serial queue and
// returns the queue promise. The body is stringified at SEND time, not
// schedule time: a queued save must carry the LATEST state.
// v1.11.55 (PERF-03): the last state body actually POSTed. A save
// whose body is byte-identical to it is a no-op — same bytes on the
// server already, so skip the POST (still mark the pill saved and keep
// the queue promise, so flushSaves() ordering is preserved). Safe:
// the seq stays OUT of the body (it rides in the header), so the
// comparison still works; a byte-identical body means nothing changed
// locally, and if another tab saved meanwhile the next REAL (changed)
// save 409s and rebases instead of clobbering. The stringify itself
// still runs per save (it is the comparison); the saved cost is the
// network round-trip + server write + backup-status refresh.
let lastSentStateBody = null;
// v1.11.61 (M-DATA1): the last state save's outcome — flushSaves()
// returns it, so bulk applies can tell the user the truth instead of
// always reporting success. It is a BOOLEAN, not a throw:
// refreshDataFromServer awaits flushSaves() unconditionally, and a
// throw there would abort the refresh (and its renderAll). Callers
// that schedule a save first always get a fresh value for that save
// (the queued task sets it on every path, including the byte-identical
// skip, which counts as success). v1.11.71 (audit #2, L15): the
// initial value is false, not true — "no save ever attempted" must
// never read as success (a saveState() that returns early because
// stateLoaded is false used to leave the initial true standing).
let lastSaveOk = false;
function runSaveState() {
  saveQueue = saveQueue.then(async () => {
    const pill = document.getElementById("savedPill");
    try {
      // v1.11.21 backstop: clamp useful to real before the state
      // leaves the browser (covers legacy data loaded from disk).
      clampUsefulState();
      // Stringify at send time, not schedule time: a queued save
      // must carry the LATEST state, not a stale snapshot.
      let body = JSON.stringify(state);
      if (body === lastSentStateBody) {
        if (pill) { pill.textContent = t("savedAuto"); pill.classList.remove("pill-err"); }
        lastSaveOk = true;
        return;
      }
      // v1.11.67 (PR1): up to 3 attempts. The save carries the
      // last-seen server seq (X-State-Seq) and the _full marker. A
      // stale save is rejected (409) with the current server state;
      // rebase the local changes onto it (3-way merge against the
      // last-synced snapshot — a genuine deletion is never
      // resurrected) and retry with the fresh seq. No toast on a 409
      // itself: the rebase is silent. The error toast below only
      // fires when the retries are exhausted or the server answers
      // another error.
      for (let attempt = 0; attempt < 3; attempt++) {
        const res = await (async () => {
          // v1.11.60 (L-PERF1): mark the POST in flight so
          // flushSavesBeacon never beacons over it (see there).
          savePostInFlight = true;
          try {
            return await fetch("/api/state", {
              method: "POST",
              headers: { "Content-Type": "application/json",
                         "X-State-Seq": serverSeq == null ? "" : String(serverSeq),
                         "X-State-Full": "1" },
              body
            });
          } finally {
            savePostInFlight = false;
          }
        })();
        if (res.ok) {
          _captureStateSeq(res);
          // Snapshot the SENT body, not `state`: the state may have
          // changed again before the response landed.
          lastSentStateBody = body;
          try { lastSyncedState = JSON.parse(body); } catch (e) { lastSyncedState = null; }
          if (pill) { pill.textContent = t("savedAuto"); pill.classList.remove("pill-err"); }
          refreshBackupStatus();
          lastSaveOk = true;
          return;
        }
        if (res.status === 409) {
          let payload = null;
          try { payload = await res.json(); } catch (e2) {}
          let srvState = payload && payload.state;
          let srvSeq = payload && typeof payload.seq === "number" ? payload.seq : null;
          if (!srvState) {
            // Defensive: the 409 should carry the state, but a
            // plain GET is the fallback.
            try {
              const r2 = await fetch("/api/state");
              if (r2.ok) { srvState = await r2.json(); _captureStateSeq(r2); srvSeq = serverSeq; }
            } catch (e3) {}
          }
          if (!srvState || srvSeq == null || isNaN(srvSeq)) break;
          state = threeWayMergeState(lastSyncedState || {}, state, srvState);
          serverSeq = srvSeq;
          try { lastSyncedState = JSON.parse(JSON.stringify(srvState)); } catch (e4) {}
          body = JSON.stringify(state);
          continue;
        }
        if (pill) { pill.textContent = t("saveFailed"); pill.classList.add("pill-err"); }
        // v1.11.65 (Batch 6, ب-۷): a failed save says WHY and offers
        // a retry — the pill alone never did.
        let reason = "";
        try { const ej = await res.json(); reason = errText(ej.error) || ej.error || ""; } catch (e2) {}
        showToast(t("toastNotSavedReason", { e: reason || ("HTTP " + res.status) }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: () => runSaveState() } });
        lastSaveOk = false;
        return;
      }
      // Retries exhausted (repeated 409s): say so, with a retry.
      if (pill) { pill.textContent = t("saveFailed"); pill.classList.add("pill-err"); }
      showToast(t("toastNotSavedReason", { e: t("serverUnreachable") }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: () => runSaveState() } });
      lastSaveOk = false;
    } catch (e) {
      if (pill) pill.textContent = t("saveFailedServer");
      if (pill) pill.classList.add("pill-err");
      showToast(t("toastNotSavedReason", { e: t("serverUnreachable") }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: () => runSaveState() } });
      lastSaveOk = false;
    }
  });
  return saveQueue;
}
// v1.11.48 (F2): run a pending debounced save NOW and wait for the
// queue to drain — including a save already in flight. No-op when idle.
// refreshDataFromServer() awaits this before any GET: the server must
// have the edit before we re-read the state, or the edit is silently
// lost while the pill says «ذخیره شد». Returns whether the drained
// save succeeded (v1.11.61, M-DATA1); callers that do not care ignore
// the return value.
async function flushSaves() {
  if (savePending) {
    clearTimeout(saveTimer);
    savePending = false;
    runSaveState();
  }
  await saveQueue;
  return lastSaveOk;
}
function saveTestbook() {
  if (!testbookLoaded) return; // same rule as saveState(): never POST empty data
  const pill = document.getElementById("savedPill");
  pill.textContent = t("saving");
  clearTimeout(tbTimer);
  tbPending = true;
  tbTimer = setTimeout(() => { tbPending = false; runSaveTestbook(); }, 400);
}
// The debounced testbook save itself (same F2 shape as runSaveState).
// Serialized on tbSaveQueue (v1.11.61, L-PERF2): a second call waits
// for the in-flight POST instead of overwriting tbSavePromise.
// v1.11.67 (PR1): same 409-rebase-retry as runSaveState, on the
// testbook counter. A deliberately deleted book is never resurrected:
// the rebase is a 3-way merge at topic granularity. No toast on a
// 409 itself — the rebase is silent.
function runSaveTestbook() {
  const pill = document.getElementById("savedPill");
  tbSavePromise = tbSaveQueue = tbSaveQueue.then(async () => {
    try {
      let body = JSON.stringify(TESTBOOK);
      for (let attempt = 0; attempt < 3; attempt++) {
        // v1.11.60 (L-PERF1): same in-flight mark as runSaveState.
        tbPostInFlight = true;
        let res;
        try {
          res = await fetch("/api/testbook", {
            method: "POST",
            headers: { "Content-Type": "application/json",
                       "X-Testbook-Seq": tbServerSeq == null ? "" : String(tbServerSeq),
                       "X-Testbook-Full": "1" },
            body
          });
        } finally {
          tbPostInFlight = false;
        }
        if (res.ok) {
          _captureTbSeq(res);
          try { lastSyncedTestbook = JSON.parse(body); } catch (e) {}
          if (pill) pill.textContent = t("savedAuto");
          refreshBackupStatus();
          return;
        }
        if (res.status === 409) {
          let payload = null;
          try { payload = await res.json(); } catch (e2) {}
          let srvTb = payload && payload.testbook;
          let srvSeq = payload && typeof payload.seq === "number" ? payload.seq : null;
          if (!srvTb) {
            try {
              const r2 = await fetch("/api/testbook");
              if (r2.ok) { srvTb = await r2.json(); _captureTbSeq(r2); srvSeq = tbServerSeq; }
            } catch (e3) {}
          }
          if (!srvTb || srvSeq == null || isNaN(srvSeq)) break;
          TESTBOOK = threeWayMergeTestbook(lastSyncedTestbook || {}, TESTBOOK, srvTb);
          tbServerSeq = srvSeq;
          try { lastSyncedTestbook = JSON.parse(JSON.stringify(srvTb)); } catch (e4) {}
          body = JSON.stringify(TESTBOOK);
          continue;
        }
        if (pill) { pill.textContent = t("saveFailed"); pill.classList.add("pill-err"); }
        // v1.11.68 (audit #2, L20): mirror the state path (ب-۷) — a
        // failed testbook save says WHY and offers a retry, not just
        // the red pill. The retry re-runs runSaveTestbook() (a fresh
        // 409-rebase-retry round on the testbook counter).
        let reason = "";
        try { const ej = await res.json(); reason = errText(ej.error) || ej.error || ""; } catch (e2) {}
        showToast(t("toastNotSavedReason", { e: reason || ("HTTP " + res.status) }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: () => runSaveTestbook() } });
        return;
      }
      // Retries exhausted (repeated 409s): say so, with a retry.
      if (pill) { pill.textContent = t("saveFailed"); pill.classList.add("pill-err"); }
      showToast(t("toastNotSavedReason", { e: t("serverUnreachable") }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: () => runSaveTestbook() } });
    } catch (e) {
      if (pill) pill.textContent = t("saveFailedServer");
      if (pill) pill.classList.add("pill-err");
      showToast(t("toastNotSavedReason", { e: t("serverUnreachable") }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: () => runSaveTestbook() } });
    }
  });
  return tbSavePromise;
}
// Same F2 rule as flushSaves, for the testbook: a pending book save
// must reach the server before a refresh replaces TESTBOOK wholesale.
async function flushTestbook() {
  if (tbPending) {
    clearTimeout(tbTimer);
    tbPending = false;
    runSaveTestbook();
  }
  if (tbSavePromise) await tbSavePromise;
}
// Flush any debounced save immediately when the tab closes: ticking a
// box and closing within the 400 ms debounce used to lose the edit.
// sendBeacon fires even while the page unloads; keepalive fetch is the
// fallback. Only ever sends the LOADED state/testbook (never defaults).
// v1.11.50: this used to be a second `flushSaves` declaration — the
// later one shadowed the async F2 version above, so EVERY flushSaves()
// call (including refreshDataFromServer's `await flushSaves()`) ran
// this beacon version and never drained the save queue; F2's fix was
// dead code in production. Renamed so the async version stays canonical.
function flushSavesBeacon() {
  const post = (url, body, inFlight) => {
    // v1.11.60 (L-PERF1): never beacon while the same kind of POST is
    // in flight — the beacon can overtake the older POST on the
    // threaded server (last-writer-wins) and the newer edit is lost
    // (proven in jsdom: tick, then untick + pagehide, then the stale
    // POST resolves after the beacon). The keepalive fetch goes
    // through the normal fetch path, dispatched after the in-flight
    // POST started, so the server sees it second. v1.11.67 (PR1):
    // the beacon now carries the seq too (_seq/_full/_beacon in the
    // body — sendBeacon cannot set headers), so a stale beacon can
    // no longer clobber a newer save: the server falls back to a
    // patch merge (ticks survive, day-flags/useful are dropped
    // rather than overwriting). The guard above still stands: it
    // avoids the overtake churn the 409-rebase would otherwise
    // have to clean up at unload.
    try {
      if (!inFlight && navigator.sendBeacon(url, new Blob([body], { type: "application/json" }))) return;
    } catch (e) { console.error("flushSavesBeacon sendBeacon failed:", e); }
    // v1.11.65 (Batch 6, R8): the swallowed errors hid a lost last
    // save at pagehide — log them (a Toast is invisible at pagehide,
    // so console.error is the signal here).
    try { fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body, keepalive: true }).catch((e) => { console.error("flushSavesBeacon keepalive fetch failed:", e); }); } catch (e2) { console.error("flushSavesBeacon fetch failed:", e2); }
  };
  clearTimeout(saveTimer); clearTimeout(tbTimer);
  // v1.11.67 (PR1): the beacon body is the full loaded state/testbook
  // plus the protocol fields — the server reads _seq/_full/_beacon
  // from the body (sendBeacon cannot set headers).
  if (stateLoaded) { clampUsefulState(); post("/api/state", JSON.stringify(Object.assign({}, state, {_seq: serverSeq, _full: true, _beacon: true})), savePostInFlight); }
  if (testbookLoaded) post("/api/testbook", JSON.stringify(Object.assign({}, TESTBOOK, {_seq: tbServerSeq, _full: true, _beacon: true})), tbPostInFlight);
}
window.addEventListener("pagehide", flushSavesBeacon);
// v1.11.60 (خ-۷, audit UX idea): a gentle leave warning ONLY while a
// timer is running — never in the normal state. (Chrome shows its own
// generic text; the i18n string is the message where the browser
// honours it.)
window.addEventListener("beforeunload", (e) => {
  if (!state.activeTimer) return;
  e.preventDefault();
  e.returnValue = t("tmLeaveWhileRunning");
});

// ---------- Real study time (v1.8.0): per-box timer ----------
// state.actualMinutes[boxId] = finished SECONDS (timer stops + manual
// entries). state.timerSessions = the session records behind that total.
// state.activeTimer = {boxId, startedAt (ms epoch, current running
// stretch), accumulated (seconds banked in this session from pauses),
// sessionStartedAt (ms epoch), status: "running"|"paused"} — stored in
// state.json on the server, so a server restart resumes it honestly from
// its stored start (the chip tooltip says so; nothing is silently closed).
function timerLiveSecondsForBox(boxId) {
  const at = state.activeTimer;
  if (!at || at.boxId !== boxId) return 0;
  if (at.status === "paused") return at.accumulated || 0;
  return (at.accumulated || 0) + Math.max(0, Math.floor((Date.now() - (at.startedAt || Date.now())) / 1000));
}
function timerTotalSeconds(boxId) {
  return ((state.actualMinutes || {})[boxId] || 0) + timerLiveSecondsForBox(boxId);
}
// ---- Useful time (v1.11.21, تایم مفید) ----
// state.usefulMinutes[boxId] = useful SECONDS (same unit as
// actualMinutes, despite the name). Stored completely independently
// of real time; an ABSENT entry means "not recorded" — the UI shows
// «ثبت نشده», never 0, never an invented value. Useful must never
// exceed real: every write goes through setUsefulMinutes (the single
// validation place) and saveState clamps again as a backstop; the
// server clamps too (clamp_useful_minutes in srv/common.py).
function usefulTotalSeconds(boxId) {
  return ((state.usefulMinutes || {})[boxId] || 0);
}
function hasUsefulMinutes(b) {
  return !!b && usefulTotalSeconds(b.id) > 0;
}
// Efficiency = useful ÷ real × 100, only when BOTH are valid: real
// time recorded AND useful time recorded. Anything else is null —
// the UI hides it instead of showing a fake value.
function efficiencyPct(usefulSecs, realSecs) {
  if (!(realSecs > 0) || !(usefulSecs > 0)) return null;
  return Math.min(100, usefulSecs / realSecs * 100);
}
function boxEfficiency(b) {
  if (!b) return null;
  return efficiencyPct(usefulTotalSeconds(b.id), timerTotalSeconds(b.id));
}
// Single validation place for useful writes: clamps the total to the
// box's real time (finished seconds + live timer) and reports whether
// it clamped, so callers can tell the user in plain language.
function setUsefulMinutes(boxId, secs) {
  secs = Math.max(0, Math.round(secs || 0));
  const real = timerTotalSeconds(boxId);
  const clamped = secs > real;
  if (clamped) secs = real;
  state.usefulMinutes = state.usefulMinutes || {};
  if (secs > 0) state.usefulMinutes[boxId] = secs;
  else delete state.usefulMinutes[boxId];
  return { clamped, value: secs };
}
// Backstop for saveState/flushSaves: clamp every stored useful total
// to its real total before the state leaves the browser (covers
// legacy data loaded from an older state.json). The real reference is
// timerTotalSeconds — finished seconds PLUS the live timer — because
// clamping against stored actualMinutes alone would delete useful
// recorded while the timer is still running.
function clampUsefulState() {
  const um = state.usefulMinutes || {};
  Object.keys(um).forEach(bid => {
    const real = timerTotalSeconds(bid);
    if (!(um[bid] > 0)) delete um[bid];
    else if (um[bid] > real) um[bid] = real;
  });
}
// Local clock "HH:MM" of a millisecond epoch, for the timer session
// span (14:30 → 16:40). Taken from the actual run — never computed
// back from the duration.
function fmtHm(ms) {
  if (ms == null) return null;
  const d = new Date(ms);
  return String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
}
// Latest timer session of a box that carries a real clock span
// (v1.11.21+ sessions only — old and manual sessions have none).
function latestClockSession(boxId) {
  const list = (state.timerSessions || []).filter(s => s && s.boxId === boxId && s.source === "timer" && s.startHm && s.endHm);
  return list.length ? list[list.length - 1] : null;
}
function sessionClockHtml(b) {
  const s = latestClockSession(b.id);
  if (!s) return "";
  return ' <span class="tm-clock" title="' + t("tmActual") + '">' + fmtTimeFa(s.startHm) + " → " + fmtTimeFa(s.endHm) + "</span>";
}
// ---- Actual vs scheduled time on every box (v1.9.0) ----
// Never invents a value: a box with no recorded time shows an honest
// empty state ("—"), not 0 presented as studied. The live timer counts
// while it runs; stopping the timer or saving a manual value re-renders
// the box in place (renderAll, no page reload).
function hasActualMinutes(b) {
  if (!b) return false;
  if (((state.actualMinutes || {})[b.id] || 0) > 0) return true;
  return !!(state.activeTimer && state.activeTimer.boxId === b.id);
}
function actualVsHtml(b) {
  const sched = minutesBetween(b.start || "00:00", b.end || "00:00");
  const actual = Math.round(timerTotalSeconds(b.id) / 60);
  const has = hasActualMinutes(b);
  const cls = !has ? "tm-vs--none" : (actual >= sched ? "tm-vs--ok" : "tm-vs--low");
  // v1.11.21: useful sits next to real wherever real is shown — only
  // when recorded; an unrecorded useful is shown nowhere as 0.
  const usefulTxt = hasUsefulMinutes(b)
    ? t("tmUsefulVs", { a: has ? fmtDurationFa(actual) : "—", u: fmtDurationFa(Math.round(usefulTotalSeconds(b.id) / 60)), s: fmtDurationFa(sched) })
    : t("tmActualVs", { a: has ? fmtDurationFa(actual) : "—", s: fmtDurationFa(sched) });
  return '<span class="tm-vs ' + cls + '">' + usefulTxt + '</span>';
}
// v1.11.31 (P1-6): the one pending "how useful was this session?" prompt.
// v1.11.43 (audit §16 item 22): it lives in state.usefulPrompt now
// (schema + default in srv/common.py), so a refresh no longer loses
// it. v1.11.53: a timer stop no longer creates one — the 100% default
// is recorded at once (see timerStopCurrent). A prompt loaded from an
// older state still renders and works as before; until answered, that
// session stays «ثبت نشده» — never 0, never fabricated.
function timerStopCurrent() {
  const at = state.activeTimer;
  if (!at) return;
  const secs = timerLiveSecondsForBox(at.boxId);
  let stopped = null; // v1.11.53: the session this stop creates (for the 100% default below)
  if (secs > 0) {
    state.actualMinutes = state.actualMinutes || {};
    state.actualMinutes[at.boxId] = (state.actualMinutes[at.boxId] || 0) + secs;
    state.timerSessions = state.timerSessions || [];
    // v1.11.21: the session keeps its exact clock span (from the
    // actual run — startHm from session start, endHm from now) and a
    // null useful until the user records one. Pause time is already
    // excluded from `secs` (accumulated only counts running time).
    const nowMs = Date.now();
    state.timerSessions.push({ boxId: at.boxId, start: at.sessionStartedAt ? new Date(at.sessionStartedAt).toISOString() : null, end: new Date(nowMs).toISOString(), seconds: secs, source: "timer", startHm: fmtHm(at.sessionStartedAt), endHm: fmtHm(nowMs), useful: null });
    if (state.timerSessions.length > 500) state.timerSessions = state.timerSessions.slice(-500);
    // v1.11.26 (QA BUG-038): useful recorded while the timer was
    // running had nowhere to go — timerAddUseful only distributes
    // over sessions that already exist, and the live interval becomes
    // a session only here. Back-fill whatever is undistributed (box
    // total − session totals) onto this just-created session, capped
    // at its own real seconds, so the box total and the session
    // totals agree again.
    const undist = usefulTotalSeconds(at.boxId) - state.timerSessions.filter(s => s && s.boxId === at.boxId).reduce((s, x) => s + (x.useful || 0), 0);
    if (undist > 0) {
      const sess = state.timerSessions[state.timerSessions.length - 1];
      if (sess && sess.boxId === at.boxId) sess.useful = Math.min(sess.seconds || 0, undist);
    }
    stopped = state.timerSessions[state.timerSessions.length - 1];
  }
  state.activeTimer = null;
  // v1.11.53 (user request 26 Nov 23:45): the useful default is 100% —
  // the just-stopped session is useful in full unless the user changes
  // it (card input / edit form). No prompt is created any more, so a
  // stopped box is never left «ثبت نشده» and the I-7 topbar chip stays
  // hidden.
  // v1.11.60 (F7): the fill room is computed at BOX level, not session
  // level — the BUG-038 back-fill above may have attributed older
  // "useful without a session" to this session, making the session
  // room 0 while the box still has unfilled real seconds (1800s manual
  // real + tick-done useful 1800 + a 600s timer stop used to leave the
  // box total at 1800/2400 = 75% while the session showed 100%).
  // Capped at this session's seconds so the default never leaks into
  // older unrecorded sessions (the 1.11.53 rule).
  if (stopped && stopped.boxId === at.boxId) {
    const room = Math.max(0, timerTotalSeconds(at.boxId) - usefulTotalSeconds(at.boxId));
    const fill = Math.min(room, stopped.seconds || 0);
    if (fill > 0) timerAddUsefulSecs(at.boxId, fill);
  }
}
function timerStart(boxId) {
  if (state.activeTimer && state.activeTimer.boxId === boxId && state.activeTimer.status === "running") return;
  if (state.activeTimer) timerStopCurrent(); // one timer at a time: fold the old one in
  const now = Date.now();
  state.activeTimer = { boxId, startedAt: now, accumulated: 0, sessionStartedAt: now, status: "running" };
  saveState(); renderAll();
}
function timerPause() {
  const at = state.activeTimer;
  if (!at || at.status !== "running") return;
  at.accumulated = timerLiveSecondsForBox(at.boxId);
  at.startedAt = null; at.status = "paused";
  saveState(); renderAll();
}
function timerResume() {
  const at = state.activeTimer;
  if (!at || at.status !== "paused") return;
  at.startedAt = Date.now(); at.status = "running";
  saveState(); renderAll();
}
function timerStop() { if (!state.activeTimer) return; timerStopCurrent(); saveState(); renderAll(); }
// ---------- One primary action per page (v1.11.55, UX-1) ----------
// Dashboard / Today share ONE primary: start/stop the current box's
// timer — exactly what Space does (P-7). The label flips with the
// timer state (timerStart/timerStop both renderAll, so the renderers
// below are the only refresh points — never the 1 s tick, which must
// stay cheap per PERF-02).
function toggleCurrentBoxTimer() {
  const info = nowBoxInfo();
  const box = info.cur || info.next;
  if (state.activeTimer) timerStop();
  else if (box) timerStart(box.id);
}
function refreshStartCurrentButtons() {
  const running = !!state.activeTimer;
  const info = running ? null : nowBoxInfo();
  const canStart = running || !!(info && (info.cur || info.next));
  [["dashStartCurrentBtn", "ux1StartCurrent"], ["todayStartCurrentBtn", "ux1StartResume"]].forEach(([id, key]) => {
    const btn = document.getElementById(id);
    if (!btn) return;
    btn.textContent = running ? t("ux1StopTimer") : t(key);
    btn.disabled = !canStart;
  });
}
// Wire the static page-primary buttons once (they live in index.html,
// outside every re-rendered container). The Remaining / Exams buttons
// get their disabled state from their own tab renderers.
function wirePagePrimaries() {
  // NOTE: wireOnce(el, handler) registers handler AS the click
  // listener — it receives the event, not the element. (The first
  // draft passed (b) => b.addEventListener(...), which threw on every
  // click because the event has no addEventListener — caught by
  // verify1155.)
  wireOnce(document.getElementById("dashStartCurrentBtn"), toggleCurrentBoxTimer);
  wireOnce(document.getElementById("todayStartCurrentBtn"), toggleCurrentBoxTimer);
  wireOnce(document.getElementById("pastBestSugBtn"), () => {
    // The best suggestion (rank 1) opens its single-preview — the same
    // preview the row's «جابه‌جا کن» button opens. Nothing moves until
    // the preview's confirm.
    const best = backlogSuggestions(1)[0];
    if (!best) return;
    sugPreview = { kind: "single", s: best };
    renderAll();
  });
  wireOnce(document.getElementById("examsNearestBtn"), () => {
    const ex = nearestExam();
    if (ex) openExamDetail(ex.id);
  });
  wireOnce(document.getElementById("asgFirstBtn"), goFirstRemainingAssignment);
}
// v1.11.66 (Batch 7, خ-۴): the Assignments tab's one primary — scroll
// to the first undone assignment (the list is sorted undone-first)
// and highlight it briefly, the خ-۲ pattern: scroll only when it is
// out of view + a 2.5 s highlight.
function goFirstRemainingAssignment() {
  const row = document.querySelector('#assignmentsList .assign-card:not(.done)');
  if (!row) return;
  const r = row.getBoundingClientRect();
  if (r.top < 0 || r.bottom > window.innerHeight) row.scrollIntoView({ behavior: "smooth", block: "nearest" });
  row.classList.add("next-focus");
  setTimeout(() => row.classList.remove("next-focus"), 2500);
}
// v1.11.28 (QA BUG-040): a forgotten running timer banks unlimited
// wall-clock time across a page close / overnight — the stored start
// is resumed honestly, so a timer left running for 8 hours banks 8
// hours. On load, a running timer older than 4 hours (or 2x its
// box's planned length, whichever is smaller) is PAUSED at that cap
// — only the capped time is kept — and the user is asked whether to
// resume it or stop it (banking the capped time).
const STALE_TIMER_MAX_SECS = 4 * 3600;
function staleTimerCapSecs(box) {
  const planned = box ? minutesBetween(box.start || "00:00", box.end || "00:00") * 60 : 0;
  return planned > 0 ? Math.min(STALE_TIMER_MAX_SECS, 2 * planned) : STALE_TIMER_MAX_SECS;
}
function checkStaleTimer() {
  const at = state.activeTimer;
  if (!at || at.status !== "running" || !at.startedAt) return;
  const box = allBoxes().find(b => b.id === at.boxId);
  const live = (at.accumulated || 0) + Math.max(0, Math.floor((Date.now() - at.startedAt) / 1000));
  const cap = staleTimerCapSecs(box);
  if (live <= cap) return;
  at.accumulated = cap;
  at.startedAt = null;
  at.status = "paused";
  saveState();
  const title = box ? box.title : at.boxId;
  if (confirm(t("tmStaleTimerAsk", { title: title, dur: fmtDurationFa(Math.round(live / 60)), cap: fmtDurationFa(Math.round(cap / 60)) }))) timerResume();
  else timerStop();
}
function timerAddManual(boxId, mins) {
  mins = Math.max(0, Math.round(parseFloat(mins) || 0));
  if (!mins) return;
  state.actualMinutes = state.actualMinutes || {};
  state.actualMinutes[boxId] = (state.actualMinutes[boxId] || 0) + mins * 60;
  state.timerSessions = state.timerSessions || [];
  // v1.11.21: a manual entry has NO clock span — start/end stay null
  // (never fabricated) and no startHm/endHm, so nothing displays.
  // v1.11.52 (P-3): it DOES record the study day (`d`), so manual
  // sessions can appear in today's log and the Analytics sessions
  // table; older manual sessions have no `d` and stay out of dated
  // views (never dated by guess).
  state.timerSessions.push({ boxId, start: null, end: null, seconds: mins * 60, source: "manual", useful: null, d: TODAY });
  if (state.timerSessions.length > 500) state.timerSessions = state.timerSessions.slice(-500);
  saveState(); renderAll();
}
// v1.11.45 (F-06): seconds-based useful recording (the prompt chips
// record an exact share of a session — e.g. 90 s at 100% is 90 s, not
// the 2 min the minutes rounding produced). Same distribution as
// timerAddUseful, in seconds; never routes through the clamp alert.
function timerAddUsefulSecs(boxId, secs) {
  secs = Math.max(0, Math.round(secs || 0));
  if (!secs) return false;
  const before = usefulTotalSeconds(boxId);
  const res = setUsefulMinutes(boxId, before + secs);
  let remaining = res.value - before;
  const liveOnBox = !!(state.activeTimer && state.activeTimer.boxId === boxId);
  if (remaining > 0 && !liveOnBox) {
    const sessions = (state.timerSessions || []).filter(s => s && s.boxId === boxId);
    for (let i = sessions.length - 1; i >= 0 && remaining > 0; i--) {
      const s = sessions[i];
      const room = (s.seconds || 0) - (s.useful || 0);
      if (room <= 0) continue;
      const add = Math.min(room, remaining);
      s.useful = (s.useful || 0) + add;
      remaining -= add;
    }
  }
  if (res.value <= before) return false;
  saveState(); renderAll();
  return true;
}
// v1.11.21: record useful minutes for a box (additive, from the card
// input). Useful is clamped to the real total; the recorded seconds
// are distributed over the box's sessions (latest first) that have no
// useful value yet, so per-session useful stays consistent with the
// total. Returns false when nothing was recorded (0, or no real time
// at all — useful can never exist without real time).
function timerAddUseful(boxId, mins) {
  mins = Math.max(0, Math.round(parseFloat(mins) || 0));
  if (!mins) return false;
  const before = usefulTotalSeconds(boxId);
  const res = setUsefulMinutes(boxId, before + mins * 60);
  let remaining = res.value - before;
  // v1.11.45 (F-05): while a timer is RUNNING on this box there is no
  // session for the live interval yet — distributing now would land
  // the useful on a PREVIOUS session. Leave it undistributed; the
  // stop-time back-fill in timerStopCurrent puts it on the new session.
  const liveOnBox = !!(state.activeTimer && state.activeTimer.boxId === boxId);
  if (remaining > 0 && !liveOnBox) {
    // Distribute the actually-recorded seconds over unfilled sessions
    // (latest first), each capped at its own real seconds.
    const sessions = (state.timerSessions || []).filter(s => s && s.boxId === boxId);
    for (let i = sessions.length - 1; i >= 0 && remaining > 0; i--) {
      const s = sessions[i];
      const room = (s.seconds || 0) - (s.useful || 0);
      if (room <= 0) continue;
      const add = Math.min(room, remaining);
      s.useful = (s.useful || 0) + add;
      remaining -= add;
    }
  }
  if (res.clamped) alert(t("tmUsefulOverReal"));
  if (res.value <= before) return false;
  saveState(); renderAll();
  return true;
}
// v1.11.52 (P-3): the study day a session belongs to — a timer
// session by its start stamp, a manual session by its recorded `d`
// (recorded since 1.11.52; older manual sessions have neither and
// return null — they stay out of dated views, never dated by guess).
function sessionStudyDay(s) {
  if (!s) return null;
  if (s.start) {
    const d = new Date(s.start);
    if (!isNaN(d.getTime())) return studyDayOf(d);
  }
  return s.d || null;
}
// v1.11.52 (P-3): one sessions table, shared by the Today log and the
// Analytics «نشست‌ها» section — box, clock span (or «دستی» for a
// manual entry), real, useful, efficiency. A useful of null is
// «ثبت نشده», never 0; efficiency hides without both values.
function sessionTableHtml(list) {
  const row = (s) => {
    const b = allBoxes().find(x => x.id === s.boxId);
    const eff = (s.useful != null && (s.seconds || 0) > 0)
      ? FA_PCT(Math.round((s.useful || 0) / (s.seconds || 1) * 100)) : "—";
    return '<tr><td>' + esc(b ? b.title : t("sessNoBox")) + '</td><td>' +
      (s.startHm ? esc(fmtTimeFa(s.startHm)) + ' → ' + esc(fmtTimeFa(s.endHm)) : esc(t("sessManual"))) + '</td><td>' +
      esc(fmtDuration(Math.round((s.seconds || 0) / 60))) + '</td><td>' +
      (s.useful != null ? esc(fmtDuration(Math.round(s.useful / 60))) : esc(t("tmUsefulNotRecorded"))) + '</td><td>' + eff + '</td></tr>';
  };
  return '<table class="sess-table"><thead><tr><th>' + t("sessColBox") + '</th><th>' + t("sessColSpan") + '</th><th>' + t("sessColReal") + '</th><th>' + t("sessColUseful") + '</th><th>' + t("sessColEff") + '</th></tr></thead><tbody>' +
    list.map(row).join("") + '</tbody></table>';
}
// v1.11.31 (P1-6): the "how useful was this session?" row, shown on the
// stopped box's card while usefulPrompt is pending for it. Chips record
// a share of the just-stopped session (100% / 75% / 50%); the minutes
// field records an exact value. A skip leaves the session «ثبت نشده».
// v1.11.53: a timer stop no longer creates a prompt (the 100% default
// is recorded at once), so this row now appears only for a pending
// prompt loaded from an older state — and 100% is marked as its
// default chip (up-chip-default).
function usefulPromptHtml(b) {
  const up = state.usefulPrompt;
  if (!up || up.boxId !== b.id) return "";
  const mins = Math.round(up.seconds / 60);
  return '<div class="useful-prompt">' +
    '<span class="up-q">' + t("tmUsefulPrompt", { d: fmtDurationFa(mins) }) + '</span>' +
    '<button class="btn up-chip up-chip-default" data-pct="100">' + FA(100) + '٪</button>' +
    '<button class="btn up-chip" data-pct="75">' + FA(75) + '٪</button>' +
    '<button class="btn up-chip" data-pct="50">' + FA(50) + '٪</button>' +
    '<label class="up-mins-wrap">' + t("tmUsefulLabel") +
    ' <input type="number" min="0" class="up-mins" placeholder="0"></label>' +
    '<button class="btn up-save">' + t("tmAddUsefulBtn") + '</button>' +
    '<button class="btn up-skip">' + t("tmUsefulSkip") + '</button>' +
    '</div>';
}
function wireUsefulPrompt(cardEl, b) {
  if (!state.usefulPrompt || state.usefulPrompt.boxId !== b.id) return;
  const clear = () => { state.usefulPrompt = null; };
  cardEl.querySelectorAll(".up-chip").forEach(btn => btn.addEventListener("click", () => {
    const secs = state.usefulPrompt ? state.usefulPrompt.seconds : 0;
    const pct = parseInt(btn.dataset.pct, 10) || 0;
    clear();
    // v1.11.45 (F-06): exact seconds — 90 s at 100% records 90 s
    // (never the rounded 2 min that tripped the clamp alert), and a
    // sub-minute share (25 s at 50% = 13 s) records instead of 0.
    const exact = Math.round(secs * pct / 100);
    if (exact > 0) timerAddUsefulSecs(b.id, exact);
    else { saveState(); renderAll(); }
  }));
  const saveBtn = cardEl.querySelector(".up-save");
  if (saveBtn) saveBtn.addEventListener("click", () => {
    const inp = cardEl.querySelector(".up-mins");
    const mins = Math.max(0, parseInt(inp ? inp.value : 0, 10) || 0);
    clear();
    if (mins > 0) timerAddUseful(b.id, mins);
    else { saveState(); renderAll(); }
  });
  const skipBtn = cardEl.querySelector(".up-skip");
  if (skipBtn) skipBtn.addEventListener("click", () => { clear(); renderAll(); });
}
// v1.11.52 (I-7): the topbar chip for a pending useful-time prompt.
// state.usefulPrompt is a SINGLE object, so the chip shows «۱ زمان
// مفید ثبت‌نشده»; it lives only on the box's card otherwise, and a
// prompt for a box on another day was easy to miss entirely. Clicking
// jumps to that box (Today when it is today's box, else its day in
// the programme) and scrolls to the card.
function renderUsefulPendingChip() {
  const chip = document.getElementById("usefulPendingChip");
  if (!chip) return;
  if (!chip.dataset.wired) {
    chip.dataset.wired = "1";
    chip.addEventListener("click", jumpToUsefulPending);
  }
  const up = state.usefulPrompt;
  chip.hidden = !up;
  if (up) chip.textContent = t("usefulPendingChip", { n: FA(1) });
}
function jumpToUsefulPending() {
  const up = state.usefulPrompt;
  if (!up) return;
  const b = allBoxes().find(x => x.id === up.boxId);
  if (!b) return;
  const day = boxStudyDay(b) || b.date;
  const goToday = day === TODAY;
  navigate({ tab: goToday ? "today" : "program", day: goToday ? undefined : day });
  setTimeout(() => {
    const el = document.querySelector((goToday ? "#todayBoxes" : "#calDayBoxes") + ' [data-box-id="' + b.id + '"]');
    if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
  }, 150);
}
function fmtClock(totalSecs) {
  const mm = Math.floor(totalSecs / 60), ss = totalSecs % 60;
  // v1.11.43 (item 21): the live timer reads Persian digits in fa mode.
  return faDigits(String(mm).padStart(2, "0") + ":" + String(ss).padStart(2, "0"));
}
// Topbar chip + visible per-box live counters, updated every second
// WITHOUT a full re-render (which would steal input focus).
// v1.11.55 (PERF-02): last exam-night reminder check — the 1 s tick
// used to run it every second even though it only matters at 22:00 on
// an exam eve; once per 60 s is plenty.
let _lastExamNightCheck = 0;
function updateTimerDisplays() {
  const chip = document.getElementById("timerChip");
  const pill = document.getElementById("floatTimerPill");
  const at = state.activeTimer;
  // No timer running: hide both live surfaces and return — the old
  // code still ran querySelectorAll("[data-tm-live]") plus the
  // exam-night check every second for nothing, and (outside a render)
  // each allBoxes() below rebuilds the ~318-box merged list.
  if (!at) {
    if (chip) chip.hidden = true;
    if (pill) pill.hidden = true;
    return;
  }
  // One merged list per tick, shared by chip + pill (was two).
  const boxes = allBoxes();
  const b = boxes.find(x => x.id === at.boxId);
  if (chip) {
    chip.hidden = false;
    const el = document.getElementById("timerChipText");
    if (el) el.textContent = (at.status === "paused" ? t("tmPaused") + " · " : "") + (b ? b.title : at.boxId) + " · " + fmtClock(timerLiveSecondsForBox(at.boxId));
    chip.title = t("tmResumedNote");
  }
  document.querySelectorAll("[data-tm-live]").forEach(el => {
    el.textContent = fmtClock(timerLiveSecondsForBox(el.dataset.tmLive));
  });
  // v1.11.43 (§17 idea 5): the floating mini-timer pill — live time +
  // stop, only while a timer runs, in every tab.
  if (pill) {
    pill.hidden = false;
    const tx = document.getElementById("floatTimerText");
    if (tx) tx.textContent = (b ? b.title : at.boxId) + " · " + fmtClock(timerLiveSecondsForBox(at.boxId));
  }
  // v1.11.43 (§17 idea 4): the 22:00 exam-night reminder — once, on
  // the exam eve, while the app is open (see checkExamNightReminder).
  // Gated to once per 60 s (it only fires at 22:00 on an exam eve).
  const now = Date.now();
  if (now - _lastExamNightCheck >= 60000) {
    _lastExamNightCheck = now;
    checkExamNightReminder();
  }
}
setInterval(updateTimerDisplays, 1000);
// v1.11.43 (§17 idea 5): wire the floating pill once — stop ends the
// timer, clicking the pill itself jumps to the running box.
function wireFloatTimer() {
  const pill = document.getElementById("floatTimerPill");
  if (!pill) return;
  const stop = document.getElementById("floatTimerStop");
  if (stop) stop.addEventListener("click", (e) => { e.stopPropagation(); timerStop(); });
  pill.addEventListener("click", () => {
    const at = state.activeTimer;
    if (!at) return;
    const b = allBoxes().find(x => x.id === at.boxId);
    if (!b) return;
    const day = boxStudyDay(b) || b.date;
    navigate({ tab: "program", day });
    setTimeout(() => {
      const el = document.querySelector('#calDayBoxes [data-box-id="' + b.id + '"]');
      if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 150);
  });
}
document.getElementById("timerChipStop").addEventListener("click", () => timerStop());

// ---------- Grouped-nav counters (v1.11.35, P3-2) ----------
// Undone past boxes on «گذشته», days left to the next exam on
// «آزمون‌ها». Refreshed on every renderAll, like the dashboard's own
// overdue count; a badge hides when its number is zero / absent.
// v1.11.52 (UX-7): a backlog count on its own says nothing about the
// load — every backlog count shows its total planned hours next to
// it (minutesBetween per box, rounded to whole hours).
function backlogCountHours(list) {
  const mins = (list || []).reduce((s, b) => s + minutesBetween(b.start || "00:00", b.end || "00:00"), 0);
  return { n: (list || []).length, hours: Math.round(mins / 60) };
}
function renderNavBadges() {
  const rb = document.getElementById("navRemainingBadge");
  if (rb) {
    const undone = allBoxes().filter(b => !isDone(b) && (boxStudyDay(b) || b.date) < TODAY && !(state.backlogHidden || {})[b.id]);
    const n = undone.length;
    const bh = backlogCountHours(undone);
    rb.hidden = !n;
    // v1.11.52 (UX-7): the badge shows the count AND the planned
    // hours («۱۵۷ · ۴۳س») — a bare count says nothing about the load.
    rb.textContent = n ? FA(n) + " · " + FA(bh.hours) + t("backlogHoursShort") : "";
    rb.title = n ? t("backlogHours", { n: FA(n), h: FA(bh.hours) }) : "";
  }
  const eb = document.getElementById("navExamsBadge");
  if (eb) {
    const next = nearestExam();
    const days = next ? examDaysLeft(next) : null;
    eb.hidden = days == null;
    eb.textContent = days != null ? FA(days) : "";
  }
  // v1.11.66 (Batch 7, Group 13 item 2): a third badge — the remaining
  // assignments count on «تکالیف» (a daily destination like the other
  // two badges). Hides when nothing is left.
  const ab = document.getElementById("navAsgBadge");
  if (ab) {
    const n = assignmentsList().filter(({ box: b }) => !isDone(b)).length;
    ab.hidden = !n;
    ab.textContent = n ? FA(n) : "";
  }
}

function renderAll() {
  refreshToday(); // the study day may have rolled over since page load
  ensureStateMaps(); // v1.11.50: backstop — a malformed in-memory state
  // (stale tab, old file) must be repaired before any renderer reads it.
  LINKED_CACHE = null; // per-render link cache (see linkedTopicIdCached)
  BUDGET_LINK_CACHE = null; // per-render box -> exam-budget map (idea 2)
  VIEWED_CHAPTERS = null; // per-render viewed-chapter set (see viewedChapters)
  // v1.11.24 (QA BUG-018): allBoxes() + topicAgg() were recomputed on
  // every call (~1,889× / ~1,464× per render, ~2,374 ms in jsdom).
  // One render, one list: the list and the per-topic aggregates are
  // computed once and memoized until the render finishes. The cache
  // is cleared in a finally so a render error can never leave stale
  // boxes behind (the next render rebuilds it).
  RENDER_CACHE = { boxes: null, topicAgg: new Map() };
  try {
    // v1.11.65 (Batch 6, L-PERF4): render only the active tab (plus
    // the always-visible chrome) — renderAll used to rebuild all 10
    // tabs on every call. The tab-entry path (navigate -> applyRoute
    // -> renderAll) renders the newly active tab, so a switch never
    // shows a stale tab. Topbar/sidebar renders stay ungated:
    // renderSummary + renderUsefulPendingChip live in the topbar,
    // renderNavBadges in the sidebar. renderAll() is timing-sensitive
    // only in a real browser (jsdom numbers are relative) — the
    // real-browser timing check stays open for the user's laptop.
    renderSummary(); renderNavBadges();
    renderUsefulPendingChip(); // v1.11.52 (I-7): topbar useful-time chip
    if (currentTab === "dashboard") renderDashboard();
    if (currentTab === "today") renderToday();
    if (currentTab === "program") renderCalendar();
    if (currentTab === "remaining") renderRemaining();
    if (currentTab === "assignments") renderAssignments();
    if (currentTab === "testbook") renderTestbookTab();
    if (currentTab === "exams") renderExams();
    if (currentTab === "analytics") {
      renderSubjectStats();
      // 3.6b: the Gemini history block is built by gmTestInitOnce only, so a
      // language switch would otherwise leave its title/empty text in the
      // old language (caught by verify1114's EN sweep). Rebuild it here —
      // renderGeminiHistory() is idempotent and guarded when the tab is hidden.
      renderGeminiHistory();
    }
    // v1.11.45 (U-02): Analytics renders only on its own tab — the
    // tab-entry path (navigate -> applyRoute -> renderAll) renders it
    // when the user switches to the tab, so the guard costs nothing.
    if (currentTab === "analytics" && typeof renderAnalytics === "function") renderAnalytics(); // analytics.js (loaded after app.js)
    if (currentTab === "settings") renderBackup(); // v1.11.57 (IA): Backup is a section inside Settings now
    if (currentTab === "calendar") renderCalendarTab();
    if (currentTab === "settings") renderSettingsTab();
    if (openBookId) renderBookView(openBookId);
  } catch (e) {
    // v1.11.50: renderAll used to have try/finally but NO catch — any
    // throw inside any of its ~15 renderers propagated out of the
    // synchronous `saveState(); renderAll();` sequence and left the
    // DOM half-built (the reported «change -> save -> crash»). The
    // guards above make a throw unlikely, but one throwing renderer
    // must never again take the whole page down: fall back to the
    // Today list alone and say so, instead of a half-built page.
    console.error("renderAll failed:", e);
    try { renderToday(); } catch (e2) { /* the Today list is guarded per-card */ }
    showToast(t("renderFailed"), { kind: "err", ms: 4000 });
  } finally {
    RENDER_CACHE = null;
  }
  renderBreadcrumb(); // v1.11.55 (UX-8): after every render, from the route
}

// ---------- Global breadcrumb (v1.11.55, UX-8) ----------
// One small line above the content in every tab: Dashboard (a link,
// unless on it) + tab name + detail. Segments are buttons that
// navigate; the last segment is plain text (the current place).
// Details: program → the Jalali day label; exams (list view) → group
// label + exam name; testbook → the book title. The testbook's own
// bookCrumb (drill-down detail) stays untouched below it.
const TAB_CRUMB_KEY = { dashboard: "tabDashboard", today: "tabToday", program: "tabProgram",
  assignments: "tabAssignments", testbook: "tabTestbook", remaining: "tabOverdue",
  exams: "tabExams", calendar: "tabCalendar", settings: "tabSettings",
  analytics: "tabAnalytics" }; // v1.11.57 (IA): gemini/backup merged away
function renderBreadcrumb() {
  const bar = document.getElementById("crumbBar");
  if (!bar) return;
  const r = currentRoute || { tab: currentTab || "dashboard" };
  const tab = (r && r.tab) || "dashboard";
  // v1.11.66 (Batch 7, L-UI1): the bar hides where it adds nothing —
  // the Dashboard is a single segment, and in the Testbook drill-down
  // the local bookCrumb already shows the full path.
  const drillDown = tab === "testbook" && !!(r && r.bookId);
  bar.hidden = tab === "dashboard" || drillDown;
  if (bar.hidden) { bar.innerHTML = ""; return; }
  const segs = []; // {label, route|null} — route null = current, plain
  if (tab !== "dashboard") segs.push({ label: t("tabDashboard"), route: { tab: "dashboard" } });
  if (tab === "dashboard") {
    segs.push({ label: t("tabDashboard"), route: null });
  } else {
    segs.push({ label: t(TAB_CRUMB_KEY[tab] || "tabDashboard"), route: null });
    if (tab === "program" && r.day) {
      segs[segs.length - 1].route = { tab: "program" };
      segs.push({ label: weekdayFa(r.day) + " " + gregToJalali(r.day).text, route: null });
    } else if (tab === "exams" && r.examView === "list") {
      segs[segs.length - 1].route = { tab: "exams" };
      segs.push({ label: t(examGroupKey(r.examGroup || examGroup)), route: r.examId ? { tab: "exams", examGroup: r.examGroup, examView: "list" } : null });
      if (r.examId) {
        const ex = findExam(r.examId);
        if (ex) segs.push({ label: examDisplayName(ex), route: null });
      }
    } else if (tab === "testbook" && r.bookId) {
      const book = (TESTBOOK.books || []).find(b => b.id === r.bookId);
      if (book) {
        segs[segs.length - 1].route = { tab: "testbook" };
        segs.push({ label: bookName(book), route: null });
      }
    }
  }
  // v1.11.66 (Batch 7, خ-۵): with the box editor open, the editing
  // box's title is the current segment — the breadcrumb is the return
  // path out of the editor. The previous segment links back to the
  // exact current route minus the modal entry.
  if (editingBoxId) {
    const b = allBoxes().find(x => x.id === editingBoxId);
    if (b) {
      const last = segs[segs.length - 1];
      if (last && !last.route) {
        const back = Object.assign({}, r);
        delete back.modal;
        last.route = back;
      }
      segs.push({ label: b.title || "", route: null });
    }
  }
  bar.innerHTML = "";
  segs.forEach((sg, i) => {
    if (i > 0) { const sep = document.createElement("span"); sep.className = "crumb-sep"; sep.textContent = "/"; bar.appendChild(sep); }
    if (sg.route) {
      const b = document.createElement("button");
      b.type = "button"; b.className = "crumb-link"; b.textContent = sg.label;
      b.addEventListener("click", () => navigate(sg.route));
      bar.appendChild(b);
    } else {
      const sp = document.createElement("span");
      sp.className = "crumb-current"; sp.textContent = sg.label;
      bar.appendChild(sp);
    }
  });
}

// ---- Summary ----
function renderSummary() {
  const boxes = allBoxes();
  const done = boxes.filter(isDone).length;
  const tests = boxes.reduce((s, b) => s + (testOf(b).completed || 0), 0);
  document.getElementById("summaryLine").innerHTML =
    t("summaryLine", { done: FA(done), total: FA(boxes.length), tests: FA(tests) });
}

// ---- Day tick display (shared by dashboard + calendar) ----
// v1.11.32 (P2-1): display-only. The old checkbox let a hand tick
// claim a day complete while its boxes were still undone (the "lying
// tick" of review weakness 9). The state now comes from the boxes
// themselves (isDayDone) and the close-day flow is the only writer
// of state.daysDone.
function dayTickEl(date) {
  const done = isDayDone(date);
  const wrap = document.createElement("span");
  wrap.className = "day-tick" + (done ? " on" : "");
  wrap.textContent = done ? t("dayCompleteDone") : t("dayComplete");
  return wrap;
}

// v1.11.32 (P2-5a): one save path for the three one-line test fields
// (total / solved / correct) — the «ذخیره» button and each field's
// change event all land here, so the three numbers are applied
// together in a single save + render (and the dated test-log delta
// is computed once, not three times). Same clamps as setBoxTests:
// correct ≤ completed ≤ total.
function saveBoxTests(b, completed, correct, total) {
  // v1.11.50: same hardening as setBoxTests — a null tests/tests_total
  // map, or a number/string entry, threw here on save (strict mode).
  state.tests = state.tests || {};
  state.tests_total = state.tests_total || {};
  let cur = state.tests[b.id];
  if (!cur || typeof cur !== "object" || Array.isArray(cur)) cur = { completed: 0, correct: 0 };
  const oldC = cur.completed || 0, oldR = cur.correct || 0;
  const tot = Math.max(0, parseInt(total, 10) || 0);
  state.tests_total[b.id] = tot;
  cur.completed = Math.max(0, parseInt(completed, 10) || 0);
  cur.correct = Math.max(0, parseInt(correct, 10) || 0);
  if (cur.correct > cur.completed) cur.correct = cur.completed;
  if (tot > 0 && cur.completed > tot) {
    cur.completed = tot;
    if (cur.correct > cur.completed) cur.correct = cur.completed;
  }
  state.tests[b.id] = cur;
  const d = testDeltaFrom(oldC, oldR, cur.completed, cur.correct);
  if (d.solved || d.correct || d.wrong) {
    logTestDelta(Object.assign({ box: b.id, topic: linkedTopicIdCached(b), src: "box" }, d));
  }
  // v1.11.35 (P2-11): wrong → error-notebook bridge. When the wrong
  // count grows and this subject has the notebook opted in, offer to
  // take the new wrong questions into the notebook — never silently,
  // and never for a subject that is opted out (the notebook stays
  // opt-in, default off). The offer is transient; the details row
  // opens so the prompt is visible.
  const oldWrong = oldC - oldR, newWrong = cur.completed - cur.correct;
  if (newWrong > oldWrong && errNbEnabled(b.subject) && !ERRNB_PROMPT[b.id]) {
    ERRNB_PROMPT[b.id] = { subject: b.subject, source: b.title || "", wrongAt: oldWrong };
    BOX_DETAILS_OPEN.add(b.id);
  }
  saveState(); renderAll();
}

// ---- Part card (screenshot style) ----
// v1.11.32 (P2-3): which cards have their details row open, kept in
// memory across renderAll (like COLL_OPEN) — ticking a box does not
// collapse the details the user had open.
const BOX_DETAILS_OPEN = new Set();
// v1.11.52 (I-2): which DONE cards the user expanded from their
// collapsed one-line row — in memory only; unticking clears it.
const PART_EXPANDED = new Set();
// v1.11.63 (Batch 4, ب-۱۰): which DONE cards have their test fields
// open behind the collapsed summary line — in memory only; unticking
// clears it, like PART_EXPANDED.
const TESTS_EDIT_OPEN = new Set();
// v1.11.63 (Batch 4, خ-۲): after a tick in the Today view, focus moves
// to the next undone box. Set by the tick handler — never by a tick
// from another tab. v1.11.72 (Batch 5, R2): the pointer PERSISTS across
// re-renders (cleared only by a fresh tick or a tab change in
// applyRoute); `scrolled` makes the guarded auto-scroll fire once.
let PENDING_NEXT_FOCUS = null;
// v1.11.54 (MQ-1): the collapsed one-line row for a ticked box,
// split out of partCard — same markup, same listeners; returns the
// div when the box is collapsed, null otherwise.
// v1.11.52 (I-2): a ticked box collapses to a one-line row (title +
// time + ✓) in «امروز» and «برنامه» — the long cards used to bury
// the still-open work. Click (or the «باز کردن» button) expands
// that card only; unticking returns it to the full card.
function partCardCollapsed(div, b, idx) {
  if (!isDone(b) || PART_EXPANDED.has(b.id)) return null;
  div.classList.add("done-compact");
  // v1.11.63 (Batch 4, ب-۱۰): the one-line row still shows the numbers
  // (tests done / correct) — a ticked test box never hides its count.
  const tr0 = testOf(b);
  const testSum = (tr0.completed > 0 || tr0.correct > 0)
    ? ' · ' + ((b.tests_total || 0) > 0
      ? t("boxTestsSummaryTotal", { done: FA(tr0.completed), correct: FA(tr0.correct), total: FA(b.tests_total) })
      : t("boxTestsSummary", { done: FA(tr0.completed), correct: FA(tr0.correct) }))
    : '';
  div.innerHTML =
    '<input type="checkbox" checked aria-label="' + t("fDone") + '">' +
    '<div style="flex:1;min-width:0"><div class="part-title">' + t("partWord") + FA(idx + 1) + ' — ' + esc(b.title) + '</div>' +
    '<div class="part-time">' + fmtTimeFa(b.start) + ' – ' + fmtTimeFa(b.end) + ' · ' + esc(subjName(b.subject)) + esc(testSum) + '</div></div>' +
    '<span class="done-mark" aria-hidden="true">✓</span>' +
    '<button type="button" class="btn done-expand-btn">' + t("doneExpand") + '</button>';
  div.querySelector('input[type="checkbox"]').addEventListener("change", (e) => {
    setDone(b, e.target.checked);
    PART_EXPANDED.delete(b.id);
    TESTS_EDIT_OPEN.delete(b.id);
    saveState(); renderAll();
  });
  const expand = () => { PART_EXPANDED.add(b.id); renderAll(); };
  div.querySelector(".done-expand-btn").addEventListener("click", expand);
  div.addEventListener("click", (e) => {
    if (e.target.type !== "checkbox" && !e.target.closest(".done-expand-btn")) expand();
  });
  return div;
}

function partCard(b, idx) {
  const tr = testOf(b);
  const acc = accuracy(b);
  // Progress = completion (tests done / total), not accuracy: 5/40 tests
  // at 100% correct used to render a full bar. Non-test boxes fall back
  // to the done tick.
  const progPct = b.tests_total ? Math.min(100, Math.round((tr.completed || 0) / b.tests_total * 100)) : (isDone(b) ? 100 : 0);
  const div = document.createElement("div");
  div.className = "part " + colorClass(b.subject) + (isDone(b) ? " done" : "") + (boxConnected(b) ? "" : " has-cal-add");
  div.dataset.boxId = b.id;
  const collapsed = partCardCollapsed(div, b, idx);
  if (collapsed) return collapsed;
  // v1.11.33 (P2-6): speed only on test boxes — solved tests from
  // state.tests, real minutes from the timer/manual entries.
  // v1.11.43 (§17 idea 9): in assignment mode the box IS a test
  // assignment by construction — the counter shows even with no
  // recorded total yet.
  const isTestBox = focusAsg || !!(b.is_test || (b.tests_total || 0) > 0 || tr.completed > 0);
  const sp = isTestBox ? speedOf(tr.completed, timerTotalSeconds(b.id) / 60) : null;
  // v1.11.37 (P3-7): readiness pill for test boxes — "ready" only when
  // the chapter's viewing box is ticked; a mark, never a block.
  const prereq = testBoxReady(b);
  // v1.11.43 (§17 idea 2): the budget link for the «چرا این باکس؟»
  // label — null when the box has no linked budget topic (no label
  // is rendered then, never an invented one).
  const why = budgetLinkForBox(b);
  // v1.11.63 (Batch 4, ب-۱۰): on a ticked box the three test fields
  // collapse to one summary line («۲۵ تست · ۲۰ درست») that only
  // reopens with «ویرایش»; the manual minute fields hide. The numbers
  // are never hidden — the summary shows them.
  const doneTests = isDone(b);
  const testsEditing = TESTS_EDIT_OPEN.has(b.id);
  const testsSummaryTxt = (b.tests_total || 0) > 0
    ? t("boxTestsSummaryTotal", { done: FA(tr.completed), correct: FA(tr.correct), total: FA(b.tests_total) })
    : t("boxTestsSummary", { done: FA(tr.completed), correct: FA(tr.correct) });
  // v1.11.63 (Batch 4, م-۷): a live-class box with a user-entered link
  // shows «ورود به کلاس» from 15 minutes before its start until it
  // ends (today only — a future day's box never matches today's clock).
  const joinLink = boxClassLink(b);
  const joinVisible = !!(joinLink && classJoinVisible(b));
  // v1.11.4: three tight rows only (was seven stacked rows, ~380px live).
  // Row 1: tick + title/time + accuracy. Row 2: test inputs + progress.
  // Row 3: timer + book links + edit/delete. Every input/button keeps
  // its class, so all listeners below attach exactly as before.
  div.innerHTML =
    '<div class="part-top">' +
      '<input type="checkbox" ' + (isDone(b) ? "checked" : "") + ' aria-label="' + t("fDone") + '">' +
      '<div style="flex:1;min-width:0"><div class="part-title">' + t("partWord") + FA(idx + 1) + ' — ' + esc(b.title) +
      (boxIsClass(b) ? ' <span class="class-badge">' + t("anTypeClass") + '</span>' : '') + '</div>' +
      '<div class="part-time">' + fmtTimeFa(b.start) + ' – ' + fmtTimeFa(b.end) + ' · ' + esc(subjName(b.subject)) + '</div>' +
      (why ? '<button type="button" class="why-link" title="' + esc(t("boxWhyTitle")) + '">' + esc(budgetLabelText(why)) + '</button>' : '') + '</div>' +
      '<span class="pct">' + (acc == null ? "—" : FA_PCT(acc)) + '</span>' +
      (sp ? '<span class="spd" title="' + esc(t("spTitle")) + '">' + speedText(sp) + '</span>' : "") +
      (prereq == null ? "" : '<span class="prereq-pill ' + (prereq ? "ready" : "not") + '">' + esc(t(prereq ? "prereqReady" : "prereqNotReady")) + '</span>') +
      // v1.11.52 (P-8): «این باکس را عوض کن» — only on an unready test
      // box (prerequisite chapter not watched yet).
      (prereq === false ? '<button type="button" class="btn swap-box-btn">' + esc(t("swapBoxBtn")) + '</button>' : "") +
      // v1.11.37 (P3-4): the calendar status is a small pill next to
      // the title/% now, not an absolute box above the card — so the
      // card's top padding goes back to 10px (see styles.css).
      connStatusBoxHtml(b) + calAddToCalBtnHtml(b) +
    '</div>' +
    // v1.11.32 (P2-3): two-mode card. Compact by default — tick,
    // title, time, %, timer button + «جزئیات». The three test fields
    // and the manual real/useful inputs live behind «جزئیات», in the
    // .timer-row below (kept with that class so the v1.11.4 layout
    // checks still find the actions + link row inside it).
    '<div class="part-compact">' +
      '<span class="tm-actual">' + actualVsHtml(b) + sessionClockHtml(b) +
      (state.activeTimer && state.activeTimer.boxId === b.id ? ' · <span class="tm-live" data-tm-live="' + esc(b.id) + '">' + fmtClock(timerLiveSecondsForBox(b.id)) + '</span>' : '') + '</span>' +
      (joinVisible ? '<a class="btn btn-primary class-join-btn" href="' + esc(joinLink) + '" target="_blank" rel="noopener">' + esc(t("classJoinBtn")) + '</a>' : '') +
      (state.activeTimer && state.activeTimer.boxId === b.id
        ? (state.activeTimer.status === "running"
          ? '<button class="btn tm-pause">' + t("tmPause") + '</button><button class="btn tm-stop">' + t("tmStop") + '</button>'
          : '<button class="btn tm-resume">' + t("tmResume") + '</button><button class="btn tm-stop">' + t("tmStop") + '</button>')
        : '<button class="btn btn-primary tm-start">' + t("tmStart") + '</button>') +
      '<button class="btn details-btn">' + (BOX_DETAILS_OPEN.has(b.id) ? t("detailsHide") : t("detailsBtn")) + '</button>' +
    '</div>' +
    '<div class="timer-row part-details' + (BOX_DETAILS_OPEN.has(b.id) ? "" : " hidden") + '">' +
    '<div class="tests-label">' + t("testsPractice") + '</div>' +
    (doneTests
      ? '<div class="tests-summary' + (testsEditing ? " hidden" : "") + '"><span>' + esc(testsSummaryTxt) + '</span>' +
        '<button type="button" class="btn tests-edit-btn">' + esc(t("editBtn")) + '</button></div>'
      : "") +
    '<div class="tests-row' + (doneTests && !testsEditing ? " hidden" : "") + '">' +
      '<label>' + t("completedLbl") + '<span class="step-wrap"><input type="number" min="0" class="t-completed" value="' + tr.completed + '">' +
      '<button type="button" class="btn step-btn step-minus" title="−">−</button>' +
      '<button type="button" class="btn step-btn step-plus" title="+">+</button></span></label>' +
      '<label>' + t("correctLbl") + '<input type="number" min="0" class="t-correct" value="' + tr.correct + '"></label>' +
      '<label>' + t("totalTestsInput") + '<input type="number" min="0" class="t-total" value="' + (b.tests_total || 0) + '" title="' + t("totalTestsHint") + '"></label>' +
      '<button class="btn t-save">' + t("saveBtn") + '</button>' +
      '<div class="progress"><div style="width:' + progPct + '%"></div></div>' +
    '</div>' +
    '<div class="tests-quick' + (doneTests && !testsEditing ? " hidden" : "") + '">' +
      '<button type="button" class="btn step-all-correct">' + esc(t("stepAllCorrect")) + '</button>' +
      '<button type="button" class="btn step-half-correct">' + esc(t("stepHalfCorrect")) + '</button>' +
      (doneTests ? '<button type="button" class="btn tests-hide-btn">' + esc(t("detailsHide")) + '</button>' : "") +
    '</div>' +
      '<div class="tm-manual-row' + (doneTests ? " hidden" : "") + '">' +
      '<label class="tm-manual">' + t("tmManualLabel") + ' <input type="number" min="0" class="tm-mins" placeholder="0"></label>' +
      '<button class="btn tm-add">' + t("tmAddBtn") + '</button>' +
      '<label class="tm-manual">' + t("tmUsefulLabel") + ' <input type="number" min="0" class="tm-useful-mins" placeholder="0"></label>' +
      '<button class="btn tm-add-useful">' + t("tmAddUsefulBtn") + '</button>' +
      '</div>' +
      // v1.11.37 (P3-5): ONE connection row — the budget-topic link and
      // the book-section links, each labelled, instead of the topic
      // title floating in the time row plus a separate book row.
      boxConnRowHtml(b) +
      '<span class="part-actions">' +
        '<button class="edit-btn">' + t("editBtn") + '</button>' +
        '<button class="del-btn">' + t("delBtn") + '</button>' +
        boxMenuBtnHtml() +
      '</span>' +
    '</div>' +
    // v1.11.31 (P1-6): the "how useful was this session?" row, shown
    // only while a timer-stop prompt is pending for this box.
    usefulPromptHtml(b);
  wireUsefulPrompt(div, b);
  // v1.11.35 (P2-11): the error-notebook prompt lives in the details
  // row (opened automatically when the prompt is set in saveBoxTests).
  const promptSlot = document.createElement("div");
  promptSlot.className = "errnb-prompt-slot";
  div.querySelector(".part-details").appendChild(promptSlot);
  wireErrNbPrompt(promptSlot, b);
  div.querySelector('input[type="checkbox"]').addEventListener("change", (e) => {
    const wasDone = isDone(b);
    setDone(b, e.target.checked); // v1.11.30 (P1-1): stamps the tick date
    if (!e.target.checked) TESTS_EDIT_OPEN.delete(b.id);
    // v1.11.63 (Batch 4, خ-۲): a tick in the Today view moves the focus
    // to the next undone box. v1.11.72 (Batch 5, R2): the pointer now
    // PERSISTS across re-renders until the next tick / tab change —
    // it is no longer consumed at the end of renderToday.
    if (e.target.checked && !wasDone && currentTab === "today") PENDING_NEXT_FOCUS = { afterId: b.id, scrolled: false };
    saveState(); renderAll();
  });
  // v1.11.32 (P2-5a): the three one-line fields + one «ذخیره» button —
  // every change and the button apply all three together (saveBoxTests),
  // so the numbers are never half-saved. (P2-3): the «جزئیات» toggle
  // only flips this card's details row — no re-render, no scroll loss.
  const saveTests = () => saveBoxTests(b,
    div.querySelector(".t-completed").value,
    div.querySelector(".t-correct").value,
    div.querySelector(".t-total").value);
  div.querySelector(".t-completed").addEventListener("change", saveTests);
  div.querySelector(".t-correct").addEventListener("change", saveTests);
  div.querySelector(".t-total").addEventListener("change", saveTests);
  div.querySelector(".t-save").addEventListener("click", saveTests);
  // v1.11.63 (Batch 4, ب-۱۰): the summary line's «ویرایش» reopens the
  // fields in place (no re-render, no scroll loss); «بستن» collapses
  // them back to the summary.
  const testsEditBtn = div.querySelector(".tests-edit-btn");
  if (testsEditBtn) testsEditBtn.addEventListener("click", () => {
    TESTS_EDIT_OPEN.add(b.id);
    const sum = div.querySelector(".tests-summary");
    const row = div.querySelector(".tests-row");
    const quick = div.querySelector(".tests-quick");
    if (sum) sum.classList.add("hidden");
    if (row) row.classList.remove("hidden");
    if (quick) quick.classList.remove("hidden");
  });
  const testsHideBtn = div.querySelector(".tests-hide-btn");
  if (testsHideBtn) testsHideBtn.addEventListener("click", () => {
    TESTS_EDIT_OPEN.delete(b.id);
    const sum = div.querySelector(".tests-summary");
    const row = div.querySelector(".tests-row");
    const quick = div.querySelector(".tests-quick");
    if (sum) sum.classList.remove("hidden");
    if (row) row.classList.add("hidden");
    if (quick) quick.classList.add("hidden");
  });
  // v1.11.63 (Batch 4, خ-۳): the test counter is a stepper, not just a
  // typing field — +/− next to «انجام‌شده», «همه درست» / «نیمی درست»
  // as one-click fills. The typing field stays; the stepper is only
  // the faster path. Every step saves through saveTests (same clamps).
  const stepNum = (sel) => { const el = div.querySelector(sel); return el ? (parseInt(el.value, 10) || 0) : 0; };
  const stepMinus = div.querySelector(".step-minus");
  if (stepMinus) stepMinus.addEventListener("click", () => {
    const inp = div.querySelector(".t-completed");
    inp.value = Math.max(0, stepNum(".t-completed") - 1);
    saveTests();
  });
  const stepPlus = div.querySelector(".step-plus");
  if (stepPlus) stepPlus.addEventListener("click", () => {
    const inp = div.querySelector(".t-completed");
    inp.value = stepNum(".t-completed") + 1;
    saveTests();
  });
  const stepAll = div.querySelector(".step-all-correct");
  if (stepAll) stepAll.addEventListener("click", () => {
    const total = stepNum(".t-total");
    const comp = div.querySelector(".t-completed");
    const corr = div.querySelector(".t-correct");
    if (total > 0) comp.value = total;
    corr.value = comp.value;
    saveTests();
  });
  const stepHalf = div.querySelector(".step-half-correct");
  if (stepHalf) stepHalf.addEventListener("click", () => {
    const corr = div.querySelector(".t-correct");
    corr.value = Math.round(stepNum(".t-completed") / 2);
    saveTests();
  });
  div.querySelector(".details-btn").addEventListener("click", (e) => {
    const det = div.querySelector(".part-details");
    const open = det.classList.contains("hidden");
    if (open) BOX_DETAILS_OPEN.add(b.id); else BOX_DETAILS_OPEN.delete(b.id);
    det.classList.toggle("hidden", !open);
    e.target.textContent = open ? t("detailsHide") : t("detailsBtn");
  });
  const tmStartBtn = div.querySelector(".tm-start");
  if (tmStartBtn) tmStartBtn.addEventListener("click", () => timerStart(b.id));
  const tmPauseBtn = div.querySelector(".tm-pause");
  if (tmPauseBtn) tmPauseBtn.addEventListener("click", timerPause);
  const tmResumeBtn = div.querySelector(".tm-resume");
  if (tmResumeBtn) tmResumeBtn.addEventListener("click", timerResume);
  const tmStopBtn = div.querySelector(".tm-stop");
  if (tmStopBtn) tmStopBtn.addEventListener("click", timerStop);
  div.querySelector(".tm-add").addEventListener("click", () => {
    const inp = div.querySelector(".tm-mins");
    timerAddManual(b.id, inp ? inp.value : 0);
  });
  div.querySelector(".tm-add-useful").addEventListener("click", () => {
    const inp = div.querySelector(".tm-useful-mins");
    timerAddUseful(b.id, inp ? inp.value : 0);
  });
  wireOwnerLinkRow(div, "box:" + b.id,
    () => boxBookLinks(b.id),
    (entries) => {
      state.boxBookLinks = state.boxBookLinks || {};
      if (entries.length) state.boxBookLinks[b.id] = entries;
      else delete state.boxBookLinks[b.id];
    });
  // v1.11.37 (P3-5): the budget-topic link is edited in the box edit
  // modal (the topic select lives there) — the row's «تغییر» opens it.
  const topicEditBtn = div.querySelector("[data-action='edit-topic']");
  if (topicEditBtn) topicEditBtn.addEventListener("click", (e) => { e.stopPropagation(); openEditBox(b); });
  const whyBtn = div.querySelector(".why-link");
  if (whyBtn && why) whyBtn.addEventListener("click", (e) => { e.stopPropagation(); openExamDetail(why.exam.id); });
  div.querySelector(".part-actions .edit-btn").addEventListener("click", () => openEditBox(b));
  wireBoxMenuBtn(div.querySelector(".menu-btn"), b);
  div.querySelector(".del-btn").addEventListener("click", () => deleteBoxById(b));
  // v1.11.52 (P-8): «جایگزین پیشنهاد بده» on an unready test box.
  const swapBtn = div.querySelector(".swap-box-btn");
  if (swapBtn) swapBtn.addEventListener("click", () => suggestBoxSwap(b));
  return div;
}

// v1.11.52 (P-8): «این باکس را عوض کن» — for a test box whose
// prerequisite chapter is not watched yet. The replacement is the
// first READY box of the same study day: same subject first, then a
// subject of the nearest exam, then any ready box. On confirm the two
// boxes swap times (same date, exchanged start/end) via two POST
// /api/boxes/update calls. The original box is MOVED, never deleted
// — no box goes to «گذشته». Day totals are unchanged by a swap, so
// there is no cap/overlap issue.
async function suggestBoxSwap(b) {
  const day = boxStudyDay(b) || b.date;
  const ready = allBoxes().filter(x => x.id !== b.id && (boxStudyDay(x) || x.date) === day &&
    !isDone(x) && testBoxReady(x) !== false);
  const nx = nearestExam();
  const nxSubjs = new Set(((nx && nx.budget) || []).map(s => s.subject));
  const rank = x => x.subject === b.subject ? 0 : (nxSubjs.has(x.subject) ? 1 : 2);
  ready.sort((x, y) => rank(x) - rank(y) || compareBoxOrder(x, y));
  const cand = ready[0];
  if (!cand) { showToast(t("swapNone"), { kind: "err", ms: 4000 }); return; }
  if (!confirm(t("swapConfirm", { a: b.title, c: cand.title }))) return;
  try {
    const r1 = await boxApiPost("/api/boxes/update", { id: b.id, start: cand.start, end: cand.end });
    const r2 = await boxApiPost("/api/boxes/update", { id: cand.id, start: b.start, end: b.end });
    if (!r1.ok || !r2.ok) { showToast(t("swapFail"), { kind: "err", ms: 4000 }); return; }
    if (r1.data && r1.data.box) applyServerBox(r1.data.box);
    if (r2.data && r2.data.box) applyServerBox(r2.data.box);
    saveState(); renderAll();
    showToast(t("swapDone"));
  } catch (e) { showToast(t("swapFail"), { kind: "err", ms: 4000 }); }
}

// ---- Edit modal (box: title, subject, topic link, date, times, tests, note, done) ----
let editingBoxId = null;
function topicSelectOptions(selected) {
  let html = '<option value="auto"' + (selected === "auto" || !selected ? " selected" : "") + '>' + t("fAuto") + '</option>' +
    '<option value="none"' + (selected === "none" ? " selected" : "") + '>' + t("fNoLink") + '</option>';
  (TESTBOOK.books || []).forEach(book => {
    html += '<optgroup label="' + esc(bookName(book)) + '">';
    (book.chapters || []).forEach(ch => (ch.topics || []).forEach(tp => {
      html += '<option value="' + esc(tp.id) + '"' + (selected === tp.id ? " selected" : "") + '>' +
        esc(chapterTitle(ch) + " — " + topicTitle(tp)) + "</option>";
    }));
    html += "</optgroup>";
  });
  return html;
}
function fillEditBox(b) {
  editingBoxId = b.id;
  document.getElementById("editModalTitle").textContent = t("edTitle");
  document.getElementById("efTitle").value = b.title || "";
  document.getElementById("efSubject").value = b.subject || "";
  document.getElementById("efTopic").innerHTML = topicSelectOptions(
    (state.topicLinks || {})[b.id] || "auto");
  document.getElementById("efDate").value = jalaliInputText(b.date);
  document.getElementById("efStart").value = b.start || "09:00";
  document.getElementById("efEnd").value = b.end || "10:30";
  document.getElementById("efTotal").value = b.tests_total || 0;
  const tr = testOf(b);
  document.getElementById("efCompleted").value = tr.completed || 0;
  document.getElementById("efCorrect").value = tr.correct || 0;
  document.getElementById("efNote").value = b.note || "";
  document.getElementById("efActual").value = Math.round(((state.actualMinutes || {})[b.id] || 0) / 60);
  document.getElementById("efActualLine").innerHTML = actualVsHtml(b);
  // v1.11.21: useful time, edited exactly like real time (same
  // round-trip rule below) — an empty field leaves the stored value
  // untouched; an absent useful shows «ثبت نشده», never 0.
  document.getElementById("efUseful").value = hasUsefulMinutes(b) ? Math.round(usefulTotalSeconds(b.id) / 60) : "";
  const eff = boxEfficiency(b);
  document.getElementById("efUsefulLine").textContent = eff == null ? t("tmUsefulNotRecorded") : t("tmEfficiency") + ": " + FA_PCT(eff);
  document.getElementById("efDone").checked = isDone(b);
  document.getElementById("efClass").checked = boxIsClass(b);
  // v1.11.63 (Batch 4, م-۷): the live-class join link — optional,
  // local-only (state.classLinks), never sent to the calendar. The
  // field starts empty; a link is only ever what the user enters.
  const linkRow = document.getElementById("efClassLinkRow");
  const linkInp = document.getElementById("efClassLink");
  if (linkRow && linkInp) {
    linkInp.value = boxClassLink(b) || "";
    linkRow.hidden = !boxIsClass(b);
  }
  // v1.11.9: connection status in the task details (§6) — a real Event
  // ID link, or disconnected; a manual box has no calendar link at all.
  const connEl = document.getElementById("efConn");
  if (connEl) {
    if (b.is_custom) connEl.textContent = t("calCustomNoConn");
    else if (boxConnected(b)) connEl.textContent = t("calConnTitle");
    else connEl.textContent = t("calDisconnTitle") + ((UNLINKED.unlinked_events || []).length ? " — " + t("menuReconnectCal") : "");
  }
  // (2.8) live programme warnings for the edited box's day.
  wireEditWarnings();
  renderEditWarnings();
  const subjects = [...new Set(allBoxes().map(x => x.subject))].sort();
  document.getElementById("subjectList").innerHTML =
    subjects.map(s => "<option value=\"" + esc(s) + "\">").join("");
  document.getElementById("editModal").classList.add("open");
  renderModalLinkRow(b);
  renderBreadcrumb(); // v1.11.66 (Batch 7, خ-۵): the editing box's title joins the breadcrumb
}
// Book links inside the box edit modal: the same multi-select picker as
// exam topics. Saving writes immediately (like the exam editor); the
// modal's own Save never touches links. Re-renders only this block so
// the modal stays open with its form values intact.
function renderModalLinkRow(b) {
  const wrap = document.getElementById("efLinks");
  if (!wrap || !b) return;
  const key = "box:" + b.id;
  wrap.innerHTML = genericLinkRowHtml(boxBookLinks(b.id), key);
  wireOwnerLinkRow(wrap, key,
    () => boxBookLinks(b.id),
    (entries) => {
      state.boxBookLinks = state.boxBookLinks || {};
      if (entries.length) state.boxBookLinks[b.id] = entries;
      else delete state.boxBookLinks[b.id];
    },
    () => renderModalLinkRow(b),
    () => renderModalLinkRow(b));
}
// User-initiated open: fill the form AND push a history entry (Back closes it).
function openEditBox(b) { fillEditBox(b); pushModalRoute({ kind: "edit", boxId: b.id }); }
function hideEditModalUI() {
  document.getElementById("editModal").classList.remove("open");
  editingBoxId = null;
  renderBreadcrumb(); // v1.11.66 (Batch 7, خ-۵): drop the editing-box segment
  // An open box-link editor must not leak into the part card behind it.
  if (linkEditingKey && linkEditingKey.indexOf("box:") === 0) { linkEditingKey = null; linkDraft = null; }
}
function closeEditModal() {
  hideEditModalUI();
  closeModalHistory();
}
document.getElementById("editClose").addEventListener("click", closeEditModal);
document.getElementById("efCancel").addEventListener("click", closeEditModal);
// v1.11.63 (Batch 4, م-۷): the link row shows only for a class box.
document.getElementById("efClass").addEventListener("change", (e) => {
  const row = document.getElementById("efClassLinkRow");
  if (row) row.hidden = !e.target.checked;
});
document.getElementById("reconnectClose").addEventListener("click", () => document.getElementById("reconnectModal").classList.remove("open"));
document.getElementById("reconnectModal").addEventListener("click", (e) => {
  if (e.target.id === "reconnectModal") document.getElementById("reconnectModal").classList.remove("open");
});
document.getElementById("editModal").addEventListener("click", (e) => {
  if (e.target.id === "editModal") closeEditModal();
});
document.getElementById("efSave").addEventListener("click", async () => {
  const id = editingBoxId;
  if (!id) return;
  const b = allBoxes().find(x => x.id === id);
  if (!b) return;
  const title = document.getElementById("efTitle").value.trim() || b.title;
  const subject = document.getElementById("efSubject").value.trim() || b.subject;
  // v1.11.41 (UI-audit batch 1): the date/time fields are Jalali text
  // and 24-hour text now — parse them back to the stored Gregorian
  // ISO / HH:MM. Empty keeps the old value (as before); an unparseable
  // non-empty value stops the save with a plain message instead of
  // silently reverting.
  const dateRaw = document.getElementById("efDate").value.trim();
  const date = dateRaw === "" ? b.date : parseJalaliInput(dateRaw);
  if (dateRaw !== "" && !date) { alert(t("jalaliInvalid")); return; }
  const startRaw = document.getElementById("efStart").value.trim();
  const endRaw = document.getElementById("efEnd").value.trim();
  const start = startRaw === "" ? b.start : parseTime24(startRaw);
  const end = endRaw === "" ? b.end : parseTime24(endRaw);
  if ((startRaw !== "" && !start) || (endRaw !== "" && !end)) { alert(t("timeInvalid")); return; }
  // v1.11.16 (audit §5 item 1.5): a zero-length box used to count as
  // 1440 minutes everywhere — refuse it at the edit form.
  if (start === end) { alert(t("edZeroLength")); return; }
  // v1.11.26 (QA BUG-036): end < start needs a confirm (see
  // confirmOvernight) — a typo must not become a 22-hour box.
  if (!confirmOvernight(start, end)) return;
  const note = document.getElementById("efNote").value;
  const total = Math.max(0, parseInt(document.getElementById("efTotal").value, 10) || 0);
  const completed = Math.min(total, Math.max(0, parseInt(document.getElementById("efCompleted").value, 10) || 0));
  const correct = Math.min(completed, Math.max(0, parseInt(document.getElementById("efCorrect").value, 10) || 0));
  const done = document.getElementById("efDone").checked;
  const isClass = document.getElementById("efClass").checked;
  const boxType = isClass ? "class" : "normal";
  // v1.11.63 (Batch 4, م-۷): the class link is local-only — validated
  // here (http(s):// or empty) and stored in state.classLinks, never
  // sent to /api/boxes/update (its fields are whitelisted server-side).
  const linkRaw = (document.getElementById("efClassLink").value || "").trim();
  if (linkRaw && !/^https?:\/\//.test(linkRaw)) { alert(t("classLinkBad")); return; }
  const link = document.getElementById("efTopic").value;
  const actualRaw = document.getElementById("efActual").value.trim();
  const storedSecs = (state.actualMinutes || {})[id] || 0;
  const usefulRaw = document.getElementById("efUseful").value.trim();
  const storedUsefulSecs = usefulTotalSeconds(id);
  // v1.11.31 (P1-10): the box fields go through POST /api/boxes/update
  // FIRST, before any local write — an explicit server error aborts
  // with the server's message and the modal stays open, nothing
  // written. A missing box in an otherwise-OK response (or an
  // unreachable server) falls back to the old local write, so the
  // user's input is never lost. NOTE (BUG-011): `topic` is sent ONLY
  // for custom boxes — the server 400s it for programme boxes.
  let serverBox = null, serverErr = null;
  try {
    const upd = { id, title, subject, date, start, end, note, type: boxType, tests_total: total };
    if (id.startsWith("custom-")) upd.topic = b.topic;
    const r = await boxApiPost("/api/boxes/update", upd);
    if (r.ok && r.data && r.data.box) serverBox = r.data.box;
    else if (!r.ok) serverErr = (r.data && r.data.error) || "";
  } catch (e) { /* unreachable: fall through to the local write */ }
  if (serverErr) { alert(errText(serverErr)); return; }
  if (serverBox) applyServerBox(serverBox);
  else if (id.startsWith("custom-")) {
    const cb = (state.custom_boxes || []).find(x => x.id === id);
    // v1.11.50: a missing custom box used to throw here (Object.assign
    // on undefined) — the server round-trip already failed, so the
    // local write is skipped instead of crashing the save.
    if (cb) Object.assign(cb, { title, subject, date, start, end, note, tests_total: total, type: boxType });
  } else {
    state.edits = state.edits || {};
    state.tests_total = state.tests_total || {};
    state.edits[id] = Object.assign({}, state.edits[id], { title, subject, date, start, end, note, type: boxType });
    state.tests_total[id] = total;
  }
  state.actualMinutes = state.actualMinutes || {};
  if (actualRaw !== "") {
    const actualMins = Math.max(0, parseInt(actualRaw, 10) || 0);
    // Round-trip: the field shows rounded minutes; re-saving the same
    // rounded value must not drift the stored seconds (45 s -> 1 min
    // -> 60 s). An empty field leaves the stored value untouched.
    state.actualMinutes[id] = actualMins === Math.round(storedSecs / 60) ? storedSecs : actualMins * 60;
  }
  // v1.11.21: useful time, same round-trip rule — and never above the
  // (possibly just-edited) real total: clamp + plain-language alert.
  if (usefulRaw !== "") {
    const usefulMins = Math.max(0, parseInt(usefulRaw, 10) || 0);
    const targetSecs = usefulMins === Math.round(storedUsefulSecs / 60) ? storedUsefulSecs : usefulMins * 60;
    const res = setUsefulMinutes(id, targetSecs);
    if (res.clamped) alert(t("tmUsefulOverReal"));
  }
  // 3.2: log the dated delta for the box's tests (totals stay the source).
  const oldTr = testOf({ id });
  const trD = testDeltaFrom(oldTr.completed, oldTr.correct, completed, correct);
  if (trD.solved || trD.correct || trD.wrong) {
    logTestDelta(Object.assign({ box: id, topic: linkedTopicIdCached(b), src: "box" }, trD));
  }
  // v1.11.50: guard the tests write (a null map threw on save).
  state.tests = state.tests || {};
  state.tests[id] = { completed, correct };
  setDone({ id }, done); // v1.11.30 (P1-1): stamps the tick date
  state.topicLinks = state.topicLinks || {};
  if (link === "auto") delete state.topicLinks[id]; else state.topicLinks[id] = link;
  // v1.11.63 (Batch 4, م-۷): the class link lives only in
  // state.classLinks — saved here, after the box write succeeded.
  state.classLinks = state.classLinks || {};
  if (isClass && linkRaw) state.classLinks[id] = linkRaw;
  else delete state.classLinks[id];
  saveState(); hideEditModalUI(); dismissModalEntry(); renderAll();
  showToast(t("toastSaved")); // v1.11.41: the edit save used to be silent
});

// ---- v1.11.2: collapsible long lists (density only) ----
// Collapsed shows only the first `collapsed` items; the rest are hidden
// behind a «show more» button. Expanded shows everything inside a capped
// panel with its own scroll (see .coll-expanded in styles.css), so the
// page itself never moves when a list opens. No data, state or behaviour
// changes: the collapsed state is presentation-only and resets on
// re-render, and lists with <= `collapsed` items get no button at all.
// v1.11.32 (P2-2): per-container open state, kept in memory across
// renderAll (like openBudgetChapters) — ticking a box no longer
// collapses every list the user had open. Key = the explicit 4th
// argument, else the container's id; a container with neither keeps
// the old behaviour (always starts collapsed).
const COLL_OPEN = {};
function attachCollapsible(container, itemSelector, collapsed, key) {
  if (!container || !itemSelector) return;
  const items = Array.from(container.children).filter(el => el.matches(itemSelector));
  if (items.length <= collapsed) return;
  const k = key || (container.id ? "id:" + container.id : null);
  const hiddenCount = items.length - collapsed;
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "btn coll-toggle";
  btn.setAttribute("aria-expanded", "false");
  const apply = (expanded) => {
    items.forEach((it, i) => it.classList.toggle("coll-item-hidden", !expanded && i >= collapsed));
    container.classList.toggle("coll-expanded", expanded);
    btn.setAttribute("aria-expanded", expanded ? "true" : "false");
    btn.textContent = expanded ? t("showLess") : t("showMore", { n: FA(hiddenCount) });
    if (k) COLL_OPEN[k] = expanded;
  };
  btn.addEventListener("click", () => apply(btn.getAttribute("aria-expanded") !== "true"));
  container.appendChild(btn);
  apply(k ? !!COLL_OPEN[k] : false);
}

// ---- Dashboard ----
function statCard(label, value, sub) {
  return '<div class="stat-card"><div class="sc-label">' + label + '</div>' +
    '<div class="sc-value">' + value + '</div><div class="sc-sub">' + (sub || "") + "</div></div>";
}
// ---- Dashboard: at-a-glance ONLY ----
// Today only: Jalali date, today's boxes + day tick, today's tests, a small
// done-past-days badge, and quick navigation. All heavy stats (overall %,
// per-subject bars, week strip, full day-by-day program, book summary)
// live in the Analytics tab now.
function renderDashboard() {
  const boxes = allBoxes();
  // Post-programme mode (1.7): after the programme ends, today is real
  // and the dashboard says so — the programme must be extended, not frozen.
  const ppBanner = document.getElementById("postProgBanner");
  if (ppBanner) {
    ppBanner.hidden = !isPostProgramme();
    if (isPostProgramme()) {
      // v1.11.62 (Batch 3, ب-۴): the banner is a card now, not a dead
      // end — a «build the next stage» button (the same wizard) plus
      // the countdown to Maz 7.
      const maz7 = findExam("maz-7");
      const left = maz7 ? examDaysLeft(maz7) : null;
      ppBanner.innerHTML = '<p>' + esc(t("postProgMsg")) + '</p>' +
        ((left != null && left >= 0) ? '<p class="muted">' + esc(t("postProgDaysLeft", { n: FA(left) })) + '</p>' : "") +
        '<div class="form-row"><button class="btn btn-primary" id="postProgBuildBtn">' + esc(t("postProgBuild")) + '</button></div>';
      const bb = document.getElementById("postProgBuildBtn");
      if (bb) bb.addEventListener("click", openDeyWizard);
    } else {
      ppBanner.innerHTML = "";
    }
  }
  // v1.11.41 (UI-audit batch 1): the dashboard is a real summary —
  // 4 KPI cards + a one-line today (renderDashKpis) + tomorrow
  // summarised (renderNext3Into). The full 7-day detailed list is
  // gone; the detail lives in Programme / Today, linked from here,
  // never duplicated.
  renderDashKpis(boxes);
  refreshStartCurrentButtons(); // v1.11.55 (UX-1): dashboard primary label
  // v1.11.63 (Batch 4, خ-۱): «شروع روز» — the first undone box today
  // + its timer + what comes after, the first thing at 11:30.
  renderStartDayCard();
  // v1.11.64 (Batch 5, م-۶): «گزارش هفته» — the Saturday review card
  // (analytics.js: renderDashWeeklyReport).
  if (typeof renderDashWeeklyReport === "function") renderDashWeeklyReport();
  // v1.11.43 (§17 idea 4): exam-night card on the Dashboard the day
  // before an exam (same checklist as the exam-day card).
  renderExamNightEve();
  // v1.11.55 (P-9): the exam-week bar (countdown / «ثبت نتیجه»).
  renderExamWeek();
  // v1.11.55 (P-10): «از دیروز تا حالا» — one line under the KPIs.
  renderYesterdayLine();
  // v1.11.30 (P1-3): the single connection-health card (async fetch).
  renderConnHealth();
  // v1.11.4: compact upcoming-exams strip — same data (upcomingExams(30))
  // and same row rendering (examRowEl) as the Exams tab; no new data
  // or exam logic. Hidden when nothing is upcoming.
  const dxTitle = document.getElementById("dashExamsTitle");
  const dxWrap = document.getElementById("dashExams");
  if (dxTitle && dxWrap) {
    dxWrap.innerHTML = "";
    const up = upcomingExams(30);
    dxTitle.hidden = !up.length;
    dxWrap.hidden = !up.length;
    if (up.length) {
      dxWrap.className = "dash-exams-strip";
      up.forEach(ex => dxWrap.appendChild(examRowEl(ex)));
      attachCollapsible(dxWrap, ".dash-exam-row", 4);
    }
  }
  // v1.11.63 (Batch 4, dashboard declutter): «دسترسی سریع» is gone —
  // the sidebar does the same job (the weekly report stays reachable
  // via sidebar → Analytics). «هفته در برابر هفته قبل» and «رکوردهای
  // شخصی» moved to Analytics (their home) — see renderAnalytics.
  // v1.11.33 (P2-7): this week's rules card — warnings + day jumps only.
  renderRulesCard();
  // v1.11.35 (P2-13): latest Gemini analysis on the dashboard.
  renderGeminiCard();
  // v1.11.40 (creative 3): efficiency-drop signal — display-only
  // card, real data only. (The personal-bests card moved to Analytics
  // in v1.11.63, Batch 4 — it lives there with the other statistics.)
  renderFatigueCard();
  // v1.11.41 (UI-audit batch 1): tomorrow, summarised — one row,
  // click opens the day in Programme. (The old 3-day detailed list
  // is gone; see renderNext3Into.)
  renderNext3Into(document.getElementById("dashNext3"));
  // v1.11.33 (P2-8): the print button moved here from the Overview tab.
  const prBtn = document.getElementById("dashPrintBtn");
  if (prBtn) prBtn.onclick = () => window.print();
}

// v1.11.63 (Batch 4, ب-۳): the «می‌رسم / نمی‌رسم» verdict under the
// next-exam KPI — the examForecast verdict for that exam + the
// required pace. READ-ONLY: examForecast logic is never changed here.
function nextExamVerdictText(ex) {
  const f = examForecast(ex);
  if (!f) return null;
  const verdictKey = { onTrack: "fcVerdictOnTrack", behind: "fcVerdictBehind",
                       impossible: "fcVerdictImpossible", unknown: "fcVerdictUnknown" }[f.verdict];
  let txt = t(verdictKey);
  if (f.hasCounts && f.needTests !== Infinity && f.rate.activeDays) {
    txt += " · " + t("dashKpiPace", { need: FA(Math.round(f.needTests)), rate: FA(Math.round(f.rate.testsPerDay)) });
  }
  return txt;
}

// ---------- Dashboard summary (v1.11.41, UI-audit batch 1) ----------
// 4 KPI cards (today, undone past, overall, next exam) + a one-line
// today. Every card is a button that jumps to the view with the
// detail — the dashboard itself holds no detail lists.
function renderDashKpis(boxes) {
  const wrap = document.getElementById("dashKpis");
  const line = document.getElementById("dashTodayLine");
  if (!wrap && !line) return;
  const todayList = boxes.filter(b => boxStudyDay(b) === TODAY && isCurrentBox(b));
  const doneToday = todayList.filter(isDone);
  const undonePastCount = boxes.filter(b => !isDone(b) && (boxStudyDay(b) || b.date) < TODAY && !(state.backlogHidden || {})[b.id]).length;
  const todayMin = todayList.reduce((s, b) => s + minutesBetween(b.start, b.end), 0);
  const current = boxes.filter(isCurrentBox);
  const doneTotal = current.filter(isDone).length;
  const up = upcomingExams(30)[0] || null;
  // v1.11.48 (P-1): the progress KPI also forecasts the end date
  // from the recent completion pace — «—» when no pace exists yet.
  const fc = forecastEndDate();
  if (wrap) {
    const kpis = [
      { label: t("dashKpiToday"), value: FA(doneToday.length) + " / " + FA(todayList.length),
        sub: fmtDurationFa(Math.round(todayMin)), go: () => navigate({ tab: "today" }) },
      { label: t("dashKpiOverdue"), value: FA(undonePastCount), sub: t("dashKpiPastSub"),
        go: () => { navigate({ tab: "remaining" });
          setTimeout(() => { const el = document.getElementById("pastUndone"); if (el) el.scrollIntoView(); }, 80); } },
      { label: t("dashKpiProgress"),
        value: FA_PCT(Math.round(100 * doneTotal / Math.max(1, current.length))), // v1.11.45 (F-13): Persian digits + ٪, like the neighbouring KPIs
        sub: FA(doneTotal) + " / " + FA(current.length) + " · " +
          (!fc ? "—" : fc.diffDays >= 0
            ? t("dashForecastEarly", { date: gregToJalali(fc.endDate).text, n: FA(fc.diffDays) })
            : t("dashForecastLate", { date: gregToJalali(fc.endDate).text, n: FA(-fc.diffDays) })),
        title: fc ? t("dashForecastRate", { w: FA(fc.windowDays), r: FA(Math.round(fc.rate * 10) / 10) }) : "",
        go: () => navigate({ tab: "program" }) },
      { label: t("dashKpiNextExam"), value: up ? (up.name || "—") : "—",
        // v1.11.48 (CQ-01): full-range jalaliLabel covers every month,
        // so the KPI shows the Jalali date for Dey exams too (Maz-7,
        // 2027-01-01) instead of a raw ISO string.
        sub: up ? jalaliLabel(up.date).text : "", go: () => navigate({ tab: "exams" }),
        // v1.11.63 (Batch 4, ب-۳): the forecast verdict + required pace
        // under the same KPI — the user's most-asked question, on the
        // most-visited spot of the dashboard.
        verdict: up ? nextExamVerdictText(up) : null },
    ];
    wrap.innerHTML = "";
    kpis.forEach(k => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "dash-kpi";
      if (k.title) btn.title = k.title;
      const l = document.createElement("span"); l.className = "dk-label"; l.textContent = k.label;
      const v = document.createElement("span"); v.className = "dk-value"; v.textContent = k.value;
      const s = document.createElement("span"); s.className = "dk-sub"; s.textContent = k.sub || "";
      btn.append(l, v, s);
      if (k.verdict) {
        const vd = document.createElement("span");
        vd.className = "dk-verdict";
        vd.textContent = k.verdict;
        btn.appendChild(vd);
      }
      btn.addEventListener("click", k.go);
      wrap.appendChild(btn);
    });
  }
  if (line) {
    line.innerHTML = "";
    const span = document.createElement("span");
    span.className = "dtl-text";
    span.textContent = t("dashTodaySummary", { done: FA(doneToday.length), total: FA(todayList.length) });
    const btn = document.createElement("button");
    btn.type = "button"; btn.className = "btn btn-primary";
    btn.textContent = t("dashTodayLink");
    btn.addEventListener("click", () => navigate({ tab: "today" }));
    line.append(span, btn);
  }
}

// ---------- Week vs last week (v1.11.43, §17 idea 7) ----------
// Real timer hours this week (Sat–Fri) vs last week + delta arrow.
// Real data only: no recorded time in either week shows the honest
// empty state, never a fabricated 0.
function weekSatOf(iso) {
  const d = new Date(iso + "T12:00:00");
  return addDays(iso, -((d.getDay() + 1) % 7));
}
function realSecsInWeek(satIso) {
  // v1.11.45 (F-04): session execution day, not box day.
  let secs = 0;
  for (let i = 0; i < 7; i++) secs += actualSecsOn(addDays(satIso, i));
  return secs;
}
function renderWeekVsCard() {
  // v1.11.63 (Batch 4, dashboard declutter): «هفته در برابر هفته قبل»
  // moved to Analytics (its home) — same card, same data, no click
  // needed (it already lives in Analytics now).
  const el = document.getElementById("anWeekVsCard");
  if (!el) return;
  const thisSat = weekSatOf(TODAY);
  const lastSat = addDays(thisSat, -7);
  const thisMin = Math.round(realSecsInWeek(thisSat) / 60);
  const lastMin = Math.round(realSecsInWeek(lastSat) / 60);
  let delta;
  if (thisMin === 0 && lastMin === 0) delta = t("dashWeekEmpty");
  else if (thisMin === lastMin) delta = t("dashWeekSame");
  else if (thisMin > lastMin) delta = "↑ " + t("dashWeekMore", { d: fmtDurationFa(thisMin - lastMin) });
  else delta = "↓ " + t("dashWeekLess", { d: fmtDurationFa(lastMin - thisMin) });
  el.innerHTML = '<span class="wv-title">' + esc(t("dashKpiWeek")) + '</span>' +
    '<span class="wv-line">' + esc(t("dashWeekThis", { h: fmtDurationFa(thisMin) })) + '</span>' +
    '<span class="wv-line">' + esc(t("dashWeekPrev", { h: fmtDurationFa(lastMin) })) + '</span>' +
    '<span class="wv-delta">' + esc(delta) + '</span>';
}

// ---------- «شروع روز» (v1.11.63, Batch 4, خ-۱) ----------
// The first thing at 11:30: the first undone box today + its timer +
// what comes after — one card, one tap, instead of dashboard → Today
// → find the box → timer. A running timer shows its box + «توقف».
function renderStartDayCard() {
  const el = document.getElementById("dashStartDay");
  if (!el) return;
  const todayList = allBoxes().filter(b => boxStudyDay(b) === TODAY && isCurrentBox(b)).slice().sort(compareBoxOrder);
  const running = state.activeTimer ? todayList.find(b => b.id === state.activeTimer.boxId) : null;
  const first = todayList.find(b => !isDone(b)) || null;
  const show = running || first;
  if (!show) {
    el.innerHTML = '<div class="sd-title">' + esc(t("sdStartDay")) + '</div>' +
      '<p class="muted">' + esc(todayList.length ? t("sdAllDone") : t("noBoxDay")) + '</p>';
    return;
  }
  const idx = todayList.indexOf(show);
  const after = todayList.slice(idx + 1).find(b => !isDone(b)) || null;
  el.innerHTML = '<div class="sd-title">' + esc(t("sdStartDay")) + '</div>' +
    '<div class="sd-box"><span class="sd-name">' + esc(subjName(show.subject) + " — " + (show.title || "")) + '</span>' +
    '<span class="sd-time">' + fmtTimeFa(show.start) + ' – ' + fmtTimeFa(show.end) + '</span></div>' +
    '<div class="sd-actions"><button type="button" class="btn btn-primary sd-start-btn">' +
    esc(t(running ? "ux1StopTimer" : "tmStart")) + '</button>' +
    '<button type="button" class="btn sd-today-btn">' + esc(t("dashTodayLink")) + '</button></div>' +
    (after ? '<div class="sd-after">' + esc(t("sdAfter")) + ' ' + esc(subjName(after.subject) + " — " + (after.title || "")) + ' · ' + fmtTimeFa(after.start) + '</div>' : "");
  el.querySelector(".sd-start-btn").addEventListener("click", () => {
    if (state.activeTimer) timerStop();
    else timerStart(show.id);
  });
  el.querySelector(".sd-today-btn").addEventListener("click", () => navigate({ tab: "today" }));
}

// ---- «امروز» tab (v1.11.36): all today-specific content moved here
// from the Dashboard — the dashboard is now a clean overview. Every
// component is REUSED (same renderers, same element ids, same order
// as the spec: stats summary, progress, programme + tasks, study time,
// activity details, remaining/overdue for today); only the calls
// moved. No data logic changed, no new state keys.
// Order on the tab: now/next bar, hero (date + tests + actual/useful
// + progress), day summary card, today's boxes (+ SR-due above them,
// «بستن روز» at the bottom).
function renderToday() {
  refreshStartCurrentButtons(); // v1.11.55 (UX-1): Today primary label
  const boxes = allBoxes();
  const todayList = boxes.filter(b => boxStudyDay(b) === TODAY && isCurrentBox(b)).slice().sort(compareBoxOrder);
  document.getElementById("dashDateLine").textContent =
    weekdayFa(TODAY) + " " + gregToJalali(TODAY).text;
  const testsToday = todayList.reduce((s, b) => s + (testOf(b).completed || 0), 0);
  const correctToday = todayList.reduce((s, b) => s + (testOf(b).correct || 0), 0);
  document.getElementById("dashTodayTests").textContent =
    t("dashTestsToday", { done: FA(testsToday), correct: FA(correctToday) });
  const todayActualSecs = actualSecsOn(TODAY); // v1.11.45 (F-04): session day, not box day
  const taEl = document.getElementById("dashTodayActual");
  if (taEl) taEl.textContent = t("dashActualToday", { t: fmtDurationFa(Math.round(todayActualSecs / 60)) });
  // v1.11.21: useful time + efficiency next to the real-time line.
  // Shown only once real time exists today; an unrecorded useful is
  // «ثبت نشده», never 0, and efficiency hides without both values.
  const tuEl = document.getElementById("dashTodayUseful");
  if (tuEl) {
    const todayUsefulSecs = usefulSecsOn(TODAY); // v1.11.45 (F-04): session day, not box day
    const eff = efficiencyPct(todayUsefulSecs, todayActualSecs);
    tuEl.textContent = todayActualSecs > 0
      ? (eff == null ? t("dashUsefulNotRecorded")
          : t("dashUsefulToday", { t: fmtDurationFa(Math.round(todayUsefulSecs / 60)), e: FA_PCT(eff) }))
      : "";
  }
  // Hero progress bar (audit §5 item 2.2): the one progress definition.
  renderHeroProgress();
  // v1.11.30 (P1-5): the "now and next" sticky bar, refreshed with the dashboard.
  renderNowNext();
  // v1.11.43 (§17 idea 1): the sticky mini-hero text refreshes with Today.
  renderMiniHero();
  // v1.11.43 (§17 idea 10): gentle nudges for boxes that ended 30+
  // minutes ago unticked, above today's list.
  renderTodayNudges();
  const sdNote = document.getElementById("dashStudyDayNote");
  if (sdNote) sdNote.textContent = t("studyDayNote");
  // Day summary card (v1.11.10): today only — the tomorrow card became
  // a small link on the dashboard (see renderDashboard).
  renderDaySummary();
  // v1.11.38 (P3-9): daily goal + streak, right under the summary.
  renderDailyGoal();
  // v1.11.35 (P3-1): fullscreen focus mode entry.
  const fcBtn = document.getElementById("dashFocusBtn");
  if (fcBtn) fcBtn.onclick = () => openFocus();
  // Spaced repetition (audit §5 item 3.4): today's due chapters, above
  // the programme. Rebuilt on every render, like the summary cards.
  renderSRDue();
  // Today only — no tomorrow, no full program, no stats.
  const el = document.getElementById("todayBoxes");
  el.innerHTML = "";
  // v1.11.45 (F-11): the exam-day card must render even on a box-less
  // day — it used to sit after this early return and never showed.
  renderExamDay();
  // v1.11.52 (I-5): the no-box day renders through the shared
  // empty-state component — title + hint + the next step (open the
  // monthly programme, where the add-box form lives).
  if (!todayList.length) {
    el.innerHTML = "";
    el.appendChild(emptyState({ title: t("noBoxDay"), hint: t("esTodayHint"),
      actionLabel: t("esTodayAction"), onAction: () => navigate({ tab: "program" }) }));
    renderTodaySessions(el); // v1.11.52 (P-3): sessions may still exist (catch-up on other days' boxes)
    PENDING_NEXT_FOCUS = null; // v1.11.63 (خ-۲): nothing to focus on
    return;
  }
  el.appendChild(dayTickEl(TODAY));
  // v1.11.50 (Part 1): ALL of today's boxes from the start — no
  // «show more», no count-limited collapsing (the old collapse call
  // on this list is gone). The list scrolls
  // INSIDE the box (#todayBoxes.today-scroll in styles.css): fixed
  // height cap, sticky day-tick header, themed scrollbar. One bad box
  // must not kill the whole list: skip it (logged) and render the
  // rest, so one task's edit can never corrupt the others.
  todayList.forEach((b, i) => {
    try { el.appendChild(partCard(b, i)); }
    catch (e) { console.error("partCard failed for box", b && b.id, e); }
  });
  // v1.11.32 (P2-1): «بستن روز» at the BOTTOM of today's list —
  // the close-day summary + per-box choices, never above the boxes.
  const cdWrap = document.createElement("div");
  cdWrap.className = "close-day-wrap";
  const cdBtn = document.createElement("button");
  cdBtn.type = "button";
  cdBtn.className = "btn";
  cdBtn.id = "closeDayBtn";
  cdBtn.textContent = t("closeDayBtn");
  cdBtn.addEventListener("click", () => openCloseDay(TODAY));
  cdWrap.appendChild(cdBtn);
  el.appendChild(cdWrap);
  renderTodaySessions(el); // v1.11.52 (P-3): today's sessions log, under the box list
  // v1.11.63 (Batch 4, خ-۲): after a tick in this view, focus moves to
  // the next undone box — smooth scroll (only when it is out of view,
  // so reading is never interrupted) + a brief highlight. The flag is
  // set only by the tick handler above (currentTab === "today"), so a
  // tick from any other tab never steals the scroll. v1.11.72 (Batch 5,
  // R2): the pointer is NOT consumed here anymore — it persists across
  // re-renders (opening the just-ticked card keeps the highlight on
  // the next box); only the scroll fires once per tick (scrolled).
  if (PENDING_NEXT_FOCUS) {
    const pending = PENDING_NEXT_FOCUS;
    const afterIdx = todayList.findIndex(b => b.id === pending.afterId);
    const next = todayList.slice(afterIdx + 1).find(b => !isDone(b));
    if (next) {
      const card = el.querySelector('[data-box-id="' + next.id + '"]');
      if (card) {
        if (!pending.scrolled) {
          pending.scrolled = true;
          const r = card.getBoundingClientRect();
          if (r.top < 0 || r.bottom > window.innerHeight) card.scrollIntoView({ behavior: "smooth", block: "nearest" });
        }
        card.classList.add("next-focus");
        setTimeout(() => card.classList.remove("next-focus"), 2500);
      }
    }
  }
  // v1.11.50 (Part 1): the «show more» collapse is gone — see the
  // note above (all of today's boxes, scrolling inside the box).
  // v1.11.40 (creative 1): exam-day mode — shows only on exam days
  // (rendered above, before the empty-day return — F-11).
}

// v1.11.52 (P-3): today's sessions log — a collapsible section under
// the box list (timer sessions with their clock span + manual entries,
// each with box, span, real, useful, efficiency). Sessions are
// attributed by session-day, so a catch-up session run today counts
// today even when its box belongs to another day.
function renderTodaySessions(el) {
  const list = (state.timerSessions || []).filter(s => sessionStudyDay(s) === TODAY);
  const det = document.createElement("details");
  det.className = "sess-details";
  det.open = true;
  const sum = document.createElement("summary");
  sum.textContent = t("sessTodayTitle");
  det.appendChild(sum);
  if (!list.length) {
    det.appendChild(emptyState({ title: t("sessEmpty") }));
  } else {
    const wrap = document.createElement("div");
    wrap.innerHTML = sessionTableHtml(list);
    det.appendChild(wrap);
  }
  el.appendChild(det);
}

// ---------- Gentle nudge (v1.11.43, §17 idea 10) ----------
// 30 minutes after an unticked box ends, a small card at the top of
// Today: «… انجام نشد. [انجام شد] [به فردا] [پنهان کن]». It stays
// until end of day — the box is ticked, moved or hidden, or the study
// day rolls over. Never a notification, just a card on the Today tab.
// A box hidden by close-day (backlogHidden) never nudges either.
function todayNudgeList() {
  const now = tehranParts(new Date());
  const nowMin = studyDayMinutes(String(now.hh).padStart(2, "0") + ":" + String(now.mm).padStart(2, "0"));
  const hidden = state.nudgeHidden || {};
  const backlogHid = state.backlogHidden || {};
  return allBoxes()
    .filter(b => boxStudyDay(b) === TODAY && isCurrentBox(b) && !isDone(b))
    .filter(b => !backlogHid[b.id] && hidden[b.id] !== TODAY)
    .filter(b => nowMin > studyDayMinutes(b.end || "00:00") + 30)
    .sort(compareBoxOrder);
}
function renderTodayNudges() {
  const wrap = document.getElementById("todayNudges");
  if (!wrap) return;
  wrap.innerHTML = "";
  todayNudgeList().forEach(b => {
    const card = document.createElement("div");
    card.className = "nudge-card";
    card.dataset.boxId = b.id;
    card.innerHTML = '<span class="nudge-text">' + esc(t("nudgeMissed", { title: b.title, time: fmtTimeFa(b.start) + "–" + fmtTimeFa(b.end) })) + '</span>' +
      '<button type="button" class="btn nudge-done">' + esc(t("nudgeDone")) + '</button>' +
      '<button type="button" class="btn nudge-tomorrow">' + esc(t("nudgeTomorrow")) + '</button>' +
      '<button type="button" class="btn nudge-hide">' + esc(t("nudgeHide")) + '</button>';
    card.querySelector(".nudge-done").addEventListener("click", () => { setDone(b, true); saveState(); renderAll(); });
    card.querySelector(".nudge-tomorrow").addEventListener("click", async () => {
      const gap = gapTomorrow(b) || findGapDay(b);
      if (!gap) { showToast(t("cdNoGap")); return; }
      if (await moveBoxToGapAsync(b, gap)) { saveState(); renderAll(); }
    });
    card.querySelector(".nudge-hide").addEventListener("click", () => {
      const h = (state.nudgeHidden = state.nudgeHidden || {});
      Object.keys(h).forEach(k => { if (h[k] && h[k] < TODAY) delete h[k]; });
      h[b.id] = TODAY;
      saveState(); renderAll();
    });
    wrap.appendChild(card);
  });
}

// ---- Day summary cards (v1.11.10) ----
// One summary card above the daily programme: «جزئیات امروز». (The
// «روز بعد» card became a small dashboard link in 1.11.36.)
// Values are COMPUTED AT RENDER TIME from the main programme data
// (allBoxes()) and stored nowhere — a sync, edit, add or delete changes
// them on the next render, and a restart recomputes the same values from
// the same data (no duplicate summary data in state, ever).
//
// Bucket rule (each box lands in exactly ONE bucket, no double-counting):
//   class   — boxActivityType(b) === "class" (shared 1.11.5 mapping:
//             explicit type "class" or title contains «کلاس», wins)
//   test    — boxActivityType(b) === "test" (is_test, not a class)
//   general — any other box whose subject is a general subject
//             (ادبیات / فارسی / عربی / دینی / زبان / زبان انگلیسی)
//   study   — everything else (homework/study/other of non-general subjects)
// Total = sum of ALL boxes' durations that day. Duration = minutesBetween
// (start, end) — end <= start means overnight (+24h). Box count = the real
// number of boxes that study day (deleted boxes are already excluded by
// allBoxes()). "Today"/"tomorrow" are STUDY days (03:30 Asia/Tehran
// boundary, boxStudyDay), so the cards match the dashboard day.
// v1.11.38 (P3-12): the general-subject set comes from the single
// SUBJECTS table in i18n.js (same set as before — ادبیات / فارسی /
// عربی / دینی / زبان / زبان انگلیسی), never a second hardcoded list.
const GENERAL_SUBJECTS = new Set(SUBJECTS.filter(r => r.type === "general").map(r => r.fa));
// v1.11.45 (F-04): actual/useful attributed by SESSION execution
// day (same pattern as analytics.js anDayActualUseful, BUG-023):
// timer-session seconds count on the study day the session STARTED
// (a catch-up session run today counts today, even on a past-dated
// box); the remainder of each of THIS day's boxes (manual entries +
// the live running timer, which has no session yet) stays on the box
// day. Undated (old) sessions fall back to their box's day. Box
// totals are unchanged — only the day attribution moves.
function dayActualUseful(iso) {
  let actualSec = 0, usefulSec = 0;
  const usefulBoxes = new Set();
  const sessByBox = {};
  (state.timerSessions || []).forEach(s => {
    if (!s || s.source !== "timer") return;
    const t = sessByBox[s.boxId] || (sessByBox[s.boxId] = { sec: 0, use: 0 });
    t.sec += (s.seconds || 0);
    t.use += (s.useful || 0);
    let sd = null;
    if (s.start) { const d = new Date(s.start); if (!isNaN(d.getTime())) sd = studyDayOf(d); }
    if (sd === null) {
      const b = allBoxes().find(x => x.id === s.boxId);
      sd = b ? (boxStudyDay(b) || b.date) : null;
    }
    if (sd === iso) {
      actualSec += (s.seconds || 0);
      if ((s.useful || 0) > 0) { usefulSec += s.useful; usefulBoxes.add(s.boxId); }
    }
  });
  allBoxes().forEach(b => {
    if ((boxStudyDay(b) || b.date) !== iso) return;
    const t = sessByBox[b.id] || { sec: 0, use: 0 };
    actualSec += Math.max(0, timerTotalSeconds(b.id) - t.sec);
    const remUseful = Math.max(0, usefulTotalSeconds(b.id) - t.use);
    usefulSec += remUseful;
    if (remUseful > 0) usefulBoxes.add(b.id);
  });
  return { actual: actualSec, useful: usefulSec, usefulBoxes: usefulBoxes.size };
}
function actualSecsOn(iso) { return dayActualUseful(iso).actual; }

function daySummary(iso) {
  const list = allBoxes().filter(b => boxStudyDay(b) === iso);
  let total = 0, cls = 0, test = 0, gen = 0, study = 0, doneMinutes = 0, doneBoxes = 0, actual = 0, usefulSecs = 0, usefulRecorded = false;
  for (const b of list) {
    const mins = minutesBetween(b.start || "00:00", b.end || "00:00");
    total += mins;
    const ty = boxActivityType(b);
    if (ty === "class") cls += mins;
    else if (ty === "test") test += mins;
    else if (GENERAL_SUBJECTS.has(b.subject)) gen += mins;
    else study += mins;
    // Today-progress (v1.11.13): done time is the PLANNED duration of
    // boxes actually ticked done (isDone) — never the timer actuals
    // (dashTodayActual). Each box counted once, in its single bucket
    // and at most once in doneMinutes.
    if (isDone(b)) { doneMinutes += mins; doneBoxes += 1; }
    // Real/useful time (v1.11.45 F-04): attributed by session
    // execution day, not box day — see dayActualUseful above. The
    // per-box loop still counts planned/done minutes only.
  }
  const au = dayActualUseful(iso);
  actual = au.actual; usefulSecs = au.useful; usefulRecorded = au.usefulBoxes > 0;
  return { boxes: list.length, total, cls, test, gen, study, doneMinutes, doneBoxes,
           actual: Math.round(actual / 60),
           useful: Math.round(usefulSecs / 60), usefulRecorded,
           efficiency: efficiencyPct(usefulSecs, actual) };
}
// Readable duration with Persian digits in fa (fmtDuration uses Latin
// digits); English reuses the existing "5h 30m" helper.
function sumDur(mins) {
  mins = Math.round(mins || 0);
  if (LANG === "en") return fmtDurationEn(mins);
  const h = Math.floor(mins / 60), m = mins % 60;
  if (h === 0) return FA(m) + " دقیقه";
  if (m === 0) return FA(h) + " ساعت";
  return FA(h) + " ساعت و " + FA(m) + " دقیقه";
}
function daySumCardHtml(iso, titleKey, withCalLink, withProgress) {
  const s = daySummary(iso);
  const dateLbl = weekdayFa(iso) + " " + gregToJalali(iso).text;
  const row = (labelKey, val) => '<div class="day-sum-row"><span>' + t(labelKey) + '</span><b>' + val + '</b></div>';
  let html = '<div class="day-sum-card"><div class="day-sum-title">' + t(titleKey) + ' · ' + esc(dateLbl) + '</div>';
  if (s.boxes === 0) {
    html += '<p class="muted day-sum-empty">' + t("sumNoProgram") + '</p>';
  } else {
    // v1.11.21: real / useful / efficiency travel together — wherever
    // real time is shown, useful sits next to it. An unrecorded useful
    // reads «ثبت نشده», never 0; no efficiency without both values.
    // (v1.11.37, P3-3: these rows are used only by the !withProgress
    // branch now — the TODAY card shows them in the hero instead.)
    const timeRows =
      row("sumRealTime", s.actual > 0 ? sumDur(s.actual) : "—") +
      row("sumUsefulTime", s.usefulRecorded ? sumDur(s.useful) : t("tmUsefulNotRecorded")) +
      row("sumEfficiency", s.efficiency == null ? "—" : FA_PCT(s.efficiency));
    // v1.11.37 (P3-3): the TODAY card keeps only the buckets + the Pvu
    // triple bar. The progress / real / useful / remaining / boxes
    // rows used to repeat the hero's four numbers a second time
    // ("one number, one place") — they now live only in the hero
    // (renderHeroProgress + the dash-mini lines above it). The
    // !withProgress branch below is unchanged (other callers, if any,
    // still get the full rows); the only caller passes true.
    html += '<div class="day-sum-rows">' +
      row("sumTotal", sumDur(s.total)) +
      (withProgress ? "" : timeRows) +
      row("sumClass", sumDur(s.cls)) +
      row("sumGeneral", sumDur(s.gen)) +
      row("sumTest", sumDur(s.test)) +
      row("sumStudy", sumDur(s.study)) +
      (withProgress ? "" : row("sumBoxes", FA(s.boxes))) +
      '</div>';
    if (withProgress) {
      // v1.11.63 (Batch 4, dashboard declutter): the hero keeps the
      // live day numbers — the Pvu triple bar that repeated them is
      // gone. The card is per-subject details now: planned minutes,
      // done/total boxes and tests per subject.
      const list = allBoxes().filter(b => boxStudyDay(b) === iso && isCurrentBox(b));
      const bySubj = {};
      list.forEach(b => {
        const k = b.subject || "—";
        const e = bySubj[k] || (bySubj[k] = { planned: 0, done: 0, total: 0, tests: 0, correct: 0 });
        e.planned += minutesBetween(b.start || "00:00", b.end || "00:00");
        e.total += 1;
        if (isDone(b)) e.done += 1;
        const tr = testOf(b);
        e.tests += (tr.completed || 0);
        e.correct += (tr.correct || 0);
      });
      const keys = Object.keys(bySubj).sort((a, b) => bySubj[b].planned - bySubj[a].planned);
      html += '<div class="day-sum-rows day-subj-rows">' +
        '<div class="day-sum-row day-subj-head"><span>' + t("daySubjTitle") + '</span></div>' +
        keys.map(k => {
          const e = bySubj[k];
          return '<div class="day-sum-row day-subj-row"><span>' + esc(subjName(k)) + '</span><b>' +
            sumDur(e.planned) + ' · ' + FA(e.done) + "/" + FA(e.total) + ' · ' +
            t("boxTestsSummary", { done: FA(e.tests), correct: FA(e.correct) }) + '</b></div>';
        }).join("") +
        '</div>';
    }
  }
  if (withCalLink) html += '<button class="btn day-sum-cal" data-tomorrow="' + esc(iso) + '">' + t("sumViewCal") + '</button>';
  return html + '</div>';
}
function renderDaySummary() {
  const el = document.getElementById("daySummaryCards");
  if (!el) return;
  // v1.11.36: the TODAY card only. The tomorrow card became a small
  // link on the dashboard («فردا → مشاهده برنامه»); its full detail
  // lives in Programme/Calendar. The card itself is unchanged
  // (daySumCardHtml with progress + the Pvu triple bar).
  el.innerHTML = daySumCardHtml(TODAY, "sumToday", false, true);
}
// ---- Hero progress bar (audit §5 item 2.2) ----
// THE single definition of "progress": % of TODAY's PLANNED time that
// is ticked done (planned minutes of done boxes ÷ total planned
// minutes, from daySummary). The three values are labelled so they can
// never be misread as each other: progress %, real (timer) minutes,
// remaining planned minutes. Other numbers keep their own labels
// ("boxes done", "tests solved") and never borrow the word "progress".
// v1.11.48 (I-1): minutes of undone boxes that can still be done
// today — for each undone box, the part of it that lies in the future
// (end after nowMin, in study-day minutes). A box that already ended
// contributes 0, a box in progress contributes only its remaining part,
// a future box its full duration. Pure (nowMin is injectable) so the
// verify suite can drive it with synthetic times.
function remainingDoableMinutes(iso, nowMin) {
  let n = 0;
  allBoxes().filter(b => boxStudyDay(b) === iso && !isDone(b)).forEach(b => {
    const s0 = studyDayMinutes(b.start || "00:00");
    const s1 = s0 + minutesBetween(b.start || "00:00", b.end || "00:00");
    if (s1 > nowMin) n += s1 - Math.max(s0, nowMin);
  });
  return n;
}
// v1.11.48 (I-1): «باقی‌مانده» is two honest numbers — the total
// remaining from the programme, and the part still doable before the
// day's last box ends. Once nothing is doable any more, the day is
// over: «روز تمام شد» instead of a number that pretends work is left.
function heroRemainingText(s) {
  if (!s.boxes) return "—";
  const doable = remainingDoableMinutes(TODAY, nowBoxInfo().nowMin);
  if (doable <= 0) return t("heroDayDone");
  return sumDur(s.total - s.doneMinutes) + " · " + t("heroDoable", { d: sumDur(doable) });
}
function renderHeroProgress() {
  const wrap = document.getElementById("dashHeroProgress");
  if (!wrap) return;
  const s = daySummary(TODAY);
  const pct = s.total ? Math.round(s.doneMinutes / s.total * 100) : 0;
  // v1.11.30 (P1-4): two honest numbers, not one. The MAIN bar is the
  // TIME progress (real timer minutes ÷ planned minutes); the bar
  // below it is the TICK progress (planned minutes of ticked boxes ÷
  // total planned). A 0% tick bar next to 3.5 recorded hours no longer
  // contradicts itself — both numbers are shown, labelled.
  const timePct = s.total ? Math.round(s.actual / s.total * 100) : 0;
  const fill = document.getElementById("heroProgressFill");
  if (fill) fill.style.width = pct + "%";
  const tfill = document.getElementById("heroTimeFill");
  if (tfill) tfill.style.width = Math.min(100, timePct) + "%";
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  set("heroTimePct", s.boxes ? FA_PCT(timePct) : t("sumNoProgram"));
  set("heroProgressPct", s.boxes ? FA_PCT(pct) + " · " + t("heroTickBoxes", { d: FA(s.doneBoxes), t: FA(s.boxes) }) : t("sumNoProgram"));
  // heroProgressVal keeps its exact old format (verify1118 pins "۰٪"
  // fresh and "۱۰۰٪" fully done) — the boxes detail lives in the
  // bar head (heroProgressPct), which no suite asserts.
  set("heroProgressVal", s.boxes ? FA_PCT(pct) : "—");
  set("heroActualVal", s.actual > 0 ? sumDur(s.actual) : "—");
  // v1.11.21: useful sits next to real in the hero too — "—" when
  // nothing recorded yet (an unrecorded useful is never shown as 0).
  set("heroUsefulVal", s.usefulRecorded ? sumDur(s.useful) : "—");
  set("heroRemainingVal", heroRemainingText(s));
}
// ---------- Daily goal + streak (v1.11.38, P3-9) ----------
// The goal is the user's own target, shown on the «امروز» tab —
// display-only: it never changes the programme and never blocks a
// box. Streak = consecutive study days the goal was met, counted back
// from today (if today is not met yet, from yesterday), from real
// data only: dated ticks (P1-1) for boxes, useful seconds per box
// for useful time. A legacy dateless tick counts for nothing — it is
// "unknown", never "today".
const DEFAULT_DAILY_GOAL = { kind: "useful", minutes: 480 };
function dailyGoalOf() {
  const g = state.dailyGoal || {};
  if (g.kind === "boxes") return { kind: "boxes", count: Math.max(0, parseInt(g.count, 10) || 0) };
  return { kind: "useful", minutes: Math.max(0, parseInt(g.minutes, 10) || 0) };
}
function goalTargetOf() {
  const g = dailyGoalOf();
  return g.kind === "boxes" ? g.count : g.minutes;
}
// Boxes ticked on a study day (dated ticks only — legacy `true` ticks
// have no date and never count toward any day).
function doneBoxesOn(iso) {
  let n = 0;
  Object.keys(state.done || {}).forEach(id => {
    const v = state.done[id];
    if (v && typeof v === "object" && v.d === iso) n += 1;
  });
  return n;
}
function usefulSecsOn(iso) {
  // v1.11.45 (F-04): session execution day, not box day — a catch-up
  // session run today counts toward today's goal, not the past day.
  return dayActualUseful(iso).useful;
}
// Today's progress toward the goal: {kind, done, target, pct, met}.
// done is useful MINUTES for a useful goal, box count for a boxes goal.
function todayGoalProgress() {
  const g = dailyGoalOf();
  const target = goalTargetOf();
  const done = g.kind === "boxes" ? doneBoxesOn(TODAY) : Math.floor(usefulSecsOn(TODAY) / 60);
  return { kind: g.kind, done, target, pct: target > 0 ? Math.min(100, Math.round(done / target * 100)) : 0, met: target > 0 && done >= target };
}
function goalMetOn(iso) {
  const g = dailyGoalOf();
  const target = goalTargetOf();
  if (target <= 0) return false;
  return g.kind === "boxes" ? doneBoxesOn(iso) >= target : usefulSecsOn(iso) >= target * 60;
}
function goalStreak() {
  let n = 0;
  let day = TODAY;
  // Today not met yet: the streak runs through yesterday.
  if (!goalMetOn(day)) day = addDays(day, -1);
  while (goalMetOn(day)) { n += 1; day = addDays(day, -1); }
  return n;
}
function renderDailyGoal() {
  const el = document.getElementById("dailyGoalCard");
  if (!el) return;
  const g = dailyGoalOf();
  const target = goalTargetOf();
  const p = todayGoalProgress();
  const streak = goalStreak();
  let html = '<h3>' + esc(t("goalTitle")) + '</h3>';
  if (target <= 0) {
    html += '<p class="muted">' + esc(t("goalUnset")) + '</p>';
  } else {
    const doneTxt = g.kind === "boxes" ? FA(p.done) : fmtDurationFa(p.done);
    const targetTxt = g.kind === "boxes" ? FA(target) : fmtDurationFa(target);
    html += '<div class="goal-line"><span>' + esc(t("goalDoneOf", { d: doneTxt, t: targetTxt })) + '</span>' +
      (p.met ? '<span class="goal-met">' + esc(t("goalMet")) + '</span>' : '') + '</div>' +
      '<div class="progress goal-bar"><div style="width:' + p.pct + '%"></div></div>' +
      '<p class="muted">' + esc(streak > 0 ? t("goalStreak", { n: FA(streak) }) : t("goalStreakNone")) + '</p>';
  }
  html += '<button type="button" class="btn goal-set-btn">' + esc(t("goalSet")) + '</button>' +
    '<div class="goal-form" hidden>' +
      '<label>' + esc(t("goalKindUseful")) + ' <input type="radio" name="goalKind" value="useful"' + (g.kind === "useful" ? " checked" : "") + '></label>' +
      '<label>' + esc(t("goalKindBoxes")) + ' <input type="radio" name="goalKind" value="boxes"' + (g.kind === "boxes" ? " checked" : "") + '></label>' +
      '<label><input type="number" min="0" class="goal-val" value="' + target + '"></label>' +
      '<button type="button" class="btn btn-primary goal-save-btn">' + esc(t("goalSave")) + '</button>' +
    '</div>';
  el.innerHTML = html;
  el.querySelector(".goal-set-btn").addEventListener("click", () => {
    el.querySelector(".goal-form").hidden = !el.querySelector(".goal-form").hidden;
  });
  el.querySelector(".goal-save-btn").addEventListener("click", () => {
    const kind = el.querySelector('input[name="goalKind"]:checked').value;
    const val = Math.max(0, parseInt(el.querySelector(".goal-val").value, 10) || 0);
    state.dailyGoal = kind === "boxes" ? { kind: "boxes", count: val } : { kind: "useful", minutes: val };
    saveState(); renderAll();
  });
}

// ---- "Now and next" sticky bar (v1.11.30, P1-5) ----
// NOTE on isCurrentBox(): it deliberately stays a no-op (always true)
// — it is a LIST filter used by the dashboard, calendar and analytics
// views, and giving it real time logic would silently hide boxes from
// those views. "Now" lives here instead: nowBoxInfo() reads the real
// Tehran clock (tehranParts, same helper as studyDayOf) and compares
// it with today's boxes in study-day minutes.
function nowBoxInfo(now) {
  const p = tehranParts(now || new Date());
  const nowMin = studyDayMinutes(String(p.hh).padStart(2, "0") + ":" + String(p.mm).padStart(2, "0"));
  const today = allBoxes().filter(b => boxStudyDay(b) === TODAY).slice().sort(compareBoxOrder);
  let cur = null, curEnd = null, next = null;
  for (const b of today) {
    const s0 = studyDayMinutes(b.start || "00:00");
    const s1 = s0 + minutesBetween(b.start || "00:00", b.end || "00:00");
    if (nowMin >= s0 && nowMin < s1) { cur = b; curEnd = s1; }
    else if (!next && nowMin < s0) next = b;
  }
  // No box left today: the next box is tomorrow's first (labelled so).
  let nextTomorrow = false;
  if (!next) {
    const tmr = allBoxes().filter(b => boxStudyDay(b) === addDays(TODAY, 1)).slice().sort(compareBoxOrder);
    if (tmr.length) { next = tmr[0]; nextTomorrow = true; }
  }
  return { cur, curLeft: cur ? (curEnd - nowMin) : null, next, nextTomorrow, nowMin };
}
// ---------- Gentle next-box reminder (v1.11.48, P-4) ----------
// While the app is open, 10 minutes before the next box starts the
// user gets one silent toast («شیمی — تست فصل ۱، ۱۰ دقیقه دیگر»)
// with a «شروع تایمر» action; clicking the toast itself jumps to
// Today + that box. Once per box per day (state.nextBoxReminded);
// never for done or backlog-hidden boxes, never when a timer already
// runs for that box, never for tomorrow's first box. Default ON —
// the toggle lives in Settings (state.nextBoxRemind, absent = on).
function checkNextBoxReminder(now) {
  // v1.11.65 (Batch 6, L-PERF5): a reminder the user never saw must
  // not be marked as seen — while the tab is hidden, do nothing (the
  // 60 s tick is stopped then too; this guard covers any other caller).
  if (document.hidden) return;
  if (state.nextBoxRemind === false) return;
  const info = nowBoxInfo(now);
  if (info.nextTomorrow || !info.next) return;
  const next = info.next;
  if (isDone(next) || (state.backlogHidden || {})[next.id]) return;
  const at = state.activeTimer;
  if (at && at.boxId === next.id) return;
  const startMin = studyDayMinutes(next.start || "00:00");
  const gap = startMin - info.nowMin;
  // v1.11.63 (Batch 4, م-۷): a live class gets a 15-minute window
  // (not 10) with its own text — «کلاس زنده شروع می‌شود».
  const isClass = boxIsClass(next);
  if (!(gap > 0 && gap <= (isClass ? 15 : 10))) return;
  const reminded = state.nextBoxReminded || (state.nextBoxReminded = {});
  if (reminded[next.id] === TODAY) return;
  // Prune entries older than today, so a box reminded yesterday may
  // fire again today — the map holds only one day's worth.
  Object.keys(reminded).forEach(k => { if (reminded[k] !== TODAY) delete reminded[k]; });
  reminded[next.id] = TODAY;
  saveState();
  const jump = () => {
    navigate({ tab: "today" });
    setTimeout(() => {
      const el = document.querySelector('#todayBoxes [data-box-id="' + next.id + '"]') ||
        document.querySelector('#calDayBoxes [data-box-id="' + next.id + '"]');
      if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 150);
  };
  showToast(isClass
    ? t("nbLiveClassToast", { s: subjName(next.subject) + " — " + (next.title || ""), t: fmtTimeFa(next.start) })
    : t("nbReminderToast", { s: subjName(next.subject) + " — " + (next.title || ""), t: fmtTimeFa(next.start) }), {
    ms: 8000,
    action: { label: t("tmStart"), fn: () => { jump(); timerStart(next.id); } },
    onClick: jump
  });
}
// ---------- Phone-away sleep reminder (v1.11.62, Batch 3, ب-۵) ----------
// Tonight's sleep time is set in «بستن روز» («ساعت خواب امشب»); while
// the app is open, one toast («گوشی رو بذار کنار») fires at that time.
// Same once-per-study-day pattern as the next-box reminder (P-4) and
// the exam-night 22:00 reminder — but on its own 30 s interval, not
// inside updateTimerDisplays (which returns early with no timer
// running, exactly when the night reminder matters most). The user
// declined a FIXED 23:30 reminder (16 Nov) — this one fires at the
// time HE chose tonight, and only while the app is open.
function checkSleepReminder() {
  // v1.11.72 (Batch 5, L17): the same hidden-tab guard L-PERF5 added
  // to checkNextBoxReminder — a reminder the user never saw must not
  // be marked as seen (sleepReminded[TODAY] stays unset while hidden).
  if (document.hidden) return;
  const log = (state.sleepLog || {})[TODAY];
  if (!log || !log.sleep) return;
  const p = tehranParts(new Date());
  const nowMin = studyDayMinutes(String(p.hh).padStart(2, "0") + ":" + String(p.mm).padStart(2, "0"));
  const sleepMin = studyDayMinutes(log.sleep);
  if (nowMin < sleepMin || nowMin - sleepMin > 30) return;
  const rem = state.sleepReminded || (state.sleepReminded = {});
  Object.keys(rem).forEach(k => { if (k !== TODAY) delete rem[k]; });
  if (rem[TODAY]) return;
  rem[TODAY] = true;
  saveState();
  showToast(t("sleepRemindToast"), { ms: 8000 });
}
setInterval(checkSleepReminder, 30000);
function renderNowNext() {
  const el = document.getElementById("dashNowNext");
  if (!el) return;
  const info = nowBoxInfo();
  if (!info.cur && !info.next) { el.hidden = true; el.innerHTML = ""; return; }
  el.hidden = false;
  let html = '<div class="nn-row">';
  if (info.cur) {
    html += '<span class="nn-now"><b>' + esc(t("nnNow")) + '</b> ' + esc(info.cur.title) +
      (isDone(info.cur) ? " ✓" : "") +
      ' · <span class="nn-min">' + esc(t("nnMinLeft", { n: FA(info.curLeft) })) + '</span></span>' +
      '<button type="button" class="btn btn-primary nn-timer" data-nn-timer="' + esc(info.cur.id) + '">' +
      esc(t("nnStartTimer")) + '</button>';
  } else {
    html += '<span class="nn-now muted">' + esc(t("nnGap")) + '</span>';
  }
  if (info.next) {
    html += '<span class="nn-next"><b>' + esc(t("nnNext")) + '</b> ' + esc(info.next.title) + ' · ' +
      fmtTimeFa(info.next.start) + (info.nextTomorrow ? ' · ' + esc(t("nnTomorrow")) : '') + '</span>';
  }
  html += '</div>';
  el.innerHTML = html;
  const btn = el.querySelector("[data-nn-timer]");
  if (btn) btn.addEventListener("click", () => timerStart(btn.getAttribute("data-nn-timer")));
}

// ---------- Sticky mini-hero (v1.11.43, §17 idea 1) ----------
// «امروز ۴ آذر · ۲ از ۶ انجام شده · باقی‌مانده ۴:۱۵ · بعد: شیمی ۱۴:۰۰»
// — the same numbers as the hero, in one line. The bar is filled on
// every renderToday; it only SHOWS once the hero has scrolled out of
// view (IntersectionObserver on .dash-hero, scroll fallback for old
// engines). Click scrolls back to the hero.
function miniHeroText() {
  const s = daySummary(TODAY);
  const info = nowBoxInfo();
  const date = gregToJalali(TODAY).text;
  // v1.11.48 (I-1): the same two honest numbers as the hero.
  const doable = remainingDoableMinutes(TODAY, info.nowMin);
  const rem = !s.boxes ? "—" : doable <= 0 ? t("heroDayDone")
    : fmtDurShort(s.total - s.doneMinutes) + " · " + t("heroDoable", { d: fmtDurShort(doable) });
  if (!info.next) return t("miniHeroNoNext", { date, done: FA(s.doneBoxes), total: FA(s.boxes), rem });
  let next = subjName(info.next.subject) + " " + fmtTimeFa(info.next.start);
  if (info.nextTomorrow) next += " (" + t("nnTomorrow") + ")";
  return t("miniHero", { date, done: FA(s.doneBoxes), total: FA(s.boxes), rem, next });
}
function renderMiniHero() {
  const el = document.getElementById("miniHero");
  if (!el) return;
  el.textContent = miniHeroText();
  updateMiniHeroVisibility();
}
function updateMiniHeroVisibility() {
  const el = document.getElementById("miniHero");
  const hero = document.querySelector("#tab-today .dash-hero");
  if (!el || !hero) return;
  el.hidden = !(hero.getBoundingClientRect().bottom < 0);
}
function wireMiniHero() {
  const el = document.getElementById("miniHero");
  if (!el) return;
  el.addEventListener("click", () => {
    const hero = document.querySelector("#tab-today .dash-hero");
    if (hero) hero.scrollIntoView({ behavior: "smooth", block: "start" });
  });
  if (typeof IntersectionObserver !== "undefined") {
    const hero = document.querySelector("#tab-today .dash-hero");
    if (hero) {
      new IntersectionObserver(entries => {
        entries.forEach(en => { el.hidden = en.isIntersecting; });
      }, { threshold: 0 }).observe(hero);
      return;
    }
  }
  document.addEventListener("scroll", updateMiniHeroVisibility, { passive: true });
}

// ---------- «تمرکز امروز» fullscreen focus mode (v1.11.35, P3-1) ----------
// Only the current box + timer + test counter + Next, no navigation
// or charts. Transient only (focusBoxId), never persisted. The live
// clock reuses the existing [data-tm-live] 1-second updater, and the
// timer buttons reuse timerStart/timerPause/timerResume/timerStop —
// each of those calls renderAll(), and the overlay re-renders itself
// after them because renderAll() never touches #focusInner.
let focusBoxId = null;
let focusAsg = false; // v1.11.43 (§17 idea 9): focus is on one test
// assignment (not today's list) — Next is hidden, the counter shows
// the assignment's numbers, «پایان» returns to the assignments tab.
function focusBoxList() {
  return allBoxes().filter(b => boxStudyDay(b) === TODAY && isCurrentBox(b)).slice().sort(compareBoxOrder);
}
let FOCUS_OPENER = null; // v1.11.45 (U-07): focus returns here on close
function openFocus() {
  FOCUS_OPENER = document.activeElement;
  focusAsg = false;
  const list = focusBoxList();
  const info = nowBoxInfo();
  focusBoxId = (info.cur && info.cur.id) || (list.length ? list[0].id : null);
  document.getElementById("focusOverlay").hidden = false;
  document.body.classList.add("focus-mode");
  renderFocus();
}
// v1.11.43 (§17 idea 9): focus on one test assignment — the box need
// not be in today's list, so renderFocus falls back to allBoxes().
function openFocusForAssignment(boxId) {
  FOCUS_OPENER = document.activeElement;
  focusAsg = true;
  focusBoxId = boxId;
  document.getElementById("focusOverlay").hidden = false;
  document.body.classList.add("focus-mode");
  renderFocus();
}
function closeFocus() {
  focusBoxId = null;
  focusAsg = false;
  document.getElementById("focusOverlay").hidden = true;
  document.body.classList.remove("focus-mode");
  renderAll();
  // v1.11.45 (U-07): return focus to the element that opened focus mode.
  if (FOCUS_OPENER && document.contains(FOCUS_OPENER)) FOCUS_OPENER.focus();
  FOCUS_OPENER = null;
}
function focusNext() {
  const list = focusBoxList();
  const i = list.findIndex(b => b.id === focusBoxId);
  const next = list.slice(i + 1).find(b => !isDone(b)) || null;
  focusBoxId = next ? next.id : null;
  renderFocus();
}
function renderFocus() {
  const inner = document.getElementById("focusInner");
  const ov = document.getElementById("focusOverlay");
  if (!inner || !ov || ov.hidden) return;
  const list = focusBoxList();
  // v1.11.43 (§17 idea 9): in assignment mode the box is looked up
  // in the whole programme, not in today's list.
  const b = (focusAsg ? allBoxes().find(x => x.id === focusBoxId) : list.find(x => x.id === focusBoxId)) || null;
  if (!b) {
    inner.innerHTML = '<h2>' + esc(t("focusTitle")) + '</h2>' +
      '<p class="muted">' + esc(t("focusNoBox")) + '</p>' +
      '<div class="focus-actions"><button class="btn focus-exit">' + esc(t("focusExit")) + '</button></div>';
    inner.querySelector(".focus-exit").addEventListener("click", closeFocus);
    return;
  }
  const tr = testOf(b);
  const acc = accuracy(b);
  // v1.11.45 (E-19, same as testBoxReady): a study box whose title
  // happens to contain a test count ("مرور ۳۰ تست …") is NOT a test box
  // — its tests_total is only inferred from the title, so the
  // focus-counts display must not treat it as one.
  const isTestBox = !!(b.is_test || boxActivityType(b) === "test" || (tr.completed || 0) > 0);
  const timer = state.activeTimer && state.activeTimer.boxId === b.id ? state.activeTimer : null;
  inner.innerHTML =
    '<h2>' + esc(t("focusTitle")) + '</h2>' +
    '<div class="focus-box-title">' + esc(b.title) + '</div>' +
    '<div class="focus-box-meta">' + fmtTimeFa(b.start) + ' – ' + fmtTimeFa(b.end) + ' · ' + esc(subjName(b.subject)) + '</div>' +
    '<div class="focus-clock">' +
      (timer ? '<span data-tm-live="' + esc(b.id) + '">' + fmtClock(timerLiveSecondsForBox(b.id)) + '</span>'
             : fmtClock(timerTotalSeconds(b.id))) + '</div>' +
    (isTestBox ? '<div class="focus-counts">' + (focusAsg
        ? esc(t("asgFocusCount", { done: FA(tr.completed || 0), total: FA(b.tests_total || 0), correct: FA(tr.correct || 0) }))
        : FA(tr.completed || 0) + ' / ' + FA(b.tests_total || 0) + ' · ' + t("correctLbl") + ' ' + FA(tr.correct || 0)) +
      (acc == null ? '' : ' · ' + FA_PCT(acc)) + '</div>' +
      '<div class="focus-tests-row">' +
        (focusAsg
          // v1.11.43 (§17 idea 9): «+ درست» / «+ غلط» steppers — the
          // numbers save live to the assignment via saveBoxTests.
          // Disabled once the total is reached (when a total exists).
          ? '<button class="btn asg-correct"' + (((b.tests_total || 0) > 0 && tr.completed >= (b.tests_total || 0)) ? " disabled" : "") + '>' + esc(t("asgFocusCorrect")) + '</button>' +
            '<button class="btn asg-wrong"' + (((b.tests_total || 0) > 0 && tr.completed >= (b.tests_total || 0)) ? " disabled" : "") + '>' + esc(t("asgFocusWrong")) + '</button>'
          : '<label>' + t("completedLbl") + ' <input type="number" min="0" class="t-completed" value="' + tr.completed + '"></label>' +
            '<label>' + t("correctLbl") + ' <input type="number" min="0" class="t-correct" value="' + tr.correct + '"></label>' +
            '<label>' + t("totalTestsInput") + ' <input type="number" min="0" class="t-total" value="' + (b.tests_total || 0) + '"></label>' +
            '<button class="btn t-save">' + t("saveBtn") + '</button>') +
      '</div>' : '') +
    '<div class="focus-actions">' +
      (timer
        ? (timer.status === "running"
          ? '<button class="btn focus-pause">' + t("tmPause") + '</button>'
          : '<button class="btn focus-resume">' + t("tmResume") + '</button>') +
          '<button class="btn focus-stop">' + t("tmStop") + '</button>'
        : '<button class="btn btn-primary focus-start">' + t("tmStart") + '</button>') +
      '<button class="btn focus-done">' + (isDone(b) ? "✓ " : "") + esc(t("focusDone")) + '</button>' +
      (focusAsg ? '' : '<button class="btn focus-next">' + esc(t("focusNext")) + '</button>') +
      (focusAsg ? '<button class="btn focus-finish">' + esc(t("asgFocusFinish")) + '</button>' : '') +
      '<button class="btn focus-exit">' + esc(t("focusExit")) + '</button>' +
    '</div>';
  const q = (s) => inner.querySelector(s);
  const st = q(".focus-start"); if (st) st.addEventListener("click", () => { timerStart(b.id); renderFocus(); });
  const pa = q(".focus-pause"); if (pa) pa.addEventListener("click", () => { timerPause(); renderFocus(); });
  const rs = q(".focus-resume"); if (rs) rs.addEventListener("click", () => { timerResume(); renderFocus(); });
  const sp = q(".focus-stop"); if (sp) sp.addEventListener("click", () => { timerStop(); renderFocus(); });
  q(".focus-done").addEventListener("click", () => { setDone(b, !isDone(b)); saveState(); renderFocus(); });
  // v1.11.43 (§17 idea 9): no Next button in assignment mode — the
  // wiring must not assume it exists (an unconditional call here threw
  // and skipped the steppers + finish wiring below).
  const nx = q(".focus-next");
  if (nx) nx.addEventListener("click", focusNext);
  q(".focus-exit").addEventListener("click", closeFocus);
  const sv = q(".t-save");
  if (sv) sv.addEventListener("click", () => {
    saveBoxTests(b, q(".t-completed").value, q(".t-correct").value, q(".t-total").value);
    renderFocus();
  });
  const ac = q(".asg-correct");
  if (ac) ac.addEventListener("click", () => {
    if ((b.tests_total || 0) > 0 && tr.completed >= (b.tests_total || 0)) return;
    saveBoxTests(b, tr.completed + 1, tr.correct + 1, b.tests_total);
    renderFocus();
  });
  const aw = q(".asg-wrong");
  if (aw) aw.addEventListener("click", () => {
    if ((b.tests_total || 0) > 0 && tr.completed >= (b.tests_total || 0)) return;
    saveBoxTests(b, tr.completed + 1, tr.correct, b.tests_total);
    renderFocus();
  });
  const ff = q(".focus-finish");
  if (ff) ff.addEventListener("click", () => { closeFocus(); navigate({ tab: "assignments" }); });
}
// v1.11.55 (UX-6): G-prefix navigation state (see the keydown handler).
let gNavArmedAt = 0;
let gNavTimer = null;
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    const ov = document.getElementById("focusOverlay");
    if (ov && !ov.hidden) { closeFocus(); return; }
    // v1.11.48 (I-4): Esc on the exam simulation opens the EXISTING
    // exit confirm — never a silent exit.
    const simOv = document.getElementById("simOverlay");
    if (sim && simOv && !simOv.hidden) { exitSim(); return; }
    // v1.11.52 (P-5): Esc closes the stage-report overlay.
    const srOv = document.getElementById("stageReportOverlay");
    if (srOv && !srOv.hidden) { closeStageReport(); return; }
    // v1.11.41 (UI-audit batch 1): Esc closes any open modal, the
    // same as its ✕ button (modals previously ignored Esc entirely).
    if (closeOpenModal()) return;
  }
  // v1.11.55 (UX-6): G-prefix navigation — press g (same guards as
  // P-7: not typing, no modifier, no modal/overlay/Cmdk) to arm a 2 s
  // window; the next T/D/P/E/A/B/G/S jumps to today/dashboard/program/
  // exams/analytics/remaining, the Gemini section inside Analytics (G)
  // or Settings (S). Any other single-character key disarms
  // (a second g does NOT re-arm); Tab/arrows are never consumed, so
  // keyboard navigation keeps working while armed. The toast confirms
  // the arming — the window itself is invisible. This block runs
  // BEFORE P-7 below, so an armed G consumes the next key instead of
  // ticking the box (T) or starting the timer (Space).
  if (!e.ctrlKey && !e.metaKey && !e.altKey) {
    const gTag = (document.activeElement && document.activeElement.tagName) || "";
    const gTyping = ["INPUT", "TEXTAREA", "SELECT", "BUTTON"].includes(gTag) ||
      (document.activeElement && document.activeElement.isContentEditable);
    const gBlocked = gTyping || openModalBack() || document.querySelector(".focus-overlay:not([hidden])") || CMDK_OPEN;
    if (!gBlocked) {
      if (gNavArmedAt && e.key && e.key.length === 1) {
        // v1.11.57 (IA): G and S carry a scroll target — the Gemini
        // section inside Analytics and the Settings tab itself.
        const dest = { t: { tab: "today" }, d: { tab: "dashboard" }, p: { tab: "program" },
          e: { tab: "exams" }, a: { tab: "analytics" }, b: { tab: "remaining" },
          g: { tab: "analytics", scroll: { type: "section", id: "anGeminiTitle" } },
          s: { tab: "settings" } }[(e.key || "").toLowerCase()];
        clearTimeout(gNavTimer); gNavTimer = null; gNavArmedAt = 0;
        if (dest) { e.preventDefault(); navigate(dest); }
        return;
      }
      if ((e.key === "g" || e.key === "G") && !gNavArmedAt) {
        gNavArmedAt = Date.now();
        showToast(t("scGoHint"));
        gNavTimer = setTimeout(() => { gNavArmedAt = 0; gNavTimer = null; }, 2000);
      }
    }
  }
  // v1.11.48 (P-7): «؟» / «?» opens the shortcuts guide; T ticks the
  // current box; Space starts/stops its timer. All three skip when
  // the user is typing, holding a modifier, or any modal / overlay is
  // open — a focused button + Space must click the button, not start
  // a timer.
  if (!e.ctrlKey && !e.metaKey && !e.altKey &&
      (e.key === "؟" || e.key === "?" || e.key === "t" || e.key === "T" || e.key === " ")) {
    const tag = (document.activeElement && document.activeElement.tagName) || "";
    const typing = ["INPUT", "TEXTAREA", "SELECT", "BUTTON"].includes(tag) ||
      (document.activeElement && document.activeElement.isContentEditable);
    if (!typing && !openModalBack() && !document.querySelector(".focus-overlay:not([hidden])") && !CMDK_OPEN) {
      if (e.key === "؟" || e.key === "?") openShortcutsModal();
      else if (e.key === "t" || e.key === "T") {
        const cur = nowBoxInfo().cur;
        if (cur) { setDone(cur, !isDone(cur)); saveState(); renderAll(); }
      } else if (e.key === " ") {
        const info = nowBoxInfo();
        const box = info.cur || info.next;
        if (box) {
          e.preventDefault();
          if (state.activeTimer) timerStop();
          else timerStart(box.id);
        }
      }
    }
  }
  if (e.key === "Tab") {
    // v1.11.52 (U5): the Ctrl+K palette is a dialog too — trap Tab
    // inside it exactly like the modals.
    if (CMDK_OPEN) {
      const box = document.querySelector(".cmdk");
      if (box) {
        const cf = modalFocusable(box);
        if (!cf.length) { e.preventDefault(); box.focus(); return; }
        if (!box.contains(document.activeElement)) { e.preventDefault(); cf[0].focus(); return; }
        const cfirst = cf[0], clast = cf[cf.length - 1];
        if (e.shiftKey && document.activeElement === cfirst) { e.preventDefault(); clast.focus(); }
        else if (!e.shiftKey && document.activeElement === clast) { e.preventDefault(); cfirst.focus(); }
        return;
      }
    }
    // v1.11.41: trap Tab inside the open modal — a keyboard user must
    // never Tab out to the page behind the modal.
    const back = openModalBack();
    if (!back) return;
    const modal = back.querySelector(".modal");
    if (!modal) return;
    const f = modalFocusable(modal);
    if (!f.length) { e.preventDefault(); modal.focus(); return; }
    if (!modal.contains(document.activeElement)) { e.preventDefault(); f[0].focus(); return; }
    const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }
});

// ---------- Modal keyboard accessibility (v1.11.41, UI-audit batch 1) ----------
// Focus goes into the modal on open and returns to the opener on close.
// A MutationObserver on the six .modal-back elements covers EVERY open
// path (direct opens, history-driven showModalUI, backdrop clicks), so
// no close path can leak focus.
let modalReturnFocus = null;
// v1.11.52 (U3): how to find the opener again after a re-render
// detaches it — the nearest [data-box-id] ancestor (the box) + the
// opener's most specific class (or its id).
let modalReturnFallback = null;
// v1.11.52 (U3): pending deferred focus restore (see modalClosed).
let modalRestoreTimer = null;
function describeFocusTarget(el) {
  if (!el || el === document.body) return null;
  const boxEl = el.closest ? el.closest("[data-box-id]") : null;
  const classes = ((el.className || "").toString().split(/\s+/).filter(c => c && c !== "btn"));
  return { boxId: boxEl ? boxEl.dataset.boxId : null,
           cls: classes.length ? classes[classes.length - 1] : null,
           id: el.id || null };
}
function modalFocusable(modal) {
  return Array.from(modal.querySelectorAll(
    'button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [href], [tabindex]:not([tabindex="-1"])'
  )).filter(el => el.offsetParent !== null || el === document.activeElement);
}
function modalOpened(back) {
  const modal = back.querySelector(".modal");
  modalReturnFocus = document.activeElement;
  // v1.11.52 (U3): remember how to find the opener again after a
  // re-render detaches it — the route-driven renderAll() rebuilds the
  // tab DOM, so document.contains(opener) is false on the Esc close
  // path and focus used to land on <body>.
  modalReturnFallback = describeFocusTarget(document.activeElement);
  const f = modal ? modalFocusable(modal) : [];
  if (f.length) f[0].focus();
  else if (modal) modal.focus();
}
function modalClosed() {
  const focusEl = (modalReturnFocus && document.contains(modalReturnFocus)) ? modalReturnFocus : null;
  const fb = modalReturnFallback;
  modalReturnFocus = null;
  modalReturnFallback = null;
  if (!focusEl && !fb) return;
  if (modalRestoreTimer !== null) return; // a restore is already pending
  // v1.11.52 (U3, second half): the Esc path pops a history entry,
  // and the popstate task re-renders the tab AFTER this observer
  // callback runs — a focus restored synchronously here would be
  // detached by that re-render and land on <body> again. So the
  // restore is deferred one task (setTimeout 0, queued behind the
  // popstate task) and the target is re-queried then, against the
  // fresh DOM.
  modalRestoreTimer = setTimeout(() => {
    modalRestoreTimer = null;
    if (openModalBack()) return; // another modal opened meanwhile
    // The opener was detached by a re-render: focus the equivalent
    // live control — the same element if it survived, else the same
    // id, else the same box's same-class button — else the first
    // focusable element of the current tab, else the tab's nav
    // button. Focus must land somewhere useful, never on <body>.
    let target = null;
    if (focusEl && document.contains(focusEl)) target = focusEl;
    if (!target && fb) {
      if (fb.id) target = document.getElementById(fb.id);
      if (!target && fb.boxId && fb.cls)
        target = document.querySelector('[data-box-id="' + fb.boxId + '"] .' + fb.cls);
    }
    if (!target) {
      const tab = document.querySelector("section:not([hidden])");
      if (tab) target = tab.querySelector('button:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])');
    }
    if (!target) target = document.querySelector('.nav-item[data-tab="' + (currentTab || "today") + '"]');
    if (target) { try { target.focus(); } catch (e) {} }
  }, 0);
}
function openModalBack() {
  return document.querySelector(".modal-back.open");
}
function closeOpenModal() {
  const back = openModalBack();
  if (!back) return false;
  const id = back.id;
  if (id === "editModal") closeEditModal();
  else if (id === "examModal") closeExamModal();
  else if (id === "statsModal") closeStatsModal();
  else if (id === "shortcutsModal") closeShortcutsModal();
  else if (id === "closeDayModal") closeCloseDay();
  else if (id === "bulkDeleteModal") closeBulkDeleteModal();
  else if (id === "deyModal") closeDeyWizard();
  else if (id === "reconnectModal") back.classList.remove("open");
  return true;
}
if (typeof MutationObserver !== "undefined") {
  const modalObs = new MutationObserver(muts => {
    muts.forEach(m => {
      if (m.type !== "attributes" || m.attributeName !== "class") return;
      const el = m.target;
      if (el.classList.contains("open")) modalOpened(el);
      else modalClosed();
    });
  });
  document.querySelectorAll(".modal-back").forEach(el => modalObs.observe(el, { attributes: true, attributeFilter: ["class"] }));
}

// ---- Book view ----
// One line of section metadata: درس group + start pages. Book data is
// never translated — page numbers and titles show as stored.
function topicMetaText(tp) {
  const parts = [];
  if (tp.group) parts.push(tp.group);
  if (tp.page) parts.push(t("metaPage", { n: FA(tp.page) }));
  if (tp.pages) parts.push(tp.pages);
  if (tp.textbookPages) parts.push(t("metaTextbook", { r: tp.textbookPages }));
  if (tp.lessonPage) parts.push(t("metaLesson", { n: FA(tp.lessonPage) }));
  if (tp.questionsPage) parts.push(t("metaQuestions", { n: FA(tp.questionsPage) }));
  if (tp.kind) parts.push(t({ exam: "kindExam", interactive: "kindInteractive", review: "kindReview", appendix: "kindAppendix", answers: "kindAnswers" }[tp.kind] || "kindExam"));
  return parts.join(" · ");
}
function masteryOptions(cur) {
  return [["", "masteryNone"], ["weak", "masteryWeak"], ["mid", "masteryMid"], ["good", "masteryGood"], ["strong", "masteryStrong"]]
    .map(([v, k]) => '<option value="' + v + '"' + (cur === v ? " selected" : "") + '>' + t(k) + '</option>').join("");
}
function statusOptions(cur) {
  return [["", "statusNone"], ["not", "statusNot"], ["studying", "statusStudying"], ["done", "statusDone"]]
    .map(([v, k]) => '<option value="' + v + '"' + (cur === v ? " selected" : "") + '>' + t(k) + '</option>').join("");
}
// Everything manually linked to this book section — the reverse view of
// all three link kinds: exam topics (topic.bookLinks), assignments
// (assignment.bookLinks) and study boxes (state.boxBookLinks). All sides
// read the same shared records, so a link shows up here and at its owner.
function reverseBookLinks(sectionId) {
  const out = [];
  allExams().forEach(ex => (ex.budget || []).forEach(s => (s.chapters || []).forEach(ch =>
    (ch.topics || []).forEach(tp => {
      if (topicLinks(tp).some(l => l.sectionId === sectionId))
        out.push({ kind: "exam", examId: ex.id, examName: examGroupLabel(ex) + " — " + examDisplayName(ex), topicName: tp.name });
    }))));
  (state.assignments || []).forEach(a => {
    if (!assignmentBookLinks(a).some(l => l.sectionId === sectionId)) return;
    const box = allBoxes().find(b => b.id === a.boxId);
    if (box) out.push({ kind: "assignment", assignmentId: a.id, boxId: box.id, boxTitle: box.title, boxDate: boxStudyDay(box) || box.date });
  });
  Object.keys(state.boxBookLinks || {}).forEach(boxId => {
    if (!boxBookLinks(boxId).some(l => l.sectionId === sectionId)) return;
    const box = allBoxes().find(b => b.id === boxId);
    if (box) out.push({ kind: "box", boxId: box.id, boxTitle: box.title, boxDate: boxStudyDay(box) || box.date });
  });
  return out;
}
function jumpToExam(id) {
  const ex = findExam(id);
  if (!ex) return;
  navigate({ tab: "exams", examGroup: ex.group, examView: "list", examId: id, scroll: { type: "exam", id } });
}
// One book section row: counts (computed), per-section test entry, study
// status, mastery, personal note, and the exams linked to it.
function bookTopicRow(tp) {
  const s = topicStats(tp);
  const tr = topicTrendLabel(tp.id);
  // v1.11.50: skip non-dict entries (a null entry threw here).
  const trHasLog = (state.testLog || []).some(e => e && e.topic === tp.id && e.d);
  const row = document.createElement("div");
  row.className = "book-topic";
  row.id = "topic-row-" + tp.id;
  const links = reverseBookLinks(tp.id);
  const examLinks = links.filter(l => l.kind === "exam");
  const asgLinks = links.filter(l => l.kind === "assignment");
  const boxLinks = links.filter(l => l.kind === "box");
  const meta = topicMetaText(tp);
  row.innerHTML =
    '<div class="bt-head"><span class="bt-title">' + esc(topicTitle(tp)) + '</span>' +
    '<span class="bt-pct">' + (s.pct == null ? "—" : FA_PCT(s.pct)) + '</span></div>' +
    (meta ? '<div class="bt-sub">' + esc(meta) + '</div>' : '') +
    '<div class="bt-nums"><span>' + t("totalLabel") + '<b>' + FA(s.total) + '</b></span>' +
    // v1.11.37 (P3-5): the source of the solved count, next to the
    // number — «از باکس‌ها» or «دستی». The `source` field already
    // existed in topicAgg; it just was never shown. Nothing when the
    // count has no source (0 solved).
    '<span>' + t("solvedLabel") + '<b>' + FA(s.solved) + '</b>' +
    (s.boxSource === "manual" ? ' <span class="bt-src">' + esc(t("bkSrcManual")) + '</span>'
      : s.boxSource === "boxes" ? ' <span class="bt-src">' + esc(t("bkSrcBoxes")) + '</span>' : '') + '</span>' +
    '<span>' + t("correctLabel") + '<b>' + FA(s.correct) + '</b></span>' +
    '<span>' + t("wrongLabel") + '<b>' + FA(s.wrong) + '</b></span>' +
    '<span>' + t("unansweredLabel") + '<b>' + (s.unanswered == null ? "—" : FA(s.unanswered)) + '</b></span>' +
    '<span>' + t("remainingLabel") + '<b>' + (s.remaining == null ? "—" : FA(s.remaining)) + '</b></span>' +
    '<span>' + t("accuracyLabel") + '<b>' + (s.acc == null ? "—" : FA_PCT(s.acc)) + '</b></span></div>' +
    '<div class="progress"><div style="width:' + (s.pct == null ? 0 : s.pct) + '%"></div></div>' +
    // v1.11.24 (QA BUG-017): a manual count wins over the linked boxes'
    // tests by design — say so, with the excluded count, instead of
    // silently dropping them from the total.
    (s.boxSource === "manual" && s.boxSolved > 0
      ? '<div class="bt-trend muted">' + esc(t("bkBoxTestsExcluded", { n: FA(s.boxSolved) })) + '</div>' : '') +
    (tr ? '<div class="bt-trend">' + esc(t("tlTitle")) + ': ' + esc(t("tlFirst")) + ' ' + FA_PCT(tr.first * 100) + ' · ' + esc(t("tlLast")) + ' ' + FA_PCT(tr.last * 100) + ' · ' + esc(t(tr.dir === "improving" ? "tlImproving" : tr.dir === "declining" ? "tlDeclining" : "tlStable")) + '</div>'
        : (trHasLog ? '<div class="bt-trend muted">' + esc(t("tlNoData")) + '</div>' : '')) +
    '<details class="bt-edit-details"><summary>' + t("editDetails") + '</summary><div class="bt-edit">' +
    '<label>' + t("totalTestsInput") + ' <input type="number" min="0" class="bt-total" value="' + s.total + '"></label>' +
    '<label>' + t("manualSolvedInput") + ' <input type="number" min="0" class="bt-manual" value="' + (tp.manual_solved || 0) + '"></label>' +
    '<label>' + t("manualCorrectInput") + ' <input type="number" min="0" class="bt-manual-c" value="' + (tp.manual_correct || 0) + '"></label>' +
    '<label>' + t("manualWrongInput") + ' <input type="number" min="0" class="bt-manual-w" value="' + (tp.manual_wrong || 0) + '"></label>' +
    '<label>' + t("masteryLabel") + ' <select class="bt-mastery">' + masteryOptions(tp.mastery || "") + '</select></label>' +
    '<label>' + t("statusLabel") + ' <select class="bt-status">' + statusOptions(tp.status || "") + '</select></label>' +
    '<label class="bt-note-lbl">' + t("noteLabel") + ' <input type="text" class="bt-note" value="' + esc(tp.note || "") + '" placeholder="' + esc(t("notePh")) + '"></label>' +
    '<button class="edit-btn bt-rename">' + t("renameTopic") + '</button></div></details>' +
    (examLinks.length ? '<div class="bt-links"><span class="bt-links-label">' + t("linkedExamsLabel") + '</span>' + examLinks.map(l =>
      '<button class="jump-btn bt-link-jump" data-exam="' + esc(l.examId) + '">' + esc(l.examName + " — " + l.topicName) + '</button>').join("") + '</div>' : '') +
    (asgLinks.length ? '<div class="bt-links"><span class="bt-links-label">' + t("linkedAssignmentsLabel") + '</span>' + asgLinks.map(l =>
      '<button class="jump-btn bt-link-jump-asg" data-box="' + esc(l.boxId) + '">' + esc(l.boxTitle) + '</button>').join("") + '</div>' : '') +
    (boxLinks.length ? '<div class="bt-links"><span class="bt-links-label">' + t("linkedBoxesLabel") + '</span>' + boxLinks.map(l =>
      '<button class="jump-btn bt-link-jump-box" data-box="' + esc(l.boxId) + '" data-day="' + esc(l.boxDate) + '">' + esc(l.boxTitle) + '</button>').join("") + '</div>' : '') +
    // v1.11.57 (IA): «تکالیف این مبحث» — the Assignments tab, filtered
    // to this topic (the audit's IA section).
    '<div class="bt-links"><button class="jump-btn bt-topic-asg-jump" data-topic="' + esc(tp.id) + '">' + esc(t("tbTopicAsgLink")) + '</button></div>';
  const clampManual = () => {
    tp.manual_solved = Math.max(0, tp.manual_solved || 0);
    tp.manual_correct = Math.min(tp.manual_solved, Math.max(0, tp.manual_correct || 0));
    tp.manual_wrong = Math.min(Math.max(0, tp.manual_solved - tp.manual_correct), Math.max(0, tp.manual_wrong || 0));
  };
  row.querySelector(".bt-total").addEventListener("change", (e) => {
    tp.tests_total = Math.max(0, parseInt(e.target.value, 10) || 0);
    saveTestbook(); renderAll();
  });
  const logManualDelta = (oldS, oldC, oldW) => {
    // 3.2: log the dated delta after the clamp (totals stay the source).
    const d = { solved: (tp.manual_solved || 0) - (oldS || 0),
                correct: (tp.manual_correct || 0) - (oldC || 0),
                wrong: (tp.manual_wrong || 0) - (oldW || 0) };
    if (d.solved || d.correct || d.wrong) {
      logTestDelta(Object.assign({ topic: tp.id, src: "book" }, d));
      saveState(); // the log lives in state; the counts live in the testbook
    }
  };
  row.querySelector(".bt-manual").addEventListener("change", (e) => {
    const o = [tp.manual_solved, tp.manual_correct, tp.manual_wrong];
    tp.manual_solved = Math.max(0, parseInt(e.target.value, 10) || 0);
    clampManual(); logManualDelta(o[0], o[1], o[2]); saveTestbook(); renderAll();
  });
  row.querySelector(".bt-manual-c").addEventListener("change", (e) => {
    const o = [tp.manual_solved, tp.manual_correct, tp.manual_wrong];
    tp.manual_correct = Math.max(0, parseInt(e.target.value, 10) || 0);
    clampManual(); logManualDelta(o[0], o[1], o[2]); saveTestbook(); renderAll();
  });
  row.querySelector(".bt-manual-w").addEventListener("change", (e) => {
    const o = [tp.manual_solved, tp.manual_correct, tp.manual_wrong];
    tp.manual_wrong = Math.max(0, parseInt(e.target.value, 10) || 0);
    clampManual(); logManualDelta(o[0], o[1], o[2]); saveTestbook(); renderAll();
  });
  row.querySelector(".bt-mastery").addEventListener("change", (e) => {
    tp.mastery = e.target.value; saveTestbook(); renderAll();
  });
  row.querySelector(".bt-status").addEventListener("change", (e) => {
    tp.status = e.target.value; saveTestbook(); renderAll();
  });
  row.querySelector(".bt-note").addEventListener("change", (e) => {
    tp.note = e.target.value; saveTestbook();
  });
  row.querySelector(".bt-rename").addEventListener("click", () => {
    const name = prompt(t("renameTopicPrompt"), tp.title);
    if (name == null) return;
    tp.title = name.trim() || tp.title;
    saveTestbook(); renderAll();
  });
  row.querySelectorAll(".bt-link-jump").forEach(btn => btn.addEventListener("click", (e) => {
    e.stopPropagation();
    jumpToExam(btn.dataset.exam);
  }));
  row.querySelectorAll(".bt-link-jump-asg").forEach(btn => btn.addEventListener("click", (e) => {
    e.stopPropagation();
    const boxId = btn.dataset.box;
    navigate({ tab: "assignments" });
    setTimeout(() => {
      const el = document.getElementById("asg-row-" + boxId);
      if (el) el.scrollIntoView({ block: "center" });
    }, 60);
  }));
  row.querySelectorAll(".bt-link-jump-box").forEach(btn => btn.addEventListener("click", (e) => {
    e.stopPropagation();
    navigate({ tab: "program", day: btn.dataset.day });
  }));
  // v1.11.57 (IA): «تکالیف این مبحث» — filter the Assignments tab to
  // this topic (renderAssignments reads asgTopicFilter).
  row.querySelectorAll(".bt-topic-asg-jump").forEach(btn => btn.addEventListener("click", (e) => {
    e.stopPropagation();
    asgTopicFilter = btn.dataset.topic;
    navigate({ tab: "assignments" });
  }));
  return row;
}
// Known book totals (audit §5 item 2.1a): the publishers' own totals
// for the user's prints — حسابان IQ 3489, شیمی بتمن 3000, گسسته IQ
// 2110. فیزیک الگو is NOT listed: the sources conflict (2571 / 2781 /
// 2819), so no total is claimed for it. Per-section counts are NOT
// known anywhere (the TOCs list pages, not question counts), so no
// per-section value is seeded — the bulk grid is how they get entered,
// and the known total is only a checksum target shown in the book stats.
const KNOWN_BOOK_TOTALS = { calc: 3489, chem: 3000 };
function bookKnownTotal(book) {
  if (!book) return 0;
  if (typeof book.known_total_tests === "number" && book.known_total_tests > 0) return book.known_total_tests;
  return KNOWN_BOOK_TOTALS[book.id] || 0;
}
// v1.11.32 (P2-5b): exact-sum proportional splits for the chapter
// bulk entry. distributeExact(n, weights) splits n across the
// weights (even split when all weights are zero). It returns integer
// arrays summing to exactly n (or to Σweights when n exceeds it —
// the caller clamps first).
function distributeExact(n, weights) {
  const w = weights.map(x => Math.max(0, x || 0));
  const W = w.reduce((a, b) => a + b, 0);
  const ww = W > 0 ? w : weights.map(() => 1);
  const WW = ww.reduce((a, b) => a + b, 0);
  const raw = ww.map(x => n * x / WW);
  const base = raw.map(Math.floor);
  let rem = n - base.reduce((a, b) => a + b, 0);
  const order = raw.map((r, i) => [r - base[i], i]).sort((a, b) => b[0] - a[0] || a[1] - b[1]);
  for (let k = 0; k < rem; k++) base[order[k % order.length][1]]++;
  return base;
}
// v1.11.34: testbook drill-down — the book view is three levels, and
// each level shows only its own info (user spec, 25 Nov):
//   L1 book → chapters only (summary per chapter)
//   L2 chapter → its sections only (+ the chapter bulk-total row)
//   L3 section → the full section detail (the existing bookTopicRow)
// Navigation: کتاب تست > book > chapter > section — every crumb
// clickable, plus a Back button that goes one level up. The data
// logic is untouched: same topicStats/bookStats, same saves, same
// state shape. bookNav is transient UI state only (never persisted,
// never in state.json — same pattern as BOX_DETAILS_OPEN / COLL_OPEN).
// chapterId is a chapter id, or "legacy" for the legacy block.
let bookNav = { bookId: null, chapterId: null, topicId: null };
// Chapter summary: total / solved / remaining / progress %, from the
// same topicStats() the section rows use — one definition, no second count.
function chapterStats(topics) {
  let solved = 0, total = 0;
  (topics || []).forEach(t => { const s = topicStats(t); solved += s.solved; total += s.total; });
  return { solved, total, remaining: total ? Math.max(0, total - solved) : null,
           pct: total ? Math.min(100, Math.round(solved / total * 100)) : null };
}
function bookNavChapter(book, chapterId) {
  if (chapterId === "legacy") return "legacy";
  return (book.chapters || []).find(c => c.id === chapterId) || null;
}
function bookNavSections(book, ch) {
  if (ch === "legacy") return Object.values(TESTBOOK.legacy || {}).filter(lg => lg.bookId === book.id);
  return (ch && ch.topics) || [];
}
function renderBookCrumb(book, ch, tp) {
  const crumb = document.getElementById("bookCrumb");
  if (!crumb) return;
  const parts = [
    { label: t("tabTestbook"), go: () => navigate({ tab: "testbook", bookId: null }) },
    { label: bookName(book), go: () => { bookNav.chapterId = null; bookNav.topicId = null; renderAll(); } },
  ];
  if (ch) parts.push({ label: ch === "legacy" ? t("legacyTitle") : chapterTitle(ch), go: () => { bookNav.topicId = null; renderAll(); } });
  if (tp) parts.push({ label: topicTitle(tp), go: () => renderAll() });
  crumb.innerHTML = "";
  parts.forEach((p, i) => {
    if (i) { const sep = document.createElement("span"); sep.className = "crumb-sep"; sep.textContent = " › "; crumb.appendChild(sep); }
    const b = document.createElement("button");
    b.type = "button";
    b.className = "crumb-btn" + (i === parts.length - 1 ? " current" : "");
    b.textContent = p.label;
    b.addEventListener("click", p.go);
    crumb.appendChild(b);
  });
  // Back button: one level up (its label says where it goes). Driven
  // from here, not from a load-time listener, so the target follows
  // the current level.
  const back = document.getElementById("bookBack");
  if (back) {
    if (tp) { back.textContent = t("bkBackChapter"); back.onclick = () => { bookNav.topicId = null; renderAll(); }; }
    else if (ch) { back.textContent = t("bkBackBook"); back.onclick = () => { bookNav.chapterId = null; bookNav.topicId = null; renderAll(); }; }
    else { back.textContent = t("backToBooks"); back.onclick = () => navigate({ tab: "testbook", bookId: null }); }
  }
}
// L1: one card per chapter — title + summary only, no sections.
function chapterCard(book, ch, topics) {
  const st = chapterStats(topics);
  const card = document.createElement("button");
  card.type = "button";
  card.className = "book-card book-chapter-card";
  const title = ch === "legacy" ? t("legacyTitle") : chapterTitle(ch);
  const pending = ch !== "legacy" && ch.pending;
  card.innerHTML = '<div class="book-name">' + esc(title) + '</div>' +
    (pending ? '<div><span class="pending-badge">' + esc(t("chapterPendingShort")) + '</span></div>' : '') +
    '<div class="book-pct">' + (st.pct == null ? "—" : FA_PCT(st.pct)) + '</div>' +
    '<div class="book-sub">' + FA(st.solved) + t("solvedSuffix") +
    (st.total ? t("ofWord") + FA(st.total) : '') +
    (st.remaining != null ? ' · ' + FA(st.remaining) + t("remainingSuffixT") : '') + '</div>' +
    '<div class="progress"><div style="width:' + (st.pct == null ? 0 : st.pct) + '%"></div></div>';
  card.addEventListener("click", () => {
    bookNav.chapterId = ch === "legacy" ? "legacy" : ch.id;
    bookNav.topicId = null;
    renderAll();
  });
  return card;
}
// L2: one compact row per section — title + summary only; the full
// detail lives at L3. Class "book-topic" keeps the P2-2 collapsible
// (and its COLL_OPEN key) working on this list.
function bookSectionRow(tp) {
  const s = topicStats(tp);
  const row = document.createElement("button");
  row.type = "button";
  row.className = "book-topic book-section-row";
  row.id = "topic-row-" + tp.id;
  row.innerHTML = '<span class="bsr-title">' + esc(topicTitle(tp)) + '</span>' +
    '<span class="bsr-nums">' + FA(s.solved) + t("solvedSuffix") +
    (s.total ? t("ofWord") + FA(s.total) : '') +
    (s.remaining != null ? ' · ' + FA(s.remaining) + t("remainingSuffixT") : '') + '</span>' +
    '<span class="bsr-pct">' + (s.pct == null ? "—" : FA_PCT(s.pct)) + '</span>' +
    '<span class="bsr-chev">›</span>';
  row.addEventListener("click", () => { bookNav.topicId = tp.id; renderAll(); });
  return row;
}
function renderBookChapters(book) {
  document.getElementById("bookTitle").textContent = t("bookPrefix") + bookName(book);
  document.getElementById("bookNote").textContent = book.books_note || "";
  const st = bookStats(book);
  const knownTotal = bookKnownTotal(book);
  document.getElementById("bookStats").innerHTML =
    statCard(t("bookProgress"), st.pct == null ? "—" : FA_PCT(st.pct), "") +
    statCard(t("solved"), FA(st.solved), "") +
    statCard(t("remainingT"), st.remaining != null ? FA(st.remaining) : "—",
      st.total ? t("ofTotalTests", { n: FA(st.total) })
               : knownTotal ? t("ofTotalTests", { n: FA(knownTotal) })
               : t("enterTotalTests"));
  const wrap = document.getElementById("bookChapters");
  wrap.innerHTML = "";
  let lastGrade = null;
  (book.chapters || []).forEach(ch => {
    // شیمی groups its chapters by grade (دهم / یازدهم / دوازدهم).
    if (ch.grade && ch.grade !== lastGrade) {
      lastGrade = ch.grade;
      const gh = document.createElement("h3");
      gh.className = "grade-head";
      gh.textContent = t({ "دهم": "grade10", "یازدهم": "grade11", "دوازدهم": "grade12" }[ch.grade] || "grade10");
      wrap.appendChild(gh);
    }
    wrap.appendChild(chapterCard(book, ch, ch.topics || []));
  });
  // Legacy topics: old v1 topics with no chapter in the new book. Their
  // counts are kept here as their own card so the migration never hides them.
  const legacy = Object.values(TESTBOOK.legacy || {}).filter(lg => lg.bookId === book.id);
  if (legacy.length) wrap.appendChild(chapterCard(book, "legacy", legacy));
  const addCh = document.createElement("button");
  addCh.className = "btn btn-primary page-primary"; // v1.11.55 (UX-1): the Testbook tab's ONE primary action
  addCh.textContent = t("addChapterBtn");
  addCh.addEventListener("click", () => {
    const name = prompt(t("newChapterPrompt"));
    if (!name || !name.trim()) return;
    book.chapters.push({ id: "ch-" + Date.now(), title: name.trim(), topics: [] });
    saveTestbook(); renderAll();
  });
  wrap.appendChild(addCh);
}
// v1.11.64 (Batch 5, م-۲): parse a pasted «title: count» list onto
// the bulk-grid inputs. Each chunk is one line, or part of a line
// split on «،» / «,». The trailing number (Persian/Arabic/Latin
// digits, optional «تست» after it) is the count; the rest is the topic
// title. Match order: exact title (digits + spaces normalised), then
// "title contains topic title" / "topic title contains title". A chunk
// with no number, or no matching topic, is returned as unmatched —
// never assigned by position, so no number is ever guessed. Returns
// { filled, unmatched } and writes only the matched inputs' values
// (no save here — the user reviews, then «ذخیره همه»).
function applyBulkPaste(text, inputs) {
  const norm = (s) => String(s || "")
    .replace(/[۰-۹]/g, d => "۰۱۲۳۴۵۶۷۸۹".indexOf(d))
    .replace(/[٠-٩]/g, d => "٠١٢٣٤٥٦٧٨٩".indexOf(d))
    .replace(/\s+/g, " ").trim();
  const disp = (tp) => norm(tp.title || tp.id);
  const chunks = String(text || "").split(/[\n،,]+/).map(s => s.trim()).filter(Boolean);
  let filled = 0;
  const unmatched = [];
  chunks.forEach(chunk => {
    const m = chunk.match(/^(.*?)[\s:：\-–]*([\d۰-۹٠-٩]+)\s*(تست|tests?)?\s*$/);
    if (!m) { unmatched.push(chunk); return; }
    const title = norm(m[1]);
    const num = parseInt(norm(m[2]), 10);
    if (!title || isNaN(num)) { unmatched.push(chunk); return; }
    let hit = inputs.find(([tp]) => disp(tp) === title || norm(topicTitle(tp)) === title);
    if (!hit) hit = inputs.find(([tp]) => {
      const a = disp(tp), b = norm(topicTitle(tp));
      return (a && (a.includes(title) || title.includes(a))) ||
             (b && (b.includes(title) || title.includes(b)));
    });
    if (!hit) { unmatched.push(chunk); return; }
    hit[1].value = String(Math.max(0, num));
    filled++;
  });
  return { filled, unmatched };
}
function renderBookChapter(book, ch) {
  const isLegacy = ch === "legacy";
  const topics = bookNavSections(book, ch);
  document.getElementById("bookTitle").textContent = isLegacy ? t("legacyTitle") : chapterTitle(ch);
  document.getElementById("bookNote").textContent = "";
  const st = chapterStats(topics);
  document.getElementById("bookStats").innerHTML =
    statCard(t("bookProgress"), st.pct == null ? "—" : FA_PCT(st.pct), "") +
    statCard(t("solved"), FA(st.solved), "") +
    statCard(t("remainingT"), st.remaining != null ? FA(st.remaining) : "—",
      st.total ? t("ofTotalTests", { n: FA(st.total) }) : t("enterTotalTests"));
  const wrap = document.getElementById("bookChapters");
  wrap.innerHTML = "";
  if (!isLegacy && ch.pending) {
    const p = document.createElement("p");
    p.className = "muted";
    p.textContent = t("chapterPending");
    wrap.appendChild(p);
  }
  // Spaced repetition (3.4) + accuracy trend (3.2): freshness, next
  // review, trend and the "reviewed" button — chapter-level, so it
  // lives on the chapter page.
  if (!isLegacy) wrap.appendChild(srChapterLine(book, ch));
  const topicsWrap = document.createElement("div");
  topicsWrap.className = "ch-topics";
  topics.forEach(tp => topicsWrap.appendChild(bookSectionRow(tp)));
  // v1.11.32 (P2-2): no id on this wrapper — the key keeps its
  // open state across re-renders.
  if (isLegacy) {
    const legacyWrap = topicsWrap;
    attachCollapsible(legacyWrap, ".book-topic", 6, "book:" + book.id + ":legacy");
  } else {
    attachCollapsible(topicsWrap, ".book-topic", 6, "book:" + book.id + ":ch:" + ch.id);
  }
  wrap.appendChild(topicsWrap);
  // v1.11.34 (user request): the per-chapter bulk entry keeps ONLY
  // the total field — solved and correct (and the derived wrong) are
  // gone from this row. Apply splits just the total across the
  // chapter's sections in proportion to their current totals (even
  // split when all are zero), with exact sums; per-section solved /
  // correct / wrong are left untouched and stay editable only in the
  // section's own detail (L3).
  if (!isLegacy && topics.length) {
    const bulk = document.createElement("div");
    bulk.className = "bulk-chapter";
    const chTotal = topics.reduce((s, t) => s + (t.tests_total || 0), 0);
    bulk.innerHTML = '<h4>' + esc(t("bulkChapterTitle")) + '</h4>' +
      '<p class="muted">' + esc(t("bulkChapterHint")) + '</p>' +
      '<div class="bulk-chapter-row">' +
      '<label>' + esc(t("totalLabel")) + ' <input type="number" min="0" class="bc-total" value="' + chTotal + '"></label>' +
      '<button class="btn bc-apply">' + esc(t("saveBtn")) + '</button></div>';
    bulk.querySelector(".bc-apply").addEventListener("click", () => {
      const total = Math.max(0, parseInt(bulk.querySelector(".bc-total").value, 10) || 0);
      const totals = distributeExact(total, ch.topics.map(tp => tp.tests_total || 0));
      ch.topics.forEach((tp, i) => { tp.tests_total = totals[i]; });
      saveTestbook(); renderAll();
    });
    wrap.appendChild(bulk);
  }
  // Bulk test-count entry (audit §5 item 2.1b): one number per section
  // on one page, so a whole chapter is entered in about a minute
  // instead of one dialog per section. Inputs are pre-filled with the
  // current values — saving writes exactly what is shown, so counts
  // the user already entered are never overwritten.
  if (!isLegacy) {
    const bulkBtn = document.createElement("button");
    bulkBtn.className = "btn";
    bulkBtn.textContent = t("bulkCountsBtn");
    bulkBtn.addEventListener("click", () => {
      const existing = wrap.querySelector(".bulk-grid-wrap");
      if (existing) { existing.remove(); bulkBtn.textContent = t("bulkCountsBtn"); return; }
      bulkBtn.textContent = t("bulkCountsCancel");
      const grid = document.createElement("div");
      grid.className = "bulk-grid-wrap";
      const h = document.createElement("h4");
      h.textContent = t("bulkCountsTitle");
      grid.appendChild(h);
      const rows = document.createElement("div");
      rows.className = "bulk-grid";
      const inputs = [];
      (ch.topics || []).forEach(tp => {
        const row = document.createElement("div");
        row.className = "bulk-row";
        const lab = document.createElement("span");
        lab.textContent = tp.title || tp.id;
        const inp = document.createElement("input");
        inp.type = "number"; inp.min = "0"; inp.className = "bulk-input";
        inp.value = String(tp.tests_total || 0);
        inp.setAttribute("aria-label", tp.title || tp.id);
        inputs.push([tp, inp]);
        row.appendChild(lab); row.appendChild(inp);
        rows.appendChild(row);
      });
      grid.appendChild(rows);
      const sumEl = document.createElement("p");
      sumEl.className = "muted";
      const updateSum = () => {
        const s = inputs.reduce((a, pair) => a + Math.max(0, parseInt(pair[1].value, 10) || 0), 0);
        sumEl.textContent = t("bulkCountsSum", { n: FA(s) });
      };
      inputs.forEach(pair => pair[1].addEventListener("input", updateSum));
      updateSum();
      grid.appendChild(sumEl);
      const saveBtn = document.createElement("button");
      saveBtn.className = "btn";
      saveBtn.textContent = t("bulkCountsSave");
      saveBtn.addEventListener("click", () => {
        inputs.forEach(pair => { pair[0].tests_total = Math.max(0, parseInt(pair[1].value, 10) || 0); });
        saveTestbook(); renderAll();
      });
      grid.appendChild(saveBtn);
      // v1.11.64 (Batch 5, م-۲): paste mode — the user pastes a list
      // «عنوان مبحث: تعداد» from his notes and the numbers are applied
      // onto the grid inputs. applyBulkPaste matches by title only and
      // reports unmatched lines; saving still happens only via
      // «ذخیره همه», after the user reviews the filled grid.
      const pasteBtn = document.createElement("button");
      pasteBtn.className = "btn";
      pasteBtn.textContent = t("bulkPasteBtn");
      pasteBtn.addEventListener("click", () => {
        const existing = grid.querySelector(".bulk-paste-wrap");
        if (existing) { existing.remove(); pasteBtn.textContent = t("bulkPasteBtn"); return; }
        pasteBtn.textContent = t("bulkPasteHide");
        const pw = document.createElement("div");
        pw.className = "bulk-paste-wrap";
        const ta = document.createElement("textarea");
        ta.placeholder = t("bulkPastePh");
        ta.setAttribute("aria-label", t("bulkPasteBtn"));
        const applyBtn = document.createElement("button");
        applyBtn.className = "btn";
        applyBtn.textContent = t("bulkPasteApply");
        const note = document.createElement("p");
        note.className = "muted";
        applyBtn.addEventListener("click", () => {
          const res = applyBulkPaste(ta.value, inputs);
          updateSum();
          note.textContent = t("bulkPasteDone", { n: FA(res.filled) }) +
            (res.unmatched.length ? " — " + t("bulkPasteNoMatch", { list: res.unmatched.join("، ") }) : "");
        });
        pw.appendChild(ta); pw.appendChild(applyBtn); pw.appendChild(note);
        grid.appendChild(pw);
      });
      grid.appendChild(pasteBtn);
      wrap.appendChild(grid);
    });
    wrap.appendChild(bulkBtn);
  }
  if (!isLegacy) {
    const addBtn = document.createElement("button");
    addBtn.className = "btn";
    addBtn.textContent = t("addTopicBtn");
    addBtn.addEventListener("click", () => {
      const name = prompt(t("newTopicPrompt"));
      if (!name || !name.trim()) return;
      ch.topics.push({ id: "t-" + Date.now(), title: name.trim(), tests_total: 0, manual_solved: 0, manual_correct: 0, manual_wrong: 0, mastery: "", status: "", note: "" });
      saveTestbook(); renderAll();
    });
    wrap.appendChild(addBtn);
  }
}
// L3: the full section detail — the existing bookTopicRow, unchanged
// (counts, progress, trend, edit details, mastery/status/note, linked
// exams / assignments / boxes). No separate topic level exists.
function renderBookSection(book, ch, tp) {
  document.getElementById("bookTitle").textContent = topicTitle(tp);
  document.getElementById("bookNote").textContent = "";
  document.getElementById("bookStats").innerHTML = "";
  const wrap = document.getElementById("bookChapters");
  wrap.innerHTML = "";
  wrap.appendChild(bookTopicRow(tp));
}
function renderBookView(bookId) {
  const book = (TESTBOOK.books || []).find(b => b.id === bookId);
  if (!book) { openBookId = null; bookNav = { bookId: null, chapterId: null, topicId: null }; return; }
  // Reset the drill-down when the book changes.
  if (bookNav.bookId !== bookId) bookNav = { bookId, chapterId: null, topicId: null };
  const ch = bookNavChapter(book, bookNav.chapterId);
  if (bookNav.chapterId && !ch) { bookNav.chapterId = null; bookNav.topicId = null; }
  let tp = null;
  if (ch && bookNav.topicId) {
    tp = bookNavSections(book, ch).find(t => t.id === bookNav.topicId) || null;
    if (!tp) bookNav.topicId = null;
  }
  document.getElementById("testbookMain").hidden = true;
  const view = document.getElementById("bookView");
  view.hidden = false;
  renderBookCrumb(book, ch, tp);
  if (!ch) renderBookChapters(book);
  else if (!tp) renderBookChapter(book, ch);
  else renderBookSection(book, ch, tp);
}

// ---------- v1.11.64 (Batch 5, ب-۸): data-completeness meter ----------
// How much of the test data is actually entered — live from the
// current data, never hardcoded. A topic counts as "entered" only when
// tests_total is a number > 0 (null and 0 are both "no count yet":
// the seed ships null, and the bulk grid writes 0 for untouched
// rows). A test box counts when its effective tests_total > 0.
// firstMissing is the first topic (book order) without a count, for
// the «رفتن به اولین مبحث بدون تعداد» jump.
function testDataCompleteness() {
  let tt = 0, te = 0, firstMissing = null;
  const walk = (topics) => {
    (topics || []).forEach(tp => {
      tt++;
      if (tp && typeof tp.tests_total === "number" && tp.tests_total > 0) te++;
      else if (!firstMissing) firstMissing = tp;
    });
  };
  (TESTBOOK.books || []).forEach(book => {
    (book.chapters || []).forEach(ch => walk(ch.topics));
  });
  Object.values(TESTBOOK.legacy || {}).forEach(lg => {
    tt++;
    if (lg && typeof lg.tests_total === "number" && lg.tests_total > 0) te++;
    else if (!firstMissing) firstMissing = lg;
  });
  const testBoxes = allBoxes().filter(b => b.is_test);
  const bt = testBoxes.length;
  // v1.11.72 (Batch 5, L31): «entered» means a STORED total only —
  // the title-inferred totals (e.g. «۳۰ تست») are not user-entered
  // data, so they no longer inflate the meter; they are counted
  // separately as boxesInferred («+۱۵ از روی عنوان»).
  const be = testBoxes.filter(b => (b.tests_total_stored || 0) > 0).length;
  const bi = testBoxes.filter(b => (b.tests_total_stored || 0) <= 0 && (b.tests_total || 0) > 0).length;
  return { topicsTotal: tt, topicsEntered: te, boxesTotal: bt, boxesEntered: be, boxesInferred: bi, firstMissing };
}
function renderTestbookMeter() {
  const el = document.getElementById("tbDataMeter");
  if (!el) return;
  const m = testDataCompleteness();
  const pct = m.topicsTotal ? Math.round(m.topicsEntered / m.topicsTotal * 100) : 100;
  el.innerHTML = '<div class="tb-meter-line"><b>' + esc(t("tbDataMeter")) + ' — ' +
    esc(t("tbDataMeterLine", { te: FA(m.topicsEntered), tt: FA(m.topicsTotal), be: FA(m.boxesEntered), bt: FA(m.boxesTotal) })) + '</b>' +
    (m.boxesInferred ? ' <span class="muted">(' + esc(t("tbDataMeterInferred", { n: FA(m.boxesInferred) })) + ')</span>' : '') +
    (m.firstMissing
      ? '<button class="btn" id="tbFirstMissingBtn">' + esc(t("tbFirstMissing")) + '</button>'
      : '<span class="muted">' + esc(t("tbDataMeterDone")) + '</span>') + '</div>' +
    '<div class="progress" style="margin-top:8px"><div style="width:' + pct + '%"></div></div>';
  const btn = document.getElementById("tbFirstMissingBtn");
  if (btn && m.firstMissing) btn.addEventListener("click", () => jumpToTopic(m.firstMissing.id));
}
// ---- Test-book tab (own page) ----
function renderTestbookTab() {
  renderTestbookMeter();
  const bc = document.getElementById("bookCardsTb");
  if (!bc) return;
  bc.innerHTML = "";
  (TESTBOOK.books || []).forEach(book => {
    const st = bookStats(book);
    const card = document.createElement("button");
    card.className = "book-card " + colorClass(book.name);
    // v1.11.42 (UI-audit batch 2, item 16): the overview card shows
    // «حل‌شده از مجموع» — when no per-section total is entered yet,
    // the verified book total (حسابان 3489 / شیمی 3000) is the
    // denominator, so the card never reads just «۰ تست حل‌شده». The
    // progress % uses the same denominator when the entered total is 0.
    const known = bookKnownTotal(book);
    const tot = st.total || known;
    const pct = st.pct != null ? st.pct : (tot ? Math.min(100, Math.round(st.solved / tot * 100)) : null);
    const rem = st.total ? st.remaining : (known ? Math.max(0, known - st.solved) : null);
    card.innerHTML = '<div class="book-name">' + esc(bookName(book)) + '</div>' +
      '<div class="book-pct">' + (pct == null ? "—" : FA_PCT(pct)) + '</div>' +
      '<div class="book-sub">' + FA(st.solved) + t("solvedSuffix") +
      (tot ? t("ofWord") + FA(tot) : '') +
      (rem != null ? ' · ' + FA(rem) + t("remainingSuffixT") : '') + '</div>' +
      '<div class="progress"><div style="width:' + (pct == null ? 0 : pct) + '%"></div></div>';
    card.addEventListener("click", () => { navigate({ tab: "testbook", bookId: book.id }); });
    bc.appendChild(card);
  });
  if (!openBookId) {
    const bv = document.getElementById("bookView");
    if (bv) bv.hidden = true;
    const tm = document.getElementById("testbookMain");
    if (tm) tm.hidden = false;
  }
  // Error notebook 2.0 (audit §5 item 3.3): appended at the end of the
  // testbook main page (hidden with it while a book is open).
  const tm = document.getElementById("testbookMain");
  if (tm) {
    const old = document.getElementById("errNbBlock");
    if (old) old.remove();
    tm.appendChild(renderErrorNotebook());
  }
}
function jumpToTopic(topicId) {
  const found = topicById(topicId);
  if (!found || !found.book) return;
  // v1.11.34: open the drill-down to book → chapter → section first,
  // so the section detail (and its topic-row id) exists when the
  // scroll fires after navigation.
  bookNav = { bookId: found.book.id,
    chapterId: found.legacy ? "legacy" : (found.chapter ? found.chapter.id : null),
    topicId: topicId };
  navigate({ tab: "testbook", bookId: found.book.id, scroll: { type: "topic", id: topicId } });
}

// ---- Calendar tab ----
// ONE monthly calendar, driven by the shared monthly-calendar state
// (v1.11.3): a single {jy, jm} is the source of truth for the
// displayed Jalali month, so every monthly calendar in the app shows
// the same month and changing it in one place changes it everywhere
// (leave the Program tab and come back — the same month is showing).
// Grid dates are REAL calendar dates (Saturday-first week); the
// 03:30 study-day boundary applies only to which study day a BOX
// belongs to (the byDay grouping below), never to the grid itself.
// Dates are built with isoOf (local date) — toISOString is UTC and
// shifts every cell one day back on a Tehran-timezone machine.
// Programme range: state fields (see programmeStart/programmeEnd
// above). Dates outside it have no programme: their cells are
// disabled. Month navigation itself is NOT clamped — the user can look
// at Dey, Bahman, Esfand, Farvardin 1406, ... (empty months show "—").
// clampDay only clamps BELOW the start: after the programme ends the
// user may still navigate to the real today (1.7, no upper clamp).
function clampDay(iso) {
  if (!iso) return programmeStart();
  if (iso < programmeStart()) return programmeStart();
  return iso;
}
// ---- Shared monthly-calendar state (v1.11.3) ----
let calView = null; // {jy, jm} — null = derive from the real current date
function calViewMonth() {
  if (!calView) { const p = jalaliParts(realTodayIso()); calView = { jy: p.jy, jm: p.jm }; }
  return calView;
}
function calMonthLabel(jy, jm) {
  // Year in plain digits (no thousands separator): «آذر ۱۴۰۵», like the
  // old calMonthAban/calMonthAzar labels — FA() would give «۱٬۴۰۵».
  if (LANG === "fa") return t(jalaliMonthKey(jm)) + " " + String(jy).replace(/\d/g, d => "۰۱۲۳۴۵۶۷۸۹"[+d]);
  return t(jalaliMonthKey(jm)) + " " + jy;
}
function calIsCurrentMonth() {
  const p = jalaliParts(realTodayIso()), v = calViewMonth();
  return p.jy === v.jy && p.jm === v.jm;
}
function calShiftMonth(d) {
  const v = calViewMonth();
  let jy = v.jy, jm = v.jm + d;
  while (jm < 1) { jm += 12; jy -= 1; }
  while (jm > 12) { jm -= 12; jy += 1; }
  calView = { jy, jm };
  renderCalendar(); // grid re-render only — no page reload, no history change
}
function calGoToday() {
  const p = jalaliParts(realTodayIso());
  calView = { jy: p.jy, jm: p.jm };
  renderCalendar();
}
// ---------- Programme-issue detection (audit §5 item 2.8) ----------
// Wires the user's own rules into the app: (a) overlapping boxes in a
// study day, (b) a day over 12h planned, (c) more than 2 boxes of one
// subject in a day, (d) the hardest lesson in the day's last box.
// Warnings only — the app never moves, deletes or changes a box because
// of them. This JS check drives the calendar + edit-form warnings;
// server.py has the same check (programme_issues) for the box API.
// "Hardest" is the subject with the lowest test accuracy (attempted >= 10
// tests) — the only honest proxy the data supports; with no test data
// the rule is skipped silently instead of guessing.
function hardestSubject() {
  const bySubj = {};
  allBoxes().forEach(b => {
    const tr = testOf(b);
    const s = bySubj[b.subject] = bySubj[b.subject] || { tests: 0, correct: 0 };
    s.tests += tr.completed || 0; s.correct += tr.correct || 0;
  });
  let worst = null, worstAcc = null;
  Object.keys(bySubj).forEach(s => {
    if (bySubj[s].tests < 10) return;
    const acc = bySubj[s].correct / bySubj[s].tests;
    if (worstAcc == null || acc < worstAcc) { worstAcc = acc; worst = s; }
  });
  return worst;
}
function dayIssues(iso, extraBox, excludeId) {
  const list = allBoxes().filter(b => (boxStudyDay(b) || b.date) === iso && b.id !== excludeId);
  if (extraBox) list.push(extraBox);
  const sorted = list.slice().sort(compareBoxOrder);
  const issues = [];
  // (a) overlaps — each pair once.
  for (let i = 0; i < sorted.length; i++) {
    for (let j = i + 1; j < sorted.length; j++) {
      const a = sorted[i], b = sorted[j];
      if (intervalsOverlap(a.start, a.end, b.start, b.end)) {
        issues.push({ kind: "overlap", text: t("issOverlap", { a: a.title || "", b: b.title || "" }) });
      }
    }
  }
  // (b) day over the daily cap (v1.11.48, F1: one DAY_CAP_MIN = 14 h
  // everywhere — the old 12 h limit is retired).
  const total = sorted.reduce((s, b) => s + minutesBetween(b.start || "00:00", b.end || "00:00"), 0);
  if (total > DAY_CAP_MIN) issues.push({ kind: "over12h", text: t("issOver12h", { h: sumDur(total) }) });
  // (c) more than 2 boxes of one subject.
  const bySubj = {};
  sorted.forEach(b => { bySubj[b.subject] = (bySubj[b.subject] || 0) + 1; });
  Object.keys(bySubj).forEach(s => {
    if (bySubj[s] > 2) issues.push({ kind: "over2", text: t("issOver2Parts", { s: subjName(s) }) });
  });
  // (d) hardest lesson last.
  const hard = hardestSubject();
  if (hard && sorted.length) {
    const last = sorted[sorted.length - 1];
    if (last.subject === hard) issues.push({ kind: "hardest", text: t("issHardestLast", { s: subjName(hard) }) });
  }
  // (e) v1.11.37 (P3-7): a test box whose chapter has not been watched
  // yet — a warning only, never a block.
  sorted.forEach(b => {
    if (testBoxReady(b) === false) issues.push({ kind: "prereq", text: t("issPrereq", { t: b.title || "" }) });
  });
  // (f) v1.11.48 (I-8): sleep guard — a warning only, never a block.
  // The user deliberately keeps post-23:30 empty (sleep is his main
  // problem), so the day's latest-ending box ending after 23:30 warns
  // once, naming its end time. 01:00 (the study-day end) is past
  // 23:30 in study-day minutes, so one check covers both thresholds.
  if (sorted.length) {
    let latest = null, lastEnd = 0;
    sorted.forEach(b => {
      const e = studyDayMinutes(b.start || "00:00") + minutesBetween(b.start || "00:00", b.end || "00:00");
      if (e > lastEnd) { lastEnd = e; latest = b; }
    });
    if (latest && lastEnd > studyDayMinutes("23:30")) {
      issues.push({ kind: "lateNight", text: t("issLateNight", { t: fmtTimeFa(latest.end) }) });
    }
  }
  return issues;
}
function issuesHtml(issues) {
  if (!issues.length) return "";
  return '<div class="iss-warn"><b>' + esc(t("issTitle")) + '</b><ul>' +
    issues.map(i => '<li>' + esc(i.text) + '</li>').join('') + '</ul></div>';
}
// Live warnings inside the box edit modal: the edited box (with its
// current form values) against the rest of that study day.
function renderEditWarnings() {
  const wrap = document.getElementById("efWarnings");
  if (!wrap || !editingBoxId) { if (wrap) wrap.innerHTML = ""; return; }
  // v1.11.41: efDate is Jalali text now — dayIssues compares Gregorian
  // ISO dates, so convert first (an unparseable date clears, as before).
  const dateRaw = document.getElementById("efDate").value.trim();
  const date = parseJalaliInput(dateRaw);
  const start = document.getElementById("efStart").value || "09:00";
  const end = document.getElementById("efEnd").value || "10:30";
  const subject = document.getElementById("efSubject").value.trim();
  const title = document.getElementById("efTitle").value.trim();
  if (!date) { wrap.innerHTML = ""; return; }
  wrap.innerHTML = issuesHtml(dayIssues(date,
    { id: editingBoxId, date, start, end, subject: subject || "عمومی", title: title || "—" }, editingBoxId));
}
function wireEditWarnings() {
  ["efDate", "efStart", "efEnd", "efSubject", "efTitle"].forEach(id => {
    const el = document.getElementById(id);
    if (!el || el.dataset.issWired) return;
    el.dataset.issWired = "1";
    el.addEventListener("input", renderEditWarnings);
    el.addEventListener("change", renderEditWarnings);
  });
}
// Live warnings under the Program tab's add-box row: the would-be box
// against the selected day. Recomputed on every calendar render too,
// so a day change re-checks the same inputs.
function updateAddBoxWarnings() {
  const wrap = document.getElementById("addBoxWarn");
  if (!wrap) return;
  const title = (document.getElementById("newBoxTitle") || {}).value || "";
  if (!title.trim()) { wrap.innerHTML = ""; return; }
  // v1.11.41: the quick-add times are 24-hour text now — parse them
  // (an unparseable value falls back to the old defaults, as before).
  const start = parseTime24((document.getElementById("newBoxStart") || {}).value) || "09:00";
  const end = parseTime24((document.getElementById("newBoxEnd") || {}).value) || "10:30";
  const subject = resolveAddBoxSubject(title);
  wrap.innerHTML = issuesHtml(dayIssues(selectedDay,
    { id: "new", date: selectedDay, start, end, subject, title }));
}
// v1.11.24 (QA BUG-016): the add-box form derived the subject from the
// raw title with no validation — «مرور شیمی» became a phantom subject
// that exists nowhere else (no colour, no budget, no analytics row).
// A derived subject is accepted only when it is already a known
// subject (the user's list, the programme's subjects, or the
// general-subjects set); anything else falls back to «عمومی», the
// same fallback the empty title already used. Shared by the add
// handler and updateAddBoxWarnings so the warnings match the box
// that will actually be created.
function resolveAddBoxSubject(title) {
  const derived = (title || "").split(":")[0].split("—")[0].trim();
  if (!derived) return "عمومی";
  const known = new Set([...(state.subjects || []), ...DATA.boxes.map(b => b.subject)]);
  GENERAL_SUBJECTS.forEach(s => known.add(s));
  return known.has(derived) ? derived : "عمومی";
}
function wireAddBoxWarnings() {
  ["newBoxTitle", "newBoxStart", "newBoxEnd"].forEach(id => {
    const el = document.getElementById(id);
    if (!el || el.dataset.issWired) return;
    el.dataset.issWired = "1";
    el.addEventListener("input", updateAddBoxWarnings);
    el.addEventListener("change", updateAddBoxWarnings);
  });
}
wireAddBoxWarnings();

function renderCalendar() {
  // Programme note (1.7): the range is state-driven, so the note shows
  // the real range instead of the hardcoded Aban/Azar text. (Re-filled
  // on every render: applyStaticI18n would otherwise restore the raw
  // {from}/{to} template on a language switch.)
  const progNoteEl = document.querySelector('[data-i18n="progNote"]');
  if (progNoteEl) progNoteEl.textContent = t("progNote", {
    from: gregToJalali(programmeStart()).text, to: gregToJalali(programmeEnd()).text });
  const grid = document.getElementById("calGrid");
  grid.innerHTML = "";
  const byDay = {};
  // Calendar cells group by STUDY day: a box starting before 03:30
  // belongs to the previous study day and shows in that day's cell.
  // v1.11.9: orphaned (disconnected) boxes stay in the programme —
  // isCurrentBox() no longer filters them out.
  allBoxes().filter(isCurrentBox).forEach(b => { const sd = boxStudyDay(b) || b.date; (byDay[sd] = byDay[sd] || []).push(b); });
  const v = calViewMonth();
  // --- Compact navigation header (‹ month › + «امروز») ---
  const nav = document.createElement("div");
  nav.className = "cal-nav";
  const prevBtn = document.createElement("button");
  prevBtn.className = "cal-nav-btn";
  prevBtn.type = "button";
  prevBtn.textContent = "‹";
  prevBtn.setAttribute("aria-label", t("calPrevMonth"));
  prevBtn.addEventListener("click", () => calShiftMonth(-1));
  const nextBtn = document.createElement("button");
  nextBtn.className = "cal-nav-btn";
  nextBtn.type = "button";
  nextBtn.textContent = "›";
  nextBtn.setAttribute("aria-label", t("calNextMonth"));
  nextBtn.addEventListener("click", () => calShiftMonth(1));
  const label = document.createElement("div");
  label.className = "cal-nav-label";
  label.id = "calMonthLabel";
  label.textContent = calMonthLabel(v.jy, v.jm);
  const todayBtn = document.createElement("button");
  todayBtn.className = "btn cal-today-btn";
  todayBtn.type = "button";
  todayBtn.id = "calTodayBtn";
  todayBtn.textContent = t("calToday");
  todayBtn.disabled = calIsCurrentMonth();
  todayBtn.addEventListener("click", calGoToday);
  nav.appendChild(prevBtn); nav.appendChild(label); nav.appendChild(nextBtn); nav.appendChild(todayBtn);
  grid.appendChild(nav);
  // v1.11.43 (§17 idea 6): week strip above the month grid — Sat–Fri
  // of THIS week, each column box count / total hours / done %.
  // Click selects the day in the grid below.
  grid.appendChild(weekStripEl(byDay));
  // --- Month grid (real calendar dates) ---
  const firstIso = gregorianFromJalali(v.jy, v.jm, 1);
  const first = new Date(firstIso + "T12:00:00");
  const lead = (first.getDay() + 1) % 7; // Saturday-first week
  const dim = jalaliMonthLength(v.jy, v.jm);
  t("calDow").forEach(d => {
    const el = document.createElement("div"); el.className = "cal-dow"; el.textContent = d; grid.appendChild(el);
  });
  for (let i = 0; i < lead; i++)
    grid.appendChild(Object.assign(document.createElement("div"), { className: "cal-cell empty" }));
  for (let day = 1; day <= dim; day++) {
    const iso = addDays(firstIso, day - 1);
    const boxes = byDay[iso] || [];
    const done = boxes.filter(isDone).length;
    const inRange = iso >= programmeStart() && iso <= programmeEnd();
    const cell = document.createElement("button");
    cell.className = "cal-cell" + (iso === selectedDay ? " sel" : "") + (iso === TODAY ? " today" : "") +
      (isDayDone(iso) ? " day-done" : "");
    cell.disabled = !inRange; // days outside the programme have no boxes
    cell.innerHTML = '<div class="n">' + FA(day) + (isDayDone(iso) ? " ✓" : "") + '</div><div class="c">' +
      (boxes.length ? "<b>" + FA(done) + "/" + FA(boxes.length) + "</b> " + t("boxesWord") : "—") + "</div>";
    cell.addEventListener("click", () => { navigate({ tab: "program", day: iso }); });
    grid.appendChild(cell);
  }
  const j = gregToJalali(selectedDay);
  document.getElementById("calDayTitle").textContent =
    weekdayFa(selectedDay) + " " + j.text + " " + t("dayBoxesSuffix");
  const box = document.getElementById("calDayBoxes");
  box.innerHTML = "";
  const tickRow = document.createElement("div");
  tickRow.className = "day-tick-row";
  tickRow.appendChild(dayTickEl(selectedDay));
  if (isDayDone(selectedDay)) {
    const badge = document.createElement("span");
    badge.className = "done-badge";
    badge.textContent = t("doneBadge");
    tickRow.appendChild(badge);
  }
  box.appendChild(tickRow);
  const list = (byDay[selectedDay] || []).slice().sort(compareBoxOrder);
  if (!list.length) box.innerHTML += '<p class="muted">' + t("noBoxDay") + '</p>';
  list.forEach((b, i) => box.appendChild(partCard(b, i)));
  // (2.8) warnings for the selected day — only when there is something
  // to warn about; an empty day has no issues to show.
  const dayWarn = document.createElement("div");
  dayWarn.innerHTML = issuesHtml(dayIssues(selectedDay));
  if (dayWarn.firstChild) box.appendChild(dayWarn);
  updateAddBoxWarnings();
}
// v1.11.43 (§17 idea 6): the week strip for renderCalendar.
function weekStripEl(byDay) {
  const strip = document.createElement("div");
  strip.className = "week-strip";
  strip.id = "weekStrip";
  const head = document.createElement("div");
  head.className = "week-strip-title";
  head.textContent = t("weekStripTitle");
  strip.appendChild(head);
  const row = document.createElement("div");
  row.className = "week-strip-row";
  const d = new Date(TODAY + "T12:00:00");
  const sat = addDays(TODAY, -((d.getDay() + 1) % 7));
  const dows = t("calDow");
  for (let i = 0; i < 7; i++) {
    const iso = addDays(sat, i);
    const boxes = byDay[iso] || [];
    const done = boxes.filter(isDone).length;
    const mins = boxes.reduce((s, b) => s + minutesBetween(b.start || "00:00", b.end || "00:00"), 0);
    const col = document.createElement("button");
    col.type = "button";
    col.className = "week-col" + (iso === TODAY ? " today" : "") + (iso === selectedDay ? " sel" : "");
    col.innerHTML = '<span class="wc-day">' + esc(dows[i]) + ' ' + FA(gregToJalali(iso).day) + '</span>' +
      '<span class="wc-nums">' + FA(boxes.length) + ' ' + t("boxesWord") + ' · ' + fmtDurShort(mins) + '</span>' +
      '<span class="wc-pct">' + (boxes.length ? FA_PCT(done / boxes.length * 100) : "—") + '</span>';
    col.addEventListener("click", () => navigate({ tab: "program", day: iso }));
    row.appendChild(col);
  }
  strip.appendChild(row);
  return strip;
}

document.getElementById("addBoxBtn").addEventListener("click", async (ev) => {
  // v1.11.45 (F-09): the async create takes a round-trip — a second
  // click meanwhile created a second box. Disable until it returns.
  const _btn = ev && ev.currentTarget ? ev.currentTarget : document.getElementById("addBoxBtn");
  if (_btn.disabled) return;
  _btn.disabled = true;
  try {
  const title = document.getElementById("newBoxTitle").value.trim();
  if (!title) { alert(t("boxTitleAlert")); return; }
  const start = parseTime24(document.getElementById("newBoxStart").value) || "09:00";
  const end = parseTime24(document.getElementById("newBoxEnd").value) || "10:30";
  // v1.11.24 (QA BUG-016): a zero-length box used to be created here
  // (the edit form already rejects start == end). Same check, same
  // message as the edit form.
  if (start === end) { alert(t("edZeroLength")); return; }
  // v1.11.26 (QA BUG-036): same overnight confirm as the edit form —
  // the add form had the identical end < start hole.
  if (!confirmOvernight(start, end)) return;
  const subject = resolveAddBoxSubject(title);
  const isTest = /تست|تکلیف|آزمون/.test(title);
  const isClass = document.getElementById("newBoxClass").checked;
  // v1.11.31 (P1-10): create through POST /api/boxes/create — the
  // server validates and assigns the id. An explicit server error
  // aborts; an OK response without a box (or an unreachable server)
  // falls back to the old local creation, so the box is never lost.
  // v1.11.52 (F3): idempotent create (client_id + adopt on lost response).
  const created = await createBoxIdempotent({ title, date: selectedDay, start, end, subject, topic: title, is_test: isTest, tests_total: 0, note: "", type: isClass ? "class" : "normal" });
  let box = created.box, serverErr = created.serverErr;
  if (serverErr) { alert(errText(serverErr)); return; }
  if (!box) {
    box = {
      id: localBoxId(), date: selectedDay, start, end, subject, topic: title, title,
      is_test: isTest, tests_total: 0, note: "", type: isClass ? "class" : "normal"
    };
  }
  (state.custom_boxes = state.custom_boxes || []).push(box);
  if (isTest && Array.isArray(state.assignments)) {
    state.assignments.push({ id: "asg-" + box.id, boxId: box.id, type: "test" });
  }
  document.getElementById("newBoxTitle").value = "";
  document.getElementById("newBoxClass").checked = false;
  saveState(); renderAll();
  } finally { _btn.disabled = false; }
});

// ---- Past tab (audit §5 item 1.8): «گذشته» — undone past work on top,
// done past work below. The v1.6.0 rule ("the overdue list shows only
// DONE past parts") is superseded by 1.8: the undone list that used to
// hide at the bottom of the Analytics tab («بررسی گذشته») now lives
// here, on top, where the daily "what did I miss?" workflow finds it
// in one tap. The data is unchanged — both sections are views over the
// same boxes. Hiding an item still sets only a per-item flag
// (state.backlogHidden): the box stays in the programme, in history,
// and can be restored from the hidden section of this same tab
// (v1.11.31, P1-7).
function remainingRowEl(b, compact) {
  const tr = testOf(b);
  const total = b.tests_total || 0;
  const sd = boxStudyDay(b) || b.date;
  const row = document.createElement("div");
  row.className = "part " + (isDone(b) ? "done " : "") + colorClass(b.subject) + (boxConnected(b) ? "" : " has-cal-add");
  row.dataset.boxId = b.id;
  // v1.11.52 (I-2): the Past tab's «فشرده» view for done boxes — the
  // same one-line row as partCard (title + time + ✓); the checkbox
  // still unticks, and the tab-level toggle switches the whole list.
  if (compact) {
    row.classList.add("done-compact");
    row.innerHTML =
      '<input type="checkbox" checked aria-label="' + t("fDone") + '">' +
      '<div style="flex:1;min-width:0"><div class="part-title">' + esc(b.title) + '</div>' +
      '<div class="part-time">' + weekdayFa(sd) + ' ' + gregToJalali(sd).text + ' · ' + fmtTimeFa(b.start) + ' – ' + fmtTimeFa(b.end) + ' · ' + esc(subjName(b.subject)) + '</div></div>' +
      '<span class="done-mark" aria-hidden="true">✓</span>';
    row.querySelector('input[type="checkbox"]').addEventListener("change", (e) => {
      setDone(b, e.target.checked);
      saveState(); renderAll();
    });
    return row;
  }
  row.innerHTML =
    '<div class="part-top">' +
      '<input type="checkbox" ' + (isDone(b) ? "checked" : "") + ' aria-label="' + t("fDone") + '">' +
      '<div style="flex:1"><div class="part-title">' + esc(b.title) + '</div>' +
      '<div class="part-time">' + weekdayFa(sd) + ' ' + gregToJalali(sd).text + ' · ' + fmtTimeFa(b.start) + ' – ' + fmtTimeFa(b.end) + ' · ' + esc(subjName(b.subject)) + (isPinned(b) ? ' · ' + esc(t("pinnedNote")) : '') + '</div>' +
      '<div class="part-time">' + t("doneTestsLabel") + (total ? FA(tr.completed || 0) + " " + t("testsWord") + t("ofWord") + FA(total) : (b.is_test ? t("totalNotEntered2") : "—")) +
      '</div></div>' +
      // v1.11.37 (P3-4): calendar status as a pill in the title row.
      connStatusBoxHtml(b) + calAddToCalBtnHtml(b) +
    '</div>' +
    '<div class="part-actions"><button class="edit-btn">' + t("editBtn") + '</button>' +
    '<button class="hide-btn">' + t("hideFromBacklog") + '</button>' + boxMenuBtnHtml() + '</div>';
  row.querySelector('input[type="checkbox"]').addEventListener("change", (e) => {
    setDone(b, e.target.checked); // v1.11.30 (P1-1): stamps the tick date
    saveState(); renderAll();
  });
  row.querySelector(".part-actions .edit-btn").addEventListener("click", () => openEditBox(b));
  row.querySelector(".part-actions .hide-btn").addEventListener("click", () => {
    state.backlogHidden = state.backlogHidden || {};
    state.backlogHidden[b.id] = true;
    saveState(); renderAll();
  });
  wireBoxMenuBtn(row.querySelector(".menu-btn"), b);
  return row;
}
// ---------- Smart backlog-compensation suggestions (audit §5 item 2.6) ----------
// Score each undone past box = exam proximity × remaining tests ×
// (1 − accuracy); the top 3–5 get a concrete gap (first future light
// day) and a one-click move button. Boxes NEVER move automatically —
// only on the button tap, via the same state.edits path as the edit
// form (so the Google push sees the move like any other edit).
function nearestExamForSubject(subject) {
  const ups = upcomingExams(36500);
  const match = ups.find(ex => (ex.budget || []).some(s =>
    s.subject === subject || (s.subject || "").indexOf(subject) >= 0 ||
    (subject || "").indexOf(s.subject || "") >= 0 ||
    (bookOfSubject(s.subject) && bookOfSubject(s.subject) === bookOfSubject(subject))));
  return match || nearestExam();
}
function intervalsOverlap(aStart, aEnd, bStart, bEnd) {
  const a0 = studyDayMinutes(aStart), a1 = a0 + minutesBetween(aStart, aEnd);
  const b0 = studyDayMinutes(bStart), b1 = b0 + minutesBetween(bStart, bEnd);
  return a0 < b1 && b0 < a1;
}
function addMinutes(time, mins) {
  const parts = String(time || "00:00").split(":").map(Number);
  const total = ((parts[0] || 0) * 60 + (parts[1] || 0) + mins) % 1440;
  return String(Math.floor(total / 60)).padStart(2, "0") + ":" + String(total % 60).padStart(2, "0");
}
// First future light day for this box, as {studyDay, date, start, end}.
// A day qualifies when it has fewer than 2 boxes of the box's subject
// (the user's own max-2-parts rule) and the day stays within 12h of
// planned time with this box added. The box keeps its clock time when
// free; otherwise it goes right after the last box of that study day.
// `date` is the CALENDAR date to store (a box starting before 03:30
// belongs to the previous study day, so its calendar date is studyDay+1);
// `studyDay` is the day the user sees. Returns null when no day in the
// next 14 days qualifies.
//
// Tests before reviews (3.6c, the user's own rule): a test box that
// would land after a review box is placed in the earliest free slot
// ending before the first review box instead; a review box sitting
// before a test box that day goes after the last box. When no such slot
// exists the usual placement applies — the rule is a preference, never
// a refusal.
function isReviewBox(b) { return /مرور/.test(b.title || ""); }
function clockFromStudyMinutes(m) {
  const total = (((m + 210) % 1440) + 1440) % 1440;
  return String(Math.floor(total / 60)).padStart(2, "0") + ":" + String(total % 60).padStart(2, "0");
}
// Earliest free slot (study-day minutes) of `dur` minutes ending no
// later than `before` (study-day minutes, exclusive). Null when none.
function earliestFreeSlot(sorted, dur, before) {
  const limit = before == null ? 1440 : before;
  let cursor = 0;
  for (const b of sorted) {
    const bs = studyDayMinutes(b.start), be = bs + minutesBetween(b.start || "00:00", b.end || "00:00");
    if (bs - cursor >= dur && cursor + dur <= limit) return cursor;
    cursor = Math.max(cursor, be);
  }
  if (cursor + dur <= limit && cursor + dur <= 1440) return cursor;
  return null;
}
function placeAfterLast(sorted, dur) {
  if (!sorted.length) return null;
  // v1.11.29 (PI-03): 03:30 is the END of the study day — studyDayMinutes
  // maps it to 0, so a box ending exactly at 03:30 compared as "first",
  // not "last". Treat it as 1440 (end of day) for the ranking and the
  // fit check, so it can never be chosen as the last box's end.
  const endKey = t => { const m = studyDayMinutes(t); return m === 0 ? 1440 : m; };
  const start = sorted.reduce((m, b) => endKey(b.end) > endKey(m) ? b.end : m, sorted[0].end);
  if (endKey(start) + dur > 1440) return null; // would cross the 03:30 study-day end
  return { start, end: addMinutes(start, dur) };
}
// v1.11.32 (P2-1): the per-day gap search, extracted unchanged from
// findGapDay so the close-day «به فردا» choice can try exactly one
// day (tomorrow) with the same rules — max 2 parts of a subject,
// 14h daily cap (DAY_CAP_MIN), tests before reviews, no overlaps. Returns
// { studyDay, date, start, end } or null when the day cannot take
// the box. The stored calendar date must really land the box on
// study day d.
function gapForDay(box, d) {
  const dur = minutesBetween(box.start || "00:00", box.end || "00:00") || 60;
  const dayBoxes = allBoxes().filter(b => boxStudyDay(b) === d);
  if (dayBoxes.filter(b => b.subject === box.subject).length >= 2) return null;
  const totalMins = dayBoxes.reduce((s, b) => s + minutesBetween(b.start || "00:00", b.end || "00:00"), 0);
  if (totalMins + dur > DAY_CAP_MIN) return null;
  const sorted = dayBoxes.slice().sort((a, b) => studyDayMinutes(a.start) - studyDayMinutes(b.start));
  const isTest = boxActivityType(box) === "test";
  const isReview = isReviewBox(box);
  const firstReview = sorted.find(b => isReviewBox(b));
  let start = box.start, end = box.end;
  const overlaps = dayBoxes.some(b => intervalsOverlap(start, end, b.start, b.end));
  if (isTest && firstReview && studyDayMinutes(start) >= studyDayMinutes(firstReview.start)) {
    const slot = earliestFreeSlot(sorted, dur, studyDayMinutes(firstReview.start));
    if (slot != null) { start = clockFromStudyMinutes(slot); end = addMinutes(start, dur); }
    else if (overlaps) {
      const after = placeAfterLast(sorted, dur);
      if (!after) return null;
      start = after.start; end = after.end;
    }
  } else if (isReview && !overlaps && sorted.some(b => boxActivityType(b) === "test" && studyDayMinutes(b.start) > studyDayMinutes(start))) {
    const after = placeAfterLast(sorted, dur);
    if (!after) return null;
    start = after.start; end = after.end;
  } else if (overlaps) {
    const after = placeAfterLast(sorted, dur);
    if (!after) return null;
    start = after.start; end = after.end;
  }
  const calDate = boxStudyDay({ date: d, start }) === d ? d : addDays(d, 1);
  return { studyDay: d, date: calDate, start, end };
}
function findGapDay(box) {
  const horizon = addDays(TODAY, 14);
  for (let d = addDays(TODAY, 1); d <= horizon; d = addDays(d, 1)) {
    const gap = gapForDay(box, d);
    if (gap) return gap;
  }
  return null;
}
// Close-day «به فردا»: the same gap search, restricted to tomorrow.
function gapTomorrow(box) {
  return gapForDay(box, addDays(TODAY, 1));
}
// v1.11.43 (§17 idea 3): the 14-hour daily cap the user set on 25 Nov
// — the compensation preview shows the destination day total against it.
const DAY_CAP_MIN = 14 * 60;
// The open compensation preview, if any: { kind: "single", s } or
// { kind: "all", items: [{ box, gap }] }. Cleared BEFORE any move so
// the preview cannot reappear after the move re-renders.
let sugPreview = null;
function backlogSuggestions(limit) {
  const undone = allBoxes().filter(b => !isDone(b) && (boxStudyDay(b) || b.date) < TODAY && !(state.backlogHidden || {})[b.id]);
  // v1.11.37 (P3-7): compensation never suggests a test for a chapter
  // whose viewing box is not ticked yet. Non-test boxes and tests with
  // no identifiable chapter are unaffected (testBoxReady returns null
  // for them); an unready test is dropped from the suggestions only —
  // the box itself stays where the user placed it.
  const ready = undone.filter(b => testBoxReady(b) !== false);
  const scored = ready.map(b => {
    const tr = testOf(b);
    let rem = Math.max(0, (b.tests_total || 0) - (tr.completed || 0));
    let acc = (tr.completed || 0) > 0 ? (tr.correct || 0) / tr.completed : null;
    const tid = linkedTopicIdCached(b);
    if (tid) {
      const found = topicById(tid);
      if (found) {
        const s = topicStats(found.topic);
        if (rem === 0 && s.remaining != null) rem = s.remaining;
        if (acc == null && s.solved > 0) acc = s.correct / s.solved;
      }
    }
    const accKnown = acc != null;
    if (!accKnown) acc = 0.5; // unknown accuracy: neutral weight, never zero
    const ex = nearestExamForSubject(b.subject);
    const dl = ex ? Math.max(1, examDaysLeft(ex)) : 365;
    return { box: b, score: (1 / dl) * Math.max(1, rem) * (1 - acc), rem, acc, accKnown, exam: ex };
  });
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, limit || 5)
    .map(s => ({ box: s.box, score: s.score, rem: s.rem, acc: s.acc, accKnown: s.accKnown,
                 exam: s.exam, gap: findGapDay(s.box) }))
    .filter(s => s.gap);
}
function moveBoxToGapSilent(box, gap) {
  if (!box || !gap) return false;
  if (box.id.startsWith("custom-")) {
    const cb = (state.custom_boxes || []).find(x => x.id === box.id);
    if (!cb) return false;
    Object.assign(cb, { date: gap.date, start: gap.start, end: gap.end });
  } else {
    // v1.11.50: guard the overlay write (a null map threw here).
    state.edits = state.edits || {};
    state.edits[box.id] = Object.assign({}, state.edits[box.id],
      { date: gap.date, start: gap.start, end: gap.end });
  }
  return true;
}
// v1.11.31 (P1-10): move through POST /api/boxes/update — the server
// is the single validation reference. An explicit server error aborts
// (and is shown); an OK response without a box (or an unreachable
// server) falls back to the old silent local move.
async function moveBoxToGapAsync(box, gap) {
  if (!box || !gap) return false;
  let serverBox = null, serverErr = null;
  try {
    const r = await boxApiPost("/api/boxes/update", { id: box.id, date: gap.date, start: gap.start, end: gap.end });
    if (r.ok && r.data && r.data.box) serverBox = r.data.box;
    else if (!r.ok) serverErr = (r.data && r.data.error) || "";
  } catch (e) { /* unreachable: fall through to the local move */ }
  if (serverErr) { alert(errText(serverErr)); return false; }
  if (serverBox) return applyServerBox(serverBox);
  return moveBoxToGapSilent(box, gap);
}
function moveBoxToGap(box, gap) {
  moveBoxToGapAsync(box, gap).then(ok => { if (ok) { saveState(); renderAll(); } });
  return true;
}
// Smart scheduling (audit §5 item 3.6c): apply ALL catch-up suggestions
// at once, with one explicit confirmation. Each gap is recomputed fresh
// (a move changes the day's load), and a suggestion whose gap vanished
// is skipped and reported — nothing ever moves silently.
// Apply all suggestions at once — the same loop as the single move:
// gaps are recomputed fresh, a suggestion whose gap vanished is
// skipped and reported. (v1.11.43: the confirm() is gone — the
// all-preview is the confirmation.)
async function applyAllSuggestions() {
  const sug = backlogSuggestions(5);
  if (!sug.length) return;
  // v1.11.52 (I-6): remember the pre-apply backup before moving anything.
  const undoPoint = await bulkUndoPoint();
  let moved = 0, skipped = 0;
  for (const s of sug) {
    const gap = findGapDay(s.box);
    if (!gap || !(await moveBoxToGapAsync(s.box, gap))) { skipped++; continue; }
    moved++;
  }
  saveState(); renderAll();
  bulkUndoToast(undoPoint, moved ? t("sugApplied", { n: FA(moved) }) : t("sugApplyNone"));
}
// ---------- Stage report (v1.11.52, P-5) ----------
// One printable page per exam: weighted readiness per subject,
// weakest topics, tests remaining + required speed (examForecast),
// previous results of the same category, top 5 compensation
// suggestions. Built from the existing functions — no new data is
// invented, and no rank is estimated (a stored rank of a past exam
// is shown as stored, never computed).
function examReadinessBySubject(ex) {
  const bySubj = {};
  (ex.budget || []).forEach(s => (s.chapters || []).forEach(ch =>
    (ch.topics || []).forEach(tp => {
      const r = bySubj[s.subject] = bySubj[s.subject] || { subject: s.subject, total: 0, done: 0, studying: 0, doneW: 0, totalW: 0, anyWeight: false };
      const p = budgetTopicProgress(s.subject, tp.name, tp.subtopics, topicLinks(tp));
      const w = (typeof tp.questions === "number" && tp.questions > 0) ? tp.questions : 1;
      if (typeof tp.questions === "number" && tp.questions > 0) r.anyWeight = true;
      r.total++; r.totalW += w;
      if (p.state === "done") { r.done++; r.doneW += w; }
      else if (p.state === "studying") r.studying++;
    })));
  return Object.keys(bySubj).map(k => {
    const r = bySubj[k];
    r.pct = r.anyWeight ? Math.round(r.doneW / r.totalW * 100) : null;
    return r;
  });
}
function examWeakestTopics(ex, n) {
  const rows = [];
  (ex.budget || []).forEach(s => (s.chapters || []).forEach(ch =>
    (ch.topics || []).forEach(tp => {
      const p = budgetTopicProgress(s.subject, tp.name, tp.subtopics, topicLinks(tp));
      if (p.state === "not" || p.state === "nolink")
        rows.push({ subject: s.subject, chapter: ch.name, name: tp.name, state: p.state });
    })));
  // Not started first, then not linked yet; budget order inside each.
  rows.sort((a, b) => (a.state === b.state ? 0 : a.state === "not" ? -1 : 1));
  return rows.slice(0, n || 5);
}
function examPrevResults(ex) {
  return (state.exams[ex.group] || [])
    .filter(x => x.id !== ex.id && x.result && x.date && x.date < (ex.date || "9999"))
    .sort((a, b) => (b.date || "").localeCompare(a.date || ""));
}
function stageReportHtml(ex) {
  const readiness = examReadinessBySubject(ex);
  const weak = examWeakestTopics(ex, 5);
  const f = examForecast(ex);
  const prev = examPrevResults(ex);
  const plan = examCompensationPlan(ex);
  const suggestions = plan ? plan.suggestions : backlogSuggestions(5);
  let html = '<div class="sr-head"><h2>' + esc(t("stageReportTitle")) + ' — ' + esc(examDisplayName(ex)) + '</h2>' +
    '<div class="sr-meta">' + esc(examDateText(ex)) + ' · ' + esc(examTypeLabel(ex.type)) + ' · ' + esc(examGroupLabel(ex)) + '</div>' +
    '<div class="sr-actions"><button type="button" class="btn btn-primary sr-print">' + esc(t("stagePrint")) + '</button>' +
    '<button type="button" class="btn sr-close">' + esc(t("closeBtn")) + '</button></div></div>';
  html += '<div class="sr-sec"><h3>' + esc(t("exReadiness")) + '</h3>';
  if (!readiness.length) html += '<p class="muted">' + esc(t("exNoBudget")) + '</p>';
  else html += readiness.map(r => {
    // v1.11.63 (Batch 4, م-۵): an adjustable target percentage next to
    // each subject (default 80%) + the gap to it, in one short line.
    const target = examTarget(ex.id, r.subject);
    const pct = (r.pct != null) ? r.pct : Math.round((r.done || 0) / Math.max(1, r.total) * 100);
    const gap = target - pct;
    return '<div class="sr-row"><span>' + esc(subjName(r.subject)) + '</span><b>' +
    FA(r.done) + '/' + FA(r.total) + ' · ' + (r.pct == null ? "—" : FA_PCT(r.pct)) + '</b>' +
    '<label class="sr-target">' + esc(t("exTargetLabel")) + ' <input type="number" min="0" max="100" class="sr-target-input" data-subj="' + esc(r.subject) + '" value="' + target + '">' + (LANG === "en" ? "%" : "٪") + '</label>' +
    (gap > 0 ? '<span class="sr-target-gap">' + esc(t("exTargetGapShort", { n: FA(gap) })) + '</span>' : '') + '</div>';
  }).join("");
  html += '</div>';
  html += '<div class="sr-sec"><h3>' + esc(t("stageWeakTopics")) + '</h3>';
  if (!weak.length) html += '<p class="muted">' + esc(t("stageNoWeak")) + '</p>';
  else html += '<ul class="sr-list">' + weak.map(w =>
    '<li>' + esc(subjName(w.subject)) + ' — ' + esc(w.chapter || "") + ' — ' + esc(w.name) +
    (w.state === "nolink" ? ' (' + esc(t("exProgNoLink")) + ')' : '') + '</li>').join("") + '</ul>';
  html += '</div>';
  html += '<div class="sr-sec"><h3>' + esc(t("fcTitle")) + '</h3>';
  if (!f) html += '<p class="muted">' + esc(t("stageNoForecast")) + '</p>';
  else {
    const verdictKey = { onTrack: "fcVerdictOnTrack", behind: "fcVerdictBehind",
                         impossible: "fcVerdictImpossible", unknown: "fcVerdictUnknown" }[f.verdict];
    html += '<div class="sr-row"><span>' + esc(t("fcTestsLeft")) + '</span><b>' +
      (f.hasCounts ? FA(f.remTests) + ' ' + esc(t("testsWord")) : esc(t("fcEnterCounts"))) + '</b></div>' +
      '<div class="sr-row"><span>' + esc(t("fcTestsPerDay")) + '</span><b>' +
      (f.needTests === Infinity ? "—" : FA(Math.round(f.needTests)) + ' ' + esc(t("testsWord"))) + '</b></div>' +
      '<div class="sr-row"><span>' + esc(t("fcHoursLeft")) + '</span><b>' + esc(sumDur(f.remMinutes)) + '</b></div>' +
      '<div class="sr-row"><span>' + esc(t("fcHoursPerDay")) + '</span><b>' +
      (f.needMinutes === Infinity ? "—" : esc(sumDur(Math.round(f.needMinutes)))) + '</b></div>' +
      '<div class="sr-row"><span>' + esc(t("fcTitle")) + '</span><b>' + esc(t(verdictKey)) + '</b></div>';
  }
  html += '</div>';
  html += '<div class="sr-sec"><h3>' + esc(t("stagePrevResults")) + '</h3>';
  if (!prev.length) html += '<p class="muted">' + esc(t("stageNoPrev")) + '</p>';
  else html += '<table class="sess-table"><thead><tr><th>' + esc(t("stageColExam")) + '</th><th>' + esc(t("stageColDate")) + '</th><th>' + esc(t("exTaraz")) + '</th><th>' + esc(t("exCorrect")) + ' / ' + esc(t("exWrong")) + ' / ' + esc(t("exUnanswered")) + '</th></tr></thead><tbody>' +
    prev.map(p => '<tr><td>' + esc(examDisplayName(p)) + '</td><td>' + esc(examDateText(p)) + '</td><td>' +
      (p.result.taraz != null ? FA(p.result.taraz) : "—") + '</td><td>' +
      FA(p.result.correct || 0) + ' / ' + FA(p.result.wrong || 0) + ' / ' + FA(p.result.unanswered || 0) + '</td></tr>').join("") + '</tbody></table>';
  html += '</div>';
  html += '<div class="sr-sec"><h3>' + esc(t("exPlanSuggestions")) + '</h3>';
  if (!suggestions.length) html += '<p class="muted">' + esc(t("stageNoSuggestions")) + '</p>';
  else html += '<ul class="sr-list">' + suggestions.map(s =>
    '<li>' + esc(s.box.title) + ' · ' + esc(gregToJalali(boxStudyDay(s.box) || s.box.date).text) + '</li>').join("") + '</ul>';
  html += '</div>';
  return html;
}
function openStageReport(exId) {
  const ex = findExam(exId);
  if (!ex) return;
  const ov = document.getElementById("stageReportOverlay");
  const inner = document.getElementById("stageReportInner");
  if (!ov || !inner) return;
  inner.innerHTML = stageReportHtml(ex);
  inner.querySelector(".sr-print").addEventListener("click", printStageReport);
  inner.querySelector(".sr-close").addEventListener("click", closeStageReport);
  // v1.11.63 (Batch 4, م-۵): the stage target is editable here — a
  // plain number (0-100), clamped, saved to state.examTargets.
  inner.querySelectorAll(".sr-target-input").forEach(inp => inp.addEventListener("change", () => {
    let v = parseInt(inp.value, 10);
    if (isNaN(v)) v = 80;
    v = Math.max(0, Math.min(100, v));
    inp.value = v;
    const m = (state.examTargets = state.examTargets || {});
    const cur = m[ex.id] || (m[ex.id] = {});
    cur[inp.dataset.subj] = v;
    saveState(); renderAll();
  }));
  ov.onclick = (e) => { if (e.target === ov) closeStageReport(); };
  ov.hidden = false;
}
function closeStageReport() {
  const ov = document.getElementById("stageReportOverlay");
  if (ov) ov.hidden = true;
  document.body.classList.remove("printing-stage-report");
}
function printStageReport() {
  document.body.classList.add("printing-stage-report");
  const done = () => document.body.classList.remove("printing-stage-report");
  window.addEventListener("afterprint", done, { once: true });
  window.print();
}

// ---------- Close the day (v1.11.32, P2-1) ----------
// The button sits at the BOTTOM of today's list, not the top: a
// one-page summary (planned / done / real / useful + unfinished
// boxes) and, for each unfinished box, three choices — «به فردا»
// (the same gap rules as findGapDay, restricted to tomorrow),
// «به اولین روز خالی» (findGapDay), «پنهان کن». On confirm the day
// flag is COMPUTED from the boxes that remain on the day (hidden
// ones no longer count) and recorded in state.daysDone — never set
// by hand, never fabricated.
function closeDaySummary(date) {
  const list = allBoxes().filter(b => boxStudyDay(b) === date && isCurrentBox(b)).sort(compareBoxOrder);
  const doneBoxes = list.filter(isDone).length;
  const planned = list.reduce((s, b) => s + minutesBetween(b.start || "00:00", b.end || "00:00"), 0);
  const tests = list.reduce((s, b) => s + (testOf(b).completed || 0), 0);
  let real = 0, useful = 0, usefulRecorded = false;
  list.forEach(b => {
    real += timerTotalSeconds(b.id);
    const u = usefulTotalSeconds(b.id);
    if (u > 0) { useful += u; usefulRecorded = true; }
  });
  return { list, doneBoxes, planned, tests, real, useful, usefulRecorded,
           unfinished: list.filter(b => !isDone(b)) };
}
let closeDayChoices = {};
function openCloseDay(date) {
  const s = closeDaySummary(date);
  closeDayChoices = {};
  const body = document.getElementById("closeDayBody");
  let html = '<p>' + t("summaryLine", { done: FA(s.doneBoxes), total: FA(s.list.length), tests: FA(s.tests) }) + '</p>' +
    '<p class="muted">' + esc(t("sumRealTime")) + ': ' + (s.real > 0 ? fmtDurationFa(Math.round(s.real / 60)) : "—") +
    ' · ' + esc(t("sumUsefulTime")) + ': ' + (s.usefulRecorded ? fmtDurationFa(Math.round(s.useful / 60)) : t("tmUsefulNotRecorded")) + '</p>';
  if (!s.unfinished.length) {
    html += '<p>' + esc(t("cdAllDone")) + '</p>';
  } else {
    html += '<h3>' + esc(t("closeDayUnfinished")) + '</h3>';
    s.unfinished.forEach(b => {
      const gT = gapTomorrow(b);
      const gF = gT ? null : findGapDay(b);
      const def = gT ? "tomorrow" : (gF ? "firstGap" : "hide");
      closeDayChoices[b.id] = def;
      html += '<div class="cd-row"><div class="cd-box"><div class="part-title">' + esc(b.title) + '</div>' +
        '<div class="part-time">' + fmtTimeFa(b.start) + ' – ' + fmtTimeFa(b.end) + ' · ' + esc(subjName(b.subject)) + '</div></div>' +
        '<div class="cd-choices">' +
        '<label><input type="radio" name="cd-' + esc(b.id) + '" value="tomorrow"' + (def === "tomorrow" ? " checked" : "") + (gT ? "" : " disabled") + '> ' + esc(t("cdToTomorrow")) + (gT ? "" : " (" + esc(t("cdNoTomorrow")) + ")") + '</label>' +
        '<label><input type="radio" name="cd-' + esc(b.id) + '" value="firstGap"' + (def === "firstGap" ? " checked" : "") + (gF ? "" : " disabled") + '> ' + esc(t("cdToFirstGap")) + (gF ? " (" + esc(gregToJalali(gF.studyDay).text) + ")" : " (" + esc(t("cdNoGap")) + ")") + '</label>' +
        '<label><input type="radio" name="cd-' + esc(b.id) + '" value="hide"' + (def === "hide" ? " checked" : "") + '> ' + esc(t("cdHide")) + '</label>' +
        '</div></div>';
    });
  }
  // v1.11.62 (Batch 3, ب-۵ + م-۳): the two low-volume night rows.
  // (1) Error-notebook review — ONLY every other night, per the user's
  // own rule (every other night, last 30 min, review the error
  // notebook). Derived from the last recorded review date; never
  // recorded yet -> show it the first time.
  const lastRev = state.lastErrorReview || null;
  const isReviewNight = !lastRev || Math.round((new Date(date + "T12:00:00") - new Date(lastRev + "T12:00:00")) / 86400000) >= 2;
  if (isReviewNight) {
    html += '<div class="cd-review"><h3>' + esc(t("cdReviewTitle")) + '</h3>' +
      '<div class="form-row"><button class="btn btn-primary" id="cdReviewOpenBtn">' + esc(t("cdReviewOpen")) + '</button>' +
      '<button class="btn" id="cdReviewedBtn">' + esc(t("cdReviewed")) + '</button></div></div>';
  }
  // (2) Sleep — ONE shared time field: tonight's «ساعت خواب امشب»
  // (ب-۵) IS the «دیشب چه ساعتی خوابیدی؟» input (م-۳): the value
  // entered tonight is last night's sleep time when read tomorrow.
  // The wake field records this morning's wake-up against last
  // night's entry. Both prefill from the stored log.
  const slog = state.sleepLog || {};
  const prevDay = addDays(date, -1);
  const tonight = slog[date] || {};
  const lastNight = slog[prevDay] || {};
  html += '<div class="form-row"><label><span>' + esc(t("cdSleepTonight")) + '</span>' +
    '<input type="time" id="cdSleepInput" value="' + esc(tonight.sleep || "") + '"></label>' +
    '<label><span>' + esc(t("cdWakeToday")) + '</span>' +
    '<input type="time" id="cdWakeInput" value="' + esc(lastNight.wake || "") + '"></label></div>';
  // v1.11.41 (UI-audit batch 1): the Apply/Cancel buttons live in the
  // modal's static sticky footer (index.html) now — the body only
  // renders the choices, so the buttons can never scroll out of view.
  body.innerHTML = html;
  const revOpen = document.getElementById("cdReviewOpenBtn");
  if (revOpen) revOpen.addEventListener("click", () => {
    // Opening the notebook from the modal counts as tonight's review.
    state.lastErrorReview = date;
    saveState();
    closeCloseDay();
    navigate({ tab: "testbook" });
    setTimeout(() => {
      const nb = document.getElementById("errNbBlock");
      if (nb) nb.scrollIntoView();
    }, 150);
  });
  const revDone = document.getElementById("cdReviewedBtn");
  if (revDone) revDone.addEventListener("click", () => {
    state.lastErrorReview = date;
    saveState();
    const row = revDone.closest(".cd-review");
    if (row) row.style.display = "none";
    showToast(t("toastSaved"));
  });
  body.querySelectorAll('input[type="radio"]').forEach(r => r.addEventListener("change", () => {
    closeDayChoices[r.name.slice(3)] = r.value;
  }));
  // onclick assignment (not addEventListener): openCloseDay runs on
  // every open, and the static footer buttons must not stack handlers.
  document.getElementById("closeDayApplyBtn").onclick = () => applyCloseDay(date);
  document.getElementById("closeDayCancelBtn").onclick = closeCloseDay;
  document.getElementById("closeDayModal").classList.add("open");
}
function closeCloseDay() {
  document.getElementById("closeDayModal").classList.remove("open");
}
async function applyCloseDay(date) {
  const s = closeDaySummary(date);
  for (const b of s.unfinished) {
    const choice = closeDayChoices[b.id] || "hide";
    if (choice === "tomorrow" || choice === "firstGap") {
      const gap = choice === "tomorrow" ? gapTomorrow(b) : findGapDay(b);
      // A move changes the day's load, so the next gap is computed
      // fresh — drop the memoized box list after each successful move.
      if (gap && await moveBoxToGapAsync(b, gap)) RENDER_CACHE = null;
    } else {
      state.backlogHidden = state.backlogHidden || {};
      state.backlogHidden[b.id] = true;
    }
  }
  // The flag is COMPUTED from the boxes that remain on the day
  // (hidden ones no longer count): all done -> the day is complete.
  // v1.11.62 (Batch 3, م-۳): persist tonight's sleep time and this
  // morning's wake time into the sleep log (an empty field clears
  // that value). Guarded on the inputs existing — applyCloseDay must
  // never wipe the log when the modal is not open.
  const sleepEl = document.getElementById("cdSleepInput");
  const wakeEl = document.getElementById("cdWakeInput");
  if (sleepEl || wakeEl) {
    state.sleepLog = state.sleepLog || {};
    const setSleepField = (d, f, v) => {
      if (v && isValidBoxTime(v)) {
        state.sleepLog[d] = Object.assign({}, state.sleepLog[d], { [f]: v });
      } else if (state.sleepLog[d]) {
        delete state.sleepLog[d][f];
        if (!state.sleepLog[d].sleep && !state.sleepLog[d].wake) delete state.sleepLog[d];
      }
    };
    if (sleepEl) setSleepField(date, "sleep", sleepEl.value || "");
    if (wakeEl) setSleepField(addDays(date, -1), "wake", wakeEl.value || "");
  }
  const remaining = allBoxes().filter(b => boxStudyDay(b) === date && isCurrentBox(b) && !(state.backlogHidden || {})[b.id]);
  state.daysDone = state.daysDone || {};
  if (remaining.length && remaining.every(isDone)) state.daysDone[date] = true;
  else delete state.daysDone[date];
  saveState();
  closeCloseDay();
  renderAll();
  showToast(t("toastSaved")); // v1.11.41: closing the day used to be silent
}
// Destination-day total: the boxes already on that study day plus
// the extra minutes of the box(es) being moved there.
function sugDayTotal(dayIso, extraMins) {
  let mins = extraMins || 0;
  allBoxes().forEach(b => {
    if (boxStudyDay(b) === dayIso) mins += minutesBetween(b.start || "00:00", b.end || "00:00");
  });
  return mins;
}
// v1.11.43 (§17 idea 3): the compensation preview panel — the
// destination day, its boxes, the moved box in a different colour and
// the day total against the 14h cap — BEFORE confirming a backlog
// move. The single preview shows the full day; the all-preview lists
// each planned move with its resulting day total (cumulative when
// several moves land on the same day).
function sugPreviewPanel() {
  if (!sugPreview) return null;
  const panel = document.createElement("div");
  panel.className = "sug-preview";
  panel.id = "sugPreview";
  const cancel = document.createElement("button");
  cancel.className = "btn";
  cancel.textContent = t("sugPreviewCancel");
  cancel.addEventListener("click", () => { sugPreview = null; renderAll(); });
  if (sugPreview.kind === "single") {
    const s = sugPreview.s;
    const day = s.gap.studyDay;
    const dayBoxes = allBoxes().filter(b => boxStudyDay(b) === day).sort(compareBoxOrder);
    const total = sugDayTotal(day, minutesBetween(s.box.start || "00:00", s.box.end || "00:00"));
    panel.innerHTML = '<h4>' + esc(t("sugPreviewTitle")) + '</h4>' +
      '<p class="muted">' + esc(gregToJalali(day).text) + ' · ' + esc(t("sugPreviewDayTotal", { total: fmtDurationFa(total), cap: fmtDurationFa(DAY_CAP_MIN) })) + '</p>' +
      '<div class="sug-preview-day">' +
      dayBoxes.map(b => '<div class="sug-preview-row"><span>' + esc(fmtTimeFa(b.start) + ' – ' + fmtTimeFa(b.end)) + '</span> <span>' + esc(b.title) + '</span></div>').join("") +
      '<div class="sug-preview-row sug-preview-moved"><span>' + esc(fmtTimeFa(s.gap.start) + ' – ' + fmtTimeFa(s.gap.end)) + '</span> <span>' + esc(s.box.title) + '</span> <span class="sug-preview-tag">' + esc(t("sugPreviewMoved")) + '</span></div>' +
      '</div>';
    const ok = document.createElement("button");
    ok.className = "btn btn-primary";
    ok.textContent = t("sugPreviewConfirm");
    ok.addEventListener("click", () => {
      // v1.11.45 (F-08): the preview survives re-renders, so the slot
      // captured at suggestion time may be taken by now — recompute
      // the gap fresh (same as applyAllSuggestions) and abort with a
      // toast when no gap remains, instead of creating an overlap.
      const ss = sugPreview.s;
      const gap = gapForDay(ss.box, ss.gap.studyDay) || findGapDay(ss.box);
      if (!gap) { showToast(t("cdNoGap"), { kind: "err", ms: 4000 }); return; }
      sugPreview = null; moveBoxToGap(ss.box, gap);
    });
    panel.appendChild(ok);
  } else {
    const added = {};
    const rows = sugPreview.items.map(it => {
      const day = it.gap.studyDay;
      added[day] = (added[day] || 0) + minutesBetween(it.box.start || "00:00", it.box.end || "00:00");
      const total = sugDayTotal(day, added[day]);
      return '<div class="sug-preview-row"><span>' + esc(it.box.title) + '</span> <span class="muted">→ ' + esc(gregToJalali(day).text) + ' · ' + esc(t("sugPreviewDayTotal", { total: fmtDurationFa(total), cap: fmtDurationFa(DAY_CAP_MIN) })) + '</span></div>';
    }).join("");
    panel.innerHTML = '<h4>' + esc(t("sugPreviewAllTitle")) + '</h4>' + rows;
    const ok = document.createElement("button");
    ok.className = "btn btn-primary";
    ok.textContent = t("sugPreviewAllConfirm");
    ok.addEventListener("click", () => { sugPreview = null; applyAllSuggestions(); });
    panel.appendChild(ok);
  }
  panel.appendChild(cancel);
  return panel;
}
function renderBacklogSuggestions(wrap) {
  const sug = backlogSuggestions(5);
  const block = document.createElement("div");
  block.className = "sug-block";
  block.id = "pastSuggest";
  const head = document.createElement("div");
  head.className = "sug-head";
  const title = document.createElement("h3");
  title.textContent = t("sugTitle");
  head.appendChild(title);
  if (sug.length) {
    const allBtn = document.createElement("button");
    allBtn.className = "btn";
    allBtn.textContent = t("sugApplyAll");
    // v1.11.43 (§17 idea 3): opens the all-preview; its confirm calls
    // applyAllSuggestions (no second confirm dialog — the preview IS it).
    allBtn.addEventListener("click", () => {
      const sug = backlogSuggestions(5);
      if (!sug.length) return;
      sugPreview = { kind: "all", items: sug.map(x => ({ box: x.box, gap: x.gap })) };
      renderAll();
    });
    head.appendChild(allBtn);
  }
  block.appendChild(head);
  if (!sug.length) {
    const p = document.createElement("p");
    p.className = "muted";
    p.textContent = t("sugNone");
    block.appendChild(p);
  } else {
    sug.forEach(s => {
      const row = document.createElement("div");
      row.className = "trow topic sug-row";
      row.dataset.box = s.box.id;
      row.innerHTML = '<span>' + esc(subjName(s.box.subject)) + ' — ' + esc(s.box.title) +
        ' <span class="muted">(' + esc(gregToJalali(boxStudyDay(s.box) || s.box.date).text) +
        (s.rem > 0 ? ' · ' + FA(s.rem) + ' ' + t("testsWord") : '') +
        (s.accKnown ? ' · ' + t("anSubjAcc") + ': ' + FA_PCT(s.acc * 100) : '') +
        (s.exam ? ' · ' + esc(examDisplayName(s.exam)) : '') + ')</span></span>' +
        '<span class="sug-gap">' + esc(gregToJalali(s.gap.studyDay).text) + '</span>';
      const btn = document.createElement("button");
      btn.className = "btn btn-primary sug-move";
      btn.textContent = t("sugMove");
      // v1.11.43 (§17 idea 3): the button opens the destination-day
      // preview; the preview's confirm does the move.
      btn.addEventListener("click", () => { sugPreview = { kind: "single", s }; renderAll(); });
      row.appendChild(btn);
      block.appendChild(row);
    });
  }
  // v1.11.43 (§17 idea 3): the open preview panel, if any.
  const pv = sugPreviewPanel();
  if (pv) block.appendChild(pv);
  wrap.insertBefore(block, wrap.firstChild);
}

// v1.11.52 (I-2): the Past tab's done list renders compact by
// default (one-line rows); the toggle in renderRemaining flips it.
let PAST_DONE_COMPACT = true;
// ---------- Bulk-delete old backlog (v1.11.56) ----------
// User request, 27 Nov 2026 («قبل 30 ابان پاک شن»): delete every undone
// box dated before 30 Aban 1405 (2026-11-21) — from the app AND from
// Google Calendar (the same delete path as deleteBoxById, v1.11.12).
// Done boxes never match; dateless custom boxes are skipped (their date
// cannot be established as before the cutoff) and reported. The cutoff
// is a Jalali text input (same style as the other date inputs); the
// count is live, computed from allBoxes() on every change. Nothing is
// deleted without the explicit modal confirm, and a versioned backup
// (POST /api/backup/now, the Backup tab's own call) is taken first.
let bulkCutoffIso = "2026-11-21"; // 30 Aban 1405
let bulkDeleteResult = null; // last run's result line, or null
let bulkDeleteBusy = false;
function bulkDeleteMatches(cutoffIso) {
  const matched = [], dateless = [];
  allBoxes().forEach(b => {
    if (isDone(b)) return;
    if (!b.date) { dateless.push(b); return; }
    if (b.date < cutoffIso) matched.push(b);
  });
  return { matched, dateless };
}
function bulkRangeText(cutoffIso) {
  // Programme start -> day before the cutoff, Jalali, Persian digits.
  // (faDigits, not FA: FA formats a NUMBER, and a "1405/08/02" string
  // through it comes out NaN — «ناعدد».)
  const from = DATA.boxes.reduce((m, b) => (!m || (b.date && b.date < m)) ? b.date : m, null) || "2026-10-24";
  const to = addDays(cutoffIso, -1);
  return { from: faDigits(jalaliInputText(from)), to: faDigits(jalaliInputText(to)) };
}
function renderBulkDeleteSection(wrap) {
  // v1.11.61 (M-UI7): the destructive, rarely-needed section lives at
  // the END of the tab, collapsed inside a <details> — the tab opens
  // with the catch-up suggestions, not with the delete card. The
  // summary IS the title (bdTitle); the inner h3 is gone.
  const det = document.createElement("details");
  det.className = "card bulk-delete-details";
  det.id = "bulkDeleteDetails";
  const sum = document.createElement("summary");
  sum.textContent = t("bdTitle");
  det.appendChild(sum);
  const sec = document.createElement("div");
  sec.id = "bulkDeleteSection";
  const note = document.createElement("p");
  note.className = "page-sub";
  note.textContent = t("bdNote");
  sec.appendChild(note);
  const row = document.createElement("div");
  row.className = "form-row";
  const lab = document.createElement("label");
  lab.textContent = t("bdCutoffLabel");
  const inp = document.createElement("input");
  inp.id = "bulkCutoffInput";
  inp.type = "text";
  inp.inputMode = "numeric";
  inp.dir = "ltr";
  inp.value = jalaliInputText(bulkCutoffIso);
  inp.setAttribute("aria-label", t("bdCutoffLabel"));
  row.appendChild(lab); row.appendChild(inp);
  sec.appendChild(row);
  const countLine = document.createElement("p");
  countLine.id = "bulkDeleteCount";
  sec.appendChild(countLine);
  const datelessLine = document.createElement("p");
  datelessLine.id = "bulkDeleteDateless";
  datelessLine.className = "page-sub";
  sec.appendChild(datelessLine);
  const delBtn = document.createElement("button");
  delBtn.id = "bulkDeleteBtn";
  delBtn.className = "btn btn-danger";
  sec.appendChild(delBtn);
  const resLine = document.createElement("p");
  resLine.id = "bulkDeleteResult";
  if (bulkDeleteResult) resLine.textContent = bulkDeleteResult;
  sec.appendChild(resLine);
  const refresh = () => {
    const parsed = parseJalaliInput(inp.value);
    if (!parsed) {
      countLine.textContent = t("bdInvalidDate");
      datelessLine.textContent = "";
      delBtn.textContent = t("bdDeleteBtn", { n: FA(0) });
      delBtn.disabled = true;
      return;
    }
    bulkCutoffIso = parsed;
    const m = bulkDeleteMatches(parsed);
    const r = bulkRangeText(parsed);
    if (!m.matched.length) {
      countLine.textContent = t("bdEmpty");
    } else {
      countLine.textContent = t("bdCount", { n: FA(m.matched.length), from: r.from, to: r.to });
    }
    datelessLine.textContent = m.dateless.length ? t("bdDateless", { n: FA(m.dateless.length) }) : "";
    delBtn.textContent = t("bdDeleteBtn", { n: FA(m.matched.length) });
    delBtn.disabled = bulkDeleteBusy || !m.matched.length;
  };
  inp.addEventListener("input", refresh);
  delBtn.addEventListener("click", () => { if (!delBtn.disabled) openBulkDeleteModal(); });
  refresh();
  det.appendChild(sec);
  wrap.appendChild(det);
}
function openBulkDeleteModal() {
  const m = bulkDeleteMatches(bulkCutoffIso);
  if (!m.matched.length) return;
  const r = bulkRangeText(bulkCutoffIso);
  const body = document.getElementById("bulkDeleteBody");
  body.innerHTML = "";
  const p1 = document.createElement("p");
  p1.textContent = t("bdModalBody", { n: FA(m.matched.length), from: r.from, to: r.to });
  body.appendChild(p1);
  const p2 = document.createElement("p");
  p2.textContent = t("bdModalBackup");
  body.appendChild(p2);
  if (m.dateless.length) {
    const p3 = document.createElement("p");
    p3.textContent = t("bdModalDateless", { n: FA(m.dateless.length) });
    body.appendChild(p3);
  }
  // onclick assignment (not addEventListener): the modal opens on every
  // click, and the static footer buttons must not stack handlers
  // (same pattern as closeDayApplyBtn).
  document.getElementById("bulkDeleteConfirmBtn").onclick = () => applyBulkDelete();
  document.getElementById("bulkDeleteCancelBtn").onclick = closeBulkDeleteModal;
  document.getElementById("bulkDeleteModal").classList.add("open");
}
function closeBulkDeleteModal() {
  document.getElementById("bulkDeleteModal").classList.remove("open");
}
async function applyBulkDelete() {
  closeBulkDeleteModal();
  if (bulkDeleteBusy) return;
  const m = bulkDeleteMatches(bulkCutoffIso);
  if (!m.matched.length) return;
  bulkDeleteBusy = true;
  renderAll();
  try {
    // 1. Backup FIRST — the Backup tab's own snapshot call. A failed
    // backup aborts the delete: nothing is removed without a snapshot.
    let bkOk = false;
    try {
      const br = await fetch("/api/backup/now", { method: "POST" });
      bkOk = br.ok;
    } catch (e) { bkOk = false; }
    if (!bkOk) {
      bulkDeleteResult = t("bdBackupFailed");
      showToast(t("bdBackupFailed"), { kind: "err", ms: 4000 });
      return;
    }
    // 2. One state mutation for all matched boxes, one state POST.
    // (Recompute after the backup: the matcher is cheap and the set
    // must be the live one.)
    const live = bulkDeleteMatches(bulkCutoffIso);
    // v1.11.61 (M-DATA1): snapshot everything the delete is about to
    // remove, so a failed save can put it back in memory instead of
    // reporting «حذف شد» for boxes the server still has. purgeBoxState
    // clears per-box rows in done/tests/actualMinutes/edits/
    // tests_total/topicLinks/boxBookLinks + assignments + usefulMinutes
    // + timerSessions + testLog (+ a usefulPrompt for the box).
    const _purgedKeys = ["done", "tests", "actualMinutes", "tests_total", "topicLinks", "boxBookLinks"];
    const preDelete = {
      customBoxes: live.matched.filter(b => String(b.id).startsWith("custom-"))
        .map(b => JSON.parse(JSON.stringify(b))),
      edits: {}, purged: {}, useful: {}, sessions: [], testLog: [],
      assignments: [], usefulPrompt: null, deleted: (state.deleted || []).slice(),
    };
    live.matched.forEach(b => {
      if (state.edits && state.edits[b.id] != null) preDelete.edits[b.id] = JSON.parse(JSON.stringify(state.edits[b.id]));
      if (state.usefulMinutes && state.usefulMinutes[b.id] != null) preDelete.useful[b.id] = state.usefulMinutes[b.id];
      _purgedKeys.forEach(k => {
        if (state[k] && typeof state[k] === "object" && state[k][b.id] != null) {
          (preDelete.purged[k] = preDelete.purged[k] || {})[b.id] = JSON.parse(JSON.stringify(state[k][b.id]));
        }
      });
    });
    preDelete.sessions = (state.timerSessions || []).filter(s => s && live.matched.some(b => b.id === s.boxId))
      .map(s => JSON.parse(JSON.stringify(s)));
    preDelete.testLog = (state.testLog || []).filter(x => x && live.matched.some(b => b.id === x.box))
      .map(x => JSON.parse(JSON.stringify(x)));
    preDelete.assignments = (state.assignments || []).filter(x => x && live.matched.some(b => b.id === x.boxId))
      .map(x => JSON.parse(JSON.stringify(x)));
    if (state.usefulPrompt && live.matched.some(b => b.id === state.usefulPrompt.boxId)) {
      preDelete.usefulPrompt = JSON.parse(JSON.stringify(state.usefulPrompt));
    }
    live.matched.forEach(b => applyBoxDeletion(b));
    saveState();
    const savedOk = await flushSaves();
    if (!savedOk) {
      // The server never got the deletion — put everything back in
      // memory and say so plainly; the push below must not run (the
      // Google events are still live because the server still has
      // the boxes). The backup from step 1 still exists either way.
      preDelete.customBoxes.forEach(cb => {
        if (!(state.custom_boxes || []).some(x => x.id === cb.id)) (state.custom_boxes = state.custom_boxes || []).push(cb);
      });
      Object.keys(preDelete.purged).forEach(k => {
        Object.keys(preDelete.purged[k]).forEach(id => { state[k] = state[k] || {}; state[k][id] = preDelete.purged[k][id]; });
      });
      Object.keys(preDelete.edits).forEach(id => { state.edits = state.edits || {}; state.edits[id] = preDelete.edits[id]; });
      Object.keys(preDelete.useful).forEach(id => { state.usefulMinutes = state.usefulMinutes || {}; state.usefulMinutes[id] = preDelete.useful[id]; });
      state.deleted = preDelete.deleted;
      preDelete.sessions.forEach(s => (state.timerSessions = state.timerSessions || []).push(s));
      preDelete.testLog.forEach(x => (state.testLog = state.testLog || []).push(x));
      preDelete.assignments.forEach(a => (state.assignments = state.assignments || []).push(a));
      if (preDelete.usefulPrompt) state.usefulPrompt = preDelete.usefulPrompt;
      bulkDeleteResult = t("bdDeleteFailed");
      showToast(t("bdDeleteFailed"), { kind: "err", ms: 4000 });
      return;
    }
    // 3. Push now (not the ~15s auto-push) so the Google outcome is
    // known for the result line: the push deletes the linked events
    // (v1.11.12); an unresolvable one is recorded in last_push and
    // stays pending for retry (v1.11.27). A push that never runs
    // (not connected) leaves the deletions queued for the auto-push.
    let gRemoved = null, gErrors = 0;
    try {
      // v1.11.69 (Audit #2 Batch 2, L18): fetchWithTimeout like the
      // other manual push sites — a hung push used to stall the
      // bulk-delete result line forever (120 s SYNC_TIMEOUT_MS).
      const pr = await fetchWithTimeout("/api/calendar/push", { method: "POST" });
      const pj = await pr.json();
      if (pr.ok && pj.summary) {
        gRemoved = pj.summary.removed || 0;
        gErrors = (pj.summary.errors || []).length;
      }
    } catch (e) { /* push unreachable: deletions stay queued */ }
    let res = t("bdResult", { n: FA(live.matched.length), s: FA(live.dateless.length) });
    if (gRemoved === null) res += " · " + t("bdResultGooglePending");
    else {
      res += " · " + t("bdResultGoogle", { d: FA(gRemoved) });
      if (gErrors) res += " · " + t("bdResultGoogleErr", { e: FA(gErrors) });
    }
    bulkDeleteResult = res;
    invalidateCalStatus(); // v1.11.55 (PERF-01): the push changed status
    showToast(t("bdResult", { n: FA(live.matched.length), s: FA(live.dateless.length) }));
  } finally {
    bulkDeleteBusy = false;
    renderAll();
  }
}
function renderRemaining() {
  const wrap = document.getElementById("remainingList");
  // v1.11.55 (UX-1): the Past tab's primary is inert with no suggestion.
  const bestBtn = document.getElementById("pastBestSugBtn");
  if (bestBtn) bestBtn.disabled = !backlogSuggestions(1).length;
  wrap.innerHTML = "";
  // Smart catch-up suggestions (audit §5 item 2.6): ranked undone past
  // work with a concrete gap + one-click move, above the undone list.
  renderBacklogSuggestions(wrap);
  const hidden = state.backlogHidden || {};
  const undonePast = allBoxes()
    .filter(b => !isDone(b) && (boxStudyDay(b) || b.date) < TODAY && !hidden[b.id])
    .sort(compareBoxOrder);
  // --- Undone past (top): this tab is the single backlog centre
  // (v1.11.31, P1-7) — the Analytics review-past section only links here.
  const undoneTitle = document.createElement("h3");
  undoneTitle.id = "pastUndone";
  // v1.11.52 (UX-7): the undone header shows the count AND the
  // planned hours («۱۵۷ کار · ≈ ۴۳ ساعت»).
  const _bh = backlogCountHours(undonePast);
  undoneTitle.textContent = t("pastUndoneTitle") + " · " +
    t("backlogHours", { n: FA(_bh.n), h: FA(_bh.hours) });
  wrap.appendChild(undoneTitle);
  if (!undonePast.length) {
    const empty = document.createElement("div");
    empty.id = "pastUndoneList";
    // v1.11.52 (I-5): shared empty state (title only — there is no
    // next step when the backlog is genuinely clear).
    empty.appendChild(emptyState({ title: t("anReviewPastEmpty") }));
    wrap.appendChild(empty);
  } else {
    // v1.11.41 (UI-audit batch 1): the undone list used to be one flat
    // list of ~157 cards — now it is grouped by day (collapsible),
    // with a subject filter + search.
    const controls = document.createElement("div");
    controls.className = "past-controls";
    const subjSel = document.createElement("select");
    subjSel.id = "pastSubjectFilter";
    subjSel.setAttribute("aria-label", t("pastSubjectFilter"));
    const allOpt = document.createElement("option");
    allOpt.value = ""; allOpt.textContent = t("pastFilterAll");
    subjSel.appendChild(allOpt);
    [...new Set(undonePast.map(b => b.subject))].sort().forEach(s => {
      const o = document.createElement("option");
      o.value = s; o.textContent = subjName(s);
      subjSel.appendChild(o);
    });
    const search = document.createElement("input");
    search.type = "search";
    search.id = "pastSearch";
    search.placeholder = t("pastSearchPh");
    search.setAttribute("aria-label", t("pastSearchPh"));
    // v1.11.61 (L-UI6): collapse every day group at once — with ~157
    // items the first paint used to be a very long page of open groups.
    const collapseBtn = document.createElement("button");
    collapseBtn.type = "button";
    collapseBtn.id = "pastCollapseAllBtn";
    collapseBtn.className = "btn";
    collapseBtn.textContent = t("pastCollapseAll");
    collapseBtn.addEventListener("click", () => {
      undoneList.querySelectorAll("details.past-day").forEach(d => { d.open = false; });
    });
    controls.append(subjSel, search, collapseBtn);
    wrap.appendChild(controls);
    const undoneList = document.createElement("div");
    undoneList.id = "pastUndoneList";
    wrap.appendChild(undoneList);
    const renderGroups = () => {
      const q = search.value.trim();
      const subj = subjSel.value;
      const filtered = undonePast.filter(b =>
        (!subj || b.subject === subj) &&
        (!q || (b.title + " " + (b.topic || "")).includes(q)));
      undoneList.innerHTML = "";
      if (!filtered.length) {
        // v1.11.61 (L-UI8): the shared empty state (I-5 rule) with a
        // clear-filters action, instead of a second bare <p> look.
        undoneList.appendChild(emptyState({
          title: t("anReviewPastEmpty"),
          actionLabel: t("esAnAction"),
          onAction: () => { subjSel.value = ""; search.value = ""; renderGroups(); },
        }));
        return;
      }
      const byDay = {};
      filtered.forEach(b => { const d = boxStudyDay(b) || b.date; (byDay[d] = byDay[d] || []).push(b); });
      Object.keys(byDay).sort().reverse().forEach((d, i) => {
        const det = document.createElement("details");
        det.className = "past-day";
        // v1.11.61 (L-UI6): only the 3 freshest day groups open by
        // default — the rest start closed (collapse-all in the
        // controls above closes the rest on demand).
        det.open = i < 3;
        const sum = document.createElement("summary");
        sum.textContent = weekdayFa(d) + " " + gregToJalali(d).text + " · " + FA(byDay[d].length) + " " + t("boxesWord");
        const rows = document.createElement("div");
        rows.className = "past-day-rows";
        byDay[d].forEach(b => rows.appendChild(remainingRowEl(b)));
        det.append(sum, rows);
        undoneList.appendChild(det);
      });
    };
    subjSel.addEventListener("change", renderGroups);
    search.addEventListener("input", renderGroups);
    renderGroups();
  }
  // --- Done past (below): the old overdue list, unchanged in meaning.
  const doneTitle = document.createElement("h3");
  doneTitle.textContent = t("pastDoneTitle");
  wrap.appendChild(doneTitle);
  // v1.11.52 (I-2): «فشرده / کامل» toggle for the done boxes — compact
  // is the default, so the long done list no longer buries the page.
  const doneToggle = document.createElement("button");
  doneToggle.type = "button";
  doneToggle.className = "btn past-done-toggle";
  doneToggle.textContent = PAST_DONE_COMPACT ? t("pastDoneViewFull") : t("pastDoneViewCompact");
  doneToggle.addEventListener("click", () => { PAST_DONE_COMPACT = !PAST_DONE_COMPACT; renderAll(); });
  wrap.appendChild(doneToggle);
  const doneList = document.createElement("div");
  doneList.id = "pastDoneList";
  wrap.appendChild(doneList);
  const donePast = allBoxes()
    .filter(b => isDone(b) && boxStudyDay(b) < TODAY && !hidden[b.id])
    .sort(compareBoxOrder);
  // v1.11.9: explicitly pinned boxes (three-dot menu → «انتقال به بک‌لاگ»)
  // show here too — the same record, no duplicate. The v1.6.0 rule stands:
  // the overdue list shows only DONE past parts, except for these
  // explicitly pinned items (any state, any day).
  const pinned = allBoxes()
    .filter(b => isPinned(b) && !hidden[b.id] && !donePast.some(x => x.id === b.id))
    .sort(compareBoxOrder);
  const rows = donePast.concat(pinned);
  const hiddenCount = allBoxes()
    .filter(b => boxStudyDay(b) < TODAY && hidden[b.id]).length;
  if (!rows.length) {
    // v1.11.52 (I-5): shared empty state.
    doneList.appendChild(emptyState({ title: t("noOverdue") }));
  } else {
    // v1.11.52 (I-2): the compact view applies to DONE rows only —
    // pinned undone rows keep the full row (they were pinned to be seen).
    rows.forEach(b => doneList.appendChild(remainingRowEl(b, PAST_DONE_COMPACT && isDone(b))));
  }
  attachCollapsible(doneList, ".part", 6);
  // --- Hidden from the backlog (v1.11.31, P1-7): items hidden from
  // this list are not gone — they are restored from HERE, in this same
  // tab, instead of from a second list elsewhere.
  if (hiddenCount) {
    const hidTitle = document.createElement("h3");
    hidTitle.id = "pastHiddenTitle";
    hidTitle.textContent = t("anReviewPastHidden");
    wrap.appendChild(hidTitle);
    const hidList = document.createElement("div");
    hidList.id = "pastHiddenList";
    wrap.appendChild(hidList);
    allBoxes()
      .filter(b => boxStudyDay(b) < TODAY && hidden[b.id])
      .sort(compareBoxOrder)
      .forEach(b => {
        const row = document.createElement("div");
        row.className = "part hidden-row";
        row.innerHTML = '<div class="part-top"><div style="flex:1;min-width:0"><div class="part-title">' + esc(b.title) + '</div>' +
          '<div class="part-time">' + esc(gregToJalali(b.date).text) + ' · ' + fmtTimeFa(b.start) + ' – ' + fmtTimeFa(b.end) + ' · ' + esc(subjName(b.subject)) + '</div></div>' +
          '<button class="btn restore-btn">' + t("backlogRestore") + '</button></div>';
        row.querySelector(".restore-btn").addEventListener("click", () => {
          if (state.backlogHidden) delete state.backlogHidden[b.id];
          saveState(); renderAll();
        });
        hidList.appendChild(row);
      });
  }
  // v1.11.61 (M-UI7): the bulk-delete section goes last, collapsed
  // (see renderBulkDeleteSection) — v1.11.56 put it first.
  renderBulkDeleteSection(wrap);
}

// ---- Dashboard: «هفته پیش‌رو» + rules card (moved from the removed Overview tab, v1.11.33 P2-7/P2-8) ----
// v1.11.33 (P2-8): the Overview tab is REMOVED. Its «هفته پیش‌رو» list
// moves to the Dashboard, the print button moves to the
// Dashboard (#dashPrintBtn) and Analytics (#anPrintBtn); the subject table
// and lagging rows already exist in Analytics, the top-topics list in the
// Remaining tab, and the book chips in the Testbook tab. Nothing else from
// the Overview is referenced anywhere now (renderDashExams deleted too).
// v1.11.70 (L22): the 7-day list itself is gone too — the Dashboard
// shows tomorrow only (renderNext3Into, v1.11.63); next7Html and
// renderNext7Into had no call site left and were removed with it.
// v1.11.63 (Batch 4, dashboard declutter): «۳ روز آینده» is «فردا»
// now — tomorrow only, one row, same shape as the 7-day list, click
// opens that day in Programme. The 3-day detail lives in the monthly
// programme.
function renderNext3Into(el) {
  if (!el) return;
  const boxes = allBoxes().filter(isCurrentBox);
  const byDay = {};
  boxes.forEach(b => { const sd = boxStudyDay(b) || b.date; (byDay[sd] = byDay[sd] || []).push(b); });
  el.innerHTML = "";
  el.className = "dash-next3";
  for (let i = 1; i <= 1; i++) {
    const iso = addDays(TODAY, i);
    const list = byDay[iso] || [];
    const done = list.filter(isDone).length;
    const row = document.createElement("div");
    row.className = "trow topic";
    row.style.cssText = "display:flex;justify-content:space-between";
    const a = document.createElement("span");
    a.textContent = weekdayFa(iso) + " " + gregToJalali(iso).text;
    const b = document.createElement("span");
    b.textContent = FA(done) + "/" + FA(list.length) + " " + t("boxesWord") + (isDayDone(iso) ? " ✓" : "");
    row.append(a, b);
    row.addEventListener("click", () => navigate({ tab: "program", day: iso }));
    el.appendChild(row);
  }
}

// ---------- v1.11.33 (P2-7): rules monitoring on the Dashboard ----------
// The rules are the user's own programme rules; the card only WARNS and
// jumps to the day — it never changes the programme (1.11.19 item-2.8).
// weekStartOf: Saturday start of the week containing iso (same convention
// as anWeekStart in analytics.js).
function weekStartOf(iso) {
  const d = new Date(iso + "T12:00:00");
  const dow = (d.getDay() + 1) % 7;
  d.setDate(d.getDate() - dow);
  return isoOf(d);
}
// Programme-wide violations: every day whose dayIssues() are non-empty,
// with the day and its issues. Computed from the programme, not stored.
// v1.11.62 (Batch 3, ب-۲): the spacing rule, finally CHECKED. The
// user's rule (25 Nov): at most 1 day gap between two sessions of the
// same specialized subject. sessionDays: {subject: [iso,...]} sorted.
// A pair of consecutive session days with more than 1 non-exam day
// between them is a violation (the raw date diff is shown, exam days
// are excused); a subject with no session at all in the window is
// flagged too. Pure — the stage builder (م-۱ ج) runs the same check
// on its output.
const SPEC_SUBJECTS = SUBJECTS.filter(r => r.type === "specialized").map(r => r.fa);
function spacingViolations(sessionDays, examDays) {
  const ex = examDays || new Set();
  const out = [];
  SPEC_SUBJECTS.forEach(s => {
    const days = ((sessionDays || {})[s] || []).slice().sort();
    if (!days.length) { out.push({ subject: s, kind: "none" }); return; }
    for (let i = 1; i < days.length; i++) {
      const a = days[i - 1], b = days[i];
      const diff = Math.round((new Date(b + "T12:00:00") - new Date(a + "T12:00:00")) / 86400000);
      let between = 0;
      for (let d = addDays(a, 1); d < b; d = addDays(d, 1)) if (!ex.has(d)) between++;
      if (between > 1) out.push({ subject: s, kind: "gap", from: a, to: b, days: diff });
    }
  });
  return out;
}
function spacingSessionDays(boxes) {
  // Distinct session days per specialized subject from a box list.
  const out = {};
  SPEC_SUBJECTS.forEach(s => { out[s] = []; });
  const seen = {};
  (boxes || []).forEach(b => {
    const s = b.subject;
    if (!SPEC_SUBJECTS.includes(s)) return;
    const d = boxStudyDay(b) || b.date;
    if (!d) return;
    const k = s + "|" + d;
    if (seen[k]) return;
    seen[k] = true;
    out[s].push(d);
  });
  Object.keys(out).forEach(s => out[s].sort());
  return out;
}
function programmeRuleViolations() {
  const out = [];
  for (let d = programmeStart(); d <= programmeEnd(); d = addDays(d, 1)) {
    const iss = dayIssues(d);
    if (iss.length) out.push({ date: d, issues: iss });
  }
  return out;
}
function renderRulesCard() {
  const el = document.getElementById("dashRules");
  if (!el) return;
  const ws = weekStartOf(TODAY);
  const we = addDays(ws, 6);
  const examDays = new Set(allExams().map(e => e.date).filter(Boolean));
  // Rule: at least 30 min of general subjects every day (except exam
  // days, which are already 13+ hours). Days with no boxes at all are
  // empty days, not violations.
  // v1.11.62 (Batch 3, ب-۹): the check now runs over ALL remaining
  // days to programme end, not just the current week.
  const noGen = [];
  const progEnd = programmeEnd();
  const noGenFrom = TODAY < programmeStart() ? programmeStart() : TODAY;
  for (let d = noGenFrom; d <= progEnd; d = addDays(d, 1)) {
    if (examDays.has(d)) continue;
    const ds = daySummary(d);
    if (ds.boxes === 0) continue;
    if (ds.gen < 30) noGen.push(d);
  }
  // Rule: geometry at least 3–4 non-class boxes per week.
  let geomCount = 0;
  allBoxes().forEach(b => {
    const sd = boxStudyDay(b) || b.date;
    if (sd < ws || sd > we) return;
    if ((b.subject || "").indexOf("هندسه") >= 0 && !boxIsClass(b)) geomCount++;
  });
  const geomOk = geomCount >= 3;
  const viol = programmeRuleViolations();
  // v1.11.62 (Batch 3, ب-۲): spacing check over the current week AND
  // the next week, clipped to the programme range.
  const spFrom = ws;
  const spTo = addDays(ws, 13) <= progEnd ? addDays(ws, 13) : progEnd;
  const spViol = (spTo >= spFrom) ? spacingViolations(spacingSessionDays(
    allBoxes().filter(b => {
      const sd = boxStudyDay(b) || b.date;
      return sd && sd >= spFrom && sd <= spTo;
    })), examDays) : [];
  let html = '<h3 class="card-title">' + t("rlTitle") + '</h3>' +
    '<div class="rl-rows">' +
    '<div class="rl-row"><span>' + t("rlNoGeneral") + '</span><b>' +
      (noGen.length ? t("rlNoGeneralCount", { n: FA(noGen.length) }) : t("rlAllOk")) + '</b></div>' +
    '<div class="rl-row"><span>' + t("rlGeom") + '</span><b>' + FA(geomCount) + " " + t("rlGeomTarget") +
      (geomOk ? " ✓" : "") + '</b></div>' +
    '<div class="rl-row"><span>' + t("rlSpacing") + '</span><b>' +
      (spViol.length ? "⚠ " + FA(spViol.length) : t("rlAllOk") + " ✓") + '</b></div>' +
    '</div>';
  if (noGen.length) {
    html += '<h4 class="rl-sub">' + t("rlNoGeneral") + ' (' + FA(noGen.length) + ')</h4><div class="rl-nogen">';
    noGen.forEach(d => {
      html += '<div class="rl-day"><div class="rl-day-head"><b>' + weekdayFa(d) + " " + gregToJalali(d).text + '</b>' +
        '<button class="btn rl-goto" data-day="' + d + '">' + t("rlGoToDay") + '</button></div></div>';
    });
    html += '</div>';
  }
  if (spViol.length) {
    html += '<h4 class="rl-sub">' + t("rlSpacing") + ' (' + FA(spViol.length) + ')</h4><div class="rl-spacing">';
    spViol.forEach(v => {
      const txt = v.kind === "none"
        ? t("rlSpacingNone", { s: subjName(v.subject) })
        : t("rlSpacingGap", { s: subjName(v.subject), n: FA(v.days), a: gregToJalali(v.from).text, b: gregToJalali(v.to).text });
      const day = v.kind === "none" ? spFrom : v.from;
      html += '<div class="rl-day"><div class="rl-day-head"><b>' + esc(txt) + '</b>' +
        '<button class="btn rl-goto-week" data-day="' + day + '">' + t("rlGoToWeek") + '</button></div></div>';
    });
    html += '</div>';
  }
  html += '<h4 class="rl-sub">' + t("rlViolations") + ' (' + FA(viol.length) + ')</h4>';
  if (!viol.length) {
    html += '<p class="muted">' + t("rlNoViolations") + '</p>';
  } else {
    html += '<div class="rl-viol">';
    viol.forEach(v => {
      html += '<div class="rl-day"><div class="rl-day-head"><b>' + weekdayFa(v.date) + " " + gregToJalali(v.date).text + '</b>' +
        '<button class="btn rl-goto" data-day="' + v.date + '">' + t("rlGoToDay") + '</button></div>' +
        '<ul class="rl-issues">' + v.issues.map(i => '<li>' + esc(i.text) + '</li>').join("") + '</ul></div>';
    });
    html += '</div>';
  }
  el.innerHTML = html;
  // v1.11.62: the old attachCollapsible(el, ".rl-day", 5) was a no-op —
  // .rl-day items are grandchildren of the card, not direct children —
  // so the violations list never collapsed. Collapse each list on its
  // own wrapper (the no-general and spacing lists are new in this
  // version; the violations list now behaves as originally intended).
  ["rl-viol", "rl-nogen", "rl-spacing"].forEach(cls => {
    const w = el.querySelector("." + cls);
    if (w) attachCollapsible(w, ".rl-day", 5);
  });
  el.querySelectorAll(".rl-goto").forEach(btn => btn.addEventListener("click", () => {
    navigate({ tab: "program", day: btn.dataset.day });
  }));
  el.querySelectorAll(".rl-goto-week").forEach(btn => btn.addEventListener("click", () => {
    navigate({ tab: "program", day: btn.dataset.day });
  }));
}

// ---------- Gemini on the dashboard (v1.11.35, P2-13) ----------
// The latest saved Gemini analysis as a «تحلیل هفته» card — the saved
// history entry, never a fabricated analysis. When there is no saved
// analysis the card says so honestly (and, when no key is stored, says
// the key is missing, with a link to Settings — the single place the
// key is managed). The key check is best-effort: a failed fetch never
// breaks the dashboard.
let gmWeekKeyCache = null;
async function renderGeminiCard() {
  const el = document.getElementById("dashGemini");
  if (!el) return;
  const latest = (state.geminiHistory || [])[0] || null;
  if (latest) {
    const full = String(latest.text || "");
    const preview = full.length > 400 ? full.slice(0, 400) + "…" : full;
    el.innerHTML = '<h3 class="card-title">' + esc(t("gmWeekTitle")) + '</h3>' +
      '<p class="gm-week-meta">' + esc(gregToJalali(latest.d || TODAY).text) +
      (latest.model ? ' · ' + esc(latest.model) : '') +
      (latest.question ? ' · ' + esc(latest.question) : '') + '</p>' +
      '<p class="gm-week-text"></p>' +
      (full.length > 400 ? '<details class="gm-week-full"><summary>' + esc(t("gmWeekFull")) + '</summary><p class="gm-week-text"></p></details>' : '') +
      '<div class="form-row"><button class="btn gm-week-open">' + esc(t("gmWeekGoGemini")) + '</button></div>';
    el.querySelector(".gm-week-text").textContent = preview;
    const fullEl = el.querySelector(".gm-week-full .gm-week-text");
    if (fullEl) fullEl.textContent = full;
    el.querySelector(".gm-week-open").addEventListener("click", () => navigate({ tab: "analytics", scroll: { type: "section", id: "anGeminiTitle" } }));
    return;
  }
  let hasKey = gmWeekKeyCache;
  const kj = await getGeminiKeyStatus(); // v1.11.65 (Batch 6, L-PERF3): shared getter, cached + deduped
  if (kj) { hasKey = !!kj.has_key; gmWeekKeyCache = hasKey; }
  // (a null read keeps the cached/unknown value)
  el.innerHTML = '<h3 class="card-title">' + esc(t("gmWeekTitle")) + '</h3>' +
    '<p class="muted">' + esc(t("gmWeekEmpty")) + '</p>' +
    (hasKey === false ? '<p class="muted">' + esc(t("gmWeekNoKey")) + '</p>' +
      '<div class="form-row"><button class="btn gm-week-key">' + esc(t("gmWeekGoSettings")) + '</button></div>' : '') +
    '<div class="form-row"><button class="btn gm-week-open">' + esc(t("gmWeekGoGemini")) + '</button></div>';
  const keyBtn = el.querySelector(".gm-week-key");
  if (keyBtn) keyBtn.addEventListener("click", () => navigate({ tab: "settings" }));
  el.querySelector(".gm-week-open").addEventListener("click", () => navigate({ tab: "analytics", scroll: { type: "section", id: "anGeminiTitle" } }));
}
function subjectStats(name) {
  // Subject equality, not substring: «شیمی» must not also count
  // «شیمی — فصل ۱»-titled boxes of another subject, and one box can
  // no longer count toward several cards.
  const boxes = allBoxes().filter(b => b.subject === name);
  const done = boxes.filter(isDone);
  // v1.11.45 (F-10): actual minutes / tests count ALL boxes of the
  // subject — an unticked box with timer time + solved tests is still
  // studied. Only the pct progress stays tick-based.
  const mins = Math.round(boxes.reduce((s, b) => s + timerTotalSeconds(b.id), 0) / 60);
  const tests = boxes.reduce((s, b) => s + (testOf(b).completed || 0), 0);
  const correct = boxes.reduce((s, b) => s + (testOf(b).correct || 0), 0);
  const acc = tests ? (correct / tests * 100) : null;
  const pct = boxes.length ? (done.length / boxes.length * 100) : 0;
  return { mins, tests, correct, acc, pct };
}
function renderSubjectStats() {
  const wrap = document.getElementById("subjectStatsList");
  wrap.innerHTML = "";
  (state.subjects || []).forEach((name, i) => {
    const st = subjectStats(name);
    const card = document.createElement("div");
    card.className = "subj-card " + colorClass(name);
    card.innerHTML =
      '<div class="row"><span class="name">' + esc(subjName(name)) + '</span>' +
      '<button class="rm" title="' + t("stDeleteTitle") + '">✕</button></div>' +
      '<div class="stat3">' +
        '<div><div class="v info">' + (st.mins > 0 ? fmtDurationFa(st.mins) : "—") + '</div><div class="l">' + t("stTimeStudied") + '</div></div>' +
        '<div><div class="v orange">' + FA(st.tests) + '</div><div class="l">' + t("stTestsCompleted") + '</div></div>' +
        '<div><div class="v accent">' + (st.acc == null ? "—" : FA_PCT(st.acc)) + '</div><div class="l">' + t("stAccuracy", { n: FA(st.correct) }) + '</div></div>' +
      '</div>' +
      '<div class="progress"><div style="width:' + st.pct + '%"></div></div>';
    card.querySelector(".rm").addEventListener("click", () => {
      // v1.11.41 (UI-audit batch 1): deleting a subject used to be
      // instant and final — now it asks «حذف درس؟» first and offers a
      // 5-second Undo after the deletion.
      if (!confirm(t("stDeleteConfirm", { name: subjName(name) }))) return;
      const idx = state.subjects.indexOf(name);
      state.subjects = state.subjects.filter(s => s !== name);
      saveState(); renderSubjectStats();
      showToast(t("stDeleted", { name: subjName(name) }), {
        ms: 5000,
        action: {
          label: t("undoBtn"),
          fn: () => {
            if (!state.subjects.includes(name)) {
              state.subjects.splice(Math.max(0, Math.min(idx, state.subjects.length)), 0, name);
            }
            saveState(); renderSubjectStats();
          }
        }
      });
    });
    wrap.appendChild(card);
  });
}
function closeStatsModal() {
  hideAllModalsUI();
  closeModalHistory();
}
document.getElementById("statsBtn").addEventListener("click", () => {
  renderSubjectStats();
  document.getElementById("statsModal").classList.add("open");
  pushModalRoute({ kind: "stats" });
});
document.getElementById("statsClose").addEventListener("click", closeStatsModal);
document.getElementById("statsModal").addEventListener("click", (e) => {
  if (e.target.id === "statsModal") closeStatsModal();
});
// v1.11.48 (I-4): a click on the sim overlay's backdrop opens the
// EXISTING exit confirm (never a silent exit) — same pattern as
// statsModal above.
document.getElementById("simOverlay").addEventListener("click", (e) => {
  if (e.target.id === "simOverlay") exitSim();
});
// ---------- Keyboard shortcuts guide (v1.11.48, P-7) ----------
// A small reference modal — no history entry (unlike stats/edit),
// opened by «؟» / «?» or the topbar «؟» button. The rows list every
// global shortcut the app supports.
function openShortcutsModal() {
  const back = document.getElementById("shortcutsModal");
  const body = document.getElementById("shortcutsBody");
  if (!back || !body) return;
  const rows = [
    ["Ctrl+K", t("scSearch")],
    ["Esc", t("scClose")],
    ["↑↓", t("scNavigate")],
    ["Enter", t("scSelect")],
    ["T", t("scTick")],
    ["Space", t("scTimer")],
    ["؟", t("scHelp")],
    // v1.11.55 (UX-6): G-prefix navigation — g arms, then one key jumps.
    ["G", t("scGoHint")],
    ["G then T", t("scGoToday")],
    ["G then D", t("scGoDash")],
    ["G then P", t("scGoProg")],
    ["G then E", t("scGoExams")],
    ["G then A", t("scGoAnalytics")],
    ["G then B", t("scGoRemaining")],
    // v1.11.57 (IA): G jumps to the Gemini section inside Analytics,
    // S to Settings (where the Backup section lives now).
    ["G then G", t("scGoGemini")],
    ["G then S", t("scGoSettings")]
  ];
  body.innerHTML = rows.map(([k, d]) =>
    '<div class="sc-row"><kbd>' + esc(k) + '</kbd><span>' + esc(d) + '</span></div>').join("");
  back.classList.add("open");
}
function closeShortcutsModal() {
  const back = document.getElementById("shortcutsModal");
  if (back) back.classList.remove("open");
}
document.getElementById("shortcutsBtn").addEventListener("click", openShortcutsModal);
document.getElementById("shortcutsClose").addEventListener("click", closeShortcutsModal);
document.getElementById("shortcutsModal").addEventListener("click", (e) => {
  if (e.target.id === "shortcutsModal") closeShortcutsModal();
});
document.getElementById("addSubjectBtn").addEventListener("click", () => {
  const inp = document.getElementById("newSubjectInput");
  const name = inp.value.trim();
  if (!name) return;
  if (!state.subjects.includes(name)) state.subjects.push(name);
  inp.value = "";
  saveState(); renderSubjectStats();
});


// ---- Assignments tab (تکالیف) ----
// An assignment IS a daily box's test work, seen from a second place.
// It stores only {id, boxId, type}; title/date/subject/tests/done are all
// read live from the underlying box + state.tests + state.done, so an edit
// in either view updates the other and the count is never stored twice.
function assignmentsList() {
  if (!Array.isArray(state.assignments)) return [];
  const removed = new Set(state.assignmentsRemoved || []);
  const boxes = {};
  allBoxes().forEach(b => { boxes[b.id] = b; });
  return state.assignments
    .filter(a => !removed.has(a.boxId) && boxes[a.boxId])
    .map(a => ({ assignment: a, box: boxes[a.boxId] }));
}
function subjectForBook(bookId) {
  return { chem: "شیمی", calc: "حسابان", phys: "فیزیک" }[bookId] || "";
}
function bookForSubject(subject) {
  return { "شیمی": "chem", "حسابان": "calc", "فیزیک": "phys" }[subject] || null;
}
// Delete a box's per-box state everywhere it lives, or a deleted box's
// tick/test counts/actual minutes/edits keep showing up (e.g. in book
// stats) after the box itself is gone.
function purgeBoxState(id) {
  // v1.11.43 (item 22): a pending useful prompt for a deleted box dies with it.
  if (state.usefulPrompt && state.usefulPrompt.boxId === id) state.usefulPrompt = null;
  ["done", "tests", "actualMinutes", "edits", "tests_total", "topicLinks", "boxBookLinks"].forEach(k => {
    if (state[k] && typeof state[k] === "object") delete state[k][id];
  });
  if (Array.isArray(state.assignments)) state.assignments = state.assignments.filter(x => x.boxId !== id);
  // v1.11.60 (L-DATA1): useful, timer sessions and test-log rows of a
  // deleted box used to live forever in state.json.
  if (state.usefulMinutes && typeof state.usefulMinutes === "object") delete state.usefulMinutes[id];
  if (Array.isArray(state.timerSessions)) state.timerSessions = state.timerSessions.filter(s => !s || s.boxId !== id);
  if (Array.isArray(state.testLog)) state.testLog = state.testLog.filter(x => !x || x.box !== id);
}

// MIGRATION (one-time): assignments did not exist before. Derive them from the
// existing daily test boxes — one assignment per test box, keyed by the SAME
// box id. No counts are copied: done/tests live only in state.done/state.tests.
// Also re-run after a backup restore (refreshDataFromServer), where the
// restored state may predate the migration.
function migrateAssignments() {
  if (Array.isArray(state.assignments)) return;
  state.assignments = DATA.boxes.filter(b => b.is_test).map(b => ({
    id: "asg-" + b.id, boxId: b.id, type: "test"
  }));
  state.assignmentsRemoved = state.assignmentsRemoved || [];
  saveState();
}
// v1.11.57 (IA): the testbook «تکالیف این مبحث» link filters this tab
// to one topic (boxes linked to it). Module-level, like openBookId —
// the clear button below is the only way out.
let asgTopicFilter = null;
// v1.11.64 (Batch 5, ب-۶): the assignments filter bar — subject +
// status + title search, above the list (in-memory only, like
// asgTopicFilter). The search input is debounced and re-renders the
// list; v1.11.72 (Batch 5, L30) also re-renders the bar, so the
// «پاک کردن فیلتر» button appears after a search-only filter — the
// focus + caret are restored when the user was still typing in the
// input, so typing never loses focus. Same pattern as the archive
// search (#anArchSearch).
let asgFilter = { subject: "all", status: "all", q: "" };
function renderAsgFilterBar() {
  const bar = document.getElementById("asgFilterBar");
  if (!bar) return;
  bar.hidden = false;
  const subjects = [...new Set(assignmentsList().map(({ box: b }) => b.subject))].sort();
  const active = asgFilter.subject !== "all" || asgFilter.status !== "all" || asgFilter.q.trim() !== "";
  bar.innerHTML =
    '<label><span>' + esc(t("anSubject")) + '</span><select id="asgFilterSubject">' +
    '<option value="all">' + esc(t("asgFilterAll")) + '</option>' +
    subjects.map(s => '<option value="' + esc(s) + '"' + (asgFilter.subject === s ? " selected" : "") + '>' + esc(subjName(s)) + '</option>').join("") +
    '</select></label>' +
    '<label><span>' + esc(t("anStatus")) + '</span><select id="asgFilterStatus">' +
    '<option value="all">' + esc(t("asgFilterAll")) + '</option>' +
    '<option value="done"' + (asgFilter.status === "done" ? " selected" : "") + '>' + esc(t("asgFilterDone")) + '</option>' +
    '<option value="remaining"' + (asgFilter.status === "remaining" ? " selected" : "") + '>' + esc(t("asgFilterRemaining")) + '</option>' +
    '</select></label>' +
    '<label class="asg-filter-search"><span>' + esc(t("asgFilterSearchPh")) + '</span><input type="text" id="asgFilterSearch" value="' + esc(asgFilter.q) + '" placeholder="' + esc(t("asgFilterSearchPh")) + '"></label>' +
    (active ? '<button class="btn" id="asgFilterClear">' + esc(t("asgFilterClear")) + '</button>' : '');
  bar.querySelector("#asgFilterSubject").addEventListener("change", (e) => { asgFilter.subject = e.target.value; renderAll(); });
  bar.querySelector("#asgFilterStatus").addEventListener("change", (e) => { asgFilter.status = e.target.value; renderAll(); });
  const sq = bar.querySelector("#asgFilterSearch");
  let timer = null;
  sq.addEventListener("input", () => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      // v1.11.72 (Batch 5, L30): the bar re-renders too, so the
      // «پاک کردن فیلتر» button appears after a search-only filter.
      // Re-rendering replaces the input element, so restore focus +
      // caret when the user was still typing in it.
      const hadFocus = document.activeElement === sq;
      asgFilter.q = sq.value;
      renderAsgList();
      renderAsgFilterBar();
      if (hadFocus) {
        const sq2 = document.getElementById("asgFilterSearch");
        if (sq2) { sq2.focus(); sq2.setSelectionRange(sq2.value.length, sq2.value.length); }
      }
    }, 250);
  });
  const clr = bar.querySelector("#asgFilterClear");
  if (clr) clr.addEventListener("click", () => { asgFilter = { subject: "all", status: "all", q: "" }; renderAll(); });
}
function renderAssignments() {
  renderAsgFilterBar();
  renderAsgList();
  // v1.11.66 (Batch 7, خ-۴): the primary is inert when nothing is left.
  const firstBtn = document.getElementById("asgFirstBtn");
  if (firstBtn) firstBtn.disabled = !document.querySelector('#assignmentsList .assign-card:not(.done)');
}
function renderAsgList() {
  const wrap = document.getElementById("assignmentsList");
  if (!wrap) return;
  let list = assignmentsList();
  if (asgTopicFilter) list = list.filter(({ box: b }) => linkedTopicId(b) === asgTopicFilter);
  // v1.11.64 (Batch 5, ب-۶): subject + status + title search.
  if (asgFilter.subject !== "all") list = list.filter(({ box: b }) => b.subject === asgFilter.subject);
  if (asgFilter.status === "done") list = list.filter(({ box: b }) => isDone(b));
  else if (asgFilter.status === "remaining") list = list.filter(({ box: b }) => !isDone(b));
  if (asgFilter.q.trim()) { const q = asgFilter.q.trim(); list = list.filter(({ box: b }) => (b.title || "").includes(q)); }
  // Sort: not-done first, then by STUDY day (not calendar date — a box
  // starting 00:30 belongs to the previous study day, see boxStudyDay).
  list.sort((x, y) => ((isDone(x.box) ? 1 : 0) - (isDone(y.box) ? 1 : 0)) ||
    compareBoxOrder(x.box, y.box));
  wrap.innerHTML = "";
  if (asgTopicFilter) {
    const info = topicById(asgTopicFilter);
    const bar = document.createElement("div");
    bar.className = "asg-filter-bar";
    const lab = document.createElement("span");
    lab.textContent = t("asgTopicFilter", { name: info ? topicTitle(info.topic) : asgTopicFilter });
    const clr = document.createElement("button");
    clr.className = "btn"; clr.type = "button"; clr.textContent = "✕";
    clr.title = t("anClear");
    clr.addEventListener("click", () => { asgTopicFilter = null; renderAll(); });
    bar.appendChild(lab); bar.appendChild(clr);
    wrap.appendChild(bar);
  }
  if (!list.length) {
    const p = document.createElement("p");
    p.className = "muted"; p.textContent = t("noAssignments");
    wrap.appendChild(p);
    return;
  }
  list.forEach(({ assignment: a, box: b }) => {
    const tr = testOf(b);
    const total = b.tests_total || 0;
    const remaining = total ? Math.max(0, total - (tr.completed || 0)) : null;
    const linkId = linkedTopicId(b);
    const linkInfo = linkId && topicById(linkId);
    const examLinks = linkId ? reverseBookLinks(linkId).filter(l => l.kind === "exam") : [];
    const sd = boxStudyDay(b) || b.date;
    const row = document.createElement("div");
    row.className = "part assign-card " + colorClass(b.subject) + (isDone(b) ? " done" : "") + (boxConnected(b) ? "" : " has-cal-add");
    row.id = "asg-row-" + b.id;
    row.innerHTML =
      '<div class="part-top">' +
        '<input type="checkbox" ' + (isDone(b) ? "checked" : "") + ' aria-label="' + t("fDone") + '">' +
        '<div style="flex:1"><div class="part-title">' + esc(b.title) + '</div>' +
        '<div class="part-time">' + weekdayFa(sd) + ' ' + gregToJalali(sd).text + ' · ' +
        fmtTimeFa(b.start) + ' – ' + fmtTimeFa(b.end) + ' · ' + esc(subjName(b.subject)) +
        (boxTopicShown(b) ? ' · ' + esc(boxTopicShown(b)) : '') + '</div>' +
        '<div class="part-time">' + t("testsLabel") + FA(tr.completed || 0) + t("doneSuffix") +
        (total ? t("ofWord") + FA(total) + ' · ' + FA(remaining) + t("remainingSuffix") : t("totalNotEntered")) +
        ' · ' + t("correctLabel") + FA(tr.correct || 0) + '</div>' +
        '<div class="part-time">' + actualVsHtml(b) + '</div>' +
        '<div class="link-badge ' + (linkInfo ? "on" : "off") + '">' +
        (linkInfo ? t("connected") + esc((linkInfo.book ? bookName(linkInfo.book) + ' › ' : '') + topicTitle(linkInfo.topic)) :
                    t("notConnected")) + '</div></div>' +
        // v1.11.37 (P3-4): calendar status as a pill in the title row.
        connStatusBoxHtml(b) + calAddToCalBtnHtml(b) +
      '</div>' +
      (examLinks.length ? '<div class="bt-links"><span class="bt-links-label">' + t("linkedExamsLabel") + '</span>' + examLinks.map(l =>
        '<button class="jump-btn bt-link-jump" data-exam="' + esc(l.examId) + '">' + esc(l.examName + " — " + l.topicName) + '</button>').join("") + '</div>' : '') +
      genericLinkRowHtml(assignmentBookLinks(a), "asg:" + a.id) +
      (a.type === "test" ? '<div class="tests-row">' +
        '<label>' + t("fCompleted") + '<input type="number" min="0" class="a-completed" value="' + (tr.completed || 0) + '"></label>' +
        '<label>' + t("fCorrect") + '<input type="number" min="0" class="a-correct" value="' + (tr.correct || 0) + '"></label>' +
        '<label>' + t("totalTestsInput") + '<input type="number" min="0" class="a-total" value="' + total + '"></label>' +
      '</div>' : '') +
      '<div class="part-actions">' +
        '<button class="edit-btn">' + t("editBtn") + '</button>' +
        (a.type === "test" ? '<button class="asg-focus-btn">' + esc(t("asgFocusStart")) + '</button>' : '') +
        (linkInfo ? '<button class="jump-btn bt-topic-jump">' + t("goToTopic") + '</button>' : '') +
        '<button class="del-btn">' + t("delAsg") + '</button>' +
        boxMenuBtnHtml() +
      '</div>';
    row.querySelector('input[type="checkbox"]').addEventListener("change", (e) => {
      setDone(b, e.target.checked); // v1.11.30 (P1-1): stamps the tick date
      saveState(); renderAll();
    });
    if (a.type === "test") {
      row.querySelector(".a-completed").addEventListener("change", (e) => setBoxTests(b.id, "completed", e.target.value));
      row.querySelector(".a-correct").addEventListener("change", (e) => setBoxTests(b.id, "correct", e.target.value));
      row.querySelector(".a-total").addEventListener("change", (e) => {
        const total2 = Math.max(0, parseInt(e.target.value, 10) || 0);
        // v1.11.50: guard the writes (a null map threw here).
        state.tests_total = state.tests_total || {};
        state.tests = state.tests || {};
        state.tests_total[b.id] = total2;
        // Lowering the total clamps the completed count (see setBoxTests).
        const cur = state.tests[b.id];
        if (cur && cur.completed > total2) { cur.completed = total2; if (cur.correct > total2) cur.correct = total2; }
        saveState(); renderAll();
      });
    }
    row.querySelector(".part-actions .edit-btn").addEventListener("click", () => openEditBox(b));
    const focusBtn = row.querySelector(".asg-focus-btn");
    if (focusBtn) focusBtn.addEventListener("click", () => openFocusForAssignment(b.id));
    wireBoxMenuBtn(row.querySelector(".menu-btn"), b);
    // v1.11.23 (QA BUG-005): the topic button has its own class. The
    // old `row.querySelector(".jump-btn")` grabbed the FIRST .jump-btn
    // in the row — an exam link when one exists — and wired jumpToTopic
    // onto it, leaving the real topic button dead and the exam button
    // with two handlers. Never attach jumpToTopic to .bt-link-jump.
    const jump = row.querySelector(".part-actions .bt-topic-jump");
    if (jump) jump.addEventListener("click", () => jumpToTopic(linkId));
    row.querySelectorAll(".bt-link-jump").forEach(btn => btn.addEventListener("click", () => jumpToExam(btn.dataset.exam)));
    row.querySelector(".del-btn").addEventListener("click", () => {
      if (!confirm(t("delAsgConfirm"))) return;
      if (b.id.startsWith("custom-")) {
        state.custom_boxes = (state.custom_boxes || []).filter(x => x.id !== b.id);
      } else {
        state.deleted = (state.deleted || []).concat([b.id]);
      }
      purgeBoxState(b.id);
      saveState(); renderAll();
    });
    wireOwnerLinkRow(row, "asg:" + a.id,
      () => assignmentBookLinks(a),
      (entries) => { if (entries.length) a.bookLinks = entries; else delete a.bookLinks; });
    wrap.appendChild(row);
  });
  attachCollapsible(wrap, ".assign-card", 6);
}

// ---- Assignment creation form: subject -> book -> chapter -> topic ----
function asgBookOptions(subject) {
  const bookId = bookForSubject(subject);
  let html = '<option value="none">' + t("noBookLink") + '</option>';
  (TESTBOOK.books || []).forEach(book => {
    html += '<option value="' + esc(book.id) + '"' + (book.id === bookId ? " selected" : "") + '>' + t("bookWord") + esc(bookName(book)) + '</option>';
  });
  return html;
}
function asgFillCascade() {
  const subject = document.getElementById("asgSubject").value;
  const type = document.getElementById("asgType").value;
  const bookSel = document.getElementById("asgBook");
  const chSel = document.getElementById("asgChapter");
  const tpSel = document.getElementById("asgTopic");
  // v1.11.45 (F-07): preserve the previous book/chapter/topic ONLY when
  // the subject is unchanged (a language-switch rebuild). On a subject
  // change the old book (e.g. the chemistry book) still exists among
  // the options, so preserving it would keep the wrong book for the
  // new subject — re-match the auto-matched book instead. The 1.11.42
  // "none" guard is kept for the unchanged-subject path.
  const subjectChanged = asgFillCascade._prevSubject != null && asgFillCascade._prevSubject !== subject;
  asgFillCascade._prevSubject = subject;
  // A language switch rebuilds these selects: keep the user's current
  // book/chapter/topic when the option still exists (else first option).
  const prevBook = subjectChanged ? null : bookSel.value;
  const prevCh = subjectChanged ? null : chSel.value;
  const prevTp = subjectChanged ? null : tpSel.value;
  const has = (sel, v) => v && [...sel.options].some(o => o.value === v);
  const row = document.getElementById("asgBookRow");
  const isTest = type === "test";
  row.style.display = isTest ? "" : "none";
  document.getElementById("asgHint").textContent = isTest
    ? t("asgHintTest")
    : t("asgHintOther");
  bookSel.innerHTML = asgBookOptions(subject);
  // v1.11.42 (item 13): a previous "none" must NOT override the
  // auto-matched book for the new subject — otherwise the `selected`
  // marker in asgBookOptions never takes effect and the chapter/section
  // menus stay disabled for every subject until the book is picked by
  // hand. An explicitly chosen book (not "none") is still preserved,
  // e.g. across a language switch.
  if (prevBook && has(bookSel, prevBook) && prevBook !== "none") bookSel.value = prevBook;
  const bookId = bookSel.value === "none" ? null : bookSel.value;
  const book = (TESTBOOK.books || []).find(b => b.id === bookId);
  // v1.11.42 (UI-audit batch 2, item 13): with no book chosen the
  // chapter/section menus are disabled with «اول کتاب را انتخاب کن»
  // instead of rendering as two empty, unexplained dropdowns.
  const pickFirst = '<option value="">' + esc(t("asgPickBookFirst")) + '</option>';
  chSel.disabled = !book;
  tpSel.disabled = !book;
  chSel.innerHTML = book ? book.chapters.map(ch =>
    '<option value="' + esc(ch.id) + '">' + esc(chapterTitle(ch)) + '</option>').join("") : pickFirst;
  if (prevCh && has(chSel, prevCh)) chSel.value = prevCh;
  const ch = book ? (book.chapters.find(c => c.id === chSel.value) || book.chapters[0]) : null;
  tpSel.innerHTML = ch ? ch.topics.map(t =>
    '<option value="' + esc(t.id) + '">' + esc(topicTitle(t)) + '</option>').join("") : pickFirst;
  if (prevTp && has(tpSel, prevTp)) tpSel.value = prevTp;
}
function asgInitForm() {
  const subjSel = document.getElementById("asgSubject");
  const subjects = [...new Set(allBoxes().map(x => x.subject))].sort();
  ["شیمی", "حسابان", "فیزیک"].forEach(s => { if (!subjects.includes(s)) subjects.unshift(s); });
  subjSel.innerHTML = subjects.map(s => '<option value="' + esc(s) + '">' + esc(subjName(s)) + '</option>').join("");
  document.getElementById("asgDate").value = jalaliInputText(TODAY); // v1.11.41: Jalali text input
  subjSel.addEventListener("change", asgFillCascade);
  document.getElementById("asgType").addEventListener("change", asgFillCascade);
  document.getElementById("asgBook").addEventListener("change", () => {
    const book = (TESTBOOK.books || []).find(b => b.id === document.getElementById("asgBook").value);
    const chSel = document.getElementById("asgChapter");
    const tpSel = document.getElementById("asgTopic");
    // v1.11.42 (item 13): same disabled placeholder as asgFillCascade
    // when the book is un-picked again.
    const pickFirst = '<option value="">' + esc(t("asgPickBookFirst")) + '</option>';
    chSel.disabled = !book;
    tpSel.disabled = !book;
    chSel.innerHTML = book ? book.chapters.map(ch =>
      '<option value="' + esc(ch.id) + '">' + esc(chapterTitle(ch)) + '</option>').join("") : pickFirst;
    const ch = book ? book.chapters[0] : null;
    tpSel.innerHTML = ch ? ch.topics.map(t =>
      '<option value="' + esc(t.id) + '">' + esc(topicTitle(t)) + '</option>').join("") : pickFirst;
  });
  document.getElementById("asgChapter").addEventListener("change", () => {
    const book = (TESTBOOK.books || []).find(b => b.id === document.getElementById("asgBook").value);
    const ch = book ? book.chapters.find(c => c.id === document.getElementById("asgChapter").value) : null;
    document.getElementById("asgTopic").innerHTML = ch ? ch.topics.map(t =>
      '<option value="' + esc(t.id) + '">' + esc(topicTitle(t)) + '</option>').join("") : "";
  });
  document.getElementById("asgAddBtn").addEventListener("click", async (ev) => {
    // v1.11.45 (F-09): same double-click guard as the add-box button.
    const _btn = ev && ev.currentTarget ? ev.currentTarget : document.getElementById("asgAddBtn");
    if (_btn.disabled) return;
    _btn.disabled = true;
    try {
    const title = document.getElementById("asgTitle").value.trim();
    if (!title) { alert(t("asgTitleAlert")); return; }
    // v1.11.41 (UI-audit batch 1): the assignment date is a Jalali
    // text input now — parse it back to the stored Gregorian ISO.
    const dateRaw = document.getElementById("asgDate").value.trim();
    const date = dateRaw === "" ? TODAY : parseJalaliInput(dateRaw);
    if (dateRaw !== "" && !date) { alert(t("jalaliInvalid")); return; }
    const subject = subjSel.value;
    const type = document.getElementById("asgType").value;
    const total = Math.max(0, parseInt(document.getElementById("asgTotal").value, 10) || 0);
    const note = document.getElementById("asgNote").value;
    const topicId = (type === "test" && document.getElementById("asgBook").value !== "none")
      ? document.getElementById("asgTopic").value : null;
    const isTest = type === "test";
    const topic = topicId && topicById(topicId) ? topicById(topicId).topic.title : title;
    // v1.11.31 (P1-10): create through POST /api/boxes/create — the
    // server validates and assigns the id. An explicit server error
    // aborts; an OK response without a box (or an unreachable server)
    // falls back to the old local creation, so the box is never lost.
    // v1.11.52 (F3): idempotent create (client_id + adopt on lost response).
    const created = await createBoxIdempotent({ title, date, start: "09:00", end: "10:30", subject, topic, is_test: isTest, tests_total: isTest ? total : 0, note });
    let box = created.box, serverErr = created.serverErr;
    if (serverErr) { alert(errText(serverErr)); return; }
    if (!box) {
      box = {
        id: localBoxId(), date, start: "09:00", end: "10:30", subject,
        topic, title, is_test: isTest, tests_total: isTest ? total : 0, note
      };
    }
    (state.custom_boxes = state.custom_boxes || []).push(box);
    state.topicLinks = state.topicLinks || {};
    if (topicId) state.topicLinks[box.id] = topicId;
    else state.topicLinks[box.id] = "none";
    if (Array.isArray(state.assignments)) {
      state.assignments.push({ id: "asg-" + box.id, boxId: box.id, type });
    }
    document.getElementById("asgTitle").value = "";
    document.getElementById("asgNote").value = "";
    saveState(); renderAll();
    showToast(t("asgAdded")); // v1.11.41: toast instead of the native alert
    } finally { _btn.disabled = false; }
  });
  asgFillCascade();
}

// ---- Exams system (آزمون‌ها) — three independent stores + Dashboard link ----
// Data model: state.exams = { maz: [...], zoodbist: [...], school: [...] }.
// Each exam: { id, group, name, stage, subject, date, jalaliFa, jalaliEn,
//   type, questions, status ("upcoming"|"held"|"analyzed"),
//   focusFa, focusEn,
//   budget: [{ subject, questions, chapters: [{ name, topics: [{ name, questions }] }] }],
//   result: { taraz, rank, rankTotal, correct, wrong, unanswered, note } | null }
// Live data lives ONLY in state.exams (persisted via /api/state).
// public/exams.json is the SEED only: on first load, missing seed exams are
// added (old state.examResults are folded into exam.result). Deleted seed
// exams are remembered in state.examsRemoved so they are never re-seeded.
let examGroup = "maz";
let examView = "cats";        // "cats" = three category cards | "list" = category's exam list
let selectedExamId = null;    // exam shown in the detail column
// Which budget topics are expanded to show their subtopics (UI-only state,
// keyed "examId|subjectIdx|chapterIdx|topicIdx" — not persisted).
const expandedBudgetTopics = new Set();
// Which budget <details> chapters are open (same reason: re-renders must
// not collapse a chapter the user just opened to work on subtopics).
const openBudgetChapters = new Set();

function deriveExamStatus(ex) {
  if (ex.result) return "analyzed";
  if (!ex.date) return "upcoming";
  return ex.date < realTodayIso() ? "held" : "upcoming";
}
function ensureExams() {
  if (!state.exams || typeof state.exams !== "object") state.exams = { maz: [], zoodbist: [], school: [] };
  ["maz", "zoodbist", "school"].forEach(g => { if (!Array.isArray(state.exams[g])) state.exams[g] = []; });
  state.examsRemoved = state.examsRemoved || [];
  // Once a seed exam has been offered, it is never re-offered — this is
  // what stops a reset (which clears state.exams) from re-seeding all 35
  // exams at once. Future NEW seed ids still seed normally.
  state.examsSeededIds = state.examsSeededIds || [];
  const removed = new Set(state.examsRemoved);
  const seeded = new Set(state.examsSeededIds);
  const seed = (EXAMS.exams || []);
  let changed = false;
  seed.forEach(se => {
    if (removed.has(se.id) || seeded.has(se.id) || findExam(se.id)) return;
    const e = Object.assign({}, se);
    e.result = (state.examResults || {})[se.id] || null;
    e.status = e.status || deriveExamStatus(e);
    e.budget = e.budget || [];
    if (!state.exams[e.group]) state.exams[e.group] = [];
    state.exams[e.group].push(e);
    state.examsSeededIds.push(se.id);
    changed = true;
  });
  if (changed) saveState();
}
function allExams() {
  return ["maz", "zoodbist", "school"].reduce((acc, g) => acc.concat(state.exams[g] || []), []);
}
function findExam(id) { return allExams().find(e => e.id === id) || null; }
function examStatusOf(ex) {
  // A stored status that contradicts the date/result is stale (e.g. the
  // modal saved "upcoming" for an exam that has since passed, or
  // "analyzed" with no result): re-derive instead of trusting it.
  const derived = deriveExamStatus(ex);
  const stored = ex.status;
  if (!stored) return derived;
  if (stored === "analyzed" && !ex.result) return derived;
  if ((stored === "upcoming" || stored === "held") && stored !== derived) return derived;
  return stored;
}
function examDisplayName(ex) {
  if (ex.name) return ex.name;
  if (ex.group === "maz") return t("exStage", { n: FA(ex.stage) });
  const s = ex.stage ? t("exStage", { n: FA(ex.stage) }) + " — " : "";
  const sub = ex.subject ? subjName(ex.subject) : "";
  if (s || sub) return s + sub;
  return t(examGroupKey(ex.group)) + " — " + (ex.date || t("exNoDate"));
}
function examDateText(ex) {
  if (!ex.date) return t("exNoDate");
  // Always compute live from ex.date (v1.11.18): the stored jalaliFa/
  // jalaliEn strings went stale when an exam's date was edited, because
  // the edit save never recomputed them (days-left was correct — it
  // already computed live from ex.date). jalaliParts covers every month,
  // so Dey+ exams keep a correct Jalali date too. The stored fields are now
  // unused but harmless — no migration, no writes to them.
  const p = jalaliParts(ex.date);
  // Plain digits, no thousands separator: FA() would give «۱٬۴۰۵» for
  // the year (same trap as calMonthLabel) — the seed strings are «۱۴۰۵».
  const faNum = (n) => String(n).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[+d]);
  const j = LANG === "fa"
    ? faNum(p.jd) + " " + t(jalaliMonthKey(p.jm)) + " " + faNum(p.jy)
    : t(jalaliMonthKey(p.jm)) + " " + p.jd + ", " + p.jy;
  return weekdayName(ex.date) + " " + j;
}
function examGroupKey(group) {
  return group === "maz" ? "exSubMaz" : group === "zoodbist" ? "exSubZb" : "exSubSchool";
}
function examGroupLabel(ex) {
  return t(examGroupKey(ex.group));
}
function isUpcomingExam(ex) {
  return examStatusOf(ex) === "upcoming" && !!ex.date && ex.date >= realTodayIso();
}
function upcomingExams(days) {
  const end = addDays(realTodayIso(), days);
  return allExams().filter(e => isUpcomingExam(e) && e.date <= end)
    .sort((a, b) => a.date.localeCompare(b.date));
}
function nearestExam() {
  const u = upcomingExams(36500);
  return u.length ? u[0] : null;
}
// v1.11.31 (P1-9): the exam a category opens on — the nearest upcoming
// exam in that category; when the category has no upcoming exam, the
// last held one. Never the first item in the list.
function defaultExamFor(items) {
  if (!items || !items.length) return null;
  const ups = items.filter(isUpcomingExam)
    .sort((a, b) => (a.date || "9999").localeCompare(b.date || "9999"));
  return ups.length ? ups[0] : items[items.length - 1];
}

// ---------- Remaining-workload forecast (audit §5 item 2.3) ----------
// For an upcoming exam: remaining tests ÷ days left = tests/day needed,
// and the same for the hours of undone boxes linked to the exam budget.
// The verdict (on track / behind / impossible) compares the needed
// daily pace with the user's historical daily rate (last 28 days,
// days with at least one done box only). If no test counts were ever
// entered for the budget, the tests part says so instead of a false
// "0 remaining" — a zero total means "unknown", never "done".
function historicalDailyRate() {
  const from = addDays(TODAY, -28);
  const days = {};
  allBoxes().forEach(b => {
    const sd = boxStudyDay(b) || b.date;
    if (!sd || sd < from || sd >= TODAY || !isDone(b)) return;
    const d = days[sd] = days[sd] || { tests: 0, minutes: 0 };
    d.tests += (testOf(b).completed || 0);
    d.minutes += minutesBetween(b.start || "00:00", b.end || "00:00");
  });
  const active = Object.keys(days);
  if (!active.length) return { testsPerDay: 0, minutesPerDay: 0, activeDays: 0 };
  const tests = active.reduce((s, d) => s + days[d].tests, 0);
  const minutes = active.reduce((s, d) => s + days[d].minutes, 0);
  return { testsPerDay: tests / active.length, minutesPerDay: minutes / active.length, activeDays: active.length };
}
// ---------- Forecasted programme end date (v1.11.48, P-1) ----------
// From the recent completion pace (dated ticks only — a legacy
// dateless tick is "unknown" and never counts): boxes/day over the
// last 7 days, falling back to the last 14 days when the 7-day rate
// is 0. Remaining boxes ÷ rate = days needed; the end date is TODAY
// + days, compared with the programme deadline (state.programme_end,
// 27 Azar 1405) in whole days. A zero rate shows «—» — never a
// fabricated date. The rate divides by CALENDAR days in the window
// (rest days count against the pace — that is the point: at THIS
// pace, when is it done?), unlike historicalDailyRate's active days.
function forecastEndDate() {
  const all = allBoxes();
  const remaining = all.filter(b => !isDone(b)).length;
  if (!remaining) return null;
  const rateFor = (days) => {
    const from = addDays(TODAY, -(days - 1));
    let n = 0;
    all.forEach(b => {
      const d = doneDate(b);
      if (!d || d < from || d > TODAY) return;
      n++;
    });
    return n / days;
  };
  let rate = rateFor(7), windowDays = 7;
  if (!(rate > 0)) { rate = rateFor(14); windowDays = 14; }
  if (!(rate > 0)) return null;
  const daysNeeded = Math.ceil(remaining / rate);
  const endDate = addDays(TODAY, daysNeeded);
  const deadline = state.programme_end || "2026-12-18";
  const diffDays = Math.round((Date.parse(deadline) - Date.parse(endDate)) / 86400000);
  return { rate, windowDays, endDate, remaining, diffDays };
}
function examBudgetLinkIds(ex) {
  const ids = new Set();
  (ex.budget || []).forEach(s => (s.chapters || []).forEach(ch => (ch.topics || []).forEach(tp => {
    budgetTopicLinks(s.subject, tp.name).forEach(id => ids.add(id));
    topicLinks(tp).forEach(l => { if (l.sectionId) ids.add(l.sectionId); });
  })));
  return ids;
}
function examForecast(ex) {
  if (!ex || !ex.date || examStatusOf(ex) !== "upcoming") return null;
  const topics = [];
  (ex.budget || []).forEach(s => (s.chapters || []).forEach(ch =>
    (ch.topics || []).forEach(tp => topics.push(tp))));
  if (!topics.length) return null; // no budget at all: nothing to forecast
  const daysLeft = examDaysLeft(ex);
  const linkIds = examBudgetLinkIds(ex);
  let remTests = 0, hasCounts = false;
  (ex.budget || []).forEach(s => (s.chapters || []).forEach(ch => (ch.topics || []).forEach(tp => {
    // Subtopic topics carry no test total (their progress is subtopic
    // ticks, not test counts) — they never contribute to "remaining tests".
    if (Array.isArray(tp.subtopics) && tp.subtopics.length) return;
    const p = budgetTopicProgress(s.subject, tp.name, tp.subtopics, topicLinks(tp));
    if (p.total > 0) { hasCounts = true; remTests += Math.max(0, p.total - p.solved); }
  })));
  let remMinutes = 0;
  // v1.11.45 (E-03): positive evidence for "onTrack" — linked boxes
  // exist and are ALL done (remMinutes is 0 because nothing is left).
  const linkedAny = allBoxes().some(b => {
    const sd = boxStudyDay(b) || b.date;
    return sd && sd < ex.date && linkIds.has(linkedTopicIdCached(b));
  });
  allBoxes().forEach(b => {
    if (isDone(b)) return;
    const sd = boxStudyDay(b) || b.date;
    // v1.11.45 (E-04): boxes ON the exam date are all post-exam
    // (analysis 15:45–23:00) — they cannot help the exam either.
    if (!sd || sd >= ex.date) return;
    if (!linkIds.has(linkedTopicIdCached(b))) return;
    remMinutes += minutesBetween(b.start || "00:00", b.end || "00:00");
  });
  const rate = historicalDailyRate();
  const needTests = daysLeft >= 1 ? remTests / daysLeft : (remTests > 0 ? Infinity : 0);
  const needMinutes = daysLeft >= 1 ? remMinutes / daysLeft : (remMinutes > 0 ? Infinity : 0);
  // No history yet (rate 0) means "cannot confirm the pace" — that is
  // "behind", never "impossible": impossibility needs a real rate to
  // compare against. (A zero rate with zero need is 0, i.e. fine.)
  const ratio = (need, r) => (need <= 0 ? 0 : (r > 0 ? need / r : 1.5));
  const worst = Math.max(ratio(needTests, rate.testsPerDay), ratio(needMinutes, rate.minutesPerDay));
  let verdict;
  // v1.11.45 (E-03): remTests/remMinutes are 0 BY CONSTRUCTION when
  // no counts were ever entered and no boxes are linked — that is
  // "unknown", never "onTrack". onTrack needs positive evidence:
  // counts entered (hasCounts) or linked boxes that are all done.
  if (remTests === 0 && remMinutes === 0) verdict = (hasCounts || linkedAny) ? "onTrack" : "unknown";
  else if (daysLeft <= 0) verdict = "impossible";
  else if (worst <= 1) verdict = "onTrack";
  else if (worst <= 1.5) verdict = "behind";
  else verdict = "impossible";
  return { exam: ex, daysLeft, remTests, hasCounts, remMinutes, needTests, needMinutes, rate, verdict };
}
function examForecastHtml(ex) {
  const f = examForecast(ex);
  if (!f) return "";
  const verdictKey = { onTrack: "fcVerdictOnTrack", behind: "fcVerdictBehind",
                       impossible: "fcVerdictImpossible", unknown: "fcVerdictUnknown" }[f.verdict];
  let html = '<div class="fc-block"><div class="fc-title">' + t("fcTitle") + ' — ' + esc(examDisplayName(ex)) + '</div><div class="fc-rows">';
  if (!f.hasCounts) {
    html += '<div class="fc-row"><span>' + t("fcTestsLeft") + '</span><b>' + t("fcEnterCounts") + '</b></div>';
  } else {
    html += '<div class="fc-row"><span>' + t("fcTestsLeft") + '</span><b>' + FA(f.remTests) + ' ' + t("testsWord") + '</b></div>' +
      '<div class="fc-row"><span>' + t("fcTestsPerDay") + '</span><b>' + (f.needTests === Infinity ? "—" : FA(Math.round(f.needTests))) + ' ' + t("testsWord") + '</b></div>';
  }
  html += '<div class="fc-row"><span>' + t("fcHoursLeft") + '</span><b>' + sumDur(f.remMinutes) + '</b></div>' +
    '<div class="fc-row"><span>' + t("fcHoursPerDay") + '</span><b>' + (f.needMinutes === Infinity ? "—" : sumDur(Math.round(f.needMinutes))) + '</b></div>' +
    '<div class="fc-row"><span>' + t("fcRate") + '</span><b>' + (f.rate.activeDays
      ? FA(Math.round(f.rate.testsPerDay)) + ' ' + t("testsWord") + ' · ' + sumDur(Math.round(f.rate.minutesPerDay))
      : "—") + '</b></div>' +
    // v1.11.33 (P2-6): speed — current from the real rate (solved tests
    // per real minute over active days), required from the exam's own
    // question count and duration. Either missing means "—" or the hint,
    // never an invented number.
    '<div class="fc-row"><span>' + t("fcSpeedNow") + '</span><b>' + speedText(
      (f.rate.activeDays && f.rate.minutesPerDay > 0 && f.rate.testsPerDay > 0)
        ? speedOf(f.rate.testsPerDay, f.rate.minutesPerDay) : null) + '</b></div>' +
    '<div class="fc-row"><span>' + t("fcSpeedNeed") + '</span><b>' + (
      (ex.questions > 0 && ex.durationMin > 0)
        ? speedText(speedOf(ex.questions, ex.durationMin))
        : (ex.questions > 0 ? t("fcEnterDuration") : "—")) + '</b></div>' +
    '</div><div class="fc-verdict v-' + f.verdict + '">' + t(verdictKey) + '</div></div>';
  return html;
}
// realTodayIso: the REAL calendar date (not the study day). Used ONLY
// for the exam countdown (nearestExam / upcoming exams): an exam is a
// calendar event with a clock time (e.g. 13 Azar 08:00), so "days left"
// counts down from the calendar date — at 01:00 on exam day the exam is
// still today, even though the study day is still yesterday.
function realTodayIso() { return tehranParts(new Date()).iso; }
function examDaysLeft(ex) {
  if (!ex.date) return null;
  const today = new Date(realTodayIso() + "T12:00:00");
  const d = new Date(ex.date + "T12:00:00");
  return Math.round((d - today) / 86400000);
}
function examTypeLabel(type) {
  return { topical: t("exTypeTopical"), review: t("exTypeReview"),
           comprehensive: t("exTypeComprehensive"), descriptive: t("exTypeDescriptive"),
           school: t("exTypeSchool") }[type] || type;
}

// ---------- Budget topic -> test-book topic linking (computed, never stored) ----------
// Keywords per book topic; a budget topic links to every book topic whose
// keyword appears in its text. Short keywords (<=3 chars) must match a whole
// token, so "آب" does not false-match "آبکاری". Falls back to the existing
// autoTopicId (single best match) when no keyword hits.
const TOPIC_KEYWORDS = {
  "chem-c1-s1": ["کیهان"], "chem-c2-s5": ["گاز"], "chem-c3-s1": ["آب"],
  "chem-c4-s1": ["هدایای زمینی"], "chem-c5-s1": ["غذای سالم"], "chem-c6-s1": ["پوشاک"],
  "chem-c7-s1": ["مولکول"], "chem-c7-s3": ["pH", "اسید"],
  "chem-c8-s1": ["الکترون"], "chem-c8-s3": ["سلول سوختی"], "chem-c8-s6": ["آبکاری"],
  "chem-c9-s1": ["هنر"], "chem-c10-s1": ["آینده"],
  "calc-c1-l1": ["تابع"], "calc-c6-l51": ["مثلثات"],
  "calc-c7-l67": ["حد و پیوستگی"], "calc-c7-l72": ["نامتناهی", "بی‌نهایت"],
  "calc-c3-l24": ["معادله", "نامعادله", "تعیین علامت"],
  "calc-c5-l38": ["نمایی", "لگاریتم"], "calc-c10-l104": ["الگو", "دنباله"],
  "calc-c11-l110": ["توان گویا"], "calc-c8-l80": ["مشتق"],
  "phys-c1-w1": ["حرکت", "شتاب"],
  "phys-c2-w1": ["دینامیک", "حرکت دایره‌ای"], "phys-c3-w1": ["نوسان", "موج"],
  "phys-c4-w1": ["برهم‌کنش"], "phys-c5-w1": ["اتمی"], "phys-c6-w1": ["هسته‌ای"]
};
function bookOfSubject(subject) {
  if (!subject) return null;
  if (/شیمی/.test(subject)) return "chem";
  if (/حسابان|ریاضی/.test(subject)) return "calc";
  if (/فیزیک/.test(subject)) return "phys";
  if (/گسسته/.test(subject)) return "disc";
  if (/هندسه/.test(subject)) return "geom";
  return null;
}
function budgetTopicLinks(subject, topicName) {
  const bookId = bookOfSubject(subject);
  if (!bookId) return [];
  const text = topicName || "";
  const tokens = text.split(/[\s،؛:()\-–—\[\]]+/).filter(Boolean);
  const ids = [];
  (TESTBOOK.books || []).filter(b => b.id === bookId).forEach(book => {
    (book.chapters || []).forEach(ch => (ch.topics || []).forEach(tp => {
      const kws = TOPIC_KEYWORDS[tp.id] || [];
      const hit = kws.some(kw => {
        if (kw.indexOf(" ") >= 0) return text.indexOf(kw) >= 0;
        if (kw.length <= 3) return tokens.indexOf(kw) >= 0;
        return tokens.some(tok => tok.indexOf(kw) >= 0) || text.indexOf(kw) >= 0;
      });
      if (hit) ids.push(tp.id);
    }));
  });
  if (!ids.length) {
    const primary = autoTopicId({ subject: subject || "", title: topicName, topic: "" });
    if (primary) ids.push(primary);
  }
  return ids;
}
// v1.11.43 (§17 idea 2): box -> exam budget topic, for the «چرا این
// باکس؟» label. Built once per render (BUDGET_LINK_CACHE, reset by
// renderAll like LINKED_CACHE): for each exam (nearest first), each
// budget topic, the book topics it links to (budgetTopicLinks) map
// back to that exam topic. A box shows the label only when its linked
// topic resolves through this map — never invented. A manual override
// ("none") or an unmapped auto topic yields no label at all.
let BUDGET_LINK_CACHE = null;
function budgetLinkForBox(b) {
  if (!BUDGET_LINK_CACHE) {
    BUDGET_LINK_CACHE = new Map();
    const exams = allExams().slice().sort((a, c) => (a.date || "9999").localeCompare(c.date || "9999"));
    exams.forEach(ex => (ex.budget || []).forEach(s => (s.chapters || []).forEach(ch => (ch.topics || []).forEach(tp => {
      budgetTopicLinks(s.subject, tp.name).forEach(tid => {
        // v1.11.45 (F-14): keep EVERY exam per topic (date order) —
        // the label prefers the exam nearest AFTER the box's study
        // day, so a topic in both Zoodbist stage 2 and the Maz 13 Azar
        // budget labels a Maz-planned box as Maz, not Zoodbist.
        const arr = BUDGET_LINK_CACHE.get(tid) || [];
        arr.push({ exam: ex, subject: s.subject, chapter: ch.name, topic: tp.name });
        BUDGET_LINK_CACHE.set(tid, arr);
      });
    }))));
  }
  const tid = linkedTopicIdCached(b);
  const cands = tid ? BUDGET_LINK_CACHE.get(tid) : null;
  if (!cands || !cands.length) return null;
  const sd = boxStudyDay(b) || b.date;
  const after = cands.filter(c => (c.exam.date || "9999") >= (sd || "9999"));
  return after.length ? after[0] : cands[0];
}
// "ماز ۱۳ آذر ۱۴۰۵ · شیمی فصل ۱": group + live Jalali date + chapter
// (the subject is prepended only when the chapter name does not
// already contain it — "حسابان ۲" stays "حسابان ۲", not "حسابان حسابان ۲").
function budgetLabelText(info) {
  const when = t(examGroupKey(info.exam.group)) + " " + examDateText(info.exam);
  const what = (info.chapter || "").indexOf(info.subject) >= 0
    ? info.chapter : subjName(info.subject) + " " + (info.chapter || "");
  return when + " · " + what;
}

// Study progress of one budget topic, computed from the program/test books:
// done when its linked book topic(s) are fully solved (or all linked boxes
// are ticked when no total was ever entered), studying when some tests are
// done, not-studied when none. "nolink" when the topic has no test-book
// counterpart (e.g. a general subject — no book exists for it).
// When the topic has subtopics, THEY decide the progress instead:
// done when every subtopic is ticked, studying when some are, not-studied
// when none are. links are still computed (for the +تکلیف button).
// A MANUAL bookLinks list (set by the user) is authoritative: progress
// comes only from those sections, aggregated across ALL of them. Without
// one, the computed keyword match below is used as a fallback for the
// progress pill only — it never creates a link.
function budgetTopicProgress(subject, topicName, subtopics, links) {
  const ids = budgetTopicLinks(subject, topicName);
  const manual = (Array.isArray(links) ? links : []).map(l => l && l.sectionId).filter(Boolean);
  const subs = Array.isArray(subtopics) ? subtopics : [];
  if (subs.length) {
    const done = subs.filter(s => s.done).length;
    const st = done === subs.length ? "done" : (done > 0 ? "studying" : "not");
    const all = manual.concat(ids.filter(i => manual.indexOf(i) < 0));
    return { state: st, solved: done, total: subs.length, links: all, subtopics: true };
  }
  if (manual.length) {
    let solved = 0, total = 0, any = false;
    manual.forEach(id => {
      const found = topicById(id);
      if (!found) return;
      any = true;
      const s = topicStats(found.topic);
      solved += s.solved; total += s.total;
    });
    if (!any) return { state: "nolink", solved: 0, total: 0, links: [], manual: true, broken: true };
    let st;
    if (total > 0) st = solved >= total ? "done" : (solved > 0 ? "studying" : "not");
    else {
      const boxes = allBoxes().filter(b => manual.indexOf(linkedTopicId(b)) >= 0);
      st = boxes.length && boxes.every(isDone) ? "done" : (solved > 0 ? "studying" : "not");
    }
    return { state: st, solved, total, links: manual, manual: true };
  }
  if (!ids.length) return { state: "nolink", solved: 0, total: 0, links: [] };
  let solved = 0, total = 0;
  ids.forEach(id => {
    const found = topicById(id);
    if (!found) return;
    const s = topicStats(found.topic);
    solved += s.solved; total += s.total;
  });
  let st;
  if (total > 0) st = solved >= total ? "done" : (solved > 0 ? "studying" : "not");
  else {
    const boxes = allBoxes().filter(b => ids.indexOf(linkedTopicId(b)) >= 0);
    st = boxes.length && boxes.every(isDone) ? "done" : (solved > 0 ? "studying" : "not");
  }
  return { state: st, solved, total, links: ids };
}
// Whole-exam readiness, WEIGHTED by each topic's budget question
// count (v1.11.32, P2-4). A topic with no book counterpart
// ("nolink" — e.g. a general subject, which has no test book) is an
// EXPLICIT ZERO: its weight still counts in
// the denominator, never silently dropped, so readiness can never
// be 100% while a subject is uncovered. Weights: tp.questions when
// a number, else 1. HONEST NULL HANDLING: all 180 budget topics
// currently have questions = null, so every weight is 1 and the
// result is the plain equal-weight share — the UI says so openly
// (exReadWeightsEqual) instead of inventing a question count.
// Return keeps the old fields (total/done/studying/pct/state) so
// the Analytics insight that reads r0.pct/r0.done/r0.total is
// unchanged, and adds weighted/unweighted/nolink/nolinkSubjects.
function examReadiness(ex) {
  const topics = [];
  (ex.budget || []).forEach(s => (s.chapters || []).forEach(ch =>
    (ch.topics || []).forEach(tp => topics.push({ subject: s.subject, name: tp.name, subtopics: tp.subtopics, bookLinks: topicLinks(tp), questions: tp.questions }))));
  if (!topics.length) return null;
  let done = 0, studying = 0, counted = 0;
  let doneW = 0, totalW = 0, nolink = 0;
  const nolinkSubjects = [];
  let anyWeight = false;
  topics.forEach(tp => {
    const w = (typeof tp.questions === "number" && tp.questions > 0) ? tp.questions : 1;
    if (typeof tp.questions === "number" && tp.questions > 0) anyWeight = true;
    const p = budgetTopicProgress(tp.subject, tp.name, tp.subtopics, tp.bookLinks);
    counted++;
    totalW += w;
    if (p.state === "nolink") {
      nolink++;
      if (nolinkSubjects.indexOf(tp.subject) < 0) nolinkSubjects.push(tp.subject);
      return; // explicit zero: weight counted, progress 0
    }
    if (p.state === "done") { done++; doneW += w; }
    else if (p.state === "studying") { studying++; }
  });
  if (!counted) return { total: 0, done: 0, studying: 0, pct: null, state: "not" };
  // v1.11.42 (UI-audit batch 2, item 12): when NO budget topic has a
  // question count, the percentage has no denominator behind it —
  // «آمادگی: ۰٪» reads as "you are 0% ready". Readiness is then
  // unjudged (pct null → the UI shows «—»), while done/total and the
  // state pill still show the real coverage underneath.
  return { total: counted, done, studying,
           pct: anyWeight ? Math.round(doneW / totalW * 100) : null,
           state: done === counted ? "done" : (done > 0 || studying > 0 ? "studying" : "not"),
           weighted: anyWeight, unweighted: !anyWeight, nolink, nolinkSubjects };
}
// «بدون کتاب» line for a readiness result: the unlinked subjects,
// shown separately instead of being silently dropped (P2-4).
function examNoBookText(r) {
  if (!r || !r.nolink) return "";
  return t("exNoBook", { s: r.nolinkSubjects.map(s => subjName(s)).join("، "), n: FA(r.nolink) });
}
function progPillHtml(state) {
  const key = { done: "exProgDone", studying: "exProgStudying",
                not: "exProgNotStudied", nolink: "exProgNoLink" }[state];
  return '<span class="prog-pill p-' + state + '">' + t(key) + '</span>';
}
// ---------- Budget subtopics (زیرمبحث‌ها) ----------
// Data: topic.subtopics = [{ id, name, questions (nullable), done }].
// Stored inside state.exams with the topic itself; topics without the key
// behave as if they had [] — nothing else in the schema changes.
// Workflow: the user copies the ready-made prompt (copy-prompt button),
// asks Gemini for the fine subtopics of that topic, then pastes the list
// (one subtopic per line) into the bulk box here. No AI API is called.
function newSubId() {
  return "sub-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 7);
}
function ensureSubtopics(tp) {
  if (!Array.isArray(tp.subtopics)) tp.subtopics = [];
  return tp.subtopics;
}
// One subtopic per non-empty line; strips common list prefixes ("1. ", "۱)",
// "- ", "• ") so a pasted Gemini list works as-is.
function parseBulkLines(text) {
  return String(text || "").split(/\r?\n/).map(line => {
    let s = line.trim();
    s = s.replace(/^[\d۰-۹]+[.)）:：\-–]\s*/, "").replace(/^[-•*–—]\s*/, "").trim();
    return s;
  }).filter(Boolean);
}
function buildGeminiPrompt(ex, subject, chapter, topicName) {
  return t("exSubPrompt", {
    topic: topicName,
    chapter: chapter || "",
    subject: subjName(subject),
    exam: examDisplayName(ex),
    date: examDateText(ex)
  });
}
function copyTextToClipboard(text, btn) {
  const done = () => {
    const old = btn.textContent;
    btn.textContent = t("exSubCopied");
    btn.classList.add("copied");
    setTimeout(() => { btn.textContent = old; btn.classList.remove("copied"); }, 1600);
  };
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(done).catch(() => fallbackCopy(text, done));
  } else fallbackCopy(text, done);
}
function fallbackCopy(text, done) {
  const ta = document.createElement("textarea");
  ta.value = text;
  ta.style.position = "fixed"; ta.style.opacity = "0";
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand("copy"); } catch (e) {}
  ta.remove();
  done();
}
function subtopicsPanelHtml(ex, subj, ch, tp, key) {
  const subs = Array.isArray(tp.subtopics) ? tp.subtopics : [];
  let html = '<div class="subtopics" data-tkey="' + esc(key) + '">' +
    '<div class="sub-head"><span>' + t("exSubtopics") + ' · ' + FA(subs.length) + '</span>' +
    '<button class="btn sub-prompt-btn" data-action="copy-prompt">' + t("exSubCopyPrompt") + '</button></div>';
  if (!subs.length) html += '<p class="muted">' + t("exSubNone") + '</p>';
  subs.forEach(sub => {
    html += '<div class="sub-row' + (sub.done ? " done" : "") + '" data-sub="' + esc(sub.id) + '">' +
      '<input type="checkbox" class="sub-done" ' + (sub.done ? "checked" : "") + ' aria-label="' + esc(t("fDone")) + '">' +
      '<button class="sub-name" data-action="rename" title="' + esc(t("exSubRenamePrompt")) + '">' + esc(sub.name) + '</button>' +
      '<label class="sub-q-lbl">' + t("exBudgetQuestions") + ' <input type="number" min="0" class="sub-q" value="' + (sub.questions != null ? sub.questions : "") + '"></label>' +
      '<button class="sub-del" data-action="del-sub" title="' + esc(t("delBtn")) + '">✕</button>' +
      '</div>';
  });
  html += '<div class="sub-add-row">' +
    '<input type="text" class="sub-add-name" placeholder="' + esc(t("exSubAddPh")) + '">' +
    '<input type="number" min="0" class="sub-add-q" placeholder="' + esc(t("exBudgetQuestions")) + '">' +
    '<button class="btn sub-add-btn" data-action="add-sub">' + t("exSubAdd") + '</button></div>' +
    '<textarea class="sub-bulk" rows="3" placeholder="' + esc(t("exSubBulkPh")) + '"></textarea>' +
    '<button class="btn btn-primary sub-bulk-btn" data-action="add-bulk">' + t("exSubAddAll") + '</button>' +
    '</div>';
  return html;
}
// Budget rendering, shared by the Dashboard and the exam cards. Reads the
// exam's stored budget exactly — nothing is invented here.
// Every topic is expandable: click its name to show its subtopics (tick,
// rename, question count, delete), a single-add row, a bulk-paste box for
// Gemini's list, and the copy-prompt button.
// Which budget topic's inline book-link editor is open (UI-only, not persisted).
let linkEditingKey = null;
// ---------- Manual exam-topic -> book-section links (MULTI-SELECT) ----------
// The user sets the links himself, per budget topic: one book at a time,
// any chapters, any sections inside them (checkboxes, with select-all per
// chapter). Stored as topic.bookLinks = [{ bookId, chapterId, sectionId }]
// inside state.exams (same persistence as subtopics). Nothing is ever
// linked automatically. A section links to a topic at most once.
// The open editor works on a draft (linkDraft) — Cancel discards it.
// Read helper: returns the normalised list (migrates the old single
// topic.bookLink to a one-entry list on the fly).
function topicLinks(tp) {
  if (!tp) return [];
  const list = Array.isArray(tp.bookLinks)
    ? tp.bookLinks.filter(l => l && l.sectionId)
    : [];
  // Defensive: a legacy single bookLink is folded in even if an (empty)
  // bookLinks list already exists — never silently drop a stored link.
  if (tp.bookLink && tp.bookLink.sectionId &&
      !list.some(l => l.sectionId === tp.bookLink.sectionId)) list.push(tp.bookLink);
  return list;
}
// One-time migration: convert every legacy single bookLink into bookLinks.
// Runs after state is loaded (and after a backup restore), so old data
// survives exactly as it was — one entry, same section. Returns true when
// anything was converted, so the caller can persist the migration at once.
function normalizeExamLinks() {
  let changed = false;
  allExams().forEach(ex => (ex.budget || []).forEach(s => (s.chapters || []).forEach(ch =>
    (ch.topics || []).forEach(tp => {
      if (!Array.isArray(tp.bookLinks)) {
        tp.bookLinks = [];
        changed = true;
      }
      // A legacy single bookLink is folded into the list even when a
      // (possibly empty) bookLinks array already exists — a stored link
      // must never be dropped by the migration.
      if (tp.bookLink && tp.bookLink.sectionId &&
          !tp.bookLinks.some(l => l && l.sectionId === tp.bookLink.sectionId)) {
        tp.bookLinks.push(tp.bookLink);
        changed = true;
      }
      if (tp.bookLink) { delete tp.bookLink; changed = true; }
      const before = tp.bookLinks.length;
      const seen = new Set();
      tp.bookLinks = tp.bookLinks.filter(l => {
        if (!l || !l.sectionId || seen.has(l.sectionId)) return false;
        seen.add(l.sectionId);
        return true;
      });
      if (tp.bookLinks.length !== before) changed = true;
    }))));
  return changed;
}
// ---------- Manual book links for assignments & study boxes (v1.9.0) ----------
// Same model as exam-topic links: manual only, multi-select, stored in
// state.json (so B2 backup covers them). Assignments carry bookLinks on
// the assignment object; boxes carry them in state.boxBookLinks[boxId]
// (shipped boxes are read-only data, so their links live in state, like
// ticks and edits). Deleting a link never deletes data; deleting a box
// drops only that box's own links.
// Normalise any bookLinks list: drop broken entries, drop duplicates
// (first occurrence wins), keep the stored shape.
function bookLinksOf(list) {
  if (!Array.isArray(list)) return [];
  const seen = new Set();
  const out = [];
  list.forEach(l => {
    if (!l || !l.sectionId || seen.has(l.sectionId)) return;
    seen.add(l.sectionId);
    out.push({ bookId: l.bookId || "", chapterId: l.chapterId || "", sectionId: l.sectionId });
  });
  return out;
}
function boxBookLinks(boxId) {
  return bookLinksOf((state.boxBookLinks || {})[boxId]);
}
function assignmentBookLinks(a) {
  return bookLinksOf(a && a.bookLinks);
}
// One-time normalisation (runs after state load and after a backup
// restore): every stored assignment/box link list is deduped and cleaned.
function normalizeBoxBookLinks() {
  if (!state.boxBookLinks || typeof state.boxBookLinks !== "object") { state.boxBookLinks = {}; return true; }
  let changed = false;
  Object.keys(state.boxBookLinks).forEach(id => {
    const clean = bookLinksOf(state.boxBookLinks[id]);
    if (clean.length !== (state.boxBookLinks[id] || []).length) changed = true;
    if (clean.length) state.boxBookLinks[id] = clean;
    else { delete state.boxBookLinks[id]; changed = true; }
  });
  return changed;
}
function normalizeAssignmentLinks() {
  let changed = false;
  (state.assignments || []).forEach(a => {
    if (a.bookLinks === undefined) return;
    const clean = bookLinksOf(a.bookLinks);
    if (clean.length !== a.bookLinks.length) changed = true;
    if (clean.length) a.bookLinks = clean;
    else { delete a.bookLinks; changed = true; }
  });
  return changed;
}
// Shared link row (chips + add/edit/remove) for ANY link owner — exam
// topics, assignments and study boxes render the same row and the same
// multi-select editor; only the save target differs (see wireOwnerLinkRow).
// v1.11.37 (P3-5): the inner chips/buttons live in bookLinksInnerHtml
// so a box card can render them inside its ONE connection row
// (boxConnRowHtml) instead of a second, separate row.
function bookLinksInnerHtml(links) {
  if (links.length) {
    const chips = links.map(l => {
      const label = linkLabel(l);
      return '<span class="book-link-chip">' + esc(label || t("exLinkBroken")) +
        '<button class="bl-chip-x" data-action="del-one-link" data-section="' + esc(l.sectionId) +
        '" title="' + esc(t("exLinkRemoveOne")) + '">✕</button></span>';
    }).join("");
    return '<span class="bl-count">' + t("exLinkCount", { n: FA(links.length) }) + '</span>' + chips +
      '<button class="edit-btn bt-link-edit" data-action="edit-link">' + t("exLinkChange") + '</button>' +
      '<button class="edit-btn bt-link-del" data-action="del-link">' + t("exLinkRemove") + '</button>';
  }
  return '<button class="edit-btn bt-link-add" data-action="add-link">' + t("exLinkBook") + '</button>';
}
function genericLinkRowHtml(links, key) {
  if (linkEditingKey === key) return '<div class="budget-link-row">' + linkEditorHtml() + '</div>';
  return '<div class="budget-link-row">' + bookLinksInnerHtml(links) + '</div>';
}
// v1.11.37 (P3-5): ONE connection row on a box card — the budget-topic
// link and the book-section links, each with its own label, instead of
// the topic title floating in the time row plus a separate book row.
// The budget link is edited in the box edit modal (the topic select
// lives there — the row's «تغییر» opens it); the book links use the
// shared multi-select editor (wired by wireOwnerLinkRow on the card).
function boxConnRowHtml(b) {
  const key = "box:" + b.id;
  if (linkEditingKey === key) return '<div class="budget-link-row">' + linkEditorHtml() + '</div>';
  const link = linkedTopicId(b);
  const linkInfo = link && topicById(link);
  return '<div class="budget-link-row box-conn-row">' +
    '<span class="bl-conn-kind">' + esc(t("bkLinkBudget")) + '</span>' +
    (linkInfo
      ? '<span class="book-link-chip">' + esc(topicTitle(linkInfo.topic)) + '</span>'
      : '<span class="muted">' + esc(t("bkLinkNone")) + '</span>') +
    '<button class="edit-btn bt-link-edit" data-action="edit-topic">' + esc(t("exLinkChange")) + '</button>' +
    '<span class="bl-conn-kind">' + esc(t("bkLinkBook")) + '</span>' +
    bookLinksInnerHtml(boxBookLinks(b.id)) +
    '</div>';
}
// Wire one owner's link row (a part card, an assignment row, or the edit
// modal's link block): open the editor, remove one link, remove all
// links, or save the editor draft. getLinks/setLinks read/write the
// owner's own list; onSaved re-renders just that surface (renderAll by
// default; the modal passes its own re-render so the modal stays open).
function wireOwnerLinkRow(container, key, getLinks, setLinks, onSaved, onCancel) {
  const after = () => { saveState(); if (onSaved) onSaved(); else renderAll(); };
  container.querySelectorAll("[data-action='add-link'], [data-action='edit-link']").forEach(btn => btn.addEventListener("click", (e) => {
    e.stopPropagation();
    const links = getLinks();
    linkDraft = {
      bookId: (links[0] && links[0].bookId) || ((TESTBOOK.books || [])[0] || {}).id || "",
      entries: links.map(l => ({ bookId: l.bookId || "", chapterId: l.chapterId || "", sectionId: l.sectionId }))
    };
    linkEditingKey = key;
    if (onSaved) onSaved(); else renderAll();
  }));
  container.querySelectorAll("[data-action='del-one-link']").forEach(btn => btn.addEventListener("click", (e) => {
    e.stopPropagation();
    setLinks(getLinks().filter(l => l.sectionId !== btn.dataset.section));
    after();
  }));
  container.querySelectorAll("[data-action='del-link']").forEach(btn => btn.addEventListener("click", (e) => {
    e.stopPropagation();
    setLinks([]);
    linkEditingKey = null;
    linkDraft = null;
    after();
  }));
  const editor = container.querySelector(".link-editor");
  if (editor) wireLinkEditorSaveCancel(editor, (entries) => {
    setLinks(entries);
    linkEditingKey = null;
    linkDraft = null;
    after();
  }, onCancel ? () => { linkEditingKey = null; linkDraft = null; onCancel(); } : null);
}
// Multi-select editor wiring shared by every owner: book switch,
// chapter/section checkboxes, save (deduped, in book order) / cancel.
// onCancel re-renders the owner's surface instead of the whole app
// (the edit modal passes its own re-render so the modal stays open).
function wireLinkEditorSaveCancel(editor, onSave, onCancel) {
  const bookSel = editor.querySelector(".bl-book");
  bookSel.addEventListener("change", () => {
    linkDraft.bookId = bookSel.value;
    renderLinkChapters(editor);
  });
  wireLinkChapterEvents(editor);
  refreshLinkEditor(editor);
  editor.querySelector(".bl-save").addEventListener("click", (e) => {
    e.stopPropagation();
    if (!linkDraft.entries.length) { alert(t("exLinkNeedSection")); return; }
    const order = linkDraftOrderIndex();
    const entries = linkDraft.entries
      .filter((l, i, arr) => arr.findIndex(x => x.sectionId === l.sectionId) === i)
      .map(l => ({ bookId: l.bookId || "", chapterId: l.chapterId || "", sectionId: l.sectionId }))
      .sort((a, b) => (order[a.sectionId] != null ? order[a.sectionId] : 1e9) -
                       (order[b.sectionId] != null ? order[b.sectionId] : 1e9));
    onSave(entries);
  });
  editor.querySelector(".bl-cancel").addEventListener("click", (e) => {
    e.stopPropagation();
    linkEditingKey = null;
    linkDraft = null;
    if (onCancel) onCancel(); else renderAll();
  });
}
// "Book — Chapter — Section" label for one link (null when broken).
function linkLabel(l) {
  const found = topicById(l.sectionId);
  if (!found) return null;
  const parts = [];
  if (found.book) parts.push(bookName(found.book));
  if (found.chapter) parts.push(chapterTitle(found.chapter));
  parts.push(topicTitle(found.topic));
  return parts.join(" — ");
}
// The open multi-select editor's draft (UI-only, not persisted until Save).
let linkDraft = null; // { bookId, entries: [{ bookId, chapterId, sectionId }] }
function linkDraftOrderIndex() {
  const order = {};
  let i = 0;
  (TESTBOOK.books || []).forEach(book => (book.chapters || []).forEach(ch =>
    (ch.topics || []).forEach(tp => { order[tp.id] = i++; })));
  return order;
}
function linkRowHtml(tp, key) {
  return genericLinkRowHtml(topicLinks(tp), key);
}
// One chapter of the link editor: a header row with the chapter's
// select-all checkbox + an expand toggle + "x/y selected" count, and a
// collapsible body listing every section with its own checkbox.
// (A plain div, not <details>: a checkbox inside <summary> would toggle
// the chapter open/closed on every click.)
function linkEditorChapterHtml(book, ch, draftSet, open) {
  const topics = ch.topics || [];
  const sel = topics.filter(tp2 => draftSet.has(tp2.id)).length;
  return '<div class="bl-ch" data-chapter="' + esc(ch.id) + '">' +
    '<div class="bl-ch-head"><input type="checkbox" class="bl-ch-all" ' + (topics.length && sel === topics.length ? "checked" : "") +
    ' aria-label="' + esc(t("exLinkSelectAll")) + '">' +
    '<button type="button" class="bl-ch-toggle"><span class="bl-ch-chev">' + (open ? "▾" : "▸") + '</span>' +
    '<span class="bl-ch-name">' + esc(chapterTitle(ch)) + '</span>' +
    '<span class="bl-ch-count">' + FA(sel) + '/' + FA(topics.length) + '</span></button></div>' +
    '<div class="bl-sections"' + (open ? "" : ' style="display:none"') + '>' + topics.map(tp2 =>
      '<label class="bl-sec"><input type="checkbox" class="bl-sec-cb" data-section="' + esc(tp2.id) +
      '" data-chapter="' + esc(ch.id) + '" data-book="' + esc(book.id) + '"' +
      (draftSet.has(tp2.id) ? " checked" : "") + '><span>' + esc(topicTitle(tp2)) + '</span></label>').join("") +
    '</div></div>';
}
function linkEditorHtml() {
  const books = TESTBOOK.books || [];
  const draft = linkDraft || { bookId: "", entries: [] };
  const book = books.find(b => b.id === draft.bookId) || books[0] || null;
  const draftSet = new Set(draft.entries.map(l => l.sectionId));
  const chips = draft.entries.map(l => {
    const label = linkLabel(l);
    return '<span class="book-link-chip">' + esc(label || t("exLinkBroken")) +
      '<button class="bl-chip-x" data-action="del-draft-link" data-section="' + esc(l.sectionId) +
      '" title="' + esc(t("exLinkRemoveOne")) + '">✕</button></span>';
  }).join("");
  return '<div class="link-editor">' +
    '<select class="bl-book">' + books.map(b =>
      '<option value="' + b.id + '"' + (book && b.id === book.id ? " selected" : "") + '>' + esc(bookName(b)) + '</option>').join("") + '</select>' +
    '<div class="bl-selected">' +
      (draft.entries.length ? chips : '<span class="muted">' + esc(t("exLinkNoneSelected")) + '</span>') +
    '</div>' +
    '<div class="bl-selected-count">' + t("exLinkSelected", { n: FA(draft.entries.length) }) + '</div>' +
    '<div class="bl-chapters">' + (book ? (book.chapters || []).map((ch, ci) =>
      linkEditorChapterHtml(book, ch, draftSet, ci === 0)).join("") : "") + '</div>' +
    '<div class="bl-actions">' +
    '<button class="btn btn-primary bl-save">' + t("exLinkSave") + '</button>' +
    '<button class="btn bl-cancel">' + t("exLinkCancel") + '</button></div></div>';
}
// Rebuild only the chapter list (book switch); then refresh counts/chips.
function renderLinkChapters(editor) {
  const books = TESTBOOK.books || [];
  const book = books.find(b => b.id === linkDraft.bookId) || books[0] || null;
  const draftSet = new Set(linkDraft.entries.map(l => l.sectionId));
  const box = editor.querySelector(".bl-chapters");
  box.innerHTML = book ? (book.chapters || []).map((ch, ci) =>
    linkEditorChapterHtml(book, ch, draftSet, ci === 0)).join("") : "";
  wireLinkChapterEvents(editor);
  refreshLinkEditor(editor);
}
// Sync chips, count, chapter counts and checkboxes with the draft —
// without rebuilding the editor (keeps open chapters and scroll position).
function refreshLinkEditor(editor) {
  const draftSet = new Set(linkDraft.entries.map(l => l.sectionId));
  const selBox = editor.querySelector(".bl-selected");
  selBox.innerHTML = linkDraft.entries.length ? linkDraft.entries.map(l => {
    const label = linkLabel(l);
    return '<span class="book-link-chip">' + esc(label || t("exLinkBroken")) +
      '<button class="bl-chip-x" data-action="del-draft-link" data-section="' + esc(l.sectionId) +
      '" title="' + esc(t("exLinkRemoveOne")) + '">✕</button></span>';
  }).join("") : '<span class="muted">' + esc(t("exLinkNoneSelected")) + '</span>';
  editor.querySelector(".bl-selected-count").textContent = t("exLinkSelected", { n: FA(linkDraft.entries.length) });
  editor.querySelectorAll(".bl-ch").forEach(det => {
    const cbs = [...det.querySelectorAll(".bl-sec-cb")];
    const sel = cbs.filter(cb => draftSet.has(cb.dataset.section)).length;
    const count = det.querySelector(".bl-ch-count");
    if (count) count.textContent = FA(sel) + "/" + FA(cbs.length);
    const all = det.querySelector(".bl-ch-all");
    if (all) {
      all.checked = cbs.length > 0 && sel === cbs.length;
      all.indeterminate = sel > 0 && sel < cbs.length;
    }
    cbs.forEach(cb => { cb.checked = draftSet.has(cb.dataset.section); });
  });
  selBox.querySelectorAll("[data-action='del-draft-link']").forEach(btn =>
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      linkDraft.entries = linkDraft.entries.filter(l => l.sectionId !== btn.dataset.section);
      refreshLinkEditor(editor);
    }));
}
function wireLinkChapterEvents(editor) {
  editor.querySelectorAll(".bl-ch-toggle").forEach(btn => btn.addEventListener("click", (e) => {
    e.stopPropagation();
    const ch = btn.closest(".bl-ch");
    const secs = ch.querySelector(".bl-sections");
    const chev = btn.querySelector(".bl-ch-chev");
    const isOpen = secs.style.display !== "none";
    secs.style.display = isOpen ? "none" : "";
    if (chev) chev.textContent = isOpen ? "▸" : "▾";
  }));
  editor.querySelectorAll(".bl-ch-all").forEach(all => all.addEventListener("change", (e) => {
    e.stopPropagation();
    const det = all.closest(".bl-ch");
    const cbs = [...det.querySelectorAll(".bl-sec-cb")];
    if (all.checked) {
      cbs.forEach(cb => {
        if (!linkDraft.entries.some(l => l.sectionId === cb.dataset.section))
          linkDraft.entries.push({ bookId: cb.dataset.book, chapterId: cb.dataset.chapter, sectionId: cb.dataset.section });
      });
    } else {
      const ids = new Set(cbs.map(cb => cb.dataset.section));
      linkDraft.entries = linkDraft.entries.filter(l => !ids.has(l.sectionId));
    }
    refreshLinkEditor(editor);
  }));
  editor.querySelectorAll(".bl-sec-cb").forEach(cb => cb.addEventListener("change", () => {
    if (cb.checked) {
      if (!linkDraft.entries.some(l => l.sectionId === cb.dataset.section))
        linkDraft.entries.push({ bookId: cb.dataset.book, chapterId: cb.dataset.chapter, sectionId: cb.dataset.section });
    } else {
      linkDraft.entries = linkDraft.entries.filter(l => l.sectionId !== cb.dataset.section);
    }
    refreshLinkEditor(editor);
  }));
}
// Budget-topic SR control for the Exams tab (v1.11.37, P3-6): the three
// recall grades + the current next-review/ease, for budget topics of
// subjects with no testbook (geometry + general subjects). Wired in
// wireBudgetSubtopics via the data-sr-budget-* attributes.
function budgetSrControlHtml(subject, name) {
  const rec = budgetSrRecord(subject, name);
  const nr = rec && rec.last ? addDays(rec.last, rec.interval || 1) : null;
  let html = '<span class="bt-sr"><span class="bt-sr-lbl">' + esc(t("srMarkReview")) + '</span>';
  [["remembered", "srGradeRemembered"], ["hard", "srGradeHard"], ["forgot", "srGradeForgot"]].forEach(([grade, key]) => {
    html += '<button class="btn sr-grade-btn" data-sr-budget-grade="' + grade +
      '" data-sr-budget-subject="' + esc(subject) + '" data-sr-budget-name="' + esc(name) + '">' +
      esc(t(key)) + '</button>';
  });
  if (nr) html += '<span class="muted">' + esc(t("srNextReview", { d: gregToJalali(nr).text })) +
    ' · ' + esc(t("srEase", { n: FA(Math.round((rec.ease || SR_EASE_DEFAULT) * 100) / 100) })) + '</span>';
  return html + '</span>';
}
function budgetHtml(ex) {
  if (!ex.budget || !ex.budget.length) return "";
  let html = '<div class="budget">';
  // v1.11.32 (P2-4): the weighted readiness line — the percentage,
  // whether the weights are real or equal (question counts not
  // entered), and the «بدون کتاب» subjects, shown separately.
  const r = examReadiness(ex);
  if (r) {
    html += '<div class="budget-readiness"><span>' + esc(t("exReadiness")) + ': ' + (r.pct == null ? "—" : FA_PCT(r.pct)) +
      ' (' + FA(r.done) + '/' + FA(r.total) + ')</span>' +
      '<span class="muted">' + esc(r.unweighted ? t("exReadWeightsEqual") : t("exReadWeighted")) + '</span>' +
      (r.nolink ? '<span class="de-nobook">' + esc(examNoBookText(r)) + '</span>' : '') + '</div>';
  }
  ex.budget.forEach((s, si) => {
    html += '<div class="budget-subj"><div class="bs-head"><span class="bs-name">' +
      esc(subjName(s.subject)) + '</span><span class="bs-q">' +
      (s.questions != null ? t("exQuestions", { n: FA(s.questions) }) : "—") + '</span></div>';
    (s.chapters || []).forEach((ch, ci) => {
      const chKey = ex.id + "|" + si + "|" + ci;
      html += '<details class="budget-ch" data-chkey="' + esc(chKey) + '"' +
        (openBudgetChapters.has(chKey) ? " open" : "") + '><summary>' + esc(subjName(ch.name)) + ' · ' +
        // v1.11.72 (Batch 5, C7): the topic count on the collapsed
        // row, so the budget can be scanned without opening chapters.
        esc(t("exTopics", { n: FA((ch.topics || []).length) })) + '</summary>';
      (ch.topics || []).forEach((tp, ti) => {
        const key = ex.id + "|" + si + "|" + ci + "|" + ti;
        const open = expandedBudgetTopics.has(key);
        const p = budgetTopicProgress(s.subject, tp.name, tp.subtopics, topicLinks(tp));
        const pill = p.subtopics
          ? '<span class="prog-pill p-' + p.state + '">' + t("exSubProgress", { done: FA(p.solved), total: FA(p.total) }) + '</span>'
          : progPillHtml(p.state);
        html += '<div class="budget-topic-wrap" data-tkey="' + esc(key) + '">' +
          '<div class="budget-topic">' +
          '<button class="bt-toggle" data-action="toggle" title="' + esc(t("exSubtopics")) + '">' +
          '<span class="bt-chev">' + (open ? "▾" : "▸") + '</span>' +
          '<span class="bt-name">' + esc(tp.name) + '</span></button>' +
          '<span class="bt-q">' + (tp.questions != null ? FA(tp.questions) : "—") + '</span>' +
          pill +
          // v1.11.37 (P3-6): SR at budget-topic level for subjects with
          // no book (geometry + general subjects) — three recall grades.
          (!bookOfSubject(s.subject) ? budgetSrControlHtml(s.subject, tp.name) : '') +
          (p.links.length ? '<button class="jump-btn bt-asg" data-topic="' + esc(p.links[0]) +
            '" data-subject="' + esc(s.subject) + '">' + t("exAddAssignment") + '</button>' : '') +
          '</div>';
        html += linkRowHtml(tp, key);
        if (open) html += subtopicsPanelHtml(ex, s, ch, tp, key);
        html += '</div>';
      });
      html += '</details>';
    });
    html += '</div>';
  });
  return html + '</div>';
}
function wireBudgetSubtopics(container, ex) {
  container.querySelectorAll(".budget-ch").forEach(d => {
    d.addEventListener("toggle", () => {
      if (d.open) openBudgetChapters.add(d.dataset.chkey);
      else openBudgetChapters.delete(d.dataset.chkey);
    });
  });
  container.querySelectorAll(".budget-topic-wrap").forEach(wrap => {
    const key = wrap.dataset.tkey;
    const parts = key.split("|");
    const si = +parts[1], ci = +parts[2], ti = +parts[3];
    // Always resolve the LIVE topic object from state (renderAll rebuilds
    // the DOM, so stale references would silently edit a dead copy).
    const getTp = () => {
      const live = findExam(ex.id);
      if (!live) return null;
      const s = (live.budget || [])[si];
      if (!s) return null;
      const ch = (s.chapters || [])[ci];
      if (!ch) return null;
      return (ch.topics || [])[ti] || null;
    };
    const getCtx = () => {
      const live = findExam(ex.id) || ex;
      const s = (live.budget || [])[si] || {};
      const ch = (s.chapters || [])[ci] || {};
      return { live, subject: s.subject || "", chapter: ch.name || "" };
    };
    const refresh = () => { saveState(); renderAll(); };
    // Manual book links: open the multi-select editor, remove one link,
    // or remove all links of this topic.
    wrap.querySelectorAll("[data-action='add-link'], [data-action='edit-link']").forEach(btn => btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const tp = getTp();
      const links = topicLinks(tp);
      linkDraft = {
        bookId: (links[0] && links[0].bookId) || ((TESTBOOK.books || [])[0] || {}).id || "",
        entries: links.map(l => ({ bookId: l.bookId || "", chapterId: l.chapterId || "", sectionId: l.sectionId }))
      };
      linkEditingKey = key;
      renderAll();
    }));
    wrap.querySelectorAll("[data-action='del-one-link']").forEach(btn => btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const tp = getTp();
      if (!tp) return;
      tp.bookLinks = topicLinks(tp).filter(l => l.sectionId !== btn.dataset.section);
      refresh();
    }));
    wrap.querySelectorAll("[data-action='del-link']").forEach(btn => btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const tp = getTp();
      if (!tp) return;
      tp.bookLinks = [];
      delete tp.bookLink;
      linkEditingKey = null;
      linkDraft = null;
      refresh();
    }));
    // Multi-select editor: book switch, chapter/section checkboxes, save/cancel.
    const editor = wrap.querySelector(".link-editor");
    if (editor) wireLinkEditorSaveCancel(editor, (entries) => {
      const tp = getTp();
      if (!tp) return;
      tp.bookLinks = entries;
      delete tp.bookLink;
      linkEditingKey = null;
      linkDraft = null;
      refresh();
    });
    wrap.querySelectorAll(".bt-toggle").forEach(btn => btn.addEventListener("click", (e) => {
      e.stopPropagation();
      if (expandedBudgetTopics.has(key)) expandedBudgetTopics.delete(key);
      else expandedBudgetTopics.add(key);
      renderAll();
    }));
    // v1.11.37 (P3-6): budget-topic SR grades (geometry + general
    // subjects) — the buttons carry subject/name/grade in data attrs.
    wrap.querySelectorAll("[data-sr-budget-grade]").forEach(btn => btn.addEventListener("click", (e) => {
      e.stopPropagation();
      markBudgetTopicReviewed(btn.dataset.srBudgetSubject, btn.dataset.srBudgetName, btn.dataset.srBudgetGrade);
    }));
    wrap.querySelectorAll(".sub-prompt-btn").forEach(btn => btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const tp = getTp();
      if (!tp) return;
      const ctx = getCtx();
      copyTextToClipboard(buildGeminiPrompt(ctx.live, ctx.subject, ctx.chapter, tp.name), btn);
    }));
    wrap.querySelectorAll(".sub-row").forEach(row => {
      const subId = row.dataset.sub;
      const subDone = row.querySelector(".sub-done");
      if (subDone) subDone.addEventListener("change", (e) => {
        const tp = getTp();
        if (!tp) return;
        const sub = (tp.subtopics || []).find(s => s.id === subId);
        if (sub) { sub.done = e.target.checked; refresh(); }
      });
      const subName = row.querySelector(".sub-name");
      if (subName) subName.addEventListener("click", (e) => {
        e.stopPropagation();
        const tp = getTp();
        if (!tp) return;
        const sub = (tp.subtopics || []).find(s => s.id === subId);
        if (!sub) return;
        const name = prompt(t("exSubRenamePrompt"), sub.name);
        if (name == null) return;
        sub.name = name.trim() || sub.name;
        refresh();
      });
      const subQ = row.querySelector(".sub-q");
      if (subQ) subQ.addEventListener("change", (e) => {
        const tp = getTp();
        if (!tp) return;
        const sub = (tp.subtopics || []).find(s => s.id === subId);
        if (!sub) return;
        const v = e.target.value.trim();
        sub.questions = v === "" ? null : Math.max(0, parseInt(v, 10) || 0);
        refresh();
      });
      const subDel = row.querySelector(".sub-del");
      if (subDel) subDel.addEventListener("click", (e) => {
        e.stopPropagation();
        const tp = getTp();
        if (!tp) return;
        const sub = (tp.subtopics || []).find(s => s.id === subId);
        if (!sub) return;
        // v1.11.63 (Batch 4, PR5): a subtopic delete used to be one
        // click, no confirm, no undo — now it asks first and offers a
        // 5-second «بازگردانی» (the stats-modal subject-delete pattern).
        if (!confirm(t("exSubDelConfirm", { name: sub.name }))) return;
        const idx = (tp.subtopics || []).indexOf(sub);
        tp.subtopics = (tp.subtopics || []).filter(s => s.id !== subId);
        refresh();
        showToast(t("exSubDeleted"), { ms: 5000, action: { label: t("undoBtn"), fn: () => {
          const cur = getTp();
          if (!cur) return;
          cur.subtopics = cur.subtopics || [];
          cur.subtopics.splice(Math.max(0, Math.min(idx, cur.subtopics.length)), 0, sub);
          refresh();
        } } });
      });
    });
    const addBtn = wrap.querySelector(".sub-add-btn");
    if (addBtn) addBtn.addEventListener("click", () => {
      const tp = getTp();
      if (!tp) return;
      const nameInp = wrap.querySelector(".sub-add-name");
      const qInp = wrap.querySelector(".sub-add-q");
      const name = (nameInp.value || "").trim();
      if (!name) return;
      const qv = (qInp.value || "").trim();
      ensureSubtopics(tp).push({
        id: newSubId(), name,
        questions: qv === "" ? null : Math.max(0, parseInt(qv, 10) || 0),
        done: false
      });
      refresh();
    });
    const bulkBtn = wrap.querySelector(".sub-bulk-btn");
    if (bulkBtn) bulkBtn.addEventListener("click", () => {
      const tp = getTp();
      if (!tp) return;
      const ta = wrap.querySelector(".sub-bulk");
      const lines = parseBulkLines(ta.value);
      if (!lines.length) return;
      const arr = ensureSubtopics(tp);
      lines.forEach(n => arr.push({ id: newSubId(), name: n, questions: null, done: false }));
      refresh();
    });
  });
}
function wireBudgetButtons(container) {
  container.querySelectorAll(".bt-asg").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      jumpToAssignmentForTopic(btn.dataset.topic, btn.dataset.subject);
    });
  });
}
function jumpToAssignmentForTopic(topicId, subjectName) {
  const found = topicById(topicId);
  if (!found) return;
  navigate({ tab: "assignments" });
  // Legacy topics (e.g. Maz stage 4 physics «دما و گرما — دهم») have
  // chapter: null (and possibly book: null): skip the book/chapter
  // steps instead of throwing inside the setTimeout and dying silently.
  const subj = found.book ? subjectForBook(found.book.id) : subjectName;
  const subjSel = document.getElementById("asgSubject");
  if (subj && subjSel) { subjSel.value = subj; asgFillCascade(); }
  setTimeout(() => {
    if (found.book) {
      const bookSel = document.getElementById("asgBook");
      bookSel.value = found.book.id;
      bookSel.dispatchEvent(new Event("change"));
    }
    setTimeout(() => {
      if (found.chapter) {
        const chSel = document.getElementById("asgChapter");
        chSel.value = found.chapter.id;
        chSel.dispatchEvent(new Event("change"));
      }
      setTimeout(() => {
        document.getElementById("asgTopic").value = topicId;
        document.getElementById("asgTitle").focus();
      }, 40);
    }, 40);
  }, 40);
}

// ---------- Dashboard: upcoming exams (30 days) + nearest exam budget ----------
// One upcoming-exam row — shared by the Exams tab and the dashboard strip
// (renderDashboard): same data (upcomingExams), same markup, same click
// behaviour. No new exam logic.
function examRowEl(ex) {
  const days = examDaysLeft(ex);
  const r = examReadiness(ex);
  const row = document.createElement("div");
  row.className = "dash-exam-row";
  row.innerHTML =
    '<span class="type-badge b-' + ex.group + '">' + t(examGroupKey(ex.group)) + '</span>' +
    '<span class="de-name">' + esc(examDisplayName(ex)) + '</span>' +
    '<span class="de-date">' + esc(examDateText(ex)) + '</span>' +
    '<span class="de-days">' + (days === 0 ? t("exToday") : (days === 1 ? t("exDayLeft") : t("exDaysLeft", { n: FA(days) }))) + '</span>' +
    '<span class="de-read">' + (r ? t("exReadiness") + ": " + (r.pct == null ? "—" : FA_PCT(r.pct)) + " " + progPillHtml(r.state) + (r.nolink ? ' <span class="de-nobook">· ' + esc(examNoBookText(r)) + '</span>' : "") : t("exNoReadiness")) + '</span>';
  row.addEventListener("click", () => openExamDetail(ex.id));
  return row;
}
// v1.11.33 (P2-8): renderDashExams deleted with the Overview tab —
// its two sections (upcoming exams, nearest-exam budget) live in
// the Exams tab and the Dashboard strip; nothing calls this now.
function openExamDetail(id) {
  const ex = findExam(id);
  if (!ex) return;
  navigate({ tab: "exams", examGroup: ex.group, examView: "list", examId: id, scroll: { type: "exam", id } });
}

// ---------- Exams tab: two-column management layout ----------
// Start column: three category cards (initial state) or the selected
// category's exam list (compact cards, independent scroll).
// End column: an empty-state hint (initial) or the selected exam's full
// detail card (budget, result, actions — the existing examCard).
// Selection changes re-render the panels only; there is no page reload.
const EXAM_CAT_ICONS = {
  maz: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>',
  zoodbist: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>',
  school: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10L12 5 2 10l10 5 10-5z"/><path d="M6 12v5c0 1.7 2.7 3 6 3s6-1.3 6-3v-5"/></svg>'
};
const EXAM_CAT_DESC = { maz: "exCatMazDesc", zoodbist: "exCatZbDesc", school: "exCatSchoolDesc" };

function examCatCard(group) {
  const items = (state.exams[group] || []).slice()
    .sort((a, b) => (a.date || "9999").localeCompare(b.date || "9999"));
  const next = items.find(e => isUpcomingExam(e));
  const card = document.createElement("button");
  card.className = "exam-cat-card cat-" + group;
  card.innerHTML =
    '<span class="cat-ico">' + EXAM_CAT_ICONS[group] + '</span>' +
    '<span class="cat-body"><span class="cat-name">' + t(examGroupKey(group)) + '</span>' +
    '<span class="cat-desc">' + t(EXAM_CAT_DESC[group]) + '</span>' +
    '<span class="cat-meta"><span>' + t("exCatCount", { n: FA(items.length) }) + '</span>' +
    (next
      ? '<span>' + t("exCatNext", { date: examDateText(next) }) + '</span>'
      : '<span>' + t("exCatNone") + '</span>') +
    '</span></span>';
  card.addEventListener("click", () => {
    // v1.11.31 (P1-9): open the nearest upcoming exam, not items[0].
    const d = defaultExamFor(items);
    navigate({ tab: "exams", examGroup: group, examView: "list", examId: d ? d.id : null });
  });
  return card;
}
function examListItem(ex, isNext, isSelected) {
  const status = examStatusOf(ex);
  const days = examDaysLeft(ex);
  const statusKey = { upcoming: "exStatusUpcoming", held: "exStatusHeld",
                      analyzed: "exStatusAnalyzed" }[status];
  const item = document.createElement("button");
  item.className = "exam-list-item" + (isSelected ? " selected" : "");
  item.innerHTML =
    '<span class="eli-top"><span class="eli-name">' + esc(examDisplayName(ex)) + '</span>' +
    '<span class="exam-status ' + (isNext ? "next" : status) + '">' +
    esc(isNext ? t("exStatusNext") : t(statusKey)) + '</span></span>' +
    '<span class="eli-meta"><span>' + esc(examDateText(ex)) + '</span>' +
    '<span>' + esc(examTypeLabel(ex.type)) + '</span>' +
    (ex.questions ? '<span>' + t("exQuestions", { n: FA(ex.questions) }) + '</span>' : '') +
    (days != null && status === "upcoming"
      ? '<span class="eli-days">' + (days === 0 ? t("exToday") : (days === 1 ? t("exDayLeft") : t("exDaysLeft", { n: FA(days) }))) + '</span>'
      : '') +
    '</span>';
  item.addEventListener("click", () => { navigate({ tab: "exams", examGroup: ex.group, examView: "list", examId: ex.id }); });
  return item;
}
function examDetailEmptyHtml(hintKey) {
  return '<div class="exam-detail-empty"><div class="ede-ico">' + EXAM_CAT_ICONS.maz +
    '</div><div class="ede-title">' + t("tabExams") + '</div><p>' + t(hintKey) + '</p></div>';
}
// ---------- Dey-month builder (v1.11.30, P1-2) ----------
// A wizard that builds a PROPOSAL for the Dey programme from the Maz
// 7+8 budgets in exams.json (+ the Dey school exams once they are
// entered — they are NOT in exams.json yet, so the wizard shows them
// as missing instead of inventing them). Nothing is created until the
// user presses «اعمال»: the preview is only a plan, and applying
// creates ordinary custom boxes (the same path as the calendar's
// «+ باکس جدید») so the normal Google push picks them up.
// Rules enforced while generating (his rules): max 2 boxes of one
// subject per day; a test never lands before its review; exam days
// have no boxes (exam morning empty); every day gets a 30-min
// general-subject box; the daily total never exceeds the chosen
// daily hours. Days start at 11:30 and never cross the 03:30
// study-day boundary.
// v1.11.38 (P3-12): the Dey general-subject rotation comes from the
// single SUBJECTS table in i18n.js (general subjects except English —
// the same rotation as before: ادبیات، فارسی، عربی، دینی، زبان).
const DEY_GEN_SUBJECTS = SUBJECTS.filter(r => r.type === "general" && r.id !== "english").map(r => r.fa);
const DEY_REVIEW_MINS = 120;
const DEY_TEST_MINS = 90;
const DEY_GENERAL_MINS = 30;
function deyBudgetItems(examIds) {
  const items = [];
  (examIds || []).forEach(id => {
    const ex = findExam(id);
    if (!ex || !ex.date) return;
    (ex.budget || []).forEach(s => {
      (s.chapters || []).forEach(ch => {
        (ch.topics || []).forEach(tp => {
          items.push({ examId: id, examDate: ex.date, subject: s.subject,
                       chapter: ch.name || "", topic: tp.name || "",
                       // v1.11.45 (E-05): the TOPIC's questions (null -> 0
                       // in the test boxes, like the reverse planner) —
                       // the subject-level count was copied onto every
                       // topic and inflated every Dey test box.
                       questions: (typeof tp.questions === "number") ? tp.questions : null });
        });
      });
    });
  });
  return items;
}
// v1.11.58 (Phase 3c): the GENERALIZED programme builder — same
// engine, any exam window (Dey, Bahman, Esfand…): the caller picks the
// target exams, an optional date range and the subjects, and gets a
// preview plan; nothing is created until Apply. The Dey preset
// (prefix «دی — », school range 2026-12-22–2027-01-20, schoolWarningKey
// "deyMissingSchool") is passed inline by the caller — the thin
// buildDeyPlan wrapper was removed in v1.11.70 (L22). Pure planner:
// (opts) -> plan. No DOM, no state writes, so the verify suite can
// drive it directly. Returns
// { start, end, exams, days: [{ date, boxes: [{ title, subject, topic,
//   is_test, tests_total, start, end, kind }] }], totalBoxes,
//   unplaced: [...], warnings: [...], missingSchool, prefix,
//   subjects, capMins }.
// opts: { exams, dailyHours, start, end, subjects, prefix,
//         schoolRange: { from, to }, schoolWarningKey }.
//   start defaults to programmeEnd()+1, end to the last selected exam
//   date, subjects to every subject in the selected budgets, prefix to
//   the Jalali month of the last selected exam (Dey for Maz 7+8 — the
//   old «دی — » titles), schoolRange to [start, end].
function buildStagePlan(opts) {
  opts = opts || {};
  // v1.11.48 (F1): the daily-hours choice caps at DAY_CAP_MIN (14 h),
  // the single cap — the old 12 h ceiling is retired.
  const dailyHours = Math.max(1, Math.min(DAY_CAP_MIN / 60, +(opts.dailyHours || 10)));
  const capMins = Math.round(dailyHours * 60);
  const isoOk = (s) => typeof s === "string" && /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(new Date(s + "T12:00:00"));
  const start = isoOk(opts.start) ? opts.start : addDays(programmeEnd(), 1);
  const examIds = (opts.exams || []).filter(id => { const ex = findExam(id); return ex && ex.date; });
  const exams = examIds.map(id => findExam(id));
  const end = isoOk(opts.end) ? opts.end : (exams.length ? exams.map(e => e.date).sort().pop() : start);
  let items = deyBudgetItems(examIds);
  if (opts.subjects && opts.subjects.length) items = items.filter(it => opts.subjects.includes(it.subject));
  const subjects = [...new Set(items.map(it => it.subject))];
  const prefix = opts.prefix || (t(jalaliMonthKey(jalaliParts(exams.length ? exams.map(e => e.date).sort().pop() : end).jm)) + " — ");
  // Available days: start..end. Maz/Zoodbist exam days are fully empty
  // (the exam itself is that day's work). v1.11.62 (Batch 3, م-۱ الف):
  // SCHOOL exam days stay in the plan — only the morning (until 12:00)
  // is free, boxes are placed from 13:00 on — otherwise 13 school-exam
  // afternoons would be wasted.
  const examDays = new Set(exams.map(e => e.date));
  const schoolExamDays = new Set(exams.filter(e => e.group === "school").map(e => e.date));
  const days = [];
  for (let d = start; d <= end; d = addDays(d, 1)) {
    if (examDays.has(d) && !schoolExamDays.has(d)) continue;
    days.push(d);
  }
  // Afternoon capacity of a school-exam day: 13:00–23:30 = 630 min.
  const dayCap = (d) => schoolExamDays.has(d) ? Math.min(capMins, 630) : capMins;
  // v1.11.62 (Batch 3, م-۱ ب): weekly classes of the stage — placed
  // FIRST in the calendar, the rest of the boxes arrange around them.
  // {subject, weekday (JS getDay 0–6), start, end}; invalid entries
  // are dropped (the wizard validates too; the planner never trusts
  // its input).
  const weeklyClasses = (opts.weeklyClasses || []).filter(w => w && w.subject &&
    typeof w.weekday === "number" && w.weekday >= 0 && w.weekday <= 6 &&
    isValidBoxTime(w.start) && isValidBoxTime(w.end) &&
    timeToMinutes(w.start) < timeToMinutes(w.end) &&
    timeToMinutes(w.end) <= 23 * 60 + 30);
  const warnings = [];
  // School exams in the window: expected (Maz programme) but maybe not
  // entered in exams.json yet — say so plainly, never invent them. The
  // Dey preset passes the Dey range + the Dey wording; the general
  // builder passes the plan window + the generic wording.
  const sr = opts.schoolRange || { from: start, to: end };
  const schoolKey = opts.schoolWarningKey || "stageNoSchool";
  const schoolInRange = (state.exams.school || []).filter(e => e.date && e.date >= sr.from && e.date <= sr.to);
  const missingSchool = schoolInRange.length === 0;
  if (missingSchool) warnings.push(t(schoolKey));
  if (!exams.length) warnings.push(t("deyNoExamSelected"));
  // v1.11.45 (E-14): with no exams the window is a single day and the
  // general-box loop still added one stray 30-min box (totalBoxes 1,
  // Apply enabled). An empty plan, not a one-box plan.
  if (!exams.length) return { start, end, exams, days: [], totalBoxes: 0,
    unplaced: [], warnings, missingSchool, prefix, subjects, capMins };
  exams.forEach(ex => {
    if (!deyBudgetItems([ex.id]).length) warnings.push(t("deyNoBudget", { ex: examDisplayName(ex) }));
  });
  // One review (2h) + one test (1.5h) per budget chapter. Reviews fill
  // the first 60% of the window (earliest first), tests the last 40%
  // (latest first), so a test naturally lands after its review; at
  // most 2 subject boxes per day and at most 2 of one subject per day,
  // so the skeleton leaves room for the boxes he adds himself.
  // v1.11.55 (F6): pre-existing boxes in the Dey window (custom boxes
  // the user already made, a previous partial plan, homework boxes).
  // They count toward the day's used minutes and subject caps, so the
  // plan never stacks on top of them; their clock intervals are also
  // skipped when the plan's times are assigned below. The window starts
  // after programmeEnd(), so these are custom boxes by construction —
  // but allBoxes() is the source either way, never an assumption.
  const existingByDay = {};
  days.forEach(d => { existingByDay[d] = []; });
  allBoxes().forEach(b => {
    const sd = boxStudyDay(b) || b.date;
    if (!sd || !(sd in existingByDay)) return;
    existingByDay[sd].push(b);
  });
  const preExistingDays = days.filter(d => existingByDay[d].length);
  if (preExistingDays.length) {
    warnings.push(t("deyPreExisting", { days: preExistingDays.map(d => gregToJalali(d).text).join("، ") }));
  }
  const reviews = items.map(it => ({ item: it, kind: "review", mins: DEY_REVIEW_MINS }));
  const tests = items.map(it => ({ item: it, kind: "test", mins: DEY_TEST_MINS }));
  // v1.11.55 (F6): each day starts seeded with its pre-existing boxes
  // as pseudo-entries (kind "existing") — place() counts their minutes
  // and subjects, and planDays filters them out of the generated boxes.
  const byDay = {};
  days.forEach(d => {
    byDay[d] = existingByDay[d].map(b => ({
      subject: b.subject, kind: "existing", mins: minutesBetween(b.start || "00:00", b.end || "00:00"),
      start: b.start, end: b.end, boxId: b.id
    }));
  });
  // Weekly classes seed as kind "weekly" pseudo-entries (fixed times):
  // place() counts their minutes/subjects, the clock assignment skips
  // their intervals, and the plan emits them as real boxes below. On
  // a school-exam day a class starting before 13:00 cannot run (the
  // morning is the exam) — it is skipped with a warning.
  days.forEach(d => {
    const dow = new Date(d + "T12:00:00").getDay();
    weeklyClasses.forEach(w => {
      if (w.weekday !== dow) return;
      if (schoolExamDays.has(d) && timeToMinutes(w.start) < 13 * 60) {
        warnings.push(t("stageWeeklySkipped", { s: subjName(w.subject), d: gregToJalali(d).text }));
        return;
      }
      byDay[d].push({ subject: w.subject, kind: "weekly", mins: minutesBetween(w.start, w.end),
                      start: w.start, end: w.end, weekly: w });
    });
  });
  const unplaced = [];
  const split = Math.max(1, Math.floor(days.length * 0.6));
  const reviewDays = days.slice(0, split);
  const testDays = days.slice(split);
  // v1.11.55 (F6): entries carry their subject on .item, seeded
  // pseudo-entries on .subject — the old filter read b.subject only,
  // so it was always 0 and the 2-per-subject cap never fired.
  const subjOf = (e) => (e.item ? e.item.subject : e.subject);
  const place = (list, dayOrder) => {
    list.forEach(ent => {
      for (const d of dayOrder) {
        const dayBoxes = byDay[d];
        const subjCount = dayBoxes.filter(b => subjOf(b) === ent.item.subject).length;
        const subjBoxes = dayBoxes.filter(b => b.kind !== "general").length;
        const used = dayBoxes.reduce((s, b) => s + b.mins, 0);
        if (subjCount < 2 && subjBoxes < 2 && used + ent.mins + DEY_GENERAL_MINS <= dayCap(d)) {
          dayBoxes.push(ent);
          ent.day = d;
          return;
        }
      }
      unplaced.push(ent);
    });
  };
  place(reviews, reviewDays);
  place(tests, testDays.slice().reverse());
  // Fix-up: a test must land strictly AFTER its review day. If the
  // window was too short for the zones to separate them, move the test
  // to the first day after its review day with room — or leave it
  // unplaced and say so, never silently drop it.
  tests.forEach((te, i) => {
    const rv = reviews[i];
    if (!te.day || !rv.day || te.day > rv.day) return;
    const idx = days.indexOf(rv.day);
    let moved = false;
    for (let j = idx + 1; j < days.length; j++) {
      const d = days[j];
      const dayBoxes = byDay[d];
      const subjCount = dayBoxes.filter(b => subjOf(b) === te.item.subject).length;
      const subjBoxes = dayBoxes.filter(b => b.kind !== "general").length;
      const used = dayBoxes.reduce((s, b) => s + b.mins, 0);
      if (subjCount < 2 && subjBoxes < 2 && used + te.mins + DEY_GENERAL_MINS <= dayCap(d)) {
        byDay[te.day] = byDay[te.day].filter(b => b !== te);
        dayBoxes.push(te);
        te.day = d;
        moved = true;
        break;
      }
    }
    if (!moved) {
      byDay[te.day] = byDay[te.day].filter(b => b !== te);
      te.day = null;
      unplaced.push(te);
    }
  });
  // Times: tests first, then reviews, general last (his rule: tests
  // before reviews; general late at night). Sequential from 11:30.
  // v1.11.55 (F6): gap-aware clock assignment. Generated boxes start
  // at 11:30 and skip over pre-existing boxes' intervals instead of
  // overlapping them; a box that would end after 23:30 (the sleep-guard
  // line) is left unplaced rather than pushed into the night.
  const DAY_END_MIN = 23 * 60 + 30;
  const planDays = days.map((d, di) => {
    const existing = (existingByDay[d] || []).map(b => ({ start: b.start || "00:00", end: b.end || "00:00" }))
      .sort((a, b) => a.start.localeCompare(b.start));
    // Weekly classes block the clock like pre-existing boxes do.
    const weeklyIv = (byDay[d] || []).filter(e => e.kind === "weekly")
      .map(e => ({ start: e.start, end: e.end })).sort((a, b) => a.start.localeCompare(b.start));
    const blocked = existing.concat(weeklyIv).sort((a, b) => a.start.localeCompare(b.start));
    const ents = byDay[d].filter(e => e.kind !== "existing" && e.kind !== "weekly").slice().sort((a, b) =>
      (a.kind === "test" ? 0 : a.kind === "review" ? 1 : 2) -
      (b.kind === "test" ? 0 : b.kind === "review" ? 1 : 2));
    const boxes = [];
    // v1.11.62 (م-۱ الف): on a school-exam day the clock starts at
    // 13:00 — the morning belongs to the exam.
    let cur = schoolExamDays.has(d) ? 13 * 60 : 11 * 60 + 30;
    const advancePastExisting = (mins) => {
      let guard = 0;
      while (guard++ < 20) {
        const hit = blocked.find(iv => {
          const ivs = timeToMinutes(iv.start), ive = timeToMinutes(iv.end);
          return cur < ive && cur + mins > ivs;
        });
        if (!hit) return;
        cur = timeToMinutes(hit.end);
      }
    };
    ents.forEach(ent => {
      advancePastExisting(ent.mins);
      if (cur + ent.mins > DAY_END_MIN) {
        // No clock room left today even though the minutes cap allowed
        // it — unplace (the deyUnplaced warning below counts it).
        byDay[d] = byDay[d].filter(b => b !== ent);
        ent.day = null;
        unplaced.push(ent);
        return;
      }
      const it = ent.item;
      const title = ent.kind === "review"
        ? prefix + t("deyReviewLbl") + " " + it.subject + ": " + (it.chapter || it.topic)
        : prefix + t("deyTestLbl") + " " + it.subject + ": " + (it.chapter || it.topic);
      boxes.push({ title, subject: it.subject, topic: it.topic, is_test: ent.kind === "test",
                   tests_total: ent.kind === "test" ? (it.questions || 0) : 0,
                   start: String(Math.floor(cur / 60)).padStart(2, "0") + ":" + String(cur % 60).padStart(2, "0"),
                   end: String(Math.floor((cur + ent.mins) / 60)).padStart(2, "0") + ":" + String((cur + ent.mins) % 60).padStart(2, "0"),
                   kind: ent.kind });
      cur += ent.mins;
    });
    // Weekly classes, at their fixed times — emitted as real boxes so
    // the apply path creates them like any generated box.
    byDay[d].filter(e => e.kind === "weekly").forEach(e => {
      boxes.push({ title: prefix + t("stageWeeklyClass") + " " + e.subject, subject: e.subject,
                   topic: prefix + t("stageWeeklyClass") + " " + e.subject, is_test: false,
                   tests_total: 0, start: e.start, end: e.end, kind: "weekly" });
    });
    // The daily 30-min general subject, last box of the day, rotating
    // through the five general subjects by day index. It also skips
    // existing intervals (F6) but is always placed — the daily عمومی
    // rule outranks the clock ceiling.
    advancePastExisting(DEY_GENERAL_MINS);
    const genSubj = DEY_GEN_SUBJECTS[di % DEY_GEN_SUBJECTS.length];
    boxes.push({ title: "عمومی — " + genSubj, subject: genSubj, topic: "عمومی — " + genSubj,
                 is_test: false, tests_total: 0,
                 start: String(Math.floor(cur / 60)).padStart(2, "0") + ":" + String(cur % 60).padStart(2, "0"),
                 end: String(Math.floor((cur + DEY_GENERAL_MINS) / 60)).padStart(2, "0") + ":" + String((cur + DEY_GENERAL_MINS) % 60).padStart(2, "0"),
                 kind: "general" });
    if (weeklyIv.length) boxes.sort((a, b) => a.start.localeCompare(b.start));
    // Pre-existing boxes, for the preview only — the apply path reads
    // d.boxes, so these can never be duplicated into custom boxes.
    return { date: d, boxes,
             existing: (existingByDay[d] || []).map(b => ({ start: b.start, end: b.end, title: b.title, subject: b.subject })) };
  });
  if (unplaced.length) warnings.push(t("deyUnplaced", { n: FA(unplaced.length) }));
  const totalBoxes = planDays.reduce((s, d) => s + d.boxes.length, 0);
  return { start, end, exams, days: planDays, totalBoxes,
           unplaced: unplaced.map(e => e.item), warnings, missingSchool,
           preExistingDays, prefix, subjects, capMins };
}
// ---- Dey wizard modal ----
let deyPlan = null;
// v1.11.62 (Batch 3, م-۱ ب): weekly classes added in step 1 — reset
// on a fresh open, kept when going Back from step 2.
let stageWeeklyClasses = [];
function openDeyWizard() {
  deyPlan = null;
  stageWeeklyClasses = [];
  renderDeyStep1();
  document.getElementById("deyModal").classList.add("open");
}
function closeDeyWizard() {
  document.getElementById("deyModal").classList.remove("open");
  deyPlan = null;
}
// v1.11.58 (Phase 3c): the wizard is now the GENERALIZED builder —
// same modal, same preview/apply flow, but step 1 lists every upcoming
// exam (grouped), a date range and the subjects to include. The Dey
// flow is the default: the next two Maz exams after programmeEnd()
// (Maz 7+8 while the programme ends 18 Azar) come pre-checked.
let stageEndTouched = false;
let stageUncheckedSubjects = new Set();
function stageUpcomingExams() {
  const pe = programmeEnd();
  return allExams().filter(e => e.date && e.date > pe)
    .sort((a, b) => a.date.localeCompare(b.date));
}
function stageDefaultCheckedIds() {
  // The next two dated Maz exams after programmeEnd() — Maz 7+8 for
  // the current programme end (18 Azar), i.e. the old Dey default.
  return stageUpcomingExams().filter(e => e.group === "maz").slice(0, 2).map(e => e.id);
}
function renderDeyStep1() {
  const body = document.getElementById("deyBody");
  // v1.11.62 (M-UI2): the sticky footer belongs to step 2 only.
  document.getElementById("deyFoot").hidden = true;
  stageEndTouched = false;
  stageUncheckedSubjects = new Set();
  const upcoming = stageUpcomingExams();
  const checked = new Set(stageDefaultCheckedIds());
  const groupOf = (g) => upcoming.filter(e => e.group === g);
  const exRow = (ex) =>
    '<label class="check-line"><input type="checkbox" class="dey-exam" value="' + esc(ex.id) + '"' +
    (checked.has(ex.id) ? " checked" : "") + '> ' +
    esc(examDisplayName(ex)) + ' · ' + esc(examDateText(ex)) + '</label>';
  const groupBlock = (g) => {
    const list = groupOf(g);
    if (!list.length) return "";
    return '<div class="dey-exam-group"><div class="muted">' + esc(t(examGroupKey(g))) + '</div>' +
      list.map(exRow).join("") + '</div>';
  };
  const defStart = addDays(programmeEnd(), 1);
  const defEnd = (() => {
    const ds = [...checked].map(id => findExam(id)).filter(Boolean).map(e => e.date).sort();
    return ds.length ? ds[ds.length - 1] : defStart;
  })();
  body.innerHTML =
    '<p class="muted">' + esc(t("deyStep1Note")) + '</p>' +
    '<div class="dey-exams">' + groupBlock("maz") + groupBlock("zoodbist") + groupBlock("school") + '</div>' +
    '<div class="form-row"><label><span>' + esc(t("stageStartLabel")) + '</span>' +
    '<input type="text" id="stageStartInput" inputmode="numeric" dir="ltr" value="' + esc(jalaliInputText(defStart)) + '" aria-label="' + esc(t("stageStartLabel")) + '"></label>' +
    '<label><span>' + esc(t("stageEndLabel")) + '</span>' +
    '<input type="text" id="stageEndInput" inputmode="numeric" dir="ltr" value="' + esc(jalaliInputText(defEnd)) + '" aria-label="' + esc(t("stageEndLabel")) + '"></label></div>' +
    '<div class="form-row"><label><span>' + esc(t("stageSubjectsLabel")) + '</span></label></div>' +
    '<div class="dey-exams" id="stageSubjects"></div>' +
    '<div class="form-row"><label><span>' + esc(t("deyDailyHours")) + '</span>' +
    '<input type="number" id="deyHours" min="1" max="14" value="10"></label></div>' +
    '<div class="stage-weekly"><div class="muted">' + esc(t("stageWeeklyTitle")) + '</div>' +
    '<div id="stageWeeklyList"></div>' +
    '<div class="form-row"><select id="stageWeeklySubject"></select>' +
    '<select id="stageWeeklyDay"></select>' +
    '<label><span>' + esc(t("stageWeeklyFrom")) + '</span><input type="time" id="stageWeeklyStart" value="15:00"></label>' +
    '<label><span>' + esc(t("stageWeeklyTo")) + '</span><input type="time" id="stageWeeklyEnd" value="17:00"></label>' +
    '<button class="btn" id="stageWeeklyAddBtn">' + esc(t("stageWeeklyAdd")) + '</button></div></div>' +
    '<p class="muted">' + esc(t("deyExamDayNote")) + '</p>' +
    '<div class="form-row"><button class="btn btn-primary" id="deyBuildBtn">' + esc(t("deyBuildPreview")) + '</button></div>' +
    '<div id="deyStep1Warn"></div>';
  const refreshSubjects = () => {
    const ids = Array.from(body.querySelectorAll(".dey-exam:checked")).map(x => x.value);
    const subs = [...new Set(deyBudgetItems(ids).map(it => it.subject))];
    const wrap = document.getElementById("stageSubjects");
    wrap.innerHTML = subs.length ? subs.map(s =>
      '<label class="check-line"><input type="checkbox" class="stage-subj" value="' + esc(s) + '"' +
      (stageUncheckedSubjects.has(s) ? "" : " checked") + '> ' + esc(subjName(s)) + '</label>').join("")
      : '<p class="muted">' + esc(t("stageNoSubjects")) + '</p>';
    wrap.querySelectorAll(".stage-subj").forEach(cb => cb.addEventListener("change", () => {
      if (cb.checked) stageUncheckedSubjects.delete(cb.value);
      else stageUncheckedSubjects.add(cb.value);
    }));
    const subjSel = document.getElementById("stageWeeklySubject");
    if (subjSel) {
      const cur = subjSel.value;
      subjSel.innerHTML = subs.map(x => '<option value="' + esc(x) + '"' + (x === cur ? " selected" : "") + '>' + esc(subjName(x)) + '</option>').join("");
    }
  };
  const refreshEnd = () => {
    if (stageEndTouched) return;
    const ids = Array.from(body.querySelectorAll(".dey-exam:checked")).map(x => x.value);
    const ds = ids.map(id => findExam(id)).filter(Boolean).map(e => e.date).sort();
    document.getElementById("stageEndInput").value = jalaliInputText(ds.length ? ds[ds.length - 1] : defStart);
  };
  body.querySelectorAll(".dey-exam").forEach(cb => cb.addEventListener("change", () => { refreshSubjects(); refreshEnd(); }));
  document.getElementById("stageEndInput").addEventListener("input", () => { stageEndTouched = true; });
  // v1.11.62 (Batch 3, م-۱ ب): weekly classes — weekday order is
  // Saturday-first, values are JS getDay() (0 = Sunday).
  const renderStageWeeklyList = () => {
    const list = document.getElementById("stageWeeklyList");
    if (!list) return;
    const wds = t("weekdays");
    list.innerHTML = stageWeeklyClasses.map((w, i) =>
      '<div class="rl-day"><div class="rl-day-head"><b>' + esc(subjName(w.subject)) + ' · ' + esc(wds[w.weekday]) +
      ' · ' + fmtTimeFa(w.start) + ' – ' + fmtTimeFa(w.end) + '</b>' +
      '<button class="btn stage-weekly-rm" data-i="' + i + '">✕</button></div></div>').join("");
    list.querySelectorAll(".stage-weekly-rm").forEach(btn => btn.addEventListener("click", () => {
      stageWeeklyClasses.splice(+btn.dataset.i, 1);
      renderStageWeeklyList();
    }));
  };
  const wdSel = document.getElementById("stageWeeklyDay");
  [6, 0, 1, 2, 3, 4, 5].forEach(v => {
    const o = document.createElement("option");
    o.value = String(v);
    o.textContent = t("weekdays")[v];
    wdSel.appendChild(o);
  });
  document.getElementById("stageWeeklyAddBtn").addEventListener("click", () => {
    const warnEl = document.getElementById("deyStep1Warn");
    const subject = document.getElementById("stageWeeklySubject").value;
    const weekday = parseInt(document.getElementById("stageWeeklyDay").value, 10);
    const start = document.getElementById("stageWeeklyStart").value;
    const end = document.getElementById("stageWeeklyEnd").value;
    if (!subject || !isValidBoxTime(start) || !isValidBoxTime(end) ||
        timeToMinutes(start) >= timeToMinutes(end) || timeToMinutes(end) > 23 * 60 + 30) {
      warnEl.innerHTML = '<p class="muted">⚠ ' + esc(t("stageWeeklyBad")) + '</p>';
      return;
    }
    warnEl.innerHTML = "";
    stageWeeklyClasses.push({ subject, weekday, start, end });
    renderStageWeeklyList();
  });
  renderStageWeeklyList();
  refreshSubjects();
  document.getElementById("deyBuildBtn").addEventListener("click", () => {
    const ids = Array.from(body.querySelectorAll(".dey-exam:checked")).map(x => x.value);
    const hours = Math.max(1, Math.min(DAY_CAP_MIN / 60, parseInt(document.getElementById("deyHours").value, 10) || 10));
    const start = parseJalaliInput(document.getElementById("stageStartInput").value) || addDays(programmeEnd(), 1);
    const end = parseJalaliInput(document.getElementById("stageEndInput").value) ||
      (ids.map(id => findExam(id)).filter(Boolean).map(e => e.date).sort().pop() || start);
    const warnEl = document.getElementById("deyStep1Warn");
    if (start > end) {
      warnEl.innerHTML = '<p class="muted">⚠ ' + esc(t("stageBadRange")) + '</p>';
      return;
    }
    const subjects = Array.from(body.querySelectorAll(".stage-subj:checked")).map(x => x.value);
    deyPlan = buildStagePlan({ exams: ids, dailyHours: hours, start, end, subjects, weeklyClasses: stageWeeklyClasses.slice() });
    renderDeyStep2();
  });
}
function renderDeyStep2() {
  const body = document.getElementById("deyBody");
  const p = deyPlan;
  const schoolDays = new Set(p.exams.filter(e => e.group === "school").map(e => e.date));
  let html = "";
  p.warnings.forEach(w => { html += '<p class="muted">⚠ ' + esc(w) + '</p>'; });
  if (!p.days.length || !p.totalBoxes) {
    html += '<p class="muted">' + esc(t("deyEmptyPlan")) + '</p>';
  } else {
    html += '<p><b>' + esc(t("deyTotalBoxes", { n: FA(p.totalBoxes), d: FA(p.days.length) })) + '</b> · ' +
      esc(gregToJalali(p.start).text) + ' — ' + esc(gregToJalali(p.end).text) + '</p>';
    html += '<div class="dey-preview">' + p.days.map(d => {
      // v1.11.58 (Phase 3c): the day's load vs the cap, visible in the
      // preview — generated boxes + pre-existing boxes on that day.
      const dayMins = d.boxes.reduce((s, b) => s + minutesBetween(b.start, b.end), 0) +
        (d.existing || []).reduce((s, b) => s + minutesBetween(b.start || "00:00", b.end || "00:00"), 0);
      return '<div class="dey-day"><div class="dey-day-title">' + esc(weekdayFa(d.date) + " " + gregToJalali(d.date).text) +
      ' <span class="muted">' + esc(t("stageDayCap", { used: fmtDuration(dayMins), cap: fmtDuration(p.capMins) })) + '</span>' +
      (schoolDays.has(d.date) ? ' <span class="muted">' + esc(t("stageSchoolDay")) + '</span>' : '') + '</div>' +
      (d.existing || []).map(b => '<div class="dey-box dey-existing"><span>' + fmtTimeFa(b.start) + ' – ' + fmtTimeFa(b.end) + '</span> <b>' +
        esc(b.title) + '</b> <span class="muted">' + esc(subjName(b.subject)) + ' · ' + esc(t("deyExistingTag")) + '</span></div>').join("") +
      d.boxes.map(b => '<div class="dey-box"><span>' + fmtTimeFa(b.start) + ' – ' + fmtTimeFa(b.end) + '</span> <b>' +
        esc(b.title) + '</b> <span class="muted">' + esc(subjName(b.subject)) + (b.is_test ? ' · ' + esc(t("deyTestLbl")) : '') + '</span></div>').join("") +
      '</div>';
    }).join("") + '</div>';
  }
  // v1.11.62 (Batch 3, م-۱ ج): spacing check on the output — the same
  // pure check as the rules card (ب-۲), over the plan's own days
  // (generated + pre-existing boxes). A move suggestion names the free
  // days between the two sessions.
  const spBoxes = [];
  p.days.forEach(d => {
    (d.boxes || []).forEach(b => spBoxes.push({ subject: b.subject, date: d.date }));
    (d.existing || []).forEach(b => spBoxes.push({ subject: b.subject, date: d.date }));
  });
  const spViol = spacingViolations(spacingSessionDays(spBoxes), new Set(p.exams.map(e => e.date)));
  html += '<h4>' + esc(t("stageSpacingTitle")) + '</h4>';
  if (!spViol.length) {
    html += '<p class="muted">' + esc(t("stageSpacingOk")) + '</p>';
  } else {
    html += '<div class="rl-spacing">';
    spViol.forEach(v => {
      let txt;
      if (v.kind === "none") {
        txt = t("rlSpacingNone", { s: subjName(v.subject) });
      } else {
        const mids = [];
        for (let d = addDays(v.from, 1); d < v.to && mids.length < 2; d = addDays(d, 1)) {
          const g = gregToJalali(d);
          mids.push(FA(g.day) + " " + g.month);
        }
        txt = t("rlSpacingGap", { s: subjName(v.subject), n: FA(v.days), a: gregToJalali(v.from).text, b: gregToJalali(v.to).text }) +
          " — " + t("stageSpacingSuggest", { s: subjName(v.subject), d: mids.join(LANG === "fa" ? " یا " : " or ") });
      }
      html += '<div class="rl-day"><div class="rl-day-head"><b>' + esc(txt) + '</b></div></div>';
    });
    html += '</div>';
  }
  body.innerHTML = html;
  // v1.11.62 (M-UI2): Back/Apply live in the modal's static sticky
  // footer (index.html) now — onclick assignment, not addEventListener:
  // renderDeyStep2 runs on every preview rebuild and the buttons must
  // not stack handlers (same pattern as closeDayApplyBtn).
  document.getElementById("deyFoot").hidden = false;
  document.getElementById("deyBackBtn").onclick = renderDeyStep1;
  const applyBtn = document.getElementById("deyApplyBtn");
  applyBtn.disabled = !p.totalBoxes;
  if (applyBtn) applyBtn.onclick = async () => {
    // v1.11.52 (I-6): remember the pre-apply backup before adding anything.
    const undoPoint = await bulkUndoPoint();
    // Apply = ordinary custom boxes (the same path as the calendar's
    // «+ باکس جدید»), so the debounced auto-push sends them to Google
    // like any other box. The programme range extends to cover them
    // (extends, never shrinks — the 1.7 rule).
    const base = Date.now();
    let n = 0;
    // The range must run to the plan's END (the last exam), not just
    // the last box day — exam days carry no boxes, so the last box is
    // the day before the exam, but the programme is not over until
    // the exam itself.
    let maxDate = p.end;
    state.custom_boxes = state.custom_boxes || [];
    p.days.forEach(d => {
      d.boxes.forEach(b => {
        state.custom_boxes.push({
          id: "custom-stage-" + base + "-" + (n++),
          date: d.date, start: b.start, end: b.end, subject: b.subject,
          topic: b.topic, title: b.title, is_test: b.is_test,
          tests_total: b.tests_total || 0, note: "", type: "normal"
        });
        if (d.date > maxDate) maxDate = d.date;
      });
    });
    if (maxDate > programmeEnd()) state.programme_end = maxDate;
    saveState();
    closeDeyWizard();
    // v1.11.52 (I-6): the apply toast carries the «بازگردانی» undo.
    bulkUndoToast(undoPoint, t("deyApplied", { n: FA(n) }));
    // Re-render from the in-memory state. Do NOT call
    // refreshDataFromServer() here: it replaces `state` wholesale from
    // GET /api/state, and the debounced saveState above has not fired
    // yet — the refresh would drop the just-applied boxes before the
    // POST ever carries them. The save (and the auto-push to Google)
    // run on their normal debounce from the state as it stands.
    renderAll();
  };
}
document.getElementById("deyClose").addEventListener("click", closeDeyWizard);
document.getElementById("deyModal").addEventListener("click", (e) => {
  if (e.target.id === "deyModal") closeDeyWizard();
});
// v1.11.32 (P2-1): close-day modal wiring (same pattern as the Dey wizard).
document.getElementById("closeDayClose").addEventListener("click", closeCloseDay);
document.getElementById("closeDayModal").addEventListener("click", (e) => {
  if (e.target.id === "closeDayModal") closeCloseDay();
});
// v1.11.56: bulk-delete modal wiring (same pattern).
document.getElementById("bulkDeleteClose").addEventListener("click", closeBulkDeleteModal);
document.getElementById("bulkDeleteModal").addEventListener("click", (e) => {
  if (e.target.id === "bulkDeleteModal") closeBulkDeleteModal();
});
function renderExams() {
  const banner = document.getElementById("examNextBanner");
  const start = document.getElementById("examsStart");
  const detail = document.getElementById("examsDetail");
  if (!banner || !start || !detail) return;
  ensureExams();
  const next = nearestExam();
  // v1.11.55 (UX-1): the Exams tab's primary is inert with no exam.
  const nearBtn = document.getElementById("examsNearestBtn");
  if (nearBtn) nearBtn.disabled = !next;
  if (next) {
    const days = examDaysLeft(next);
    banner.innerHTML = '<div class="exam-next"><div class="en-label">' + t("exNextExam") + '</div>' +
      '<div class="en-title">' + esc(examGroupLabel(next) + " — " + examDisplayName(next)) + '</div>' +
      '<div class="en-meta">' + esc(examDateText(next)) + ' · ' + esc(examTypeLabel(next.type)) + '</div>' +
      '<div class="en-days">' + (days === 0 ? t("exToday") : (days === 1 ? t("exDayLeft") : t("exDaysLeft", { n: FA(days) }))) + '</div></div>';
  } else {
    banner.innerHTML = '<p class="muted">' + t("exNoUpcoming") + '</p>';
  }

  start.innerHTML = "";
  detail.innerHTML = "";
  if (examView === "cats") {
    // v1.11.30 (P1-2): the Dey-month builder — the programme ends 27
    // Azar, and this is where the Dey programme gets built.
    const deyBtn = document.createElement("button");
    deyBtn.className = "btn btn-primary dey-open-btn";
    deyBtn.textContent = t("deyOpen");
    deyBtn.addEventListener("click", openDeyWizard);
    start.appendChild(deyBtn);
    // v1.11.38 (P3-8): timed exam simulation entry.
    const simBtn = document.createElement("button");
    simBtn.className = "btn sim-open-btn";
    simBtn.textContent = t("simTitle");
    simBtn.addEventListener("click", openSimSetup);
    start.appendChild(simBtn);
    // v1.11.40 (creative 2 + 5): reverse planning from an exam and the
    // Konkur coverage map — both render into the detail pane.
    const revBtn = document.createElement("button");
    revBtn.className = "btn rev-open-btn";
    revBtn.textContent = t("revTitle");
    revBtn.addEventListener("click", () => { revOpen = true; covOpen = false; renderExams(); });
    start.appendChild(revBtn);
    const covBtn = document.createElement("button");
    covBtn.className = "btn cov-open-btn";
    covBtn.textContent = t("covTitle");
    covBtn.addEventListener("click", () => { covOpen = true; revOpen = false; renderExams(); });
    start.appendChild(covBtn);
    if (revOpen) { renderReversePlannerInto(detail); return; }
    if (covOpen) { renderCoverageMapInto(detail); return; }
    // v1.11.41 (UI-audit batch 1): the layout is inverted — the exam
    // groups ARE the main content, so they render into the wide detail
    // pane (the tools stay in the narrow column). The big dashed empty
    // box the page used to open with is gone.
    const cats = document.createElement("div");
    cats.className = "exams-cats";
    cats.setAttribute("aria-label", t("exCatsTitle"));
    ["maz", "zoodbist", "school"].forEach(g => cats.appendChild(examCatCard(g)));
    detail.appendChild(cats);
    return;
  }
  // List view for the selected category.
  const back = document.createElement("button");
  back.className = "btn exams-back";
  back.textContent = "← " + t("exBackToCats");
  back.addEventListener("click", () => { navigate({ tab: "exams", examView: "cats", examId: null }); });
  start.appendChild(back);
  const note = document.createElement("p");
  note.className = "muted";
  note.textContent = t({ maz: "exGroupMazNote", zoodbist: "exGroupZbNote", school: "exGroupSchoolNote" }[examGroup]);
  start.appendChild(note);
  const addBtn = document.createElement("button");
  addBtn.className = "btn btn-primary";
  addBtn.textContent = t("exAddExam");
  addBtn.addEventListener("click", () => openExamModal(null, examGroup));
  start.appendChild(addBtn);
  const items = (state.exams[examGroup] || []).slice()
    .sort((a, b) => (a.date || "9999").localeCompare(b.date || "9999") || (a.stage || 0) - (b.stage || 0));
  if (!selectedExamId || !items.some(e => e.id === selectedExamId)) {
    // v1.11.31 (P1-9): default to the nearest upcoming exam, not items[0].
    const d = defaultExamFor(items);
    selectedExamId = d ? d.id : null;
  }
  const list = document.createElement("div");
  list.className = "exams-list";
  items.forEach(ex => list.appendChild(examListItem(ex, next && ex.id === next.id, ex.id === selectedExamId)));
  start.appendChild(list);
  const sel = selectedExamId ? findExam(selectedExamId) : null;
  if (sel) detail.appendChild(examCard(sel, next && sel.id === next.id));
  else detail.innerHTML = examDetailEmptyHtml("exSelectExamHint");
}
// ---------- Per-subject exam results (audit §5 item 3.1) ----------
// result.subjects = { subject: {correct, wrong, unanswered} }, keyed by
// the budget subject string. Old results have no subjects — they render
// exactly as before. The totals (correct/wrong/unanswered) are never
// recomputed from the per-subject rows: the stored totals stay the
// source of truth, the rows are their breakdown.
function examSubjectRows(r) {
  const subs = (r && r.subjects) || {};
  return Object.keys(subs).map(s => {
    const v = subs[s] || {};
    const c = v.correct || 0, w = v.wrong || 0, u = v.unanswered || 0;
    const att = c + w;
    return { subject: s, correct: c, wrong: w, unanswered: u, acc: att ? (c / att * 100) : null };
  });
}
function weakestExamSubject(r) {
  const rows = examSubjectRows(r).filter(s => (s.correct + s.wrong) > 0 && s.acc != null);
  if (!rows.length) return null;
  return rows.reduce((a, b) => (b.acc < a.acc ? b : a));
}
// Per-subject inputs in the result form: one row per budget subject.
function examSubjectFormHtml(ex) {
  const subs = (ex.budget || []).map(s => s.subject).filter(Boolean);
  if (!subs.length) return '<p class="muted">' + t("exSubjNoData") + '</p>';
  const stored = ((ex.result || {}).subjects) || {};
  return '<h4>' + esc(t("exSubjTitle")) + '</h4>' + subs.map(s => {
    const v = stored[s] || {};
    return '<div class="form-row ex-subj-row" data-subject="' + esc(s) + '">' +
      '<label>' + esc(subjName(s)) + '</label>' +
      '<label>' + t("exCorrect") + ' <input type="number" min="0" class="xf-subj-correct" value="' + (v.correct != null ? v.correct : "") + '"></label>' +
      '<label>' + t("exWrong") + ' <input type="number" min="0" class="xf-subj-wrong" value="' + (v.wrong != null ? v.wrong : "") + '"></label>' +
      '<label>' + t("exUnanswered") + ' <input type="number" min="0" class="xf-subj-unanswered" value="' + (v.unanswered != null ? v.unanswered : "") + '"></label>' +
      '</div>';
  }).join('');
}
function examResultHtml(ex) {
  const r = ex.result;
  if (!r) return '<p class="muted">' + t("exNoResult") + '</p>';
  // v1.11.38 (P3-8): a simulation result is labelled as one, so it
  // never passes as a real exam result.
  const simBadge = r.simulated ? '<p><span class="sim-badge">' + esc(t("simSimulated")) + '</span></p>' : '';
  const attempted = (r.correct || 0) + (r.wrong || 0);
  const total = attempted + (r.unanswered || 0);
  const acc = attempted ? (r.correct / attempted * 100) : null;
  // v1.11.16 (audit §5 item 1.6): coverage (attempted ÷ total) shown
  // next to accuracy (correct ÷ attempted) — the same two labelled
  // numbers as the Analytics trend table, so no exam reads two
  // different accuracies in two places.
  const cov = total ? (attempted / total * 100) : null;
  let html = simBadge + '<div class="exam-result"><span><b>' + t("exTaraz") + ':</b> ' +
    (r.taraz != null ? FA(r.taraz) : "—") + '</span>' +
    '<span><b>' + t("exRank") + ':</b> ' + (r.rank != null ? FA(r.rank) : "—") +
    (r.rankTotal != null ? ' ' + t("exRankOf", { n: FA(r.rankTotal) }) : "") + '</span>' +
    '<span><b>' + t("exCorrect") + ':</b> ' + FA(r.correct || 0) + '</span>' +
    '<span><b>' + t("exWrong") + ':</b> ' + FA(r.wrong || 0) + '</span>' +
    '<span><b>' + t("exUnanswered") + ':</b> ' + FA(r.unanswered || 0) + '</span>' +
    (acc != null ? '<span><b>' + t("exAccuracy") + ':</b> ' + FA_PCT(acc) +
      ' <span class="muted">(' + t("exAttempted", { n: FA(attempted) }) + ')</span></span>' : "") +
    (cov != null ? '<span><b>' + t("exCoverage") + ':</b> ' + FA_PCT(cov) +
      ' <span class="muted">(' + FA(attempted) + t("ofWord") + FA(total) + ')</span></span>' : "") +
    '</div>';
  // (3.1) per-subject breakdown + weakest subject, when entered.
  const subjRows = examSubjectRows(r);
  if (subjRows.length) {
    html += '<table class="ex-subj"><tr><th>' + t("anThSubject") + '</th><th>' + t("exCorrect") + '</th><th>' + t("exWrong") + '</th><th>' + t("exUnanswered") + '</th><th>' + t("exAccuracy") + '</th></tr>' +
      subjRows.map(s => '<tr><td>' + esc(subjName(s.subject)) + '</td><td>' + FA(s.correct) + '</td><td>' + FA(s.wrong) + '</td><td>' + FA(s.unanswered) + '</td><td>' + (s.acc == null ? "—" : FA_PCT(s.acc)) + '</td></tr>').join('') + '</table>';
    const weak = weakestExamSubject(r);
    if (weak) html += '<p class="muted">' + t("exSubjWeakest") + ': <b>' + esc(subjName(weak.subject)) + '</b> · ' + FA_PCT(weak.acc) + '</p>';
  }
  if (r.note) html += '<p class="muted">' + t("exNote") + ': ' + esc(r.note) + '</p>';
  return html;
}
// ---------- Post-exam compensation plan (v1.11.35, P2-12) ----------
// Computed at render time from the saved result + the testbook +
// the backlog — nothing new is persisted. The plan is: the weakest
// subjects by accuracy, their weakest chapters (remaining tests ×
// (1 - accuracy), the same scoring as backlogSuggestions), and the
// ready compensation suggestions (backlog suggestions for the weak
// subjects first, filled with the top overall). Subjects with no
// book (general subjects) get no chapters, only suggestions.
function bookIdForSubject(subject) {
  const s = String(subject || "");
  if (s.indexOf("حسابان") >= 0) return "calc";
  if (s.indexOf("شیمی") >= 0) return "chem";
  if (s.indexOf("فیزیک") >= 0) return "phys";
  if (s.indexOf("گسسته") >= 0) return "disc";
  if (s.indexOf("هندسه") >= 0) return "geom";
  return null;
}
function weakChaptersForSubject(subject, limit) {
  const bookId = bookIdForSubject(subject);
  if (!bookId) return [];
  const book = (TESTBOOK.books || []).find(b => b.id === bookId);
  if (!book) return [];
  const rows = [];
  (book.chapters || []).forEach(ch => {
    let solved = 0, correct = 0, rem = 0;
    (ch.topics || []).forEach(tp => {
      const s = topicStats(tp);
      solved += s.solved; correct += s.correct; rem += s.remaining || 0;
    });
    const acc = solved > 0 ? correct / solved : null;
    rows.push({ book, chapter: ch, solved, correct, remaining: rem, acc,
      score: rem * (1 - (acc == null ? 0.5 : acc)) });
  });
  rows.sort((a, b) => b.score - a.score);
  return rows.filter(r => r.remaining > 0).slice(0, limit || 3);
}
function examCompensationPlan(ex) {
  const r = ex && ex.result;
  if (!r) return null;
  const rows = examSubjectRows(r).filter(s => (s.correct + s.wrong) > 0 && s.acc != null)
    .sort((a, b) => a.acc - b.acc);
  const weakSubjects = rows.slice(0, 3).map(s => s.subject);
  const chapters = [];
  weakSubjects.forEach(s => weakChaptersForSubject(s, 3).forEach(c =>
    chapters.push(Object.assign({ subject: s }, c))));
  chapters.sort((a, b) => b.score - a.score);
  const all = backlogSuggestions(5);
  const mine = all.filter(s => weakSubjects.indexOf(s.box.subject) >= 0);
  const suggestions = mine.concat(all.filter(s => weakSubjects.indexOf(s.box.subject) < 0)).slice(0, 5);
  return { weakSubjects, chapters: chapters.slice(0, 5), suggestions };
}
function examPlanHtml(ex) {
  const plan = examCompensationPlan(ex);
  if (!plan) return "";
  let html = '<div class="exam-plan"><h4>' + esc(t("exPlanTitle")) + '</h4>';
  if (plan.chapters.length) {
    html += '<h4>' + esc(t("exPlanWeakChapters")) + '</h4><ul class="plan-chapters">' +
      plan.chapters.map(c =>
        '<li>' + esc(bookName(c.book) + " — " + chapterTitle(c.chapter)) +
        ' · ' + FA(c.remaining) + ' ' + esc(t("exPlanSuggested")) +
        (c.acc != null ? ' · ' + FA_PCT(c.acc * 100) : '') + '</li>').join("") + '</ul>';
  } else {
    html += '<p class="muted">' + esc(t("exPlanNoWeak")) + '</p>';
  }
  if (plan.suggestions.length) {
    html += '<h4>' + esc(t("exPlanSuggestions")) + '</h4>' +
      plan.suggestions.map(s =>
        '<div class="plan-sug">' + esc(s.box.title) + ' · ' +
        esc(gregToJalali(s.gap.studyDay).text) + '</div>').join("") +
      '<button class="btn btn-primary ex-plan-apply">' + esc(t("exPlanApplyAll")) + '</button>';
  }
  return html + '</div>';
}
// One click places the plan's suggestions — the same move + confirm +
// alert flow as applyAllSuggestions, scoped to this plan's list.
async function applyExamPlan(plan) {
  if (!plan || !plan.suggestions.length) return;
  if (!confirm(t("sugApplyAllConfirm"))) return;
  // v1.11.52 (I-6): remember the pre-apply backup (after the confirm).
  const undoPoint = await bulkUndoPoint();
  let moved = 0, skipped = 0;
  for (const s of plan.suggestions) {
    const gap = findGapDay(s.box);
    if (!gap || !(await moveBoxToGapAsync(s.box, gap))) { skipped++; continue; }
    moved++;
  }
  saveState(); renderAll();
  bulkUndoToast(undoPoint, moved ? t("sugApplied", { n: FA(moved) }) : t("sugApplyNone"));
}
// ---------- Product batch 8 (v1.11.40): P3-13 is server-side; the
// five creative ideas live here. ----------
// ----- Creative 1: «حالت روز آزمون» (exam-day mode) -----
// On an exam day the Today tab shows presence + start times, the
// venue address (editable, stored as ex.venue in state.exams —
// same mutate-then-saveState pattern as the exam modal), the "what
// to bring" checklist (persisted in state.examPack[examId]), and a
// «ثبت نتیجه» button that opens the exam's result form. Times come
// from the Maz SMS (presence 07:30, start 08:00); Zoodbist and
// school exams start 08:00. No end time is invented. Display-only
// otherwise: nothing is created, moved or deleted.
function examDayTimes(ex) {
  if (ex.group === "maz") return { presence: "07:30", start: "08:00" };
  return { presence: null, start: "08:00" };
}
function todaysExam() {
  // v1.11.45 (F-12): exams are calendar events — compare against the
  // real calendar day, not the study day (03:30 boundary): at 01:00
  // on exam morning the study day is still yesterday, but the exam
  // is today; the morning after, the exam must be gone.
  return allExams().find(e => e.date === realTodayIso()) || null;
}
// ---------- Exam-night mode (v1.11.43, §17 idea 4) ----------
// One-page checklist for the night before an exam: venue, things to
// bring, suggested sleep time, a 22:00 reminder button. The card
// turns green when everything is ticked. Shown in two places: the
// exam-day card itself (a toggle button — the venue + bring items
// already live on that card, so its panel only adds the night items)
// and the Dashboard on the day before an exam (the full checklist).
// Sleep = exam start − 9.5h (08:00 → 22:30 the night before). The
// exam start is the exam's stored time when present, else the
// exam-day times (Maz 08:00, Zoodbist/school 08:00).
let exNightOpen = false; // the exam-day card's night panel, kept open across re-renders
function examNightStart(ex) {
  return (ex && ex.startTime) || examDayTimes(ex).start || "08:00";
}
function examNightSleep(ex) {
  const mins = (timeToMinutes(examNightStart(ex)) - 570 + 1440) % 1440;
  return String(Math.floor(mins / 60)).padStart(2, "0") + ":" + String(mins % 60).padStart(2, "0");
}
function examNightPack(ex) { return ((state.examPack || {})[ex.id]) || {}; }
function examNightAllDone(ex) {
  const pack = examNightPack(ex);
  return !!(ex.venue && pack.bringCard && pack.bringPen && pack.bringId && pack.sleepOk && pack.nightReminder);
}
function examNightSlimHtml(ex) {
  const pack = examNightPack(ex);
  const start = examNightStart(ex), sleep = examNightSleep(ex);
  return '<div class="exn-sleep">' + esc(t("exNightSleep", { time: fmtTimeFa(sleep), start: fmtTimeFa(start) })) + '</div>' +
    '<label class="exd-item exn-sleep-ok"><input type="checkbox" class="exn-sleep-check"' + (pack.sleepOk ? " checked" : "") + '> ' +
    esc(t("exNightSleepCheck", { time: fmtTimeFa(sleep) })) + '</label>' +
    '<button type="button" class="btn exn-remind' + (pack.nightReminder ? " on" : "") + '">' +
    esc(pack.nightReminder ? t("exNightRemindOn") : t("exNightRemind")) + '</button>' +
    (examNightAllDone(ex) ? '<div class="exn-done">' + esc(t("exNightAllDone")) + '</div>' : '');
}
function examNightFullHtml(ex) {
  const pack = examNightPack(ex);
  const items = [["bringCard", "exdBringCard"], ["bringPen", "exdBringPen"], ["bringId", "exdBringId"]];
  return '<div class="exn-head"><span class="exn-title">' + esc(t("exNightTitle")) + '</span>' +
    '<span class="exn-exam">' + esc(examGroupLabel(ex) + " — " + examDisplayName(ex)) + '</span></div>' +
    '<label class="exd-venue"><span>' + esc(t("exdVenue")) + '</span> ' +
    '<input type="text" class="exn-venue-input" value="' + esc(ex.venue || "") + '" placeholder="' + esc(t("exdVenuePh")) + '"></label>' +
    '<div class="exd-bring"><div class="exd-bring-title">' + esc(t("exdBring")) + '</div>' +
    items.map(pair =>
      '<label class="exd-item"><input type="checkbox" class="exn-pack" data-pack="' + pair[0] + '"' + (pack[pair[0]] ? " checked" : "") + '> ' + esc(t(pair[1])) + '</label>').join("") +
    '</div>' +
    examNightSlimHtml(ex);
}
function wireExamNight(container, ex) {
  const venue = container.querySelector(".exn-venue-input");
  if (venue) venue.addEventListener("change", ev => { ex.venue = ev.target.value.trim(); saveState(); renderAll(); });
  container.querySelectorAll(".exn-pack").forEach(cb => cb.addEventListener("change", () => {
    const p = (state.examPack = state.examPack || {});
    const cur = p[ex.id] || (p[ex.id] = {});
    cur[cb.dataset.pack] = cb.checked;
    saveState(); renderAll();
  }));
  const sleepCb = container.querySelector(".exn-sleep-check");
  if (sleepCb) sleepCb.addEventListener("change", () => {
    const p = (state.examPack = state.examPack || {});
    const cur = p[ex.id] || (p[ex.id] = {});
    cur.sleepOk = sleepCb.checked;
    saveState(); renderAll();
  });
  const rem = container.querySelector(".exn-remind");
  if (rem) rem.addEventListener("click", () => {
    const p = (state.examPack = state.examPack || {});
    const cur = p[ex.id] || (p[ex.id] = {});
    cur.nightReminder = !cur.nightReminder;
    if (!cur.nightReminder) delete cur.nightReminderShown;
    saveState(); renderAll();
  });
}
// ---------- «هدف مرحله‌ای» (v1.11.63, Batch 4, م-۵) ----------
// Per-exam per-subject readiness targets — plain percentages
// (default 80%), editable in the stage report. Targets are
// percentages of questions/tests only, never a prediction of exam
// standing (standing ban: no estimation of any standing figure).
function examTarget(exId, subject) {
  const m = (state.examTargets || {})[exId] || {};
  const v = m[subject];
  return (typeof v === "number" && v >= 0 && v <= 100) ? v : 80;
}
// The subject furthest below its target (by percentage), with the
// questions still needed to reach it — shown on the exam-week bar.
// Returns null when every subject is at target (or there is no
// readiness data). Tests-left is computed from the same weighted
// budget counts (target% × total − done), never invented.
function examTargetDistance(ex) {
  const bySubj = examReadinessBySubject(ex);
  if (!bySubj || !bySubj.length) return null;
  let worst = null;
  bySubj.forEach(r => {
    if (!r || r.total == null || r.total <= 0) return;
    const pct = (r.pct != null) ? r.pct : Math.round((r.done || 0) / r.total * 100);
    const target = examTarget(ex.id, r.subject);
    const gap = target - pct;
    if (gap > 0 && (!worst || gap > worst.gap)) {
      const testsLeft = (r.anyWeight && r.totalW > 0)
        ? Math.max(0, Math.ceil(target / 100 * r.totalW - (r.doneW || 0)))
        : null;
      worst = { subject: r.subject, pct, target, gap, testsLeft };
    }
  });
  return worst;
}
// ---------- Exam-week bar (v1.11.55, P-9) ----------
// 7 days before a Maz exam the dashboard shows a countdown bar:
// readiness (from examReadiness), remaining boxes for that exam, and
// a short checklist (venue, sleep time, error-notebook review). After
// the exam the bar becomes «ثبت نتیجه» until a result is recorded,
// then it hides. Other exam groups (Zoodbist / school) keep their own
// cards — the week bar is the Maz milestone only.
// "Remaining boxes" = undone boxes for the exam's budget subjects,
// scheduled between today and the exam day (not a topic-link match —
// boxes carry subject + date, and that is the honest count).
// v1.11.63 (Batch 4, L-UI4): the exam-week bar uses SVG icons like
// the rest of the app — no raw emoji. Feather-style paths.
function exwSvg(kind) {
  const paths = {
    pin: '<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle>',
    moon: '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>'
  };
  return '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (paths[kind] || "") + '</svg>';
}
function examWeekRemainingBoxes(ex) {
  const subjects = new Set((ex.budget || []).map(s => s.subject));
  if (!subjects.size) return 0;
  return allBoxes().filter(b => {
    if (isDone(b) || !subjects.has(b.subject)) return false;
    const sd = boxStudyDay(b) || b.date;
    return sd && sd >= TODAY && sd < ex.date;
  }).length;
}
function renderExamWeek() {
  const el = document.getElementById("dashExamWeek");
  if (!el) return;
  // v1.11.55 (P-9 fix during verify1155): the bar is about the NEAREST
  // Maz exam, not the earliest ever — the first draft picked maz-1
  // (Oct 9, long past, no result) and showed «ثبت نتیجه» for it
  // forever. Nearest upcoming (1–7 days out) wins the week bar; the
  // exam day itself and the most recently held exam without a result
  // get the «ثبت نتیجه» variant; otherwise the bar hides.
  const maz = allExams().filter(e => e.group === "maz" && e.date);
  const withDays = maz.map(e => ({ e, d: examDaysLeft(e) })).filter(x => x.d != null);
  const nextUp = withDays.filter(x => x.d >= 0).sort((a, b) => a.d - b.d)[0] || null;
  const lastHeld = withDays.filter(x => x.d < 0).sort((a, b) => b.d - a.d)[0] || null;
  let ex = null, days = null, resultMode = false;
  if (nextUp && nextUp.d >= 1 && nextUp.d <= 7 && !nextUp.e.result) { ex = nextUp.e; days = nextUp.d; }
  else if (nextUp && nextUp.d === 0 && !nextUp.e.result) { ex = nextUp.e; days = 0; resultMode = true; }
  else if (lastHeld && !lastHeld.e.result) { ex = lastHeld.e; days = lastHeld.d; resultMode = true; }
  if (!ex) { el.hidden = true; el.innerHTML = ""; return; }
  if (resultMode) {
    // Exam day / just held, no result yet — the bar becomes «ثبت نتیجه»:
    // opens the exam detail and unfolds its result form.
    // v1.11.63 (Batch 4, M-UI4): «بعداً» hides this exam's bar until a
    // result is recorded (state.examPack[examId].resultDismissed) —
    // the bar used to stay forever until a result was recorded.
    if (((state.examPack || {})[ex.id] || {}).resultDismissed) { el.hidden = true; el.innerHTML = ""; return; }
    el.innerHTML = '<div class="exw-title">' + esc(t("exWeekResultTitle", { name: examDisplayName(ex) })) + '</div>' +
      '<button type="button" class="btn btn-primary exw-result-btn">' + esc(t("exWeekResultBtn")) + '</button>' +
      '<button type="button" class="btn exw-result-later">' + esc(t("exWeekResultLater")) + '</button>';
    el.querySelector(".exw-result-btn").addEventListener("click", () => {
      openExamDetail(ex.id);
      setTimeout(() => { const btn = document.querySelector(".ex-result-btn"); if (btn) btn.click(); }, 200);
    });
    el.querySelector(".exw-result-later").addEventListener("click", () => {
      const p = (state.examPack = state.examPack || {});
      const cur = p[ex.id] || (p[ex.id] = {});
      cur.resultDismissed = true;
      saveState(); renderAll();
    });
    el.hidden = false;
    return;
  }
  const r = examReadiness(ex);
  const remaining = examWeekRemainingBoxes(ex);
  const pack = examNightPack(ex);
  const reviewed = !!(pack && pack.examWeekReviewed);
  // v1.11.63 (Batch 4, م-۵): the subject furthest below its stage
  // target — «شیمی ۶۰٪ از هدف ۹۰٪ — ۱۲ تست مانده» (tests part only
  // when the budget carries question counts).
  const gap = examTargetDistance(ex);
  el.innerHTML =
    '<div class="exw-title">' + esc(t("exWeekTitle", { name: examDisplayName(ex), n: FA(days) })) + '</div>' +
    '<div class="exw-line">' + esc(t("exWeekCoverage", { pct: r && r.pct != null ? FA_PCT(r.pct) : "—", done: FA(r ? r.done : 0), total: FA(r ? r.total : 0) })) + ' · ' +
    esc(t("exWeekRemaining", { n: FA(remaining) })) + '</div>' +
    (gap ? '<div class="exw-line exw-target">' + esc(t("exWeekTargetGap", { subj: subjName(gap.subject), pct: FA_PCT(gap.pct), target: FA_PCT(gap.target) })) +
      (gap.testsLeft != null ? ' — ' + esc(t("exWeekTargetTests", { n: FA(gap.testsLeft) })) : '') + '</div>' : '') +
    '<div class="exw-check">' +
    // v1.11.63 (Batch 4, L-UI4): SVG icons like the rest of the app
    // (no raw emoji) + a «محل:» label before the address.
    (ex.venue ? '<div class="exw-item">' + exwSvg("pin") + '<span class="exw-label">' + esc(t("exWeekVenue")) + '</span> ' + esc(ex.venue) + '</div>' : '') +
    '<div class="exw-item">' + exwSvg("moon") + ' ' + esc(t("exWeekSleep", { time: fmtTimeFa(examNightSleep(ex)) })) + '</div>' +
    '<label class="exw-item exw-review"><input type="checkbox" class="exw-review-check"' + (reviewed ? " checked" : "") + '> ' + esc(t("exWeekReview")) + '</label>' +
    '</div>';
  const cb = el.querySelector(".exw-review-check");
  if (cb) cb.addEventListener("change", () => {
    const p = (state.examPack = state.examPack || {});
    const cur = p[ex.id] || (p[ex.id] = {});
    cur.examWeekReviewed = cb.checked;
    saveState();
  });
  el.hidden = false;
}
// ---------- «از دیروز تا حالا» (v1.11.55, P-10) ----------
// One line under the dashboard KPIs: yesterday's boxes + real/useful
// time + the backlog delta (yesterday → now), with an arrow.
// Backlog(as of yesterday) = boxes with studyDay < yesterday that
// were undone as of yesterday: undone now, OR ticked yesterday/TODAY
// (a dated tick proves it was undone before that tick). Legacy `true`
// ticks predate dated ticks (1.11.30) and are excluded — their date
// is unknown, never fabricated.
// Gate: with no dated tick and no timer session at all, there is no
// real "yesterday" data — show «هنوز داده کافی نیست» instead of
// fabricated numbers.
function fmtHM(secs) {
  const m = Math.round((secs || 0) / 60);
  // faDigits, not FA: FA is Number-based and strips the leading zero
  // (FA("05") === "۵"), while String(m % 60) alone left Latin digits
  // ("۱:20" — both caught by verify1155).
  return faDigits(Math.floor(m / 60) + ":" + String(m % 60).padStart(2, "0"));
}
function renderYesterdayLine() {
  const el = document.getElementById("dashYesterday");
  if (!el) return;
  const yday = addDays(TODAY, -1);
  const boxes = allBoxes();
  const hasDatedTick = boxes.some(b => doneDate(b));
  const hasSessions = (state.timerSessions || []).some(s => s && s.source === "timer");
  if (!hasDatedTick && !hasSessions) {
    el.innerHTML = '<span class="muted">' + esc(t("anQNotEnough")) + '</span>';
    el.hidden = false;
    return;
  }
  const yBoxes = boxes.filter(b => boxStudyDay(b) === yday && isCurrentBox(b));
  const yDone = yBoxes.filter(isDone).length;
  const au = dayActualUseful(yday);
  const hidden = state.backlogHidden || {};
  const backlogNow = boxes.filter(b => { const sd = boxStudyDay(b) || b.date; return sd && sd < TODAY && !isDone(b) && !hidden[b.id]; }).length;
  const backlogYday = boxes.filter(b => {
    const sd = boxStudyDay(b) || b.date;
    if (!sd || sd >= yday || hidden[b.id]) return false;
    if (!isDone(b)) return true;
    const d = doneDate(b);
    return d === yday || d === TODAY; // ticked yesterday or today: was undone as of yesterday
  }).length;
  const delta = backlogYday - backlogNow;
  // v1.11.63 (Batch 4, L-UI3): the line gets a small title + four
  // labeled rows; the backlog delta is a word («کمتر/بیشتر») in
  // success/warning colour — a down arrow reads as "worse" even when
  // the backlog shrinking is good news. No change keeps the old text.
  const deltaCls = delta > 0 ? "good" : (delta < 0 ? "bad" : "");
  const deltaTxt = delta > 0 ? esc(t("yesterdayLessWord")) + ' ' + FA(delta)
    : delta < 0 ? esc(t("yesterdayMoreWord")) + ' ' + FA(-delta)
    : esc(t("yesterdaySame"));
  el.innerHTML = '<div class="yest-title">' + esc(t("yesterdayTitle")) + '</div>' +
    '<div class="yest-rows">' +
    '<div class="yest-row"><span>' + esc(t("yesterdayDoneLbl")) + '</span><b>' + FA(yDone) + '/' + FA(yBoxes.length) + '</b></div>' +
    '<div class="yest-row"><span>' + esc(t("sumRealTime")) + '</span><b>' + fmtHM(au.actual) + '</b></div>' +
    '<div class="yest-row"><span>' + esc(t("sumUsefulTime")) + '</span><b>' + fmtHM(au.useful) + '</b></div>' +
    '<div class="yest-row"><span>' + esc(t("yesterdayBacklogLbl")) + '</span><b>' + FA(backlogYday) + ' ← ' + FA(backlogNow) + ' <span class="yest-delta ' + deltaCls + '">(' + deltaTxt + ')</span></b></div>' +
    '</div>';
  el.hidden = false;
}
// The Dashboard eve card: shown only when tomorrow is an exam day,
// with the full checklist. Called from renderDashboard.
function renderExamNightEve() {
  const el = document.getElementById("dashExamNight");
  if (!el) return;
  const ex = allExams().find(e => e.date === addDays(realTodayIso(), 1)) || null; // v1.11.45 (F-12): calendar day, like todaysExam
  if (!ex) { el.hidden = true; el.innerHTML = ""; el.classList.remove("exd-all-done"); return; }
  el.innerHTML = examNightFullHtml(ex);
  wireExamNight(el, ex);
  el.hidden = false;
  el.classList.toggle("exd-all-done", examNightAllDone(ex));
}
// The 22:00 reminder, checked once a second by updateTimerDisplays:
// on the exam eve, at/after 22:00 Tehran, with the reminder on and
// not yet shown today — one toast, then the day is marked shown.
function checkExamNightReminder() {
  const ex = allExams().find(e => e.date === addDays(realTodayIso(), 1)); // v1.11.45 (F-12): calendar day
  if (!ex) return;
  const pack = examNightPack(ex);
  if (!pack.nightReminder || pack.nightReminderShown === TODAY) return;
  const p = tehranParts(new Date());
  if (p.hh < 22) return;
  const p0 = (state.examPack = state.examPack || {});
  const cur = p0[ex.id] || (p0[ex.id] = {});
  cur.nightReminderShown = TODAY;
  saveState();
  showToast(t("exNightRemindToast", { time: fmtTimeFa(examNightSleep(ex)), start: fmtTimeFa(examNightStart(ex)) }), { ms: 6000 });
}
function renderExamDay() {
  const el = document.getElementById("examDayCard");
  if (!el) return;
  const ex = todaysExam();
  if (!ex) { el.hidden = true; el.innerHTML = ""; return; }
  const times = examDayTimes(ex);
  const pack = ((state.examPack || {})[ex.id]) || {};
  const items = [["bringCard", "exdBringCard"], ["bringPen", "exdBringPen"], ["bringId", "exdBringId"]];
  el.innerHTML =
    '<div class="exd-head"><span class="exd-title">' + esc(t("exdTitle")) + '</span>' +
    '<span class="exd-today">' + esc(t("exdToday")) + '</span></div>' +
    '<div class="exd-name">' + esc(examGroupLabel(ex) + " — " + examDisplayName(ex)) + '</div>' +
    '<div class="exd-meta">' + esc(examDateText(ex)) + ' · ' + esc(examTypeLabel(ex.type)) +
    (ex.questions ? ' · ' + esc(t("exdQuestions")) + ' ' + FA(ex.questions) : '') + '</div>' +
    '<div class="exd-times">' +
      (times.presence ? '<span>' + esc(t("exdPresence")) + ' <b>' + fmtTimeFa(times.presence) + '</b></span>' : '') +
      '<span>' + esc(t("exdStart")) + ' <b>' + fmtTimeFa(times.start) + '</b></span>' +
    '</div>' +
    '<label class="exd-venue"><span>' + esc(t("exdVenue")) + '</span> ' +
      '<input type="text" class="exd-venue-input" value="' + esc(ex.venue || "") + '" placeholder="' + esc(t("exdVenuePh")) + '"></label>' +
    '<div class="exd-bring"><div class="exd-bring-title">' + esc(t("exdBring")) + '</div>' +
      items.map(pair =>
        '<label class="exd-item"><input type="checkbox" class="exd-pack" data-pack="' + pair[0] + '"' + (pack[pair[0]] ? " checked" : "") + '> ' + esc(t(pair[1])) + '</label>').join("") +
    '</div>' +
    '<button type="button" class="btn exd-night-btn" id="examDayNightBtn">' + esc(t("exNightTitle")) + '</button>' +
    '<div class="exn-panel" id="examDayNightPanel" hidden></div>' +
    '<button class="btn btn-primary exd-result">' + esc(t("exdResult")) + '</button>';
  el.hidden = false;
  el.querySelector(".exd-venue-input").addEventListener("change", ev => {
    ex.venue = ev.target.value.trim();
    saveState();
    el.classList.toggle("exd-all-done", examNightAllDone(ex));
  });
  el.querySelectorAll(".exd-pack").forEach(cb => cb.addEventListener("change", () => {
    const p = (state.examPack = state.examPack || {});
    const cur = p[ex.id] || (p[ex.id] = {});
    cur[cb.dataset.pack] = cb.checked;
    saveState();
    el.classList.toggle("exd-all-done", examNightAllDone(ex));
  }));
  // v1.11.43 (§17 idea 4): the night checklist toggle — the venue +
  // bring items already live on this card, so the panel only adds the
  // night items; the green state counts them all together.
  const nightBtn = el.querySelector("#examDayNightBtn");
  const nightPanel = el.querySelector("#examDayNightPanel");
  if (nightBtn && nightPanel) {
    nightBtn.addEventListener("click", () => { exNightOpen = !exNightOpen; renderAll(); });
    nightPanel.hidden = !exNightOpen;
    if (exNightOpen) { nightPanel.innerHTML = examNightSlimHtml(ex); wireExamNight(nightPanel, ex); }
  }
  el.classList.toggle("exd-all-done", examNightAllDone(ex));
  el.querySelector(".exd-result").addEventListener("click", () => {
    navigate({ tab: "exams", examGroup: ex.group, examView: "list", examId: ex.id, scroll: { type: "exam", id: ex.id } });
    setTimeout(() => {
      const card = document.getElementById("exam-card-" + ex.id);
      const form = card && card.querySelector(".exam-form");
      if (form) { form.hidden = false; form.scrollIntoView({ block: "start" }); }
    }, 120);
  });
}
// ----- Creative 2: «برنامه‌ریزی معکوس از آزمون» (reverse planning) -----
// Pick an exam + a coverage target; the programme places one 90-minute
// test box per uncovered budget topic BACKWARDS from the exam date
// into empty gaps of future days. Coverage is counted done-only, the
// same definition as examReadiness; weight = budget questions or 1.
// Placement uses the same rules as every other placement (gapForDay:
// max 2 parts of a subject per day, 12h daily cap, tests before
// reviews, no overlaps) plus: exam days are skipped entirely, and
// boxes already planned in this run count toward the max-2 rule and
// the 12h cap. The plan is shown first; nothing is created until
// «جای‌گذاری همه» is clicked.
let revOpen = false, revExamId = null, revTarget = 90, revPlan = null, revPlanFor = null;
let covOpen = false;
function reversePlanTopics(ex) {
  const topics = [];
  (ex.budget || []).forEach(s => (s.chapters || []).forEach(ch =>
    (ch.topics || []).forEach(tp => {
      const p = budgetTopicProgress(s.subject, tp.name, tp.subtopics, topicLinks(tp));
      topics.push({
        subject: s.subject, name: tp.name,
        weight: (typeof tp.questions === "number" && tp.questions > 0) ? tp.questions : 1,
        state: p.state, solved: p.solved, total: p.total
      });
    })));
  return topics;
}
function reverseCoverage(ex) {
  const topics = reversePlanTopics(ex);
  if (!topics.length) return null;
  const totalW = topics.reduce((s, tp) => s + tp.weight, 0);
  const doneW = topics.filter(tp => tp.state === "done").reduce((s, tp) => s + tp.weight, 0);
  return { topics, totalW, doneW, pct: totalW ? Math.round(doneW / totalW * 100) : 0 };
}
function buildReversePlan(ex, targetPct) {
  const cov = reverseCoverage(ex);
  if (!cov || !ex.date) return { plan: [], cov, needW: 0, accW: 0 };
  const needW = Math.ceil(targetPct / 100 * cov.totalW) - cov.doneW;
  if (needW <= 0) return { plan: [], cov, needW, accW: 0 };
  const cands = cov.topics.filter(tp => tp.state !== "done")
    .sort((a, b) => b.weight - a.weight || String(a.name).localeCompare(String(b.name)));
  const examDays = new Set(allExams().map(e => e.date).filter(Boolean));
  const plan = [], drafts = [];
  let accW = 0;
  for (const tp of cands) {
    if (accW >= needW) break;
    const box = {
      title: subjName(tp.subject) + " — " + t("testsWord") + " " + tp.name,
      subject: tp.subject, topic: tp.name,
      start: "09:00", end: "10:30", is_test: true, tests_total: 0,
      note: "", type: "normal"
    };
    let placed = null;
    for (let d = addDays(ex.date, -1); d > TODAY; d = addDays(d, -1)) {
      if (examDays.has(d)) continue;
      const dayBoxes = allBoxes().filter(b => boxStudyDay(b) === d);
      const dayDrafts = drafts.filter(x => boxStudyDay(x) === d);
      const subjCount = dayBoxes.filter(b => b.subject === tp.subject).length +
        dayDrafts.filter(x => x.subject === tp.subject).length;
      if (subjCount >= 2) continue;
      const dayMins = dayBoxes.reduce((s, b) => s + minutesBetween(b.start || "00:00", b.end || "00:00"), 0) +
        dayDrafts.reduce((s, b) => s + minutesBetween(b.start || "00:00", b.end || "00:00"), 0);
      if (dayMins + 90 > DAY_CAP_MIN) continue;
      const g = gapForDay(box, d);
      if (!g) continue;
      if (dayDrafts.some(x => intervalsOverlap(g.start, g.end, x.start, x.end))) continue;
      placed = g; break;
    }
    if (!placed) continue; // no gap before the exam: skip this topic
    const nb = Object.assign({}, box, { date: placed.date, start: placed.start, end: placed.end });
    drafts.push(nb);
    plan.push({ topic: tp, box: nb });
    accW += tp.weight;
  }
  return { plan, cov, needW, accW };
}
async function applyReversePlan(plan) {
  if (!plan || !plan.length) return;
  // v1.11.52 (I-6): remember the pre-apply backup before creating anything.
  const undoPoint = await bulkUndoPoint();
  let placed = 0, failed = 0;
  for (const item of plan) {
    const b = item.box;
    // v1.11.52 (F3): idempotent create (client_id + adopt on lost response).
    const created = await createBoxIdempotent({ title: b.title, date: b.date, start: b.start, end: b.end, subject: b.subject, topic: b.topic, is_test: true, tests_total: 0, note: "", type: "normal" });
    let box = created.box, serverErr = created.serverErr;
    if (serverErr) { failed++; continue; }
    if (!box) {
      box = { id: localBoxId(), date: b.date, start: b.start, end: b.end, subject: b.subject, topic: b.topic, title: b.title, is_test: true, tests_total: 0, note: "", type: "normal" };
    }
    (state.custom_boxes = state.custom_boxes || []).push(box);
    placed++;
  }
  saveState();
  // v1.11.61 (M-DATA1): same check as the bulk delete — the old code
  // toasted «اعمال شد» without waiting for the save at all. On
  // failure the toast says the save failed (the undo point from the
  // pre-apply backup is still offered, so the user can roll back).
  const savedOk = await flushSaves();
  renderAll();
  bulkUndoToast(undoPoint, !savedOk ? t("toastNotSaved")
    : (failed ? t("revPartial", { n: FA(placed) }) : t("revApplied")));
}
function renderReversePlannerInto(detail) {
  const upcoming = allExams().filter(e => e.date && e.date >= TODAY)
    .sort((a, b) => (a.date || "9999").localeCompare(b.date || "9999"));
  const ex = revExamId ? findExam(revExamId) : (upcoming[0] || null);
  if (ex) revExamId = ex.id;
  let html = '<div class="rev-plan"><h3>' + esc(t("revTitle")) + '</h3>';
  html += '<div class="form-row"><label>' + esc(t("revPick")) + ' <select class="rev-exam">' +
    upcoming.map(e => '<option value="' + esc(e.id) + '"' + (ex && e.id === ex.id ? " selected" : "") + '>' +
      esc(examGroupLabel(e) + " — " + examDisplayName(e) + " · " + examDateText(e)) + '</option>').join("") +
    '</select></label>' +
    '<label>' + esc(t("revTarget")) + ' <select class="rev-target">' +
    [50, 70, 90].map(p => '<option value="' + p + '"' + (revTarget === p ? " selected" : "") + '>' + FA(p) + '٪</option>').join("") +
    '</select></label>' +
    '<button class="btn btn-primary rev-build">' + esc(t("revPlan")) + '</button></div>';
  if (!ex) {
    html += '<p class="muted">' + esc(t("exNoUpcoming")) + '</p>';
  } else {
    const cov = reverseCoverage(ex);
    if (!cov) {
      html += '<p class="muted">' + esc(t("exNoBudget")) + '</p>';
    } else {
      const days = examDaysLeft(ex);
      html += '<p class="rev-cov">' + esc(t("revCoverage")) + ': ' + FA_PCT(cov.pct) +
        ' · ' + esc(t("revTarget")) + ' ' + FA(revTarget) + '٪' +
        (days != null ? ' · ' + FA(days) + ' ' + esc(t("revDays")) : '') + '</p>';
      const uncovered = cov.topics.filter(tp => tp.state !== "done");
      html += '<p class="muted">' + esc(t("revUncovered")) + ': ' + FA(uncovered.length) + ' / ' + FA(cov.topics.length) + '</p>';
      if (revPlan && revPlanFor === ex.id) {
        if (!revPlan.plan.length) {
          // Target already met (but topics may still be uncovered) is
          // not "all covered" and not "no gap": say so plainly.
          html += '<p class="muted">' + esc(revPlan.needW <= 0
            ? t("revCoverage") + ": " + FA_PCT(cov.pct) + " ✓"
            : (uncovered.length === 0 ? t("revNone") : t("revNoplan"))) + '</p>';
        } else {
          html += '<p>' + esc(t("revNeed")) + '</p><ul class="rev-list">' +
            revPlan.plan.map(item =>
              '<li>' + esc(gregToJalali(boxStudyDay(item.box)).text) + ' · ' + fmtTimeFa(item.box.start) + '–' + fmtTimeFa(item.box.end) +
              ' · ' + esc(item.box.title) + '</li>').join("") + '</ul>' +
            (revPlan.accW < revPlan.needW
              ? '<p class="muted">' + esc(t("revPartial", { n: FA(revPlan.plan.length) })) + '</p>' : '') +
            '<button class="btn btn-primary rev-apply">' + esc(t("revApply")) + '</button>';
        }
      }
    }
  }
  html += '</div>';
  detail.innerHTML = html;
  const sel = detail.querySelector(".rev-exam");
  if (sel) sel.addEventListener("change", () => { revExamId = sel.value; revPlan = null; revPlanFor = null; renderExams(); });
  const tgt = detail.querySelector(".rev-target");
  if (tgt) tgt.addEventListener("change", () => { revTarget = parseInt(tgt.value, 10) || 90; revPlan = null; revPlanFor = null; renderExams(); });
  const build = detail.querySelector(".rev-build");
  if (build) build.addEventListener("click", () => {
    const e2 = findExam(revExamId);
    if (!e2) return;
    revPlan = buildReversePlan(e2, revTarget);
    revPlanFor = e2.id;
    renderExams();
  });
  const apply = detail.querySelector(".rev-apply");
  if (apply) apply.addEventListener("click", async () => {
    // v1.11.45 (E-16): single-flight — a second click while the awaited
    // apply is still running re-ran the same plan and duplicated the
    // custom boxes. Disable until it finishes.
    if (apply.disabled) return;
    apply.disabled = true;
    try { await applyReversePlan(revPlan.plan); }
    finally { apply.disabled = false; }
    revPlan = null; revPlanFor = null;
  });
}
// ----- Creative 3: «تشخیص افت بازده» (efficiency-drop detection) -----
// If useful/real falls below 50% for 2+ consecutive days WITH data
// (real time recorded and useful recorded for at least one box),
// suggest a light day (2 review boxes + rest) instead of "study
// more". Display-only: no box is created, moved or deleted. A day
// with no study at all has no ratio and does not count.
function fatigueSignal() {
  const series = anDailySeries(allBoxes())
    .filter(d => d.actual > 0 && d.usefulBoxes > 0)
    .sort((a, b) => a.date.localeCompare(b.date));
  const recent = series.slice(-3);
  let low = 0;
  for (let i = recent.length - 1; i >= 0; i--) {
    const d = recent[i];
    const ratio = d.actual > 0 ? d.useful / d.actual : null;
    if (ratio != null && ratio < 0.5) low++;
    else break;
  }
  return low >= 2 ? { days: low } : null;
}
function renderFatigueCard() {
  const el = document.getElementById("dashFatigue");
  if (!el) return;
  const sig = fatigueSignal();
  if (!sig) { el.hidden = true; el.innerHTML = ""; return; }
  el.innerHTML = '<div class="fat-title">' + esc(t("fatTitle")) + '</div>' +
    '<p>' + esc(t("fatBody", { n: FA(sig.days) })) + '</p>';
  el.hidden = false;
}
// ----- Creative 4: «بهترینِ خودم» (personal bests) -----
// Best useful day, best test week, best chapter accuracy —
// self-comparison only, never a rank or taraz estimate. All from
// real data; honest empty states when there is nothing to compare.
// Best chapter needs at least 10 solved tests (same floor as the
// Analytics chapter table's accuracy display).
function personalBests() {
  const days = anDailySeries(allBoxes()).filter(d => d.usefulBoxes > 0);
  const bestDay = days.length ? days.reduce((a, b) => (b.useful > a.useful ? b : a)) : null;
  const weeks = anWeeklySeries(allBoxes()).filter(w => w.tests > 0);
  const bestWeek = weeks.length ? weeks.reduce((a, b) => (b.tests > a.tests ? b : a)) : null;
  let bestChapter = null;
  (TESTBOOK.books || []).forEach(book => (book.chapters || []).forEach(ch => {
    (ch.topics || []).forEach(tp => {
      const s = topicStats(tp);
      if ((s.solved || 0) >= 10 && s.acc != null) {
        if (!bestChapter || s.acc > bestChapter.acc ||
            (s.acc === bestChapter.acc && s.solved > bestChapter.solved)) {
          bestChapter = { book: book.id, chapter: ch, acc: s.acc, solved: s.solved };
        }
      }
    });
  }));
  return { bestDay, bestWeek, bestChapter };
}
function renderPersonalBests() {
  // v1.11.63 (Batch 4, dashboard declutter): «رکوردهای شخصی» moved
  // to Analytics (its home) — same card, same data.
  const el = document.getElementById("anPersonalBestCard");
  if (!el) return;
  const pb = personalBests();
  if (!pb.bestDay && !pb.bestWeek && !pb.bestChapter) {
    el.innerHTML = '<div class="pb-title">' + esc(t("pbTitle")) + '</div>' +
      '<p class="muted">' + esc(t("pbNone")) + '</p>';
    return;
  }
  let html = '<div class="pb-title">' + esc(t("pbTitle")) + '</div><div class="pb-rows">';
  if (pb.bestDay) {
    html += '<div class="pb-row"><span>' + esc(t("pbDay")) + '</span><b>' +
      esc(gregToJalali(pb.bestDay.date).text) + ' · ' + esc(fmtDurationFa(Math.round(pb.bestDay.useful))) + ' ' + esc(t("pbUseful")) + '</b></div>';
  }
  if (pb.bestWeek) {
    html += '<div class="pb-row"><span>' + esc(t("pbWeek")) + '</span><b>' +
      esc(gregToJalali(pb.bestWeek.date).text) + ' · ' + FA(pb.bestWeek.tests) + ' ' + esc(t("testsWord")) + '</b></div>';
  }
  if (pb.bestChapter) {
    html += '<div class="pb-row"><span>' + esc(t("pbChapter")) + '</span><b>' +
      esc(bookName(pb.bestChapter.book) + " — " + chapterTitle(pb.bestChapter.chapter)) +
      ' · ' + FA_PCT(pb.bestChapter.acc) + '</b></div>';
  }
  el.innerHTML = html + '</div>';
}
// ----- Creative 5: «نقشهٔ پوشش کنکور» (Konkur coverage map) -----
// One visual colour map of the whole syllabus: every chapter of every
// book (testbook solved/total — green ≥80%, yellow 1–79%, grey 0%,
// «بدون داده» when the chapter has no test total), plus هندسه and the
// general subjects, whose rows come from the nearest upcoming exam
// that has the subject in its budget (budgetTopicProgress counts,
// done-only — the same definition as examReadiness; a topic with no
// book link and no subtopics counts as not done). Display-only.
function coverageMapData() {
  const rows = [];
  (TESTBOOK.books || []).forEach(book => {
    (book.chapters || []).forEach(ch => {
      let solved = 0, total = 0;
      (ch.topics || []).forEach(tp => { const s = topicStats(tp); solved += s.solved; total += s.total; });
      rows.push({ kind: "chapter", book: book.id, chapter: ch, solved, total,
                  pct: total ? Math.min(100, Math.round(solved / total * 100)) : null });
    });
  });
  const wanted = ["هندسه", "عربی", "دینی", "ادبیات", "زبان انگلیسی"];
  wanted.forEach(subj => {
    const ex = allExams().filter(e => e.date && e.date >= TODAY &&
      (e.budget || []).some(s => s.subject === subj))
      .sort((a, b) => (a.date || "9999").localeCompare(b.date || "9999"))[0];
    if (!ex) return;
    let done = 0, total = 0;
    (ex.budget || []).forEach(s => {
      if (s.subject !== subj) return;
      (s.chapters || []).forEach(ch => (ch.topics || []).forEach(tp => {
        const p = budgetTopicProgress(s.subject, tp.name, tp.subtopics, topicLinks(tp));
        total++;
        if (p.state === "done") done++;
      }));
    });
    rows.push({ kind: "subject", subject: subj, solved: done, total,
                pct: total ? Math.round(done / total * 100) : null });
  });
  return rows;
}
function covCellClass(pct) {
  if (pct == null) return "cov-nodata";
  if (pct >= 80) return "cov-full";
  if (pct >= 1) return "cov-partial";
  return "cov-none";
}
function renderCoverageMapInto(detail) {
  const rows = coverageMapData();
  const books = (TESTBOOK.books || []);
  let html = '<div class="cov-map"><h3>' + esc(t("covTitle")) + '</h3>';
  html += '<div class="cov-legend">' +
    '<span class="cov-swatch cov-full"></span>' + esc(t("covFull")) +
    ' <span class="cov-swatch cov-partial"></span>' + esc(t("covPartial")) +
    ' <span class="cov-swatch cov-none"></span>' + esc(t("covNone")) +
    ' <span class="cov-swatch cov-nodata"></span>' + esc(t("covNodata")) + '</div>';
  html += '<h4>' + esc(t("covBooks")) + '</h4>';
  books.forEach(book => {
    const chs = rows.filter(r => r.kind === "chapter" && r.book === book.id);
    if (!chs.length) return;
    html += '<div class="cov-book"><div class="cov-book-name">' + esc(bookName(book.id)) + '</div><div class="cov-cells">' +
      chs.map(r =>
        '<div class="cov-cell ' + covCellClass(r.pct) + '" title="' + esc(chapterTitle(r.chapter)) + '">' +
        '<span class="cov-cell-name">' + esc(chapterTitle(r.chapter)) + '</span>' +
        '<span class="cov-cell-pct">' + (r.pct == null ? esc(t("covNodata")) : FA_PCT(r.pct)) + '</span></div>').join("") +
      '</div></div>';
  });
  const subjRows = rows.filter(r => r.kind === "subject");
  if (subjRows.length) {
    const geo = subjRows.filter(r => r.subject === "هندسه");
    const gen = subjRows.filter(r => r.subject !== "هندسه");
    if (geo.length) {
      html += '<h4>' + esc(t("covGeometry")) + '</h4><div class="cov-cells">' +
        geo.map(r =>
          '<div class="cov-cell ' + covCellClass(r.pct) + '">' +
          '<span class="cov-cell-name">' + esc(subjName(r.subject)) + '</span>' +
          '<span class="cov-cell-pct">' + (r.pct == null ? esc(t("covNodata")) : FA_PCT(r.pct)) + '</span></div>').join("") + '</div>';
    }
    if (gen.length) {
      html += '<h4>' + esc(t("covGeneral")) + '</h4><div class="cov-cells">' +
        gen.map(r =>
          '<div class="cov-cell ' + covCellClass(r.pct) + '">' +
          '<span class="cov-cell-name">' + esc(subjName(r.subject)) + '</span>' +
          '<span class="cov-cell-pct">' + (r.pct == null ? esc(t("covNodata")) : FA_PCT(r.pct)) + '</span></div>').join("") + '</div>';
    }
  }
  detail.innerHTML = html + '</div>';
}
function examCard(ex, isNext) {
  const status = examStatusOf(ex);
  const r = ex.result || {};
  const card = document.createElement("div");
  card.className = "exam-card st-" + status + (isNext ? " st-next" : "");
  card.id = "exam-card-" + ex.id;
  const statusKey = { upcoming: "exStatusUpcoming", held: "exStatusHeld",
                      analyzed: "exStatusAnalyzed" }[status];
  const statusText = isNext ? t("exStatusNext") : t(statusKey);
  const days = examDaysLeft(ex);
  card.innerHTML =
    '<div class="exam-head"><span class="exam-title">' + esc(examGroupLabel(ex) + " — " + examDisplayName(ex)) + '</span>' +
    '<span class="exam-status ' + (isNext ? "next" : status) + '">' + esc(statusText) + '</span></div>' +
    '<div class="exam-meta"><span class="type-badge b-' + ex.group + '">' + t(examGroupKey(ex.group)) + '</span> ' +
    esc(examDateText(ex)) + ' · ' + esc(examTypeLabel(ex.type)) + ' · ' +
    (ex.questions ? t("exQuestions", { n: FA(ex.questions) }) : t("exQuestionsDescriptive")) +
    (days != null && status === "upcoming" ? ' · ' + (days === 0 ? t("exToday") : (days === 1 ? t("exDayLeft") : t("exDaysLeft", { n: FA(days) }))) : "") + '</div>' +
    '<div class="exam-focus">' + esc(LANG === "fa" ? (ex.focusFa || "") : (ex.focusEn || ex.focusFa || "")) + '</div>' +
    '<div class="exam-budget-wrap">' + (ex.budget && ex.budget.length ? budgetHtml(ex) : '<p class="muted">' + t("exNoBudget") + '</p>') + '</div>' +
    '<div class="exam-forecast-wrap">' + (status === "upcoming" ? examForecastHtml(ex) : "") + '</div>' +
    '<div class="exam-result-wrap">' + examResultHtml(ex) + '</div>' +
    '<div class="exam-plan-wrap">' + examPlanHtml(ex) + '</div>' +
    '<div class="part-actions">' +
      '<button class="edit-btn ex-edit">' + t("exEditExam") + '</button>' +
      '<button class="edit-btn ex-result-btn">' + t("exEditResult") + '</button>' +
      '<button class="edit-btn ex-report">' + t("stageReportBtn") + '</button>' +
      '<button class="del-btn ex-del">' + t("exDeleteExam") + '</button>' +
    '</div>' +
    '<div class="exam-form" hidden>' +
      '<div class="form-row">' +
        '<label>' + t("exTaraz") + ' <input type="number" min="0" class="xf-taraz" value="' + (r.taraz != null ? r.taraz : "") + '"></label>' +
        '<label>' + t("exRank") + ' <input type="number" min="0" class="xf-rank" value="' + (r.rank != null ? r.rank : "") + '"></label>' +
        '<label>' + t("exRankOf", { n: "" }).trim() + ' <input type="number" min="0" class="xf-ranktotal" value="' + (r.rankTotal != null ? r.rankTotal : "") + '"></label>' +
      '</div>' +
      '<div class="form-row">' +
        '<label>' + t("exCorrect") + ' <input type="number" min="0" class="xf-correct" value="' + (r.correct != null ? r.correct : "") + '"></label>' +
        '<label>' + t("exWrong") + ' <input type="number" min="0" class="xf-wrong" value="' + (r.wrong != null ? r.wrong : "") + '"></label>' +
        '<label>' + t("exUnanswered") + ' <input type="number" min="0" class="xf-unanswered" value="' + (r.unanswered != null ? r.unanswered : "") + '"></label>' +
      '</div>' +
      '<div class="form-row"><label style="flex:1">' + t("exNote") + ' <input type="text" class="xf-note" value="' + esc(r.note || "") + '" placeholder="' + esc(t("exNotePh")) + '"></label></div>' +
      '<div class="ex-subj-form">' + examSubjectFormHtml(ex) + '</div>' +
      '<div class="form-row">' +
        '<button class="btn btn-primary xf-save">' + t("exSaveResult") + '</button>' +
        (ex.result ? '<button class="btn xf-del">' + t("exDeleteResult") + '</button>' : '') +
      '</div>' +
    '</div>';
  wireBudgetButtons(card);
  wireBudgetSubtopics(card, ex);
  // v1.11.35 (P2-12): one click places the compensation plan's
  // suggestions (the plan is recomputed at click time, so gaps are fresh).
  const planBtn = card.querySelector(".ex-plan-apply");
  if (planBtn) planBtn.addEventListener("click", () => applyExamPlan(examCompensationPlan(ex)));
  const form = card.querySelector(".exam-form");
  card.querySelector(".ex-result-btn").addEventListener("click", () => { form.hidden = !form.hidden; });
  card.querySelector(".ex-edit").addEventListener("click", () => openExamModal(ex.id));
  // v1.11.52 (P-5): the printable stage report for this exam.
  card.querySelector(".ex-report").addEventListener("click", () => openStageReport(ex.id));
  card.querySelector(".ex-del").addEventListener("click", () => {
    if (!confirm(t("exDeleteExamConfirm"))) return;
    deleteExamById(ex.id);
  });
  const numVal = (sel) => {
    const v = card.querySelector(sel).value.trim();
    return v === "" ? null : Math.max(0, parseInt(v, 10) || 0);
  };
  card.querySelector(".xf-save").addEventListener("click", () => {
    // (3.1) per-subject rows — only when the form has them (an exam
    // with no budget shows no rows, and its stored subjects stay as-is).
    const oldSubjects = (ex.result && ex.result.subjects) || null;
    const subjRows = card.querySelectorAll(".ex-subj-row");
    const subjects = {};
    subjRows.forEach(row => {
      const s = row.dataset.subject;
      const cv = row.querySelector(".xf-subj-correct").value.trim();
      const wv = row.querySelector(".xf-subj-wrong").value.trim();
      const uv = row.querySelector(".xf-subj-unanswered").value.trim();
      if (cv === "" && wv === "" && uv === "") return;
      subjects[s] = {
        correct: cv === "" ? 0 : Math.max(0, parseInt(cv, 10) || 0),
        wrong: wv === "" ? 0 : Math.max(0, parseInt(wv, 10) || 0),
        unanswered: uv === "" ? 0 : Math.max(0, parseInt(uv, 10) || 0)
      };
    });
    ex.result = {
      taraz: numVal(".xf-taraz"), rank: numVal(".xf-rank"), rankTotal: numVal(".xf-ranktotal"),
      correct: numVal(".xf-correct"), wrong: numVal(".xf-wrong"), unanswered: numVal(".xf-unanswered"),
      note: card.querySelector(".xf-note").value.trim()
    };
    if (subjRows.length) {
      // Rows present: what is shown is what is stored; all rows blank
      // clears the breakdown.
      if (Object.keys(subjects).length) ex.result.subjects = subjects;
    } else if (oldSubjects) {
      ex.result.subjects = oldSubjects;
    }
    if (examStatusOf(ex) === "upcoming") ex.status = "analyzed";
    // v1.11.63 (Batch 4, M-UI4): a recorded result re-opens the bar —
    // a dismissal from before no longer hides anything.
    if (state.examPack && state.examPack[ex.id]) delete state.examPack[ex.id].resultDismissed;
    saveState(); renderAll();
    // v1.11.63 (Batch 4, م-۴): the compensation plan, right after the
    // result is saved — the weakest subject is the most wrong answers
    // of the JUST-SAVED result, the plan itself comes from the existing
    // examCompensationPlan and applies with the same I-6 undo point as
    // the Exams-tab button (F8, v1.11.61). No plan / no subject rows →
    // the plain «saved» toast only.
    const plan = examCompensationPlan(ex);
    const subjMap = (ex.result && ex.result.subjects) || {};
    let weakest = null;
    Object.keys(subjMap).forEach(s => {
      const w = (subjMap[s] && subjMap[s].wrong) || 0;
      if (w > 0 && (!weakest || w > weakest.wrong)) weakest = { subject: s, wrong: w };
    });
    if (plan && plan.suggestions && plan.suggestions.length && weakest) {
      showToast(t("exCompToast", { subj: subjName(weakest.subject), wrong: FA(weakest.wrong), n: FA(plan.suggestions.length) }), {
        ms: 9000,
        action: { label: t("exCompToastAction"), fn: () => applyExamPlan(plan) }
      });
    } else {
      showToast(t("exResultSaved")); // v1.11.41: toast instead of the native alert
    }
  });
  const del = card.querySelector(".xf-del");
  if (del) del.addEventListener("click", () => {
    if (!confirm(t("exDeleteResultConfirm"))) return;
    ex.result = null;
    saveState(); renderAll();
  });
  return card;
}
function deleteExamById(id) {
  const ex = findExam(id);
  if (!ex) return;
  state.exams[ex.group] = (state.exams[ex.group] || []).filter(x => x.id !== id);
  state.examsRemoved = state.examsRemoved || [];
  if (!state.examsRemoved.includes(id)) state.examsRemoved.push(id);
  saveState(); renderAll();
  showToast(t("exExamDeleted")); // v1.11.41: toast instead of the native alert
}

// ---------- Timed exam simulation (v1.11.38, P3-8) ----------
// A real timed exam run: overall countdown, per-subject time budgets,
// correct/wrong/unanswered per subject with negative marking (each
// wrong answer costs ⅓), and the result saved through the EXISTING
// exam result path — same shape as a saved Maz/school result, flagged
// `simulated: true` so it never passes as a real result. Transient
// only (module-level `sim`), never persisted; leaving mid-run asks
// first (applyRoute guard) and saves nothing.
let sim = null;
function simExamList() {
  const all = [];
  ["maz", "zoodbist", "school"].forEach(g => (state.exams[g] || []).forEach(ex => all.push(ex)));
  return all.slice().sort((a, b) => (a.date || "9999").localeCompare(b.date || "9999"));
}
function simSubjects(ex) {
  return (ex.budget || []).map(s => s.subject).filter(Boolean);
}
function simTotalQuestions(ex) {
  return (ex.budget || []).reduce((a, s) => a + (s.questions || 0), 0);
}
function simDurationMin(ex) {
  return (ex && ex.durationMin > 0) ? ex.durationMin : 180;
}
function simSubjectBudgetMin(ex, subj) {
  const total = simTotalQuestions(ex);
  const dur = simDurationMin(ex);
  const subs = simSubjects(ex);
  if (total <= 0) return Math.round(dur / Math.max(1, subs.length));
  const q = ((ex.budget || []).find(s => s.subject === subj) || {}).questions || 0;
  return Math.round(dur * q / total);
}
function simRawScore(row) {
  const c = row.correct || 0, w = row.wrong || 0;
  return Math.round((c - w / 3) * 10) / 10;
}
function openSimSetup() {
  const detail = document.getElementById("examsDetail");
  if (!detail) return;
  const list = simExamList();
  const next = nearestExam();
  const sel = next ? next.id : (list[0] ? list[0].id : null);
  detail.innerHTML = '<div class="card sim-setup"><h3>' + esc(t("simTitle")) + '</h3>' +
    '<p class="muted">' + esc(t("simNegMark")) + '</p>' +
    '<label>' + esc(t("simPickExam")) + ' <select class="sim-exam-sel">' +
    list.map(ex => '<option value="' + esc(ex.id) + '"' + (ex.id === sel ? " selected" : "") + '>' +
      esc(examGroupLabel(ex) + " — " + examDisplayName(ex) + " · " + examDateText(ex)) + '</option>').join('') +
    '</select></label>' +
    '<div class="sim-setup-info"></div>' +
    '<button type="button" class="btn btn-primary sim-start-btn">' + esc(t("simStart")) + '</button></div>';
  const info = detail.querySelector(".sim-setup-info");
  const selEl = detail.querySelector(".sim-exam-sel");
  const showInfo = () => {
    const ex = findExam(selEl.value);
    if (!ex) { info.innerHTML = ""; return; }
    const subs = simSubjects(ex);
    info.innerHTML = '<p>' + esc(t("simDuration")) + ': ' + FA(simDurationMin(ex)) + ' ' + esc(t("simMin")) + '</p>' +
      (subs.length
        ? '<ul>' + subs.map(s => '<li>' + esc(subjName(s)) + ' — ' + esc(t("simBudgetMin")) + ': ' + FA(simSubjectBudgetMin(ex, s)) + ' ' + esc(t("simMin")) + '</li>').join('') + '</ul>'
        : '<p class="muted">' + esc(t("simNoBudget")) + '</p>');
  };
  selEl.addEventListener("change", showInfo);
  showInfo();
  detail.querySelector(".sim-start-btn").addEventListener("click", () => {
    if (!selEl.value) { alert(t("simNoExam")); return; }
    startSim(selEl.value);
  });
}
function startSim(examId) {
  const ex = findExam(examId);
  if (!ex) return;
  const subs = simSubjects(ex);
  const rows = {};
  subs.forEach(s => { rows[s] = { correct: 0, wrong: 0, unanswered: 0 }; });
  if (!subs.length) rows["__total__"] = { correct: 0, wrong: 0, unanswered: 0 };
  const durMin = simDurationMin(ex);
  sim = { examId, totalSecs: durMin * 60, endsAt: Date.now() + durMin * 60000, rows, timerId: null };
  sim.timerId = setInterval(simTick, 1000);
  // v1.11.55 (F5): persist the run in state so a refresh resumes it
  // (endsAt alone drives the clock; the interval id is not stored).
  // sim.rows IS state.sim.rows (same object) — simReadRows writes the
  // one live rows object, so a server refresh can never leave the
  // persisted rows stale behind the module sim.
  state.sim = { examId, endsAt: sim.endsAt, rows };
  saveState();
  renderSim();
  document.getElementById("simOverlay").hidden = false;
}
function simTimeLeftSecs() {
  if (!sim) return 0;
  return Math.max(0, Math.round((sim.endsAt - Date.now()) / 1000));
}
function simFmtClock(secs) {
  const h = Math.floor(secs / 3600), m = Math.floor(secs % 3600 / 60), s = secs % 60;
  return String(h).padStart(2, "0") + ":" + String(m).padStart(2, "0") + ":" + String(s).padStart(2, "0");
}
function simReadRows() {
  if (!sim) return;
  document.querySelectorAll(".sim-subj-row").forEach(row => {
    const s = row.dataset.subject;
    const num = (sel) => Math.max(0, parseInt(row.querySelector(sel).value, 10) || 0);
    sim.rows[s] = { correct: num(".sim-correct"), wrong: num(".sim-wrong"), unanswered: num(".sim-unanswered") };
  });
  // v1.11.55 (F5): the persisted rows are the live rows object — a
  // server refresh replaces state.sim, so re-point it here (cheap
  // no-op when startSim/resumeSim already shared the object).
  if (state.sim && state.sim.examId === sim.examId) state.sim.rows = sim.rows;
}
function simTotals() {
  let c = 0, w = 0, u = 0;
  Object.keys(sim.rows).forEach(s => { c += sim.rows[s].correct || 0; w += sim.rows[s].wrong || 0; u += sim.rows[s].unanswered || 0; });
  return { correct: c, wrong: w, unanswered: u, raw: Math.round((c - w / 3) * 10) / 10 };
}
function renderSim() {
  const ov = document.getElementById("simOverlay");
  const inner = document.getElementById("simInner");
  if (!sim || !ov || !inner) return;
  const ex = findExam(sim.examId);
  const left = simTimeLeftSecs();
  const subs = Object.keys(sim.rows);
  const totals = simTotals();
  let html = '<h2>' + esc(t("simTitle")) + '</h2>' +
    '<p class="muted">' + esc(examGroupLabel(ex) + " — " + examDisplayName(ex)) + ' · ' + esc(examDateText(ex)) + '</p>' +
    '<div class="sim-clock" id="simClock">' + esc(t("simTimeLeft")) + ': <b>' + simFmtClock(left) + '</b></div>' +
    '<p class="muted">' + esc(t("simNegMark")) + '</p>' +
    '<h4>' + esc(t("simPerSubject")) + '</h4>';
  subs.forEach(s => {
    const r = sim.rows[s];
    const label = s === "__total__" ? examDisplayName(ex) : subjName(s);
    const budget = s === "__total__" ? simDurationMin(ex) : simSubjectBudgetMin(ex, s);
    html += '<div class="form-row ex-subj-row sim-subj-row" data-subject="' + esc(s) + '">' +
      '<label>' + esc(label) + ' <span class="muted">(' + esc(t("simBudgetMin")) + ': ' + FA(budget) + ' ' + esc(t("simMin")) + ')</span></label>' +
      '<label>' + t("exCorrect") + ' <input type="number" min="0" class="sim-correct" value="' + r.correct + '"></label>' +
      '<label>' + t("exWrong") + ' <input type="number" min="0" class="sim-wrong" value="' + r.wrong + '"></label>' +
      '<label>' + t("exUnanswered") + ' <input type="number" min="0" class="sim-unanswered" value="' + r.unanswered + '"></label>' +
      '<span class="muted">' + esc(t("simRawScore")) + ': ' + FA(simRawScore(r)) + '</span>' +
      '</div>';
  });
  html += '<div class="sim-totals"><b>' + esc(t("exCorrect")) + ':</b> ' + FA(totals.correct) +
    ' · <b>' + esc(t("exWrong")) + ':</b> ' + FA(totals.wrong) +
    ' · <b>' + esc(t("exUnanswered")) + ':</b> ' + FA(totals.unanswered) +
    ' · <b>' + esc(t("simRawScore")) + ':</b> ' + FA(totals.raw) + '</div>' +
    '<div class="part-actions">' +
    '<button type="button" class="btn btn-primary sim-finish-btn">' + esc(t("simFinishSave")) + '</button>' +
    '<button type="button" class="btn sim-exit-btn">' + esc(t("simExitNoSave")) + '</button>' +
    '</div>';
  inner.innerHTML = html;
  // v1.11.55 (F5): every typed count is persisted (debounced) — a
  // refresh mid-run keeps the entered counts, not just the clock.
  // No re-render here: renderSim would rebuild the inputs and steal
  // focus mid-typing.
  inner.querySelectorAll(".sim-subj-row input").forEach(inp =>
    inp.addEventListener("input", () => { simReadRows(); saveState(); }));
  inner.querySelector(".sim-finish-btn").addEventListener("click", () => finishSim(false));
  inner.querySelector(".sim-exit-btn").addEventListener("click", exitSim);
}
function simTick() {
  if (!sim) return;
  const left = simTimeLeftSecs();
  const clock = document.getElementById("simClock");
  if (clock) clock.innerHTML = esc(t("simTimeLeft")) + ': <b>' + simFmtClock(left) + '</b>';
  if (left <= 0) finishSim(true);
}
function stopSimSilent() {
  if (sim && sim.timerId) clearInterval(sim.timerId);
  sim = null;
  // v1.11.55 (F5): the persisted run goes with it — otherwise the
  // next load would resume a sim the user already finished or exited.
  if (state.sim) { state.sim = null; saveState(); }
  const ov = document.getElementById("simOverlay");
  if (ov) ov.hidden = true;
}
// v1.11.55 (F5): resume a sim stored in state (refresh / crashed tab).
// endsAt drives the clock, rows are intact. Expired while away:
// restore WITHOUT the interval so the user can still finish (save
// the rows) or exit — never auto-finish silently (finishSim asks
// before overwriting a real result).
function resumeSim() {
  if (sim || !state.sim) return;
  const saved = state.sim;
  const ex = (saved && typeof saved.examId === "string") ? findExam(saved.examId) : null;
  if (!ex || typeof saved.endsAt !== "number" || !saved.rows || typeof saved.rows !== "object") {
    state.sim = null; saveState(); return;
  }
  const rows = {};
  Object.keys(saved.rows).forEach(subj => {
    const r = saved.rows[subj];
    if (r && typeof r === "object") rows[subj] = { correct: numOr0(r.correct), wrong: numOr0(r.wrong), unanswered: numOr0(r.unanswered) };
  });
  if (!Object.keys(rows).length) { state.sim = null; saveState(); return; }
  state.sim.rows = rows;
  sim = { examId: saved.examId, totalSecs: Math.max(0, Math.round((saved.endsAt - Date.now()) / 1000)), endsAt: saved.endsAt, rows, timerId: null };
  if (saved.endsAt > Date.now()) {
    sim.timerId = setInterval(simTick, 1000);
    showToast(t("simResumed"));
  }
  renderSim();
  document.getElementById("simOverlay").hidden = false;
}
function exitSim() {
  if (!confirm(t("simExitConfirm"))) return;
  stopSimSilent();
}
function finishSim(auto) {
  if (!sim) return;
  // Stop the clock first: a declined overwrite confirm must not
  // re-trigger finish every second from the interval.
  if (sim.timerId) { clearInterval(sim.timerId); sim.timerId = null; }
  simReadRows();
  const ex = findExam(sim.examId);
  const totals = simTotals();
  const subjects = {};
  Object.keys(sim.rows).forEach(s => {
    if (s === "__total__") return;
    subjects[s] = { correct: sim.rows[s].correct || 0, wrong: sim.rows[s].wrong || 0, unanswered: sim.rows[s].unanswered || 0 };
  });
  // A real (non-simulation) result already exists: never overwrite silently.
  // v1.11.45 (E-15): on decline, restart the interval with the
  // remaining time (sim.endsAt is still in the future for a manual
  // finish) — the old code returned with timerId null, overlay open,
  // clock frozen, no resume path.
  if (ex.result && !ex.result.simulated && !confirm(t("simOverwriteConfirm"))) {
    if (simTimeLeftSecs() > 0) sim.timerId = setInterval(simTick, 1000);
    return;
  }
  ex.result = {
    taraz: null, rank: null, rankTotal: null,
    correct: totals.correct, wrong: totals.wrong, unanswered: totals.unanswered,
    note: "", simulated: true
  };
  if (Object.keys(subjects).length) ex.result.subjects = subjects;
  if (examStatusOf(ex) === "upcoming") ex.status = "analyzed";
  stopSimSilent();
  saveState(); renderAll();
  showToast(t(auto ? "simTimeout" : "simSaved")); // v1.11.41: toast instead of the native alert
}

// ---------- Exam create/edit modal (incl. structured budget editor) ----------
let editingExamId = null;
let editingBudget = [];
function cleanBudget(budget) {
  return (budget || []).filter(s => s.subject && s.subject.trim()).map(s => ({
    subject: s.subject.trim(),
    questions: (s.questions === "" || s.questions == null) ? null : Math.max(0, parseInt(s.questions, 10) || 0),
    chapters: (s.chapters || []).filter(ch => (ch.name && ch.name.trim()) || (ch.topics || []).some(tp => tp.name && tp.name.trim())).map(ch => ({
      name: (ch.name || "").trim(),
      topics: (ch.topics || []).filter(tp => tp.name && tp.name.trim()).map(tp => {
        const out = {
          name: tp.name.trim(),
          questions: (tp.questions === "" || tp.questions == null) ? null : Math.max(0, parseInt(tp.questions, 10) || 0)
        };
        // Subtopics live on the topic: keep them through a modal edit, or
        // editing an exam in the modal would silently wipe them.
        const subs = (tp.subtopics || []).filter(s => s.name && s.name.trim()).map(s => ({
          id: s.id || newSubId(), name: s.name.trim(),
          questions: (s.questions === "" || s.questions == null) ? null : Math.max(0, parseInt(s.questions, 10) || 0),
          done: !!s.done
        }));
        if (subs.length) out.subtopics = subs;
        // Manual book links live on the topic too: keep them through a
        // modal edit (migrating the old single bookLink to the list).
        const links = topicLinks(tp);
        if (links.length) out.bookLinks = links.map(l => ({
          bookId: l.bookId || "", chapterId: l.chapterId || "",
          sectionId: l.sectionId
        }));
        return out;
      })
    }))
  })).filter(s => s.chapters.length);
}
function renderBudgetEditor() {
  const wrap = document.getElementById("xfBudget");
  wrap.innerHTML = "";
  editingBudget.forEach((s, si) => {
    const sDiv = document.createElement("div");
    sDiv.className = "be-subj";
    sDiv.innerHTML =
      '<div class="form-row"><input type="text" class="be-subject" list="budgetSubjectList" placeholder="' + esc(t("exBudgetSubjectPh")) + '" value="' + esc(s.subject || "") + '">' +
      '<input type="number" min="0" class="be-subj-q" placeholder="' + esc(t("exBudgetQuestions")) + '" value="' + (s.questions != null ? s.questions : "") + '">' +
      '<button class="btn be-del-subj" title="' + esc(t("delBtn")) + '">✕</button></div>' +
      '<div class="be-chapters"></div>' +
      '<button class="btn be-add-ch">' + t("exAddChapter") + '</button>';
    sDiv.querySelector(".be-subject").addEventListener("input", (e) => { s.subject = e.target.value; });
    sDiv.querySelector(".be-subj-q").addEventListener("input", (e) => { s.questions = e.target.value === "" ? null : e.target.value; });
    sDiv.querySelector(".be-del-subj").addEventListener("click", () => {
      // v1.11.63 (Batch 4, PR5): the budget editor's deletes were all
      // one click with no way back — same confirm + 5-second undo as
      // the subtopic delete above (in-memory restore, nothing saved
      // until the editor saves).
      if (!confirm(t("exBudgetDelConfirm", { name: s.subject || "—" }))) return;
      const removed = editingBudget.splice(si, 1)[0];
      renderBudgetEditor();
      showToast(t("exBudgetDeleted"), { ms: 5000, action: { label: t("undoBtn"), fn: () => {
        editingBudget.splice(Math.max(0, Math.min(si, editingBudget.length)), 0, removed);
        renderBudgetEditor();
      } } });
    });
    const chWrap = sDiv.querySelector(".be-chapters");
    (s.chapters || []).forEach((ch, ci) => {
      const cDiv = document.createElement("div");
      cDiv.className = "be-ch";
      cDiv.innerHTML =
        '<div class="form-row"><input type="text" class="be-ch-name" placeholder="' + esc(t("exBudgetChapterPh")) + '" value="' + esc(ch.name || "") + '">' +
        '<button class="btn be-del-ch" title="' + esc(t("delBtn")) + '">✕</button></div>' +
        '<div class="be-topics"></div>' +
        '<button class="btn be-add-topic">' + t("exAddTopic") + '</button>';
      cDiv.querySelector(".be-ch-name").addEventListener("input", (e) => { ch.name = e.target.value; });
      cDiv.querySelector(".be-del-ch").addEventListener("click", () => {
        // v1.11.63 (Batch 4, PR5): confirm + 5-second undo — see the
        // subject delete above.
        if (!confirm(t("exBudgetDelConfirm", { name: ch.name || "—" }))) return;
        const removed = s.chapters.splice(ci, 1)[0];
        renderBudgetEditor();
        showToast(t("exBudgetDeleted"), { ms: 5000, action: { label: t("undoBtn"), fn: () => {
          s.chapters.splice(Math.max(0, Math.min(ci, s.chapters.length)), 0, removed);
          renderBudgetEditor();
        } } });
      });
      const tpWrap = cDiv.querySelector(".be-topics");
      (ch.topics || []).forEach((tp, ti) => {
        const tRow = document.createElement("div");
        tRow.className = "form-row be-topic";
        tRow.innerHTML =
          '<input type="text" class="be-topic-name" placeholder="' + esc(t("exBudgetTopicPh")) + '" value="' + esc(tp.name || "") + '">' +
          '<input type="number" min="0" class="be-topic-q" placeholder="' + esc(t("exBudgetQuestions")) + '" value="' + (tp.questions != null ? tp.questions : "") + '">' +
          '<button class="btn be-del-topic" title="' + esc(t("delBtn")) + '">✕</button>';
        tRow.querySelector(".be-topic-name").addEventListener("input", (e) => { tp.name = e.target.value; });
        tRow.querySelector(".be-topic-q").addEventListener("input", (e) => { tp.questions = e.target.value === "" ? null : e.target.value; });
        tRow.querySelector(".be-del-topic").addEventListener("click", () => {
          // v1.11.63 (Batch 4, PR5): confirm + 5-second undo — see the
          // subject delete above.
          if (!confirm(t("exBudgetDelConfirm", { name: tp.name || "—" }))) return;
          const removed = ch.topics.splice(ti, 1)[0];
          renderBudgetEditor();
          showToast(t("exBudgetDeleted"), { ms: 5000, action: { label: t("undoBtn"), fn: () => {
            ch.topics.splice(Math.max(0, Math.min(ti, ch.topics.length)), 0, removed);
            renderBudgetEditor();
          } } });
        });
        tpWrap.appendChild(tRow);
      });
      cDiv.querySelector(".be-add-topic").addEventListener("click", () => {
        ch.topics.push({ name: "", questions: null }); renderBudgetEditor();
      });
      chWrap.appendChild(cDiv);
    });
    sDiv.querySelector(".be-add-ch").addEventListener("click", () => {
      s.chapters.push({ name: "", topics: [{ name: "", questions: null }] }); renderBudgetEditor();
    });
    wrap.appendChild(sDiv);
  });
  // datalist of known subjects for the subject inputs
  let dl = document.getElementById("budgetSubjectList");
  if (!dl) {
    dl = document.createElement("datalist");
    dl.id = "budgetSubjectList";
    document.body.appendChild(dl);
  }
  dl.innerHTML = ["حسابان", "هندسه", "گسسته و آمار", "فیزیک", "شیمی",
                  "ادبیات", "عربی", "دینی", "زبان انگلیسی"].map(s => "<option value=\"" + esc(s) + "\">").join("");
}
function fillExamModal(id, group) {
  editingExamId = id || null;
  const ex = id ? findExam(id) : null;
  const g = ex ? ex.group : (group || "maz");
  document.getElementById("examModalTitle").textContent = ex ? t("exEditExam") : t("exAddExam");
  // Only prefill the name when the user set one explicitly. Seed exams get
  // their display name COMPUTED (stage/subject), so it keeps translating
  // between FA/EN; storing the computed FA name would freeze it in Persian.
  document.getElementById("xfName").value = ex && ex.name ? ex.name : "";
  document.getElementById("xfName").placeholder = ex ? examDisplayName(ex) : t("exExamNamePh");
  document.getElementById("xfGroup").value = g;
  document.getElementById("xfType").value = ex ? ex.type : (g === "school" ? "school" : g === "zoodbist" ? "descriptive" : "topical");
  document.getElementById("xfStatus").value = ex ? examStatusOf(ex) : "upcoming";
  document.getElementById("xfDate").value = ex && ex.date ? jalaliInputText(ex.date) : "";
  document.getElementById("xfQuestions").value = ex && ex.questions != null ? ex.questions : "";
  // v1.11.33 (P2-6): exam duration in minutes — drives «سرعت لازم».
  document.getElementById("xfDuration").value = ex && ex.durationMin != null ? ex.durationMin : "";
  document.getElementById("xfFocus").value = ex ? (LANG === "fa" ? (ex.focusFa || "") : (ex.focusEn || ex.focusFa || "")) : "";
  document.getElementById("xfDelete").style.display = ex ? "" : "none";
  editingBudget = ex ? JSON.parse(JSON.stringify(ex.budget || [])) : [];
  renderBudgetEditor();
  document.getElementById("examModal").classList.add("open");
}
// User-initiated open: fill the form AND push a history entry (Back closes it).
function openExamModal(id, group) { fillExamModal(id, group); pushModalRoute({ kind: "exam", examId: id || undefined, group: group || undefined }); }
function hideExamModalUI() {
  document.getElementById("examModal").classList.remove("open");
  editingExamId = null;
  editingBudget = [];
}
function closeExamModal() {
  hideExamModalUI();
  closeModalHistory();
}
document.getElementById("examClose").addEventListener("click", closeExamModal);
document.getElementById("xfCancel").addEventListener("click", closeExamModal);
document.getElementById("examModal").addEventListener("click", (e) => {
  if (e.target.id === "examModal") closeExamModal();
});
document.getElementById("xfAddSubject").addEventListener("click", () => {
  editingBudget.push({ subject: "", questions: null, chapters: [{ name: "", topics: [{ name: "", questions: null }] }] });
  renderBudgetEditor();
});
document.getElementById("xfDelete").addEventListener("click", () => {
  if (!editingExamId) return;
  if (!confirm(t("exDeleteExamConfirm"))) return;
  const id = editingExamId;
  closeExamModal();
  deleteExamById(id);
});
document.getElementById("xfSave").addEventListener("click", () => {
  const name = document.getElementById("xfName").value.trim();
  const group = document.getElementById("xfGroup").value;
  const type = document.getElementById("xfType").value;
  const status = document.getElementById("xfStatus").value;
  // v1.11.41 (UI-audit batch 1): the exam date is a Jalali text input
  // now — parse it back to the stored Gregorian ISO. Empty means no
  // date (as before); an unparseable value stops the save.
  const dateRaw = document.getElementById("xfDate").value.trim();
  const date = dateRaw === "" ? null : parseJalaliInput(dateRaw);
  if (dateRaw !== "" && !date) { alert(t("jalaliInvalid")); return; }
  const qv = document.getElementById("xfQuestions").value.trim();
  const questions = qv === "" ? null : Math.max(0, parseInt(qv, 10) || 0);
  // v1.11.33 (P2-6): exam duration in minutes (null when blank).
  const dv = document.getElementById("xfDuration").value.trim();
  const durationMin = dv === "" ? null : Math.max(0, parseInt(dv, 10) || 0);
  const focus = document.getElementById("xfFocus").value.trim();
  const budget = cleanBudget(editingBudget);
  let savedId = editingExamId;
  if (editingExamId) {
    const ex = findExam(editingExamId);
    if (ex) {
      if (ex.group !== group) {
        state.exams[ex.group] = (state.exams[ex.group] || []).filter(x => x.id !== ex.id);
        ex.group = group;
        state.exams[group].push(ex);
      }
      // Keep name null for seed exams so the display name stays computed
      // (and therefore translatable); only an explicit user name is stored.
      // Focus is per-language: save only the language being edited, or
      // an English edit would overwrite the Persian focus (and vice versa).
      const focusPatch = LANG === "fa" ? { focusFa: focus } : { focusEn: focus };
      Object.assign(ex, { name: name || null, type, status, date, questions,
                          durationMin, budget }, focusPatch);
      examGroup = group;
    }
  } else {
    const id = group + "-" + Date.now();
    const ex = { id, group, name: name || (t(examGroupKey(group)) + " — " + (date || t("exNoDate"))),
                 stage: null, subject: null, date, jalaliFa: null, jalaliEn: null,
                 type, questions, durationMin, status,
                 focusFa: LANG === "fa" ? focus : "", focusEn: LANG === "en" ? focus : "",
                 budget, result: null };
    state.exams[group].push(ex);
    examGroup = group;
    examView = "list";
    selectedExamId = ex.id;
    savedId = id;
  }
  saveState(); hideExamModalUI(); dismissModalEntry();
  navigate({ tab: "exams", examGroup: group, examView: "list", examId: savedId });
  showToast(t("exExamSaved")); // v1.11.41: toast instead of the native alert
});

// ---------- History routing (mouse side buttons + browser Back/Forward) ----------
// Every view is a route: {tab, examGroup, examView, examId, bookId, day, modal, scroll}.
// The route lives in the URL hash (#/exams/maz/maz-5) so a reload restores the
// view; the full route object (incl. the scroll target) lives in history.state.
// Back/Forward — mouse side buttons, Alt+Left/Right, browser buttons — fire
// popstate; we apply the stored route without touching history again.
// User-initiated navigation goes through navigate(): it pushes ONE entry per
// action and never pushes a duplicate of the current route. Modals get their
// own entry too, so Back closes the modal (same as Cancel — drafts are only
// committed on Save, and the exam modal edits a clone, so nothing saved is
// ever lost by going back).
const TABS = ["dashboard", "today", "program", "assignments", "testbook", "remaining", "exams", "calendar", "settings", "analytics"]; // v1.11.57 (IA): 12 -> 10 — "gemini" lives inside Analytics, "backup" inside Settings
let currentTab = "dashboard";
let currentRoute = null;
let modalPushed = false; // true only when WE pushed the modal's history entry
function normalizeRoute(r) {
  // v1.11.57 (IA): the Gemini and Backup tabs merged away — an old
  // #/gemini or #/backup hash (or a pre-merge history entry) lands on
  // the surviving tab, scrolled to the merged section, not the dashboard.
  if (r && r.tab === "gemini") return { tab: "analytics", scroll: { type: "section", id: "anGeminiTitle" } };
  if (r && r.tab === "backup") return { tab: "settings", scroll: { type: "section", id: "setBackupTitle" } };
  const out = { tab: (r && TABS.includes(r.tab)) ? r.tab : "dashboard" };
  if (out.tab === "exams") {
    out.examGroup = ["maz", "zoodbist", "school"].includes(r.examGroup) ? r.examGroup : examGroup;
    out.examView = r.examView === "list" ? "list" : "cats";
    out.examId = out.examView === "list" ? (r.examId || null) : null;
  }
  if (out.tab === "testbook") out.bookId = r.bookId || null;
  if (out.tab === "program") out.day = clampDay((typeof r.day === "string" && /^\d{4}-\d{2}-\d{2}$/.test(r.day)) ? r.day : selectedDay);
  if (r.modal) out.modal = r.modal; // {kind:"edit"|"exam"|"stats", boxId?, examId?, group?}
  if (r.scroll) out.scroll = r.scroll; // {type:"exam"|"topic", id} — history.state only, never in the hash
  return out;
}
function routeForTab(tab) {
  const base = { tab };
  if (tab === "exams") { base.examGroup = examGroup; base.examView = examView; base.examId = examView === "list" ? selectedExamId : null; }
  if (tab === "testbook") base.bookId = openBookId;
  if (tab === "program") base.day = selectedDay;
  return base;
}
function routeEquals(a, b) {
  if (!a || !b) return a === b;
  const keys = ["tab", "examGroup", "examView", "examId", "bookId", "day"];
  if (!keys.every(k => (a[k] || null) === (b[k] || null))) return false;
  const am = a.modal, bm = b.modal;
  if (!am && !bm) return true;
  if (!am || !bm) return false;
  return am.kind === bm.kind && (am.boxId || null) === (bm.boxId || null) &&
    (am.examId || null) === (bm.examId || null) && (am.group || null) === (bm.group || null);
}
function routeToHash(r) {
  let h = "#/" + r.tab;
  if (r.tab === "program" && r.day) h += "/" + r.day;
  if (r.tab === "testbook" && r.bookId) h += "/" + encodeURIComponent(r.bookId);
  if (r.tab === "exams" && r.examView === "list") {
    h += "/" + r.examGroup;
    if (r.examId) h += "/" + encodeURIComponent(r.examId);
  }
  if (r.modal) {
    const q = ["modal=" + r.modal.kind];
    if (r.modal.boxId) q.push("box=" + encodeURIComponent(r.modal.boxId));
    if (r.modal.examId) q.push("exam=" + encodeURIComponent(r.modal.examId));
    if (r.modal.group) q.push("group=" + r.modal.group);
    h += "?" + q.join("&");
  }
  return h;
}
function hashToRoute() {
  const raw = (location.hash || "").replace(/^#\/?/, "");
  if (!raw) return { tab: "dashboard" };
  const parts = raw.split("?");
  const seg = parts[0].split("/").filter(Boolean).map(s => { try { return decodeURIComponent(s); } catch (e) { return s; } });
  // v1.11.57 (IA): the raw first segment passes through — normalizeRoute
  // maps an unknown tab to the dashboard and the merged-away gemini /
  // backup tabs to their surviving sections (an old #/gemini bookmark
  // must not silently become the dashboard here).
  const r = { tab: seg[0] || "dashboard" };
  if (r.tab === "program" && seg[1] && /^\d{4}-\d{2}-\d{2}$/.test(seg[1])) r.day = seg[1];
  if (r.tab === "testbook" && seg[1]) r.bookId = seg[1];
  if (r.tab === "exams" && seg[1] && ["maz", "zoodbist", "school"].includes(seg[1])) {
    r.examGroup = seg[1]; r.examView = "list";
    if (seg[2]) r.examId = seg[2];
  }
  if (parts[1]) {
    const p = new URLSearchParams(parts[1]);
    if (p.get("modal")) r.modal = { kind: p.get("modal"), boxId: p.get("box") || undefined,
      examId: p.get("exam") || undefined, group: p.get("group") || undefined };
  }
  return r;
}
function hideAllModalsUI() {
  ["editModal", "examModal", "statsModal", "shortcutsModal"].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.remove("open");
  });
}
// UI-only modal open (no history write) — used when a route carrying a modal
// is applied (Back/Forward into it, or a reload on a modal hash).
function showModalUI(m) {
  if (!m) return;
  if (m.kind === "edit" && m.boxId) {
    const b = allBoxes().find(x => x.id === m.boxId);
    if (b) fillEditBox(b);
  } else if (m.kind === "exam") {
    fillExamModal(m.examId || null, m.group);
  } else if (m.kind === "stats") {
    renderSubjectStats();
    document.getElementById("statsModal").classList.add("open");
  }
}
// Apply a route: set section state, switch tab, render, open/close modals,
// scroll to a target. Never touches history — popstate and navigate() own that.
function applyRoute(r) {
  r = normalizeRoute(r);
  // v1.11.38 (P3-8): a running simulation locks the app — leaving
  // mid-run asks first and saves nothing. navigate() pushes history
  // first, and Back/hashchange arrive here directly, so the guard
  // runs here, before the route changes. Declining repairs the URL
  // back to the current route (replaceState, no new history entry).
  if (sim && sim.timerId && r.tab && currentRoute && r.tab !== currentRoute.tab) {
    if (!confirm(t("simExitConfirm"))) {
      history.replaceState({ route: currentRoute }, "", routeToHash(currentRoute));
      return;
    }
    stopSimSilent();
  }
  // v1.11.72 (Batch 5, R2): a tab change drops the «next box» pointer
  // (a fresh tick sets a new one); modal-only route changes keep it.
  if (r.tab && currentRoute && r.tab !== currentRoute.tab) PENDING_NEXT_FOCUS = null;
  modalPushed = !!(r.modal && applyRoute._fromState);
  currentRoute = r;
  currentTab = r.tab;
  if (r.tab === "exams") { examGroup = r.examGroup; examView = r.examView; selectedExamId = r.examId; }
  if (r.tab === "testbook") openBookId = r.bookId;
  if (r.tab === "program" && r.day) selectedDay = r.day;
  hideAllModalsUI();
  switchTab(r.tab);
  renderAll();
  if (r.modal) showModalUI(r.modal);
  if (r.scroll) {
    // v1.11.57 (IA): "section" scrolls to a merged section's heading
    // (Gemini inside Analytics, Backup inside Settings) and opens its
    // collapsible Analytics wrapper first, like the index links do.
    const id = r.scroll.type === "exam" ? "exam-card-" + r.scroll.id
      : r.scroll.type === "section" ? r.scroll.id : "topic-row-" + r.scroll.id;
    setTimeout(() => {
      const el = document.getElementById(id);
      if (!el) return;
      const det = el.closest("details.an-sec");
      if (det) det.open = true;
      el.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 80);
  }
}
function navigate(partial) {
  // An edit/exam modal with an open draft: navigating away discards
  // it (drafts are only committed on Save), so confirm first. Back
  // bypasses navigate() — its drafts are only committed on Save too.
  const modalOpen = document.querySelector(".modal-back.open");
  if (modalOpen && (editingBoxId || editingExamId)) {
    if (!confirm(t("navDiscardDraft"))) return;
  }
  const r = normalizeRoute(Object.assign({}, routeForTab(partial.tab || (currentRoute && currentRoute.tab) || "dashboard"), partial));
  // A modal is open: drop its history entry first (replace, not back) so
  // Back never resurrects a modal the user already left.
  if (currentRoute && currentRoute.modal) {
    const base = Object.assign({}, currentRoute); delete base.modal;
    hideAllModalsUI();
    history.replaceState({ route: base }, "", routeToHash(base));
    currentRoute = base;
    modalPushed = false;
  }
  if (routeEquals(r, currentRoute)) { applyRoute(r); return; }
  history.pushState({ route: r }, "", routeToHash(r));
  applyRoute(r);
}
// Push a history entry for an opened modal (Back closes it, Forward reopens).
function pushModalRoute(modal) {
  if (!currentRoute) return;
  const r = Object.assign({}, currentRoute, { modal });
  if (routeEquals(r, currentRoute)) return;
  history.pushState({ route: r }, "", routeToHash(r));
  currentRoute = r;
  modalPushed = true;
}
// Replace the modal entry with its base route (used after Save: no Back step).
function dismissModalEntry() {
  if (currentRoute && currentRoute.modal) {
    const base = Object.assign({}, currentRoute); delete base.modal;
    history.replaceState({ route: base }, "", routeToHash(base));
    currentRoute = base;
  }
  modalPushed = false;
  hideAllModalsUI();
}
// User-initiated modal close (Cancel / X / backdrop): step back if we pushed
// the modal entry; otherwise just replace it away (fresh load on a modal hash
// must never navigate the user out of the app).
function closeModalHistory() {
  if (currentRoute && currentRoute.modal && modalPushed) {
    modalPushed = false;
    history.back();
  } else {
    dismissModalEntry();
  }
}
window.addEventListener("popstate", (e) => {
  const st = e.state;
  const r = (st && st.route) ? st.route : hashToRoute();
  applyRoute._fromState = !!(st && st.route);
  try { applyRoute(r); } finally { applyRoute._fromState = false; }
});
window.addEventListener("hashchange", () => {
  const r = hashToRoute();
  if (!routeEquals(normalizeRoute(r), currentRoute)) applyRoute(r);
});
function initRouting() {
  const r = normalizeRoute(hashToRoute());
  history.replaceState({ route: r }, "", routeToHash(r));
  applyRoute(r);
}

// ---- Tabs / theme / reset ----
function switchTab(name) {
  currentTab = name;
  // v1.11.42 (item 18): the active tab also carries aria-current so a
  // keyboard/screen-reader user knows where they are, not just a sighted one.
  document.querySelectorAll(".tab").forEach(t => {
    const on = t.dataset.tab === name;
    t.classList.toggle("active", on);
    if (on) t.setAttribute("aria-current", "page");
    else t.removeAttribute("aria-current");
  });
  ["dashboard", "today", "program", "assignments", "testbook", "remaining", "exams", "calendar", "settings", "analytics"].forEach(n => {
    const el = document.getElementById("tab-" + n);
    if (el) el.hidden = (n !== name);
  });
  if (name === "analytics") gmTestInitOnce(); // v1.11.57 (IA): the Gemini section lives here now — lazy model-list fetch (m10)
}
document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => navigate({ tab: tab.dataset.tab }));
});
// Theme (v1.11.19, audit §5 item 2.9): one helper for the topbar
// toggle AND the Settings tab buttons — same state, same attribute.
function setThemeMode(mode) {
  state.theme = mode === "light" ? "light" : "dark";
  document.documentElement.setAttribute("data-theme", state.theme);
  saveState();
  const td = document.getElementById("setThemeDark");
  const tl = document.getElementById("setThemeLight");
  if (td) td.classList.toggle("btn-primary", state.theme === "dark");
  if (tl) tl.classList.toggle("btn-primary", state.theme !== "dark");
}
document.getElementById("themeBtn").addEventListener("click", () => {
  setThemeMode(state.theme === "dark" ? "light" : "dark");
});
wireOnce(document.getElementById("setThemeDark"), () => setThemeMode("dark"));
wireOnce(document.getElementById("setThemeLight"), () => setThemeMode("light"));
wireOnce(document.getElementById("setLangFa"), () => applyLang("fa", true));
wireOnce(document.getElementById("setLangEn"), () => applyLang("en", true));
document.getElementById("resetBtn").addEventListener("click", async () => {
  if (!confirm(t("confirmReset"))) return;
  if (!stateLoaded) { alert(t("saveFailedServer")); return; } // never POST empty defaults
  // The dialog promises test-book totals are NOT deleted, so TESTBOOK
  // is kept. v1.11.45 (E-02): exams are wiped but examsSeededIds is
  // left EMPTY — the seeds re-seed on reload like a fresh install.
  // Marking every seed id as seeded (the old code) emptied the Exams
  // tab forever: ensureExams() skips seeded ids, so all 35 seed exams
  // (and the Dey wizard / reverse planner / exam-day card) were gone.
  state = { done: {}, tests: {}, tests_total: {}, subjects: state.subjects, theme: state.theme, lang: state.lang,
            custom_boxes: [], deleted: [], edits: {}, daysDone: {}, topicLinks: {},
            examResults: {},
            exams: null, examsRemoved: [], examsSeededIds: [],
            assignments: null, assignmentsRemoved: [],
            boxBookLinks: {},
            dailyGoal: { kind: "useful", minutes: 480 },
            actualMinutes: {}, timerSessions: [], activeTimer: null };
  // Save synchronously BEFORE the reload, or the debounced save never
  // fires and the old state comes back; the reload re-runs loadAll(),
  // which rebuilds the assignments from the (kept) programme.
  try {
    await fetch("/api/state", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(state) });
  } catch (e) {}
  location.reload();
});

// ---- Gemini tab (server-side key) ----
async function refreshKeyStatus() {
  // v1.11.65 (Batch 6, L-PERF3): shared getter, cached + deduped.
  const j = await getGeminiKeyStatus();
  if (!j) {
    document.getElementById("keyStatus").textContent = t("keyServerDown");
    return;
  }
  document.getElementById("keyStatus").textContent = j.has_key
    ? t("keySavedStatus") // v1.11.28 (QA BUG-046): the endpoint returns only a boolean now
    : t("keyNotEntered");
}
document.getElementById("saveKeyBtn").addEventListener("click", async () => {
  const key = document.getElementById("geminiKeyInput").value.trim();
  if (!key) { alert(t("keyEmpty")); return; }
  const res = await fetch("/api/gemini-key", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ key })
  });
  if (res.ok) {
    invalidateGeminiKeyStatus(); // v1.11.65 (Batch 6, L-PERF3): the saved key must be re-read fresh
    document.getElementById("geminiKeyInput").value = "";
    refreshKeyStatus();
    showToast(t("keySavedMsg")); // v1.11.41: toast instead of the native alert
  } else {
    alert(t("keySaveFailed"));
  }
});
// ---- v1.11.64 (Batch 5, م-۸): Telegram settings + weekly-report send ----
// The bot token lives server-side only (telegram_token.txt, like the
// Gemini key — never sent to the browser); the chat id is a plain
// number in state.telegramChatId. The weekly report's «ارسال به
// تلگرام» button sends ONLY that report, ONLY on click, and opens
// this Settings section when either value is missing.
async function refreshTelegramStatus() {
  const el = document.getElementById("tgStatus");
  if (!el) return;
  const ci = document.getElementById("tgChatIdInput");
  if (ci && !ci.value) ci.value = state.telegramChatId || "";
  try {
    const res = await fetch("/api/telegram-status");
    const j = await res.json();
    el.textContent = (j.has_token && j.has_chat_id) ? t("tgStatusSet") : t("tgStatusMissing");
  } catch (e) {
    el.textContent = t("tgStatusMissing");
  }
}
document.getElementById("tgSaveBtn").addEventListener("click", async () => {
  const token = document.getElementById("tgTokenInput").value.trim();
  const chatId = document.getElementById("tgChatIdInput").value.trim();
  if (!token || !chatId) { alert(t("tgEmpty")); return; }
  const res = await fetch("/api/telegram-token", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ token, chat_id: chatId })
  });
  if (res.ok) {
    document.getElementById("tgTokenInput").value = "";
    state.telegramChatId = chatId.replace(/[^0-9-]/g, "").slice(0, 20);
    saveState();
    refreshTelegramStatus();
    showToast(t("tgSaved"));
  } else {
    alert(t("saveFailed"));
  }
});
// Sends the weekly report text (5-8 lines, built by weeklyReportText
// in analytics.js) to the user's Telegram via the bot. Only ever
// called from the report card's button — never automatic, and only
// this report, nothing else.
async function sendWeeklyReportToTelegram() {
  const text = (typeof weeklyReportText === "function") ? weeklyReportText() : null;
  if (!text) return;
  let st = null;
  try { st = await (await fetch("/api/telegram-status")).json(); } catch (e) {}
  if (!st || !st.has_token || !st.has_chat_id) {
    showToast(t("wrTgSetup"), { kind: "err" });
    navigate({ tab: "settings" });
    setTimeout(() => { const el = document.getElementById("tgSettingsCard"); if (el) el.scrollIntoView({ behavior: "smooth", block: "start" }); }, 80);
    return;
  }
  try {
    const res = await fetch("/api/telegram-send", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text })
    });
    let j = {};
    try { j = await res.json(); } catch (e) {}
    if (res.ok && j.ok) showToast(t("wrTgSent"));
    else showToast(t("wrTgFailed") + (j.error ? ": " + j.error : ""), { kind: "err" });
  } catch (e) {
    showToast(t("wrTgFailed"), { kind: "err" });
  }
}
// ---- Gemini model picker (server-side selection, default gemini-2.5-flash) ----
// The model is stored on the server (gemini_model.txt) and used by /api/gemini,
// so the analysis button always uses the model shown here. The list button
// asks Google which models THIS key can use — the diagnostic for a 404.
const KNOWN_GEMINI_MODELS = ["gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash",
  "gemini-2.0-flash-lite", "gemini-1.5-pro", "gemini-1.5-flash"];
const CUSTOM_MODEL_VALUE = "__custom__";
function geminiModelChosen() {
  const sel = document.getElementById("geminiModelSelect");
  const custom = document.getElementById("geminiModelCustom");
  if (sel && sel.value === CUSTOM_MODEL_VALUE) return (custom ? custom.value : "").trim();
  return sel ? sel.value : "";
}
function syncModelCustomVisibility() {
  const sel = document.getElementById("geminiModelSelect");
  const custom = document.getElementById("geminiModelCustom");
  if (sel && custom) custom.style.display = sel.value === CUSTOM_MODEL_VALUE ? "" : "none";
}
async function refreshGeminiModel() {
  const sel = document.getElementById("geminiModelSelect");
  const status = document.getElementById("geminiModelStatus");
  if (!sel) return;
  sel.innerHTML = KNOWN_GEMINI_MODELS.map(m =>
    '<option value="' + m + '">' + m + '</option>').join("") +
    '<option value="' + CUSTOM_MODEL_VALUE + '">' + esc(t("gmModelCustomOpt")) + '</option>';
  // v1.11.65 (Batch 6, L-PERF3): shared getter, cached + deduped.
  const j = await getGeminiModel();
  if (!j) {
    if (status) status.textContent = t("keyServerDown");
  } else {
    const model = j.model || KNOWN_GEMINI_MODELS[0];
    gmCurrentModel = model;
    if (KNOWN_GEMINI_MODELS.indexOf(model) >= 0) {
      sel.value = model;
      document.getElementById("geminiModelCustom").value = "";
    } else {
      sel.value = CUSTOM_MODEL_VALUE;
      document.getElementById("geminiModelCustom").value = model;
    }
    if (status) status.textContent = t("gmModelCurrent", { model });
  }
  syncModelCustomVisibility();
}
async function saveGeminiModel(model) {
  const status = document.getElementById("geminiModelStatus");
  const res = await fetch("/api/gemini-model", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model })
  });
  if (res.ok) {
    invalidateGeminiModel(); // v1.11.65 (Batch 6, L-PERF3): the saved model must be re-read fresh
    const j = await res.json();
    if (status) status.textContent = t("gmModelSaved", { model: j.model });
    return true;
  }
  if (status) status.textContent = t("gmModelInvalid");
  return false;
}
document.getElementById("geminiModelSelect").addEventListener("change", syncModelCustomVisibility);
// v1.11.64 (Batch 5, L-UI2): the model selection auto-saves on change
// (the save button next to it stays as an explicit alternative and
// calls the same path). Changing the select used to do nothing until
// «ذخیره مدل» was pressed, with no hint that it had not saved.
document.getElementById("geminiModelSelect").addEventListener("change", async () => {
  const model = geminiModelChosen();
  if (!model) return; // empty custom name: leave the stored model alone
  if (await saveGeminiModel(model)) refreshGeminiModel();
});
document.getElementById("geminiModelSaveBtn").addEventListener("click", async () => {
  const model = geminiModelChosen();
  if (!model) { alert(t("gmModelInvalid")); return; }
  if (await saveGeminiModel(model)) refreshGeminiModel();
});
// v1.11.66 (Batch 7, Group 13 item 4): the key lives in Settings, the
// model lab lives here — «مدیریت کلید» jumps to the key section in
// Settings instead of moving the lab.
document.getElementById("gmKeyLinkBtn").addEventListener("click", () => {
  navigate({ tab: "settings", scroll: { type: "section", id: "setGeminiKeyTitle" } });
});
document.getElementById("geminiListModelsBtn").addEventListener("click", async () => {
  const list = document.getElementById("geminiModelsList");
  list.innerHTML = '<p class="muted">' + esc(t("gmModelsLoading")) + '</p>';
  try {
    const res = await fetch("/api/gemini-models");
    const j = await res.json();
    if (!res.ok) {
      const msg = (j.error && j.error.indexOf("معتبر نیست") !== -1) ? t("keyInvalid") : (errText(j.error) || t("gmModelsFailed"));
      list.innerHTML = '<p class="muted"><span class="error">' + esc(msg) + '</span></p>';
      return;
    }
    const models = j.models || [];
    if (!models.length) {
      list.innerHTML = '<p class="muted">' + esc(t("gmModelsNone")) + '</p>';
      return;
    }
    list.innerHTML = '<p class="muted">' + esc(t("gmModelsAvailable")) + '</p>' +
      '<div class="gm-model-chips">' + models.map(m => {
        // /api/gemini-models returns full metadata objects (older shape: plain strings).
        const id = (typeof m === "string") ? m : (m.id || "");
        return '<button class="btn gm-model-chip" data-model="' + esc(id) + '">' + esc(id) + '</button>';
      }).join("") + '</div>';
    list.querySelectorAll(".gm-model-chip").forEach(btn => btn.addEventListener("click", async () => {
      const model = btn.dataset.model;
      if (await saveGeminiModel(model)) refreshGeminiModel();
    }));
  } catch (e) {
    list.innerHTML = '<p class="muted"><span class="error">' + esc(t("serverUnreachable")) + '</span></p>';
  }
});
// ---- Gemini model test panel (v1.6.0) ----
// Discovers the REAL usable models from /api/gemini-models (the live API
// list — new models Google adds appear automatically; nothing here is the
// source of truth), tests each with ONE tiny cheap request via
// POST /api/gemini-test, and compares them. Official capability info comes
// from Google's documentation (ai.google.dev/gemini-api/docs/models, read
// 2026-11-24); a capability is "high" only where the docs state it outright
// — anything else renders as «نامشخص». Tests NEVER change the default
// selected model (gemini_model.txt). Results persist in localStorage.
const GM_TEST_STORE_KEY = "konkur-gm-test-v1";
// Knowledge base keyed by exact model id. use/limits are short bilingual
// descriptions translated from Google's docs; qualitative ratings are
// "high" or null (null = unverified = «نامشخص»). status follows the docs:
// 2.5-flash/pro deprecated, 2.0-flash/flash-lite shut down.
const GM_MODEL_INFO = {
  "gemini-4-carbon": { status: "stable", use: { fa: "قوی‌ترین مدل استدلالی — مهندسی نرم‌افزار پیچیده، کار دانشی چندرسانه‌ای، استدلال علمی و امنیت سایبری", en: "Strongest reasoning model — complex software engineering, multimodal knowledge work, scientific reasoning, cybersecurity defense" }, reasoning: "high", coding: "high", vision: "high", multimodal: "high", speed: null, limits: { fa: "حداکثر خروجی ۶۴ هزار توکن / ۱ میلیون توکن", en: "Max output 64K / 1M tokens" }, tags: ["reasoning", "coding", "research", "fileImage", "exam"] },
  "gemini-4-neon": { status: "stable", use: { fa: "هوش در سطح مرز دانش با انجام سریع کارهای پیچیده — مهندسی نرم‌افزار، کار دانشی و علمی", en: "Frontier-level intelligence with fast end-to-end task completion — complex software engineering, knowledge work, science" }, reasoning: "high", coding: "high", vision: null, multimodal: null, speed: "high", limits: { fa: "حداکثر خروجی ۶۴ هزار توکن / ۱ میلیون توکن", en: "Max output 64K / 1M tokens" }, tags: ["reasoning", "coding", "research", "fast", "exam"] },
  "gemini-4-hydrogen": { status: "stable", use: { fa: "هوش پیشرفته برای همه — سریع و کم‌مصرف برای کدنویسی روزمره و کارهای عاملی", en: "Cutting-edge intelligence for everyone — speed and efficiency for everyday coding and agentic workflows" }, reasoning: null, coding: "high", vision: null, multimodal: null, speed: "high", limits: { fa: "حداکثر خروجی ۶۴ هزار توکن / ۱ میلیون توکن", en: "Max output 64K / 1M tokens" }, tags: ["coding", "fast", "teaching"] },
  "gemini-4-argon": { status: "stable", use: { fa: "مدل استدلالی بهینه — پاسخ سریع‌تر و مصرف توکن کمتر در کدنویسی، ریاضی و علوم", en: "Efficient frontier reasoning model — faster responses, lower token spend than Carbon, for complex coding, agentic, math, science" }, reasoning: "high", coding: "high", vision: null, multimodal: null, speed: "high", limits: { fa: "حداکثر خروجی ۶۴ هزار توکن / ۱ میلیون توکن", en: "Max output 64K / 1M tokens" }, tags: ["reasoning", "coding", "research", "exam"] },
  "gemini-3.8-flash": { status: "stable", use: { fa: "مدل Flash نسل قبل برای مهندسی نرم‌افزار، عامل‌های خودگردان و کارهای سازمانی پیچیده", en: "Previous-generation Flash model for software engineering, autonomous agents, complex enterprise workflows" }, reasoning: null, coding: "high", vision: null, multimodal: null, speed: null, limits: null, tags: ["coding", "research", "exam"] },
  "gemini-3.6-flash": { status: "stable", use: { fa: "مدل Flash نسل قبل — تعادل سرعت و چندرسانه‌ای برای کارهای عاملی و روزمره", en: "Previous-generation Flash model balancing speed and multimodal capabilities across general agentic and everyday tasks" }, reasoning: null, coding: null, vision: null, multimodal: "high", speed: "high", limits: null, tags: ["fast", "fileImage", "teaching"] },
  "gemini-3.5-flash-lite": { status: "stable", use: { fa: "سریع‌ترین و اقتصادی‌ترین مدل 3.5 برای اجرای پرحجم", en: "Fastest, most cost-effective 3.5 model for high-throughput execution" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: "high", limits: null, tags: ["fast"] },
  "gemini-3.1-flash-lite": { status: "stable", use: { fa: "عملکرد در سطح مرز دانش با کسری از هزینه", en: "Frontier-class performance rivaling larger models at a fraction of the cost" }, reasoning: "high", coding: null, vision: null, multimodal: null, speed: "high", limits: null, tags: ["fast", "reasoning", "exam"] },
  "gemini-3-flash-preview": { status: "preview", use: { fa: "عملکرد در سطح مرز دانش با کسری از هزینه (پیش‌نمایش)", en: "Frontier-class performance rivaling larger models at a fraction of the cost (preview)" }, reasoning: "high", coding: null, vision: null, multimodal: null, speed: "high", limits: null, tags: ["fast", "reasoning", "exam"] },
  "gemini-3.1-pro-preview": { status: "preview", use: null, reasoning: null, coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: [] },
  "gemini-2.5-pro": { status: "deprecated", use: { fa: "پیشرفته‌ترین مدل خانواده‌ی 2.5 برای کارهای پیچیده — استدلال عمیق و کدنویسی. منسوخ شده؛ از ۱ دسامبر ۲۰۲۶ به gemini-3.8-flash هدایت می‌شود", en: "Most advanced model for complex tasks in the 2.5 family — deep reasoning and coding. Deprecated; routes to gemini-3.8-flash from 1 Dec 2026" }, reasoning: "high", coding: "high", vision: null, multimodal: null, speed: null, limits: null, tags: ["reasoning", "coding", "research", "exam"] },
  "gemini-2.5-flash": { status: "deprecated", use: { fa: "بهترین نسبت قیمت به عملکرد برای کارهای پرحجم کم‌تأخیر که استدلال می‌خواهند. منسوخ شده؛ از ۱ دسامبر ۲۰۲۶ به gemini-3.5-flash-lite هدایت می‌شود", en: "Best price-performance model for low-latency, high-volume tasks that require reasoning. Deprecated; routes to gemini-3.5-flash-lite from 1 Dec 2026" }, reasoning: "high", coding: null, vision: null, multimodal: null, speed: "high", limits: null, tags: ["reasoning", "fast", "exam"] },
  "gemini-2.5-flash-lite": { status: "stable", use: { fa: "سریع‌ترین و اقتصادی‌ترین مدل چندرسانه‌ای خانواده‌ی 2.5", en: "Fastest and most budget-friendly multimodal model in the 2.5 family" }, reasoning: null, coding: null, vision: null, multimodal: "high", speed: "high", limits: null, tags: ["fast", "fileImage"] },
  "gemini-2.0-flash": { status: "shutdown", use: { fa: "مدل کارآمد نسل دوم — سرعت بالا، ابزار بومی و پنجره‌ی ۱ میلیون توکنی. خاموش شده است", en: "Second-generation workhorse model — superior speed, native tool use, 1M token context. Shut down" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: "high", limits: null, tags: ["fast"] },
  "gemini-2.0-flash-lite": { status: "shutdown", use: { fa: "سریع‌ترین مدل نسل دوم، بهینه برای هزینه و تأخیر کم. خاموش شده است", en: "Fastest second-generation model, optimized for cost efficiency and low latency. Shut down" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: "high", limits: null, tags: ["fast"] },
  "gemini-1.5-pro": { status: "unknown", use: null, reasoning: null, coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: [] },
  "gemini-1.5-flash": { status: "unknown", use: null, reasoning: null, coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: [] },
  "gemini-nano-banana-2.1": { status: "stable", use: { fa: "تولید و ویرایش تصویر با کیفیت بصری بهتر، تایپوگرافی و سازگاری چندمرحله‌ای", en: "High-efficiency image generation and editing with improved visual quality, typography, multi-turn consistency" }, reasoning: null, coding: null, vision: "high", multimodal: null, speed: null, limits: null, tags: ["fileImage"] },
  "gemini-3.1-flash-image": { status: "stable", use: { fa: "خلق بصری در مقیاس تولید با هوش سری 3 و سرعت بالا", en: "High-efficiency production-scale visual creation, combining Gemini 3 intelligence with fast generation speeds" }, reasoning: null, coding: null, vision: "high", multimodal: null, speed: null, limits: null, tags: ["fileImage"] },
  "gemini-3.1-flash-lite-image": { status: "stable", use: { fa: "سریع‌ترین و ارزان‌ترین مدل تصویر جمینای برای سرعت و مقیاس", en: "Fastest and cheapest Gemini image model, engineered for velocity and scale" }, reasoning: null, coding: null, vision: "high", multimodal: null, speed: "high", limits: null, tags: ["fileImage"] },
  "gemini-3-pro-image": { status: "stable", use: { fa: "موتور طراحی حرفه‌ای با هسته‌ی استدلالی برای تصاویر 4K استودیویی", en: "Professional design engine with a reasoning core for studio-quality 4K visuals" }, reasoning: null, coding: null, vision: "high", multimodal: null, speed: null, limits: null, tags: ["fileImage"] },
  "gemini-2.5-flash-image": { status: "stable", use: { fa: "تولید و ویرایش بومی تصویر پیشرفته برای کارهای خلاقانه‌ی سریع", en: "State-of-the-art native image generation and editing for fast, creative workflows" }, reasoning: null, coding: null, vision: "high", multimodal: null, speed: null, limits: null, tags: ["fileImage"] },
  "gemini-3.8-flash-tts": { status: "stable", use: { fa: "مدل تبدیل متن به گفتار پیشرو برای کیفیت استودیویی و بازیگری رسا", en: "Flagship creative text-to-speech model for studio-grade voice fidelity, expressive acting" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: [] },
  "gemini-3.8-flash-lite-tts": { status: "stable", use: { fa: "تبدیل متن به گفتار سریع و اقتصادی برای تولید پرحجم", en: "Fast, cost-efficient text-to-speech model for high-throughput production" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: "high", limits: null, tags: [] },
  "gemini-3.8-live": { status: "stable", use: { fa: "گزینه‌ی پیش‌فرض برای تجربه‌های صوتی کم‌تأخیر بدون تأخیر استدلال", en: "Default Live API model for most low-latency voice agent experiences without reasoning delays" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: "high", limits: null, tags: [] },
  "gemini-3.8-live-extended-thinking": { status: "stable", use: { fa: "مدل صوتی با استدلال بالا برای گفت‌وگوی زنده", en: "High-reasoning Live API model for voice interactions when higher background reasoning is required" }, reasoning: "high", coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: ["reasoning"] },
  "gemini-2.5-flash-preview-tts": { status: "stable", use: { fa: "تبدیل متن به گفتار سریع و قابل‌کنترل برای دستیارهای بلادرنگ", en: "Fast and controllable text-to-speech for low-latency, cost-efficient applications" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: "high", limits: null, tags: [] },
  "gemini-2.5-pro-preview-tts": { status: "stable", use: { fa: "سنتز گفتار باکیفیت برای پادکست و کتاب صوتی", en: "High-fidelity speech synthesis optimized for quality in structured workflows like podcasts and audiobooks" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: [] },
  "gemini-2.5-flash-native-audio-preview-12-2025": { status: "stable", use: { fa: "مدل Live پیشرو برای عامل‌های صوتی و تصویری دوطرفه‌ی کم‌تأخیر", en: "Flagship Live API model for low-latency, bidirectional voice and video agents" }, reasoning: null, coding: null, vision: null, multimodal: "high", speed: "high", limits: null, tags: [] },
  "gemini-3.5-transcribe": { status: "stable", use: { fa: "تبدیل گفتار به متن کم‌تأخیر با تشخیص گوینده و زمان‌بندی کلمات", en: "Low-latency speech-to-text model with speaker diarization and word timestamps" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: "high", limits: null, tags: [] },
  "gemini-3.1-flash-live-preview": { status: "stable", use: { fa: "مدل صوتی قدیمی؛ گوگل مهاجرت به Gemini 3.8 Live را پیشنهاد می‌کند", en: "Legacy audio-to-audio preview model; Google recommends updating to Gemini 3.8 Live" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: [] },
  "gemini-3.1-flash-tts-preview": { status: "stable", use: { fa: "مدل گفتاری قدیمی؛ مهاجرت به 3.8 Flash TTS پیشنهاد می‌شود", en: "Legacy TTS preview model; Google recommends updating to Gemini 3.8 Flash TTS" }, reasoning: null, coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: [] },
  "gemini-omni-1.2-flash": { status: "stable", use: { fa: "تولید و ویرایش ویدیوی سریع تا ۱۵ ثانیه با صدای بومی", en: "Fast video generation and editing up to 15 seconds with native audio" }, reasoning: null, coding: null, vision: "high", multimodal: null, speed: "high", limits: null, tags: ["fileImage"] },
  "gemini-omni-1.1-flash": { status: "stable", use: { fa: "تولید و ویرایش ویدیوی سریع تا ۱۵ ثانیه با صدای بومی", en: "Fast video generation and editing up to 15 seconds with native audio" }, reasoning: null, coding: null, vision: "high", multimodal: null, speed: "high", limits: null, tags: ["fileImage"] },
  "deep-research-preview-04-2026": { status: "preview", use: { fa: "مدل عاملی پژوهش عمیق — برنامه‌ریزی و اجرای چندمرحله‌ای پژوهش روی صدها منبع", en: "Agentic model that autonomously plans and executes multi-step research across hundreds of sources" }, reasoning: "high", coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: ["research", "reasoning", "exam"] },
  "deep-research-max-preview-04-2026": { status: "preview", use: { fa: "بیشترین جامعیت در گردآوری و ترکیب خودکار منابع", en: "Maximum comprehensiveness for automated context gathering and synthesis" }, reasoning: "high", coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: ["research", "reasoning", "exam"] },
};
const GM_TAG_KEYS = { coding: "gmTestTagCoding", research: "gmTestTagResearch", reasoning: "gmTestTagReasoning", fast: "gmTestTagFast", fileImage: "gmTestTagFileImage", teaching: "gmTestTagTeaching", exam: "gmTestTagExam" };
const GM_USE_CASES = [
  { key: "gmTestUseResearch", tags: ["research", "reasoning"], prefer: "reasoning" },
  { key: "gmTestUseBudget", tags: ["reasoning", "research"], prefer: "reasoning" },
  { key: "gmTestUsePlanning", tags: ["fast", "reasoning"], prefer: "speed" },
  { key: "gmTestUseCoding", tags: ["coding"], prefer: "coding" },
  { key: "gmTestUseLargeDoc", tags: ["research", "reasoning"], prefer: "context" },
];
let gmTestModels = [];
let gmTestResults = {};
let gmTestLastAt = 0;
let gmTestRunning = false;
let gmTestDefaultModel = "";
// v1.11.29 (QA BUG-054): limits is bilingual {fa,en} like `use`;
// a legacy plain string still renders as-is.
function gmLimitsText(limits) {
  if (!limits) return null;
  if (typeof limits === "string") return limits;
  return limits[LANG] || limits.en || limits.fa || null;
}
function gmInfo(id) {
  return GM_MODEL_INFO[id] || { status: "unknown", use: null, reasoning: null, coding: null, vision: null, multimodal: null, speed: null, limits: null, tags: [] };
}
function gmFamilyRank(id) {
  if (id.indexOf("gemini-4") === 0) return 0;
  if (id.indexOf("gemini-3") === 0) return 1;
  if (id.indexOf("gemini-2.5") === 0) return 2;
  if (id.indexOf("gemini-2.0") === 0) return 3;
  if (id.indexOf("gemini-1.5") === 0) return 4;
  return 5;
}
// Long-document ability is derived from the API's own context limit
// (>= 1M input tokens), never guessed.
function gmLongDoc(m) {
  return (typeof m.inputTokenLimit === "number" && m.inputTokenLimit >= 1000000) ? "high" : null;
}
function gmCapVal(v) { return v === "high" ? t("gmTestValHigh") : t("gmTestUnknown"); }
function gmErrLabel(kind) {
  return { auth: "gmTestErrAuth", rate_limit: "gmTestErrRate", not_found: "gmTestErrNotFound", network: "gmTestErrNetwork", model: "gmTestErrModel", unknown: "gmTestErrUnknown" }[kind] || "gmTestErrUnknown";
}
function gmFmtTokens(n) {
  if (typeof n !== "number" || !n) return "—";
  if (n >= 1000000) { const v = Math.round(n / 100000) / 10; return (v % 1 ? v : Math.round(v)) + "M"; }
  if (n >= 1000) return Math.round(n / 1000) + "K";
  return String(n);
}
function gmLatencyOf(m) { const r = gmTestResults[m.id]; return (r && typeof r.latencyMs === "number") ? r.latencyMs : null; }
function gmTestLoadStored() {
  try {
    const raw = localStorage.getItem(GM_TEST_STORE_KEY);
    if (!raw) return;
    const j = JSON.parse(raw);
    if (j && typeof j === "object") { gmTestResults = j.results || {}; gmTestLastAt = j.lastAt || 0; }
  } catch (e) {}
}
function gmTestSaveStored() {
  try { localStorage.setItem(GM_TEST_STORE_KEY, JSON.stringify({ results: gmTestResults, lastAt: gmTestLastAt })); } catch (e) {}
}
async function gmTestFetchModels() {
  const res = await fetch("/api/gemini-models");
  const j = await res.json();
  if (!res.ok) {
    const msg = (j.error && j.error.indexOf("معتبر نیست") !== -1) ? t("keyInvalid") : (errText(j.error) || t("gmTestLoadFailed"));
    throw new Error(msg);
  }
  const list = (j.models || []).map(m => (typeof m === "string")
    ? { id: m, displayName: m, description: "", version: "", inputTokenLimit: null, outputTokenLimit: null, methods: [] }
    : m);
  // Known models missing from this key's list are shown too, marked unavailable.
  const seen = {};
  list.forEach(m => { seen[m.id] = true; });
  Object.keys(GM_MODEL_INFO).concat(KNOWN_GEMINI_MODELS).forEach(id => {
    if (!seen[id]) list.push({ id, displayName: id, description: "", version: "", inputTokenLimit: null, outputTokenLimit: null, methods: [], listed: false });
  });
  list.forEach(m => { if (m.listed !== false) m.listed = true; });
  return list;
}
async function gmTestOne(id) {
  const res = await fetch("/api/gemini-test", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ model: id }) });
  const j = await res.json();
  if (!res.ok) return { ok: false, latencyMs: null, errorKind: "unknown", errorMessage: errText(j.error) || t("gmTestLoadFailed"), at: Date.now() };
  return { ok: !!j.ok, latencyMs: (typeof j.latencyMs === "number" ? j.latencyMs : null), errorKind: j.errorKind || (j.ok ? "" : "unknown"), errorMessage: j.errorMessage || "", at: Date.now() };
}
// "Test all" must only probe listed, text-capable, live models: probing
// ~40 models including shutdown, deprecated, image/TTS/video ones with
// a text prompt wastes the quota and reports noise as failures. A NEW
// model the API lists (not in GM_MODEL_INFO) stays testable.
const GM_NON_TEXT_RE = /image|tts|live|transcribe|omni|nano-banana|deep-research|audio/i;
function gmTestable(m) {
  if (m.listed === false) return false;
  const info = GM_MODEL_INFO[m.id];
  if (info && (info.status === "shutdown" || info.status === "unknown")) return false;
  if (GM_NON_TEXT_RE.test(m.id)) return false;
  if (Array.isArray(m.methods) && m.methods.length && m.methods.indexOf("generateContent") < 0) return false;
  return true;
}
function gmTestSortedModels() {
  const sort = (document.getElementById("gmTestSort") || {}).value || "status";
  const arr = gmTestModels.slice();
  const statusRank = m => {
    const r = gmTestResults[m.id];
    if (r && r.testing) return 1;
    if (r && r.ok) return 0;
    if (r && !r.ok) return 2;
    return 3;
  };
  if (sort === "speed") arr.sort((a, b) => (gmLatencyOf(a) == null ? Infinity : gmLatencyOf(a)) - (gmLatencyOf(b) == null ? Infinity : gmLatencyOf(b)));
  else if (sort === "type") arr.sort((a, b) => gmFamilyRank(a.id) - gmFamilyRank(b.id) || a.id.localeCompare(b.id));
  else arr.sort((a, b) => statusRank(a) - statusRank(b) || gmFamilyRank(a.id) - gmFamilyRank(b.id));
  return arr;
}
function gmTestCardHtml(m) {
  const info = gmInfo(m.id);
  const r = gmTestResults[m.id];
  const status = !m.listed ? "na" : (r && r.testing ? "testing" : (r ? (r.ok ? "ok" : "fail") : "idle"));
  const statusText = !m.listed ? t("gmTestNotListed") : (r && r.testing ? t("gmTestTestingStatus") : (r ? (r.ok ? t("gmTestOk") : t("gmTestFailed")) : t("gmTestUntested")));
  const lat = gmLatencyOf(m);
  const docNote = info.status === "deprecated" ? t("gmTestDeprecated") : (info.status === "shutdown" ? t("gmTestShutdown") : (info.status === "preview" ? t("gmTestPreview") : ""));
  const isDefault = gmTestDefaultModel && m.id === gmTestDefaultModel;
  const tags = (info.tags || []).map(tag => '<span class="gm-tag">' + esc(t(GM_TAG_KEYS[tag] || "gmTestUnknown")) + '</span>').join("");
  const useText = info.use ? (info.use[LANG] || info.use.en || info.use.fa) : t("gmTestUnknown");
  const capRow = (labelKey, val) => '<tr><td>' + esc(t(labelKey)) + '</td><td>' + esc(val) + '</td></tr>';
  return '<div class="gm-test-card">' +
    '<div class="gm-test-head"><div><div class="gm-test-name">' + esc(m.displayName || m.id) + '</div>' +
    '<div class="gm-test-id">' + esc(m.id) + '</div></div>' +
    '<span class="gm-status ' + status + '">' + esc(statusText) + '</span></div>' +
    '<div class="gm-test-meta">' +
    (m.version ? esc(m.version) + ' · ' : '') + esc(t("gmTestCapContext")) + ': ' + esc(gmFmtTokens(m.inputTokenLimit)) + ' / ' + esc(gmFmtTokens(m.outputTokenLimit)) +
    (docNote ? ' · ' + esc(docNote) : '') +
    (isDefault ? ' · <b>' + esc(t("gmTestIsDefault")) + '</b>' : '') +
    (lat != null ? '<br>' + esc(t("gmTestLatency", { ms: FA(lat) })) : '') +
    '</div>' +
    (r && !r.ok && !r.testing ? '<div class="gm-test-err">' + esc(t(gmErrLabel(r.errorKind))) + (r.errorMessage ? '<br>' + esc(r.errorMessage) : '') + '</div>' : '') +
    (tags ? '<div class="gm-test-tags">' + tags + '</div>' : '') +
    '<details><summary>' + esc(t("gmTestDetails")) + '</summary><table class="gm-cap-table">' +
    capRow("gmTestCapUse", useText) +
    capRow("gmTestCapReasoning", gmCapVal(info.reasoning)) +
    capRow("gmTestCapCoding", gmCapVal(info.coding)) +
    capRow("gmTestCapLongDoc", gmCapVal(gmLongDoc(m))) +
    capRow("gmTestCapVision", gmCapVal(info.vision)) +
    capRow("gmTestCapMultimodal", gmCapVal(info.multimodal)) +
    capRow("gmTestCapSpeed", gmCapVal(info.speed)) +
    capRow("gmTestCapContext", gmFmtTokens(m.inputTokenLimit) + " / " + gmFmtTokens(m.outputTokenLimit)) +
    capRow("gmTestCapLimits", gmLimitsText(info.limits) || t("gmTestUnknown")) +
    '</table></details>' +
    '<div style="margin-top:8px"><button class="btn" data-retest="' + esc(m.id) + '"' + (gmTestRunning ? ' disabled' : '') + '>' + esc(t("gmTestRetest")) + '</button></div>' +
    '</div>';
}
function gmRenderTestCards() {
  const el = document.getElementById("gmTestList");
  if (!el) return;
  if (!gmTestModels.length) { el.innerHTML = ""; return; }
  el.innerHTML = gmTestSortedModels().map(m => gmTestCardHtml(m)).join("");
  el.querySelectorAll("[data-retest]").forEach(btn => btn.addEventListener("click", async () => {
    const id = btn.dataset.retest;
    if (gmTestRunning) return;
    gmTestResults[id] = { testing: true };
    gmRenderTestCards();
    const r = await gmTestOne(id);
    gmTestResults[id] = r;
    gmTestLastAt = Date.now();
    gmTestSaveStored();
    gmRenderTestCards(); gmRenderTestSummary(); gmRenderTestCompare(); gmRenderTestRecs();
  }));
}
function gmRenderTestSummary() {
  const sEl = document.getElementById("gmTestSummary");
  const lEl = document.getElementById("gmTestLast");
  if (!sEl) return;
  let ok = 0, fail = 0, na = 0;
  gmTestModels.forEach(m => {
    if (!m.listed) { na++; return; }
    const r = gmTestResults[m.id];
    if (r && r.ok) ok++;
    else if (r && !r.ok && !r.testing) fail++;
  });
  sEl.textContent = gmTestModels.length ? t("gmTestSummary", { ok: FA(ok), fail: FA(fail), na: FA(na) }) : t("gmTestSummaryNone");
  if (lEl) lEl.textContent = gmTestLastAt ? t("gmTestLast", { time: new Date(gmTestLastAt).toLocaleString(LANG === "fa" ? "fa-IR" : "en-GB") }) : t("gmTestLastNever");
}
function gmRenderTestCompare() {
  const el = document.getElementById("gmTestCompare");
  if (!el) return;
  const tested = gmTestModels.filter(m => { const r = gmTestResults[m.id]; return r && !r.testing; });
  if (!tested.length) {
    el.innerHTML = '<h3 class="section-title" style="margin-top:16px">' + esc(t("gmTestCompareTitle")) + '</h3><p class="muted">' + esc(t("gmTestCompareHint")) + '</p>';
    return;
  }
  tested.sort((a, b) => {
    const ra = gmTestResults[a.id], rb = gmTestResults[b.id];
    if (ra.ok !== rb.ok) return ra.ok ? -1 : 1;
    return (ra.latencyMs == null ? Infinity : ra.latencyMs) - (rb.latencyMs == null ? Infinity : rb.latencyMs);
  });
  const rows = [
    ["gmTestRowReasoning", m => gmCapVal(gmInfo(m.id).reasoning)],
    ["gmTestRowCoding", m => gmCapVal(gmInfo(m.id).coding)],
    ["gmTestRowSpeed", m => gmCapVal(gmInfo(m.id).speed)],
    ["gmTestRowFileImage", m => gmCapVal(gmInfo(m.id).multimodal)],
    ["gmTestRowCapacity", m => gmFmtTokens(m.inputTokenLimit)],
    ["gmTestRowStatus", m => { const r = gmTestResults[m.id]; return r.ok ? t("gmTestOk") : t(gmErrLabel(r.errorKind)); }],
    ["gmTestRowPerf", m => { const r = gmTestResults[m.id]; return r.ok ? (r.latencyMs != null ? t("gmTestLatency", { ms: FA(r.latencyMs) }) : "—") : t(gmErrLabel(r.errorKind)); }],
  ];
  let html = '<h3 class="section-title" style="margin-top:16px">' + esc(t("gmTestCompareTitle")) + '</h3><div class="gm-compare-wrap"><table><tr><th></th>' +
    tested.map(m => '<th>' + esc(m.displayName || m.id) + '</th>').join("") + '</tr>';
  rows.forEach(pair => {
    html += '<tr><td>' + esc(t(pair[0])) + '</td>' + tested.map(m => '<td>' + esc(pair[1](m)) + '</td>').join("") + '</tr>';
  });
  el.innerHTML = html + '</table></div>';
}
function gmPickForUseCase(uc) {
  const cands = gmTestModels.filter(m => {
    const r = gmTestResults[m.id];
    if (!r || !r.ok) return false;
    const tags = gmInfo(m.id).tags || [];
    return uc.tags.some(tag => tags.indexOf(tag) >= 0);
  });
  if (!cands.length) return null;
  const score = m => {
    const info = gmInfo(m.id);
    const r = gmTestResults[m.id];
    let s = 0;
    if (uc.prefer === "reasoning" && info.reasoning === "high") s += 10;
    if (uc.prefer === "coding" && info.coding === "high") s += 10;
    if (uc.prefer === "context" && typeof m.inputTokenLimit === "number") s += Math.min(5, m.inputTokenLimit / 1000000);
    if (uc.prefer === "speed" && typeof r.latencyMs === "number") s += Math.max(0, 5 - r.latencyMs / 1000);
    return s;
  };
  cands.sort((a, b) => score(b) - score(a) || (gmLatencyOf(a) == null ? Infinity : gmLatencyOf(a)) - (gmLatencyOf(b) == null ? Infinity : gmLatencyOf(b)));
  return cands[0];
}
function gmRenderTestRecs() {
  const el = document.getElementById("gmTestRecs");
  if (!el) return;
  const anyTested = gmTestModels.some(m => { const r = gmTestResults[m.id]; return r && !r.testing; });
  let html = '<h3 class="section-title" style="margin-top:16px">' + esc(t("gmTestRecsTitle")) + '</h3>';
  if (!anyTested) { el.innerHTML = html + '<p class="muted">' + esc(t("gmTestRecsHint")) + '</p>'; return; }
  html += '<div class="gm-rec-list">';
  GM_USE_CASES.forEach(uc => {
    const pick = gmPickForUseCase(uc);
    html += '<div>' + esc(t(uc.key)) + ': ' + (pick ? '<b>' + esc(pick.displayName || pick.id) + '</b> <span class="muted">(' + esc(pick.id) + ')</span>' : esc(t("gmTestNoPick"))) + '</div>';
  });
  el.innerHTML = html + '</div>';
}
function refreshGmTestPanel() { gmRenderTestCards(); gmRenderTestSummary(); gmRenderTestCompare(); gmRenderTestRecs(); }
let gmTestLastError = ""; // v1.11.45 (E-18): last test-all failure, kept visible in the summary
async function gmTestAll() {
  if (gmTestRunning) return;
  gmTestLastError = "";
  const btn = document.getElementById("gmTestAllBtn");
  const listEl = document.getElementById("gmTestList");
  gmTestRunning = true;
  if (btn) { btn.disabled = true; btn.textContent = t("gmTestTesting"); }
  try {
    if (!gmTestModels.length) {
      if (listEl) listEl.innerHTML = '<p class="muted">' + esc(t("gmModelsLoading")) + '</p>';
      gmTestModels = await gmTestFetchModels();
      // v1.11.65 (Batch 6, L-PERF3): shared getter, cached + deduped.
      const dm = await getGeminiModel();
      if (dm) gmTestDefaultModel = dm.model || "";
    }
    gmRenderTestCards();
    for (const m of gmTestModels.filter(gmTestable)) {
      gmTestResults[m.id] = { testing: true };
      gmRenderTestCards();
      const r = await gmTestOne(m.id);
      gmTestResults[m.id] = r;
      gmTestLastAt = Date.now();
      gmTestSaveStored();
      gmRenderTestCards();
      await new Promise(r2 => setTimeout(r2, 250));
    }
  } catch (e) {
    // v1.11.45 (E-18): the error goes to the persistent summary
    // element — the old code wrote it into #gmTestList, which the
    // finally block immediately re-rendered over (invisible failure).
    gmTestLastError = e.message || t("gmTestLoadFailed");
    const sEl = document.getElementById("gmTestSummary");
    if (sEl) sEl.textContent = gmTestLastError;
  } finally {
    gmTestRunning = false;
    if (btn) { btn.disabled = false; btn.textContent = t("gmTestAllBtn"); }
    // Re-render once more so the per-model retest buttons are enabled again
    // (during the run they were rendered disabled).
    gmRenderTestCards();
    gmRenderTestSummary(); gmRenderTestCompare(); gmRenderTestRecs();
    if (gmTestLastError) { const sEl = document.getElementById("gmTestSummary"); if (sEl) sEl.textContent = gmTestLastError; }
  }
}
document.getElementById("gmTestAllBtn").addEventListener("click", gmTestAll);
document.getElementById("gmTestSort").addEventListener("change", gmRenderTestCards);
gmTestLoadStored(); // stored test results (latencies) are local-only, load them at once
// Load the live model list only when the Gemini tab is first opened:
// fetching it on every page load is wasted work (and a failed key
// shows an error in a tab the user may never open).
let gmTestInitDone = false;
async function gmTestInitOnce() {
  if (gmTestInitDone) return;
  gmTestInitDone = true;
  renderGeminiHistory(); // 3.6b: saved analyses under the ask box
  try {
    gmTestModels = await gmTestFetchModels();
    // v1.11.65 (Batch 6, L-PERF3): shared getter, cached + deduped.
    const dm = await getGeminiModel();
    if (dm) gmTestDefaultModel = dm.model || "";
    gmRenderTestCards(); gmRenderTestSummary(); gmRenderTestCompare(); gmRenderTestRecs();
  } catch (e) {
    // v1.11.45 (E-18): the flag was set BEFORE the fetch and never
    // reset on failure, so the lab could never retry without a reload.
    gmTestInitDone = false;
    const listEl = document.getElementById("gmTestList");
    if (listEl) listEl.innerHTML = '<p class="muted"><span class="error">' + esc(e.message || t("gmTestLoadFailed")) + '</span></p>';
    gmRenderTestSummary();
  }
}
document.getElementById("analyzeBtn").addEventListener("click", async () => {
  const out = document.getElementById("geminiOut");
  out.textContent = t("analyzing");
  const boxes = allBoxes();
  const done = boxes.filter(isDone).length;
  const bySubject = {};
  boxes.forEach(b => {
    const s = bySubject[b.subject] = bySubject[b.subject] || { total: 0, done: 0 };
    s.total++; if (isDone(b)) s.done++;
  });
  const lines = Object.keys(bySubject).map(s =>
    subjName(s) + ": " + bySubject[s].done + " / " + bySubject[s].total + " " + t("boxesWord")).join("\n");
  const bookLines = (TESTBOOK.books || []).map(book => {
    const st = bookStats(book);
    return t("bookPrefix") + bookName(book) + ": " + st.solved + t("solvedSuffix") +
      (st.total ? t("ofWord") + st.total : "") + (st.pct == null ? "" : " (" + FA_PCT(st.pct) + ")");
  }).join("\n");
  const question = document.getElementById("geminiQuestion").value.trim();
  const prompt = t("promptIntro") +
    t("promptStatus", { done, total: boxes.length, lines, books: bookLines }) +
    (question ? t("promptQuestion") + question : "") +
    t("promptTasks") +
    (question ? t("promptQ4") : "");
  try {
    const res = await fetch("/api/gemini", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt })
    });
    const j = await res.json();
    if (!res.ok) {
      let msg;
      if (j.error && j.error.indexOf("معتبر نیست") !== -1) msg = t("keyInvalid");
      else if (j.error && j.error.indexOf("HTTP 404") !== -1) msg = t("gmModelNotFound");
      else msg = errText(j.error) || t("keyInvalid");
      out.innerHTML = '<span class="error">' + esc(msg) + "</span>";
      return;
    }
    out.textContent = j.text;
    saveGeminiHistory(question, j.text);
  } catch (e) {
    out.innerHTML = '<span class="error">' + t("serverUnreachable") + '</span>';
  }
});

// ---------- Gemini history (audit §5 item 3.6b) ----------
// Saved analyses: {id, d, model, question, text}, newest first, capped
// at 20. Stored in state (not a separate file) so backups cover it.
// The analysis used to be fire-and-forget — now every successful ask is
// kept and can be re-opened or deleted from the Gemini tab.
const GM_HISTORY_MAX = 20;
let gmCurrentModel = "";
function saveGeminiHistory(question, text) {
  state.geminiHistory = state.geminiHistory || [];
  state.geminiHistory.unshift({ id: "gm-" + Date.now(), d: TODAY,
    model: gmCurrentModel || "", question: question || "", text: text || "" });
  if (state.geminiHistory.length > GM_HISTORY_MAX) state.geminiHistory.length = GM_HISTORY_MAX;
  saveState(); renderGeminiHistory();
}
function renderGeminiHistory() {
  const out = document.getElementById("geminiOut");
  if (!out || !out.parentNode) return;
  const old = document.getElementById("geminiHistoryWrap");
  if (old) old.remove();
  const wrap = document.createElement("div");
  wrap.id = "geminiHistoryWrap";
  wrap.className = "gm-history";
  const title = document.createElement("h3");
  title.textContent = t("gmHistoryTitle");
  wrap.appendChild(title);
  const list = (state.geminiHistory || []);
  if (!list.length) {
    const p = document.createElement("p");
    p.className = "muted";
    p.textContent = t("gmHistoryEmpty");
    wrap.appendChild(p);
  } else {
    const clearBtn = document.createElement("button");
    clearBtn.className = "btn";
    clearBtn.textContent = t("gmHistoryClear");
    clearBtn.addEventListener("click", () => {
      if (!confirm(t("gmHistoryClearConfirm"))) return;
      state.geminiHistory = [];
      saveState(); renderGeminiHistory();
    });
    wrap.appendChild(clearBtn);
    list.forEach(h => {
      const det = document.createElement("details");
      det.className = "gm-history-item";
      const label = (h.question || t("gmTitle")) + " — " + gregToJalali(h.d || TODAY).text + (h.model ? " · " + h.model : "");
      det.innerHTML = "<summary>" + esc(label) + "</summary><p class=\"gm-history-text\"></p>";
      det.querySelector(".gm-history-text").textContent = h.text || "";
      const db = document.createElement("button");
      db.className = "btn";
      db.textContent = t("gmHistoryDelete");
      db.addEventListener("click", (ev) => {
        ev.preventDefault();
        state.geminiHistory = (state.geminiHistory || []).filter(x => x.id !== h.id);
        saveState(); renderGeminiHistory();
      });
      det.appendChild(db);
      wrap.appendChild(det);
    });
  }
  out.parentNode.insertBefore(wrap, out.nextSibling);
}

// ---- Backup (local automatic + B2 cloud) ----
// Local backups are always on: every save snapshots state.json / testbook.json
// into the data dir (outside the app folder). The cloud layer is inert until
// B2 credentials are entered in the Backup tab.
let backupStatusCache = null;

function fmtBackupTs(iso) {
  if (!iso) return "";
  return String(iso).replace("T", " ").replace(/\+.*$/, "");
}
// v1.11.42 (UI-audit batch 2, item 20): backup version dates display
// in Jalali, like every other date in the app — «۴ آذر ۱۴۰۵ · ۲۲:۵۸:۲۲»
// instead of «2026-11-25 22:58:22». The time keeps two digits per
// component (Persian digits in fa, Latin in en). Falls back to the
// Gregorian form when the value does not parse. The calendar log and
// sync status keep fmtBackupTs — out of scope for this item.
function fmtBackupTsJalali(iso) {
  if (!iso) return "";
  const s = String(iso);
  const j = gregToJalali(s.slice(0, 10));
  if (!j || !j.text) return fmtBackupTs(iso);
  const tm = s.slice(11, 19);
  if (!tm) return j.text;
  const two = (x) => {
    const d = String(parseInt(x, 10)).padStart(2, "0");
    return LANG === "fa" ? d.replace(/\d/g, (c) => "۰۱۲۳۴۵۶۷۸۹"[+c]) : d;
  };
  return j.text + " · " + tm.split(":").map(two).join(":");
}

async function renderBackupPill(status) {
  // v1.11.14 — topbar backup pill rendered from a (possibly cached) backup
  // status, so language switches re-label it without a new fetch.
  const pill = document.getElementById("backupPill");
  if (!pill || !status) return;
  const cloud = status.cloud || {};
  if (cloud.conflict || (cloud.last_sync && cloud.last_sync.ok === false)) {
    pill.textContent = t("bkPillError");
    pill.className = "pill-backup err";
  } else if (cloud.enabled && cloud.configured) {
    pill.textContent = t("bkPillOk");
    pill.className = "pill-backup ok";
  } else {
    pill.textContent = t("bkPillLocal");
    pill.className = "pill-backup";
  }
  pill.dataset.live = "1";
}
async function refreshBackupStatus() {
  const pill = document.getElementById("backupPill");
  try {
    const res = await fetch("/api/backup");
    const j = await res.json();
    backupStatusCache = j;
    renderBackupPill(j);
  } catch (e) {
    if (pill) { pill.textContent = t("bkPillError"); pill.className = "pill-backup err"; }
  }
}

async function refreshDataFromServer() {
  // v1.11.48 (F2): flush pending saves FIRST — the debounced save may
  // still hold an edit the server has not seen; re-reading before it
  // lands would silently drop that edit while the pill says «saved».
  await flushSaves();
  await flushTestbook();
  try {
    const [, sRes, tRes] = await Promise.all([loadProgrammeBoxes(), fetch("/api/state"), fetch("/api/testbook")]);
    // Replace wholesale (not Object.assign): a backup restore REPLACES
    // the state, so a merge here would resurrect the wiped boxes/ticks.
    if (sRes.ok) { _captureStateSeq(sRes); state = await sRes.json(); stateLoaded = true; _snapshotState(); }
    ensureStateMaps(); // v1.11.50: repair a malformed state in memory
    // before the render below reads it (a backup restore can replace
    // the state wholesale with an old/malformed shape).
    syncProgrammeRange(); // 1.7: extend the stored range to the programme as loaded
    if (tRes.ok) { _captureTbSeq(tRes); TESTBOOK = await tRes.json(); testbookLoaded = true; _snapshotTestbook(); }
    ensureExams();
    migrateAssignments();
    normalizeExamLinks(); normalizeBoxBookLinks(); normalizeAssignmentLinks();
  } catch (e) {
    // v1.11.65 (Batch 6, R8): the empty catch swallowed a failed
    // refresh — the app kept showing stale data with no signal. Log it
    // and say so; the render below still runs with the old data.
    console.error("refreshDataFromServer failed:", e);
    showToast(t("refreshFailed"), { kind: "err", ms: 4000 });
  }
  renderAll();
}

function bkVersionRow(v, kind) {
  const row = document.createElement("div");
  row.className = "bk-row";
  const kb = v.size ? (Math.round(v.size / 102.4) / 10) + " KB" : "";
  // v1.11.61 (L-UI9): the row id is the Jalali date + size; the full
  // filename (with its hash) moves to the tooltip. The verified flag
  // keeps its own small marker.
  const label = fmtBackupTsJalali(v.ts_iso) || (v.file || "");
  row.innerHTML = '<span class="bk-file" title="' + esc(v.file || "") + '">' + esc(label) + (kb ? " · " + kb : "") + '</span>' +
    (v.verified === false ? '<span class="bk-meta">⚠</span>' : "") +
    '<button class="btn bk-restore-btn">' + t("bkRestore") + "</button>";
  // v1.11.65 (Batch 6, ب-۷): a restore says WHY when it fails and
  // offers a retry — the native alert showed neither, and the success
  // alert becomes a short toast (the three-state contract).
  const doRestore = async () => {
    try {
      const res = await fetch("/api/backup/restore", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind, file: v.file })
      });
      if (res.ok) {
        showToast(t("bkRestored"));
        await refreshDataFromServer();
        renderBackup();
        return;
      }
      let reason = "";
      try { const ej = await res.json(); reason = errText(ej.error) || ej.error || ""; } catch (e2) {}
      showToast(t("bkRestoreFailedReason", { e: reason || ("HTTP " + res.status) }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: doRestore } });
    } catch (e) {
      showToast(t("bkRestoreFailedReason", { e: t("serverUnreachable") }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: doRestore } });
    }
  };
  row.querySelector(".bk-restore-btn").addEventListener("click", async () => {
    if (!confirm(t("bkRestoreConfirm"))) return;
    await doRestore();
  });
  return row;
}

function bkCloudRow(kind, entry) {
  const row = document.createElement("div");
  row.className = "bk-row";
  const ts = entry.ts ? fmtBackupTsJalali(new Date(entry.ts * 1000).toISOString()) : "";
  row.innerHTML = '<span class="bk-file">' + esc(kind) + " — " + esc(entry.key || "") + '</span>' +
    '<span class="bk-meta">' + esc(ts) + '</span>' +
    '<button class="btn bk-restore-btn">' + t("bkRestore") + "</button>";
  // v1.11.65 (Batch 6, ب-۷): same contract as the local restore —
  // a failed cloud restore says why and offers a retry; success is a
  // short toast, not a native alert.
  const doCloudRestore = async () => {
    try {
      const res = await fetch("/api/backup/restore-cloud", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind, key: entry.key })
      });
      if (res.ok) {
        showToast(t("bkRestored"));
        await refreshDataFromServer();
        renderBackup();
        return;
      }
      let reason = "";
      try { const ej = await res.json(); reason = errText(ej.error) || ej.error || ""; } catch (e2) {}
      showToast(t("bkRestoreFailedReason", { e: reason || ("HTTP " + res.status) }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: doCloudRestore } });
    } catch (e) {
      showToast(t("bkRestoreFailedReason", { e: t("serverUnreachable") }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: doCloudRestore } });
    }
  };
  row.querySelector(".bk-restore-btn").addEventListener("click", async () => {
    if (!confirm(t("bkRestoreConfirm"))) return;
    await doCloudRestore();
  });
  return row;
}

async function renderBackup() {
  // v1.11.19 (audit §5 item 2.9): local + B2 backup only. v1.11.57 (IA):
  // this is a section inside the Settings tab now (not its own tab) —
  // the updater buttons and the calendar panel have their own places
  // and are wired there; re-apply translations on every render.
  applyStaticI18n();
  let status = backupStatusCache;
  let list = null, b2cfg = null;
  try {
    const [sRes, lRes, cRes] = await Promise.all([
      fetch("/api/backup"), fetch("/api/backup/list"), fetch("/api/backup/b2-config")
    ]);
    if (sRes.ok) { status = await sRes.json(); backupStatusCache = status; }
    if (lRes.ok) list = await lRes.json();
    if (cRes.ok) b2cfg = await cRes.json();
  } catch (e) { /* server unreachable — leave the panel as-is */ }
  if (!status) return;
  // v1.11.19 (audit §5 item 2.9): the calendar panel and the updater
  // never lived in this section — they have their own places, and
  // their renders run there (renderCalendarTab / renderSettingsTab).
  // This section is local + B2 backup only.
  const dirEl = document.getElementById("bkDataDir");
  if (dirEl) dirEl.textContent = t("bkDataDir", { d: status.data_dir || "" });
  const local = status.local || {};
  const last = local.last_backup;
  const localInfo = document.getElementById("bkLocalInfo");
  if (localInfo) {
    localInfo.textContent = (last ? t("bkLastBackup", { t: fmtBackupTsJalali(last.ts_iso) }) : t("bkNoBackup")) +
      " · " + t("bkVersionsCount", { n: FA((local.state_backups || 0) + (local.testbook_backups || 0)) });
  }
  const cloud = status.cloud || {};
  const cloudInfo = document.getElementById("bkCloudInfo");
  if (cloudInfo) {
    let line;
    if (!cloud.configured) line = t("bkCloudNotConfigured");
    else if (!cloud.enabled) line = t("bkCloudDisabled");
    else if (cloud.last_sync && cloud.last_sync.ok === false) line = t("bkCloudError", { e: cloud.last_sync.error || "" });
    else line = t("bkCloudEnabled") + " · " +
      (cloud.last_sync && cloud.last_sync.ts_iso ? t("bkCloudLastSync", { t: fmtBackupTsJalali(cloud.last_sync.ts_iso) }) : t("bkCloudNever"));
    cloudInfo.textContent = line;
  }
  const conflictBox = document.getElementById("bkConflictBox");
  if (conflictBox) {
    conflictBox.hidden = !cloud.conflict;
    conflictBox.innerHTML = "";
    if (cloud.conflict) {
      const c = cloud.conflict;
      conflictBox.innerHTML = '<p><b>' + t("bkCloudConflict") + '</b></p>' +
        '<p class="muted">' + t("bkCloudConflictNote") + "</p>";
      const mineBtn = document.createElement("button");
      mineBtn.className = "btn btn-primary";
      mineBtn.textContent = t("bkCloudUseMine");
      mineBtn.addEventListener("click", async () => {
        await fetch("/api/backup/resolve-conflict", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ kind: c.kind })
        });
        refreshBackupStatus(); renderBackup();
      });
      const cloudBtn = document.createElement("button");
      cloudBtn.className = "btn";
      cloudBtn.textContent = t("bkCloudUseCloud");
      cloudBtn.addEventListener("click", async () => {
        if (!confirm(t("bkRestoreConfirm"))) return;
        // v1.11.65 (Batch 6, ب-۷): same contract as the row restores —
        // a failed restore says why and offers a retry (this site had
        // no error handling at all — a network error threw).
        const doConflictRestore = async () => {
          try {
            const res = await fetch("/api/backup/restore-cloud", {
              method: "POST", headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ kind: c.kind, key: c.remote_key })
            });
            if (res.ok) {
              showToast(t("bkRestored"));
              await refreshDataFromServer();
            } else {
              let reason = "";
              try { const ej = await res.json(); reason = errText(ej.error) || ej.error || ""; } catch (e2) {}
              showToast(t("bkRestoreFailedReason", { e: reason || ("HTTP " + res.status) }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: doConflictRestore } });
            }
          } catch (e) {
            showToast(t("bkRestoreFailedReason", { e: t("serverUnreachable") }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: doConflictRestore } });
          }
          renderBackup();
        };
        await doConflictRestore();
      });
      conflictBox.appendChild(mineBtn);
      conflictBox.appendChild(cloudBtn);
    }
  }
  if (list) {
    const stateBox = document.getElementById("bkStateVersions");
    const tbBox = document.getElementById("bkTbVersions");
    const cloudBox = document.getElementById("bkCloudVersions");
    const stateVs = (list.versions || []).filter(v => v.kind === "state");
    const tbVs = (list.versions || []).filter(v => v.kind === "testbook");
    if (stateBox) {
      stateBox.innerHTML = "";
      if (!stateVs.length) stateBox.innerHTML = '<p class="muted">' + t("bkNoBackup") + "</p>";
      stateVs.slice(0, 30).forEach(v => stateBox.appendChild(bkVersionRow(v, "state")));
    }
    if (tbBox) {
      tbBox.innerHTML = "";
      if (!tbVs.length) tbBox.innerHTML = '<p class="muted">' + t("bkNoBackup") + "</p>";
      tbVs.slice(0, 30).forEach(v => tbBox.appendChild(bkVersionRow(v, "testbook")));
    }
    if (cloudBox) {
      cloudBox.innerHTML = "";
      const manifest = (list.cloud && list.cloud.manifest) || null;
      if (!manifest || (!manifest.state && !manifest.testbook)) {
        cloudBox.innerHTML = '<p class="muted">' + (cloud.configured ? t("bkCloudNever") : t("bkCloudNotConfigured")) + "</p>";
      } else {
        if (manifest.state) cloudBox.appendChild(bkCloudRow("state", manifest.state));
        if (manifest.testbook) cloudBox.appendChild(bkCloudRow("testbook", manifest.testbook));
      }
    }
    // v1.11.4 — Backup versions lists collapsed to 1 row by default
    // (same collapsible pattern as v1.11.2: toggle expands, capped height
    // + internal scroll, expanding never lengthens the whole page).
    attachCollapsible(stateBox, ".bk-row", 1);
    attachCollapsible(tbBox, ".bk-row", 1);
    attachCollapsible(cloudBox, ".bk-row", 1);
  }
  if (b2cfg) {
    const ep = document.getElementById("bkEndpoint");
    const bk = document.getElementById("bkBucket");
    const kid = document.getElementById("bkKeyId");
    if (ep && !ep.value) ep.value = b2cfg.endpoint || "s3.us-west-000.backblazeb2.com";
    if (bk && !bk.value) bk.value = b2cfg.bucket || "konkur-backup";
    if (kid && b2cfg.key_id_masked) kid.placeholder = b2cfg.key_id_masked;
    const st = document.getElementById("bkB2Status");
    if (st && b2cfg.configured) st.textContent = t("bkCloudEnabled") + (b2cfg.enabled ? "" : " — " + t("bkCloudDisabled"));
  }
}

// ---- Calendar tab (v1.11.19, audit §5 item 2.9): the Google Calendar
// sync panel lived inside the Backup tab; it is now a top-level tab of
// its own. Same panel, same element ids — only the section moved, so
// renderCalendarPanel / wireCalendarPanel work unchanged.
function renderCalendarTab() {
  wireCalendarPanel();
  renderCalendarPanel();
}
// ---- Settings tab (v1.11.19, audit §5 item 2.9): theme, language,
// data reset, Gemini key and app updates. The updater lived in the
// Backup tab; the reset button lived in the topbar next to the daily
// controls. Nothing here changes behaviour — only where the controls live.
function renderSettingsTab() {
  wireBackupTab();
  applyStaticI18n();
  refreshUpdateStatus();
  refreshAutoUpdate();
  // v1.11.42 (item 20): the styled update-file picker shows the chosen
  // file name (or «فایلی انتخاب نشده») — refreshed here so a language
  // switch never leaves a stale label behind.
  const ufName = document.getElementById("updFileName");
  if (ufName) ufName.textContent = updFileName || t("fileNone");
  // Keep the theme/language buttons in sync with the current state.
  const td = document.getElementById("setThemeDark");
  const tl = document.getElementById("setThemeLight");
  if (td) td.classList.toggle("btn-primary", state.theme === "dark");
  if (tl) tl.classList.toggle("btn-primary", state.theme !== "dark");
  const lf = document.getElementById("setLangFa");
  const le = document.getElementById("setLangEn");
  if (lf) lf.classList.toggle("btn-primary", LANG === "fa");
  if (le) le.classList.toggle("btn-primary", LANG === "en");
  // v1.11.48 (P-4): the next-box reminder toggle — default ON
  // (state.nextBoxRemind absent = on). Wired once here, not at init:
  // renderSettingsTab runs on every Settings visit, and the dataset
  // flag stops the change listener being attached twice.
  const nbc = document.getElementById("nextBoxRemindChk");
  if (nbc) {
    nbc.checked = state.nextBoxRemind !== false;
    if (!nbc.dataset.wired) {
      nbc.dataset.wired = "1";
      nbc.addEventListener("change", () => { state.nextBoxRemind = nbc.checked; saveState(); });
    }
  }
}

document.getElementById("backupPill").addEventListener("click", () => navigate({ tab: "settings", scroll: { type: "section", id: "setBackupTitle" } })); // v1.11.57 (IA): Backup is a section inside Settings now
document.getElementById("bkNowBtn").addEventListener("click", async () => {
  const btn = document.getElementById("bkNowBtn");
  try {
    const res = await fetch("/api/backup/now", { method: "POST" });
    if (res.ok) {
      backupStatusCache = await res.json();
      showToast(t("bkNowDone")); // v1.11.41: toast instead of the native alert
    }
  } catch (e) {}
  refreshBackupStatus(); renderBackup();
  if (btn) btn.textContent = t("bkNowBtn");
});

// ---- In-app self-update (Part 5) ----
// The server validates the zip, backs up the current code into the data dir,
// installs over the app folder (data dir untouched) and restarts itself.
// The page polls /api/version until the expected version answers, then reloads.
async function refreshUpdateStatus() {
  try {
    const res = await fetch("/api/update/status");
    if (!res.ok) return;
    const j = await res.json();
    const ver = document.getElementById("updVersion");
    // v1.11.42 (item 20): the build date displays in Jalali, like the
    // backup dates — «1.11.42 (۴ آذر ۱۴۰۵)» instead of «(2026-11-26)».
    if (ver) ver.textContent = j.version.version +
      (j.version.build_date ? " (" + (gregToJalali(j.version.build_date).text || j.version.build_date) + ")" : "");
    const info = document.getElementById("updBackupInfo");
    const rb = document.getElementById("updRollbackBtn");
    if (j.backups && j.backups.length) {
      const b = j.backups[0];
      if (info) info.textContent = t("updBackupOf", { version: b.version || "?", date: fmtBackupTsJalali(b.ts_iso) || "" });
      if (rb) rb.disabled = false;
    } else {
      if (info) info.textContent = t("updNoBackup");
      if (rb) rb.disabled = true;
    }
  } catch (e) { /* server unreachable — leave the panel as-is */ }
}
function updSetBusy(busy, msgKey) {
  ["updInstallFileBtn", "updInstallUrlBtn", "updRollbackBtn"].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.disabled = busy;
  });
  const st = document.getElementById("updStatus");
  if (st && msgKey) st.textContent = t(msgKey);
}
async function updWaitForServer(expectedVersion) {
  // The old server exits ~1s after the install response; the new one needs
  // ~3-4s to come up. Wait first so we never reload against the old server.
  await new Promise(r => setTimeout(r, 4000));
  const st = document.getElementById("updStatus");
  for (let i = 0; i < 30; i++) {
    try {
      const res = await fetch("/api/version");
      if (res.ok) {
        const j = await res.json();
        if (!expectedVersion || j.version === expectedVersion) {
          if (st) st.textContent = t("updServerBack");
          setTimeout(() => location.reload(), 800);
          return true;
        }
      }
    } catch (e) { /* server still down — keep polling */ }
    await new Promise(r => setTimeout(r, 1000));
  }
  if (st) st.textContent = t("updServerDown");
  updSetBusy(false);
  if (typeof updAutoSetBusy === "function") updAutoSetBusy(false);
  return false;
}
async function updHandleInstallResponse(res, retryFn) {
  const st = document.getElementById("updStatus");
  let j = {};
  try { j = await res.json(); } catch (e) {}
  if (!res.ok) {
    // v1.11.65 (Batch 6, ب-۷): a failed install says why in a toast
    // too, and offers a retry — the status line alone was easy to miss.
    const reason = errText(j.error) || res.status;
    if (st) st.textContent = t("updFailed", { error: reason });
    updSetBusy(false);
    showToast(t("updFailed", { error: reason }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: retryFn } });
    return;
  }
  if (st) st.textContent = t("updDone");
  updWaitForServer(j.version && j.version.version);
}
function updHandleInstallError(retryFn) {
  const st = document.getElementById("updStatus");
  if (st) st.textContent = t("updFailed", { error: t("serverUnreachable") });
  updSetBusy(false);
  showToast(t("updFailed", { error: t("serverUnreachable") }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: retryFn } });
}
async function doInstallFile() {
  const file = document.getElementById("updFile").files[0];
  if (!file) { alert(t("updNoFile")); return; }
  updSetBusy(true, "updInstalling");
  try {
    const res = await fetch("/api/update/upload", {
      method: "POST", headers: { "Content-Type": "application/zip" }, body: file
    });
    await updHandleInstallResponse(res, doInstallFile);
  } catch (e) { updHandleInstallError(doInstallFile); }
}
document.getElementById("updInstallFileBtn").addEventListener("click", doInstallFile);
async function doInstallUrl() {
  const url = document.getElementById("updUrl").value.trim();
  if (!url) { alert(t("updNoUrl")); return; }
  updSetBusy(true, "updInstalling");
  try {
    const res = await fetch("/api/update/url", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url })
    });
    await updHandleInstallResponse(res, doInstallUrl);
  } catch (e) { updHandleInstallError(doInstallUrl); }
}
document.getElementById("updInstallUrlBtn").addEventListener("click", doInstallUrl);
async function doRollback() {
  if (!confirm(t("updRollbackConfirm"))) return;
  updSetBusy(true, "updInstalling");
  try {
    const res = await fetch("/api/update/rollback", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({})
    });
    let j = {};
    try { j = await res.json(); } catch (e) {}
    const st = document.getElementById("updStatus");
    if (!res.ok) {
      const reason = errText(j.error) || res.status;
      if (st) st.textContent = t("updFailed", { error: reason });
      updSetBusy(false);
      showToast(t("updFailed", { error: reason }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: doRollback } });
      return;
    }
    if (st) st.textContent = t("updRollbackDone");
    updWaitForServer(j.version && j.version.version);
  } catch (e) { updHandleInstallError(doRollback); }
}
document.getElementById("updRollbackBtn").addEventListener("click", doRollback);

// ---- One-click auto-update (v1.10.0) ----
// The release channel is the public StudyFlow repo (latest.json manifest).
// A check only notifies; installing always needs the user's click on the
// «دانلود و نصب» button. Download progress comes from the server, which
// streams the zip, verifies its SHA-256 against the manifest, then runs
// the standard install + restart flow.
let updAutoLastPhase = null;
let updAutoPollTimer = null;
let updAutoAvailableVersion = null;
// v1.11.4 — the manifest URL the field falls back to when nothing is
// stored (mirrors DEFAULT_MANIFEST_URL in server.py).
const DEFAULT_MANIFEST_URL = "https://raw.githubusercontent.com/ParhammPm/studyflow/main/latest.json";
// Attach a click handler once: re-calling with the same element is a
// no-op, so the Backup tab can safely re-wire its buttons on every
// render (renderBackup) without double-firing.
function wireOnce(el, handler) {
  if (!el || el.dataset.wired) return;
  el.dataset.wired = "1";
  el.addEventListener("click", handler);
}
function updAutoSetBusy(busy) {
  ["updCheckBtn", "updInstallAutoBtn", "updManifestSaveBtn"].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.disabled = busy;
  });
}
function updAutoShowProgress(show) {
  const w = document.getElementById("updAutoProgressWrap");
  if (w) w.hidden = !show;
}
function updAutoSetProgress(pct) {
  const bar = document.getElementById("updAutoProgressBar");
  if (bar) bar.style.width = Math.max(0, Math.min(100, pct || 0)) + "%";
}
function updAutoRenderStatus(res) {
  const st = document.getElementById("updAutoStatus");
  const notes = document.getElementById("updAutoNotes");
  const btn = document.getElementById("updInstallAutoBtn");
  if (!st) return;
  let msg = "";
  updAutoAvailableVersion = null;
  if (btn) btn.hidden = true;
  const r = res && res.last_result;
  if (res && res.last_error) {
    msg = t("updCheckFailed", { error: res.last_error });
  } else if (r) {
    if (r.blocked_min_version) {
      msg = t("updMinVersion", { min: r.blocked_min_version });
    } else if (r.update_available) {
      msg = t("updAvailable", { version: r.version });
      updAutoAvailableVersion = r.version;
      if (btn) {
        btn.hidden = false;
        btn.textContent = t("updInstallAuto", { version: r.version });
      }
    } else {
      msg = t("updUpToDate", { version: r.current_version || (res.current && res.current.version) || "" });
    }
    if (notes) notes.textContent = r.notes || "";
  } else {
    msg = t("updNeverChecked");
  }
  if (res && res.last_check) msg += " · " + t("updLastCheck", { time: fmtBackupTs(res.last_check) });
  st.textContent = msg;
}
async function refreshAutoUpdate() {
  try {
    const res = await fetch("/api/update/auto");
    if (!res.ok) return;
    const j = await res.json();
    const urlEl = document.getElementById("updManifestUrl");
    if (urlEl && document.activeElement !== urlEl) urlEl.value = (j.config && j.config.manifest_url) || DEFAULT_MANIFEST_URL;
    updAutoRenderStatus(j);
    const st = j.state;
    if (st && (st.phase === "downloading" || st.phase === "verifying" || st.phase === "installing")) {
      updAutoPollProgress(st.version);
    }
  } catch (e) { /* server unreachable — leave the panel as-is */ }
}
function updAutoPollProgress(expectedVersion) {
  if (updAutoPollTimer) return;
  updAutoShowProgress(true);
  updAutoLastPhase = null;
  updAutoPollTimer = setInterval(async () => {
    let st;
    try {
      const res = await fetch("/api/update/auto-progress");
      if (!res.ok) throw new Error("http " + res.status);
      st = await res.json();
    } catch (e) {
      // Server down: if we were already installing, the restart is under
      // way — wait for the new server. Otherwise it is a real failure.
      if (updAutoLastPhase === "installing" || updAutoLastPhase === "done") {
        clearInterval(updAutoPollTimer); updAutoPollTimer = null;
        updWaitForServer(expectedVersion);
      } else {
        const el = document.getElementById("updAutoStatus");
        if (el) el.textContent = t("updCheckFailed", { error: t("serverUnreachable") });
        clearInterval(updAutoPollTimer); updAutoPollTimer = null;
        updAutoSetBusy(false); updSetBusy(false);
      }
      return;
    }
    updAutoLastPhase = st.phase;
    const el = document.getElementById("updAutoStatus");
    if (st.phase === "downloading") {
      updAutoSetProgress(st.percent || 0);
      if (el) el.textContent = t("updDownloading", { pct: FA(st.percent || 0) });
    } else if (st.phase === "verifying") {
      updAutoSetProgress(100);
      if (el) el.textContent = t("updVerifying");
    } else if (st.phase === "installing") {
      updAutoSetProgress(100);
      if (el) el.textContent = t("updInstalling");
    } else if (st.phase === "done") {
      clearInterval(updAutoPollTimer); updAutoPollTimer = null;
      if (el) el.textContent = t("updDone");
      updWaitForServer(st.version || expectedVersion);
    } else if (st.phase === "error") {
      clearInterval(updAutoPollTimer); updAutoPollTimer = null;
      updAutoShowProgress(false);
      if (el) el.textContent = t("updFailed", { error: st.error || "?" });
      updAutoSetBusy(false); updSetBusy(false);
    }
  }, 1000);
}
async function onUpdCheckClick() {
  const st = document.getElementById("updAutoStatus");
  updAutoSetBusy(true);
  if (st) st.textContent = t("updChecking");
  try {
    const res = await fetch("/api/update/check", { method: "POST" });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) {
      if (st) st.textContent = t("updCheckFailed", { error: errText(j.error) || res.status });
      updAutoSetBusy(false);
      return;
    }
    updAutoRenderStatus({ last_check: j.checked_at, last_result: j, last_error: null, current: { version: j.current_version } });
  } catch (e) {
    if (st) st.textContent = t("updCheckFailed", { error: t("serverUnreachable") });
  }
  updAutoSetBusy(false);
}
wireOnce(document.getElementById("updCheckBtn"), onUpdCheckClick);
async function onUpdManifestSaveClick() {
  const urlEl = document.getElementById("updManifestUrl");
  const st = document.getElementById("updAutoStatus");
  const url = urlEl ? urlEl.value.trim() : "";
  try {
    const res = await fetch("/api/update/auto-config", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ manifest_url: url })
    });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) {
      if (st) st.textContent = t("updCheckFailed", { error: errText(j.error) || res.status });
      return;
    }
    if (urlEl) urlEl.value = j.manifest_url || DEFAULT_MANIFEST_URL;
    if (st) st.textContent = t("updManifestSaved");
    // NOTE: no refreshAutoUpdate() here — it would overwrite the "saved"
    // confirmation with the last-check status. The saved state is shown
    // again the next time the Backup tab renders.
  } catch (e) {
    if (st) st.textContent = t("updCheckFailed", { error: t("serverUnreachable") });
  }
}
wireOnce(document.getElementById("updManifestSaveBtn"), onUpdManifestSaveClick);
async function onUpdInstallAutoClick() {
  const version = updAutoAvailableVersion;
  if (!version) return;
  if (!confirm(t("updInstallAutoConfirm", { version }))) return;
  updAutoSetBusy(true);
  updSetBusy(true); // also lock the manual update buttons during the install
  updAutoShowProgress(true);
  updAutoSetProgress(0);
  const st = document.getElementById("updAutoStatus");
  if (st) st.textContent = t("updDownloading", { pct: FA(0) });
  try {
    const res = await fetch("/api/update/install-auto", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ version })
    });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) {
      // v1.11.65 (Batch 6, ب-۷): same contract as the manual installs —
      // a failed auto-update says why in a toast and offers a retry.
      const reason = errText(j.error) || res.status;
      if (st) st.textContent = t("updFailed", { error: reason });
      updAutoSetBusy(false); updSetBusy(false);
      updAutoShowProgress(false);
      showToast(t("updFailed", { error: reason }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: onUpdInstallAutoClick } });
      return;
    }
    updAutoPollProgress(j.version || version);
  } catch (e) {
    if (st) st.textContent = t("updFailed", { error: t("serverUnreachable") });
    updAutoSetBusy(false); updSetBusy(false);
    updAutoShowProgress(false);
    showToast(t("updFailed", { error: t("serverUnreachable") }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: onUpdInstallAutoClick } });
  }
}
wireOnce(document.getElementById("updInstallAutoBtn"), onUpdInstallAutoClick);
// v1.11.4 — re-wire the Backup tab's buttons every time the tab renders:
// the auto-update buttons (wired once, above) and the calendar/OAuth
// panel (wireCalendarPanel is guarded internally by calWired). If the
// load-time wiring was ever skipped, the buttons still work; if it ran,
// these calls are no-ops and nothing double-fires.
function wireBackupTab() {
  wireOnce(document.getElementById("updCheckBtn"), onUpdCheckClick);
  wireOnce(document.getElementById("updManifestSaveBtn"), onUpdManifestSaveClick);
  wireOnce(document.getElementById("updInstallAutoBtn"), onUpdInstallAutoClick);
  // v1.11.42 (item 20): the styled update-file picker shows the chosen
  // file name. wireOnce is click-only, so this change listener gets
  // its own once-guard.
  const updFileEl = document.getElementById("updFile");
  if (updFileEl && !updFileEl.dataset.nameWired) {
    updFileEl.dataset.nameWired = "1";
    updFileEl.addEventListener("change", () => {
      updFileName = (updFileEl.files && updFileEl.files[0]) ? updFileEl.files[0].name : "";
      const nm = document.getElementById("updFileName");
      if (nm) nm.textContent = updFileName || t("fileNone");
    });
  }
  wireCalendarPanel();
}
// v1.11.42 (item 20): the name shown by the styled update-file picker.
let updFileName = "";
document.getElementById("bkSaveBtn").addEventListener("click", async () => {
  const st = document.getElementById("bkB2Status");
  const body = {
    endpoint: document.getElementById("bkEndpoint").value.trim(),
    bucket: document.getElementById("bkBucket").value.trim() || "konkur-backup",
    key_id: document.getElementById("bkKeyId").value.trim(),
    application_key: document.getElementById("bkAppKey").value.trim(),
    enabled: true
  };
  try {
    const res = await fetch("/api/backup/b2-config", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    if (res.ok) {
      document.getElementById("bkAppKey").value = "";
      document.getElementById("bkKeyId").value = "";
      if (st) st.textContent = t("bkB2Saved");
      alert(t("bkB2Saved"));
    } else {
      const j = await res.json().catch(() => ({}));
      if (st) st.textContent = errText(j.error) || t("bkB2TestFail");
    }
  } catch (e) { if (st) st.textContent = t("serverUnreachable"); }
  refreshBackupStatus(); renderBackup();
});
document.getElementById("bkTestBtn").addEventListener("click", async () => {
  const st = document.getElementById("bkB2Status");
  if (st) st.textContent = t("analyzing");
  try {
    const res = await fetch("/api/backup/b2-test", { method: "POST" });
    const j = await res.json();
    if (st) st.textContent = j.ok ? t("bkB2TestOk") : t("bkB2TestFail") + (j.error ? ": " + errText(j.error) : "");
  } catch (e) { if (st) st.textContent = t("serverUnreachable"); }
});
document.getElementById("bkClearBtn").addEventListener("click", async () => {
  if (!confirm(t("bkB2ClearConfirm"))) return;
  const st = document.getElementById("bkB2Status");
  try {
    await fetch("/api/backup/b2-clear", { method: "POST" });
    document.getElementById("bkKeyId").value = "";
    document.getElementById("bkAppKey").value = "";
    if (st) st.textContent = t("bkB2Cleared");
  } catch (e) { if (st) st.textContent = t("serverUnreachable"); }
  refreshBackupStatus(); renderBackup();
});


// ---- Calendar sync (v1.8.0 pull, v1.11.0 two-way): ICS pull + manual file
// import for reading; OAuth 2.0 (Desktop-app client) pushes app edits back
// to Google Calendar. Credentials + tokens live server-side only and are
// only ever shown masked. Push is debounced server-side (~15s after a box
// edit) plus a manual «ارسال تغییرات به گوگل» button.
let calImportContent = "", calImportFilename = "";
let calWired = false;
// The Client ID is a public identifier (not a secret): the v1.11.0 design
// pre-fills it as the default. The server backfills the same default when
// nothing is stored, so the field must never look mysteriously empty.
const DEFAULT_GOOGLE_CLIENT_ID = "695272599724-cv1g08aem3ajt079bj11dfdb96c1ibsg.apps.googleusercontent.com";
let calClientIdAutofilled = false;
function calSummaryText(sm) {
  if (!sm) return "";
  let out = t("calAdded", { n: FA(sm.added || 0) }) + " · " + t("calUpdated", { n: FA(sm.updated || 0) }) + " · " + t("calRemoved", { n: FA(sm.removed || 0) });
  if (sm.skipped_tombstone) out += " · " + t("calSkippedTomb", { n: FA(sm.skipped_tombstone) });
  if (sm.kept_touched) out += " · " + t("calKeptTouched", { n: FA(sm.kept_touched) });
  if (sm.conflicts) out += " · " + t("calConflictsTitle") + ": " + FA(sm.conflicts);
  return out;
}
function calPushSummaryText(sm) {
  if (!sm) return "";
  return t("calPushDone", { c: FA(sm.created || 0), u: FA(sm.updated || 0), d: FA(sm.removed || 0) }) + (sm.error_count ? " · ⚠ " + FA(sm.error_count) : "");
}
// --- Unlinked Google events cache (v1.11.9): feeds the reconnect picker.
// Refreshed at load and after every manual sync; the menu enables
// «اتصال مجدد» only when this list is non-empty (a real reconnection
// must be possible).
let UNLINKED = { unlinked_events: [], unlinked_boxes: [] };
async function refreshUnlinked() {
  try {
    const r = await fetch("/api/calendar/unlinked");
    if (r.ok) UNLINKED = await r.json();
  } catch (e) { /* offline: keep the last known list */ }
}
// ---- Single connection-health card (v1.11.30, P1-3) ----
// One dashboard card for the REAL state of both connections (ICS pull
// + OAuth push), built from the same /api/calendar/status payload the
// Calendar tab renders — no second source of truth, no scattered
// status bits. Refreshed on every dashboard render, after every
// topbar sync, and on the 60 s tick. Shows «not configured» / «never
// synced» / errors plainly instead of looking in-sync when it is not.
async function renderConnHealth() {
  const el = document.getElementById("dashConnHealth");
  if (!el) return;
  const st = await getCalStatus(); // v1.11.55 (PERF-01): shared fetch
  if (!st) {
    el.innerHTML = '<div class="conn-health-title">' + esc(t("connHealthTitle")) + '</div>' +
      '<p class="muted">' + esc(t("serverUnreachable")) + '</p>';
    return;
  }
  const cfg = st.config || {};
  const oAuth = st.oauth || {};
  const push = st.push || {};
  const row = (label, val) => '<div class="conn-row"><span>' + esc(label) + '</span><b>' + val + '</b></div>';
  let icsTxt;
  if (!cfg.configured) icsTxt = esc(t("calNoConfig"));
  else {
    icsTxt = cfg.last_sync
      ? esc(t("calLastSync", { t: fmtBackupTs(cfg.last_sync) })) + (cfg.last_summary ? " — " + esc(calSummaryText(cfg.last_summary)) : "")
      : esc(t("calNeverSynced"));
    if (cfg.last_error) icsTxt += ' · ⚠ ' + esc(cfg.last_error);
  }
  let oauthTxt;
  if (oAuth.connected) {
    oauthTxt = esc(t("calOAuthConnected", { email: oAuth.email || "—", t: oAuth.expires_at ? fmtBackupTs(new Date(oAuth.expires_at * 1000).toISOString()) : "—" }));
    if (oAuth.token_refresh_expires_soon) {
      oauthTxt += " — " + esc(t("calOAuthTokenSoon", { n: FA(oAuth.token_refresh_days_left != null ? oAuth.token_refresh_days_left : 1) }));
    }
  } else {
    oauthTxt = esc(t(oAuth.credentials_set ? "calOAuthNotConnected" : "calOAuthNoCreds"));
  }
  let pushTxt;
  if (!push.connected) {
    pushTxt = esc(t("calPushNotConnected"));
  } else {
    const parts = [];
    if (push.pending_count) parts.push(esc(t("calPushPending", { n: FA(push.pending_count) })));
    const lp = push.last_push;
    if (lp) {
      parts.push(esc(t("calPushLast", { t: fmtBackupTs(lp.ts), s: lp.ok ? calPushSummaryText(lp.summary) : (errText(lp.error) || t("calError")) })));
    } else if (!parts.length) {
      parts.push(esc(t("calPushNever")));
    }
    pushTxt = parts.join(" · ");
  }
  let html = '<div class="conn-health-title">' + esc(t("connHealthTitle")) + '</div>' +
    row(t("connHealthIcs"), icsTxt) +
    row(t("connHealthOAuth"), oauthTxt) +
    row(t("connHealthPush"), pushTxt);
  const conf = push.conflicts || [];
  if (conf.length) html += row(t("connHealthConflicts"), FA(conf.length));
  el.innerHTML = html;
}
// v1.11.65 (Batch 6, L-PERF6): a manual sync/push must never hang the
// UI forever — every manual calendar fetch goes through here with a
// 120 s client timeout (AbortSignal.timeout where the runtime has it,
// else a manual AbortController + setTimeout). The timeout is a
// module-level let so the jsdom harness can shorten it for the probe.
let SYNC_TIMEOUT_MS = 120000;
function fetchWithTimeout(url, opts, ms) {
  ms = (ms == null ? SYNC_TIMEOUT_MS : ms);
  if (typeof AbortSignal !== "undefined" && typeof AbortSignal.timeout === "function") {
    return fetch(url, Object.assign({}, opts, { signal: AbortSignal.timeout(ms) }));
  }
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  const done = (v) => { clearTimeout(timer); return v; };
  return fetch(url, Object.assign({}, opts, { signal: ctrl.signal })).then(done, (e) => { clearTimeout(timer); throw e; });
}
// --- Topbar manual sync (v1.11.9): the same POST /api/calendar/sync
// the Backup tab's manual button calls. While a sync is running the
// button is disabled (a second click cannot start another sync); after
// it finishes, the short result shows next to the button, and an error
// shows short and readable.
let calSyncBusy = false;
async function topbarSync() {
  if (calSyncBusy) return;
  calSyncBusy = true;
  const btn = document.getElementById("calSyncPill");
  const res = document.getElementById("calSyncResult");
  // v1.11.65 (Batch 6, ب-۷): a spinner on the button while the sync
  // runs — the three-state contract (in progress → done → failed,
  // because… [retry]) starts here.
  if (btn) { btn.disabled = true; btn.classList.add("syncing"); btn.textContent = t("calSyncing"); }
  const retrySync = () => topbarSync();
  try {
    const r = await fetchWithTimeout("/api/calendar/sync", { method: "POST" });
    const j = await r.json();
    if (r.ok && j.summary) {
      const sm = j.summary;
      const pullTxt = t("calSyncResultShort", {
        t: fmtBackupTs(new Date().toISOString()),
        a: FA(sm.added || 0), u: FA(sm.updated || 0), d: FA(sm.unlinked || 0)
      });
      // v1.11.30 (P1-3): the topbar button is honest — it pulls AND
      // pushes, and reports BOTH. A push that never ran (not
      // connected) or failed is shown, never silently swallowed.
      // v1.11.45 (E-17): the toast follows the same rule — success only
      // when BOTH legs succeeded, an error toast when the push failed.
      let pushTxt = "";
      let pushOk = false;
      let pushErr = null;
      try {
        const pr = await fetchWithTimeout("/api/calendar/push", { method: "POST" });
        const pj = await pr.json();
        if (pr.ok && pj.summary) {
          pushTxt = t("calSyncPushLabel") + ": " + calPushSummaryText(pj.summary);
          pushOk = !((pj.summary.errors || []).length);
          if (!pushOk) pushErr = (pj.summary.errors || [])[0] || null;
        } else {
          const firstErr = pj && pj.summary && pj.summary.errors && pj.summary.errors[0];
          pushErr = firstErr ? errText(firstErr) : (errText(pj.error) || t("calError"));
          pushTxt = t("calSyncPushLabel") + ": " + pushErr;
        }
      } catch (e2) {
        pushErr = (e2 && e2.name === "AbortError") ? t("syncTimeout") : t("serverUnreachable");
        pushTxt = t("calSyncPushLabel") + ": " + pushErr;
      }
      if (res) {
        res.hidden = false;
        res.classList.remove("err");
        res.textContent = pullTxt + " · " + pushTxt;
      }
      if (pushOk) showToast(t("toastSyncDone")); // v1.11.41: sync completion toasts, like other done actions
      else showToast(t("syncFailedReason", { e: pushErr || t("calError") }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: retrySync } });
      // v1.11.10: apply the fresh link data BEFORE re-rendering, or the
      // dashboard re-renders with the pre-sync links and the corner
      // boxes only flip on the next render.
      invalidateCalStatus(); // v1.11.55 (PERF-01): sync+push changed status
      await renderCalendarPanel();
      renderConnHealth();
      await refreshDataFromServer();
      await refreshUnlinked();
    } else {
      const reason = errText(j.error) || t("calError");
      if (res) {
        res.hidden = false;
        res.classList.add("err");
        res.textContent = "⚠ " + shortErr(j.error || t("calError"));
      }
      showToast(t("syncFailedReason", { e: reason }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: retrySync } });
    }
  } catch (e) {
    const reason = (e && e.name === "AbortError") ? t("syncTimeout") : t("serverUnreachable");
    if (res) {
      res.hidden = false;
      res.classList.add("err");
      res.textContent = "⚠ " + reason;
    }
    showToast(t("syncFailedReason", { e: reason }), { kind: "err", ms: 8000, action: { label: t("retryBtn"), fn: retrySync } });
  } finally {
    calSyncBusy = false;
    if (btn) { btn.disabled = false; btn.classList.remove("syncing"); btn.textContent = t("calSyncBtnTop"); }
  }
}
// Short, readable error for the topbar result (server errors can be long).
// --- Server error translation (v1.11.14): the server returns Persian error
// strings; in EN mode they must read English. errText maps known server
// messages (exact, prefix, or title-capturing patterns) to i18n keys;
// unknown strings pass through unchanged (raw Google/B2 SDK details are
// already English). User data inside a message (a box title) is preserved
// as-is — only the surrounding sentence is translated.
const SERVER_ERR_EXACT = {
  "آدرس ICS تنظیم نشده است": "errIcsNotSet",
  "آدرس ICS باید با https:// شروع شود": "errIcsHttps",
  "فایل ICS خیلی بزرگ است": "errIcsTooBig",
  "گوگل متصل نیست — اول «اتصال به گوگل» را بزن": "errGoogleNotConnected",
  "توکن گوگل منقضی شده و توکن تمدید نیست — دوباره متصل شو": "errGoogleTokenExpired",
  "توکن گوگل رد شد — دوباره متصل شو": "errGoogleTokenRejected",
  "توکن ۷روزه منقضی شد — دوباره وصل شو": "errToken7dExpired",
  "این باکس در حال همگام‌سازی است — چند لحظه دیگر دوباره تلاش کن": "errBoxSyncing",
  "شروع و پایان باکس نمی‌توانند برابر باشند": "errBoxZeroLength",
  "اول Client Secret را ذخیره کن": "errClientSecretFirst",
  "درخواست ورود معتبر نیست یا منقضی شده — دوباره «اتصال به گوگل» را بزن": "errAuthRequestInvalid",
  "فایل به‌روزرسانی خیلی بزرگ است": "errUpdateTooBig",
  "فایل zip خیلی بزرگ است": "errZipTooBig",
  "هش فایل دانلودشده با مانیفست مطابقت ندارد — نصب انجام نشد": "errHashMismatch",
  "ساختار JSON شناخته نشد — باید {items: [...]} یا آرایه‌ای از رویدادها باشد": "errJsonStructure",
  "عنوان باکس خالی است": "errBoxTitleEmpty",
  "تاریخ باکس خالی است": "errBoxDateEmpty",
  "شناسه‌ی باکس خالی است": "errBoxIdEmpty",
  "این باکس حذف شده است": "errBoxDeleted",
  "باکسی با این شناسه پیدا نشد": "errBoxNotFound",
  "هیچ فیلدی برای تغییر داده نشده است": "errNoFields",
  "شناسه‌ی رویداد خالی است": "errEventIdEmpty",
  "باکس دستی به رویداد تقویم وصل نمی‌شود": "errCustomNoLink",
  "رویدادی با این شناسه در آخرین سینک پیدا نشد": "errEventNotInSync",
  "این رویداد قبلاً در برنامه حذف شده است": "errEventAlreadyDeleted",
  "پشتیبان‌گیری قبل از اتصال ممکن نشد — هیچ تغییری اعمال نشد": "errBackupBeforeLink",
  "گوگل شناسه‌ی رویداد نداد": "errEventNoId",
  // v1.11.25 (QA BUG-026): these three server errors had no mapping and
  // showed as raw Persian in English mode.
  "B2 تنظیم نشده است": "errB2NotConfigured",
  "در فایل هیچ رویداد درسی پیدا نشد": "errNoStudyEvents"
};
const SERVER_ERR_PREFIX = [
  ["ارتباط با گوگل ممکن نشد: ", "errGoogleUnreachable"],
  ["فایل JSON معتبر نیست: ", "errJsonInvalid"],
  ["آماده‌سازی همگام‌سازی دوطرفه ممکن نشد: ", "errTwoWayPrep"],
  ["خواندن فایل ممکن نشد: ", "errReadFile"],
  // v1.11.25 (QA BUG-026): Gemini server errors — the HTTP code / detail
  // after the prefix is kept verbatim (it is a number / technical text).
  ["خطای سرور جمینای: HTTP ", "errGeminiServer"],
  ["ارتباط با جمینای برقرار نشد: ", "errGeminiUnreachable"]
];
function errText(s) {
  s = String(s == null ? "" : s);
  if (!s) return s;
  const ex = SERVER_ERR_EXACT[s];
  if (ex) return t(ex);
  for (const [pre, key] of SERVER_ERR_PREFIX) {
    if (s.indexOf(pre) === 0) return t(key) + ": " + s.slice(pre.length);
  }
  let m;
  if ((m = s.match(/^حذف «(.+?)»: (.*)$/))) return t("errPushDelete", { title: m[1] }) + ": " + m[2];
  if ((m = s.match(/^به‌روز وضعیت «(.+?)»: (.*)$/))) return t("errPushUpdateStatus", { title: m[1] }) + ": " + m[2];
  if ((m = s.match(/^به‌روز «(.+?)»: (.*)$/))) return t("errPushUpdate", { title: m[1] }) + ": " + m[2];
  if ((m = s.match(/^ساخت «(.+?)»: (.*)$/))) return t("errPushCreate", { title: m[1] }) + ": " + m[2];
  if ((m = s.match(/^رویداد «(.+?)» در گوگل پیدا نشد( — پیوندش برداشته شد)?$/)))
    return t("errEventNotFoundGoogle", { title: m[1] }) + (m[2] ? " — " + t("errEventLinkRemoved") : "");
  if ((m = s.match(/^«(.+?)» در تقویم عوض شده بود — ویرایش برنامه فرستاده نشد؛ در همگام‌سازی بعدی نسخه‌ی تقویم اعمال می‌شود$/)))
    return t("errChangedInCalendar", { title: m[1] });
  if ((m = s.match(/^بررسی زنده‌ی تقویم ممکن نشد — ویرایش «(.+?)» فرستاده نشد؛ در همگام‌سازی بعدی دوباره تلاش می‌شود$/)))
    return t("errLiveCheckFailed", { title: m[1] });
  if ((m = s.match(/^این رویداد به باکس «(.+?)» وصل است که داده‌ی کاربر دارد — اول آن را حذف یا جابه‌جا کن$/)))
    return t("errEventLinked", { title: m[1] });
  // v1.11.45 (U-05): an unmatched server error in EN mode used to
  // fall through as raw Persian — prefix it with the English generic
  // label instead. (In fa mode the raw string is already readable.)
  if (LANG === "en") return t("errUnknownServer") + ": " + s;
  return s;
}
function shortErr(s) {
  s = errText(s);
  return s.length > 80 ? s.slice(0, 80) + "…" : s;
}
async function renderCalendarPanel() {
  const st = await getCalStatus(); // v1.11.55 (PERF-01): shared fetch
  if (!st) return;
  // v1.11.10: every status refresh also refreshes the per-box link data
  // (this is the single choke point for the 60 s tick, both manual sync
  // buttons and the settings saves) — the next render then shows the
  // fresh connection corner boxes without a page reload.
  applyCalendarLinks(st);
  const cfg = st.config || {};
  const urlEl = document.getElementById("calIcsUrl");
  if (urlEl) urlEl.placeholder = cfg.ics_url_masked || t("calIcsPh");
  const intEl = document.getElementById("calInterval");
  // Do not overwrite the interval input while the user is typing in it
  // (the 60 s refresh used to eat the half-typed value).
  if (intEl && document.activeElement !== intEl) intEl.value = cfg.interval_minutes || 30;
  const enEl = document.getElementById("calEnabled");
  if (enEl) enEl.checked = !!cfg.enabled;
  const stEl = document.getElementById("calStatus");
  if (stEl) {
    stEl.textContent = cfg.configured
      ? (cfg.last_sync ? t("calLastSync", { t: fmtBackupTs(cfg.last_sync) }) + (cfg.last_summary ? " — " + calSummaryText(cfg.last_summary) : "") : t("calNeverSynced")) + (cfg.last_error ? " · \u26a0 " + cfg.last_error : "")
      : t("calNoConfig");
  }
  const psEl = document.getElementById("calProgStats");
  if (psEl && st.programme) psEl.textContent = t("calProgrammeStats", { n: FA(st.programme.box_count || 0), m: FA(st.programme.mapped || 0), tb: FA(st.programme.tombstones || 0) });
  // --- OAuth + push status (v1.11.0) ---
  const oAuth = st.oauth || {};
  const push = st.push || {};
  // v1.11.42 (item 17): per-step status pills — step 1 is the OAuth
  // connection, step 2 the ICS address, step 3 (manual import) is
  // always ready because it needs no connection at all.
  const s1 = document.getElementById("calStep1Status");
  if (s1) {
    s1.textContent = oAuth.connected ? t("calStepConnected") : t("calStepNotConnected");
    s1.classList.toggle("ok", !!oAuth.connected);
  }
  const s2 = document.getElementById("calStep2Status");
  if (s2) {
    s2.textContent = cfg.configured ? t("calStepSet") : t("calStepNotSet");
    s2.classList.toggle("ok", !!cfg.configured);
  }
  const s3 = document.getElementById("calStep3Status");
  if (s3) { s3.textContent = t("calStepReady"); s3.classList.add("ok"); }
  // v1.11.42 (item 20): the styled file picker shows the chosen file
  // name (or «فایلی انتخاب نشده») — refreshed here so a language
  // switch never leaves a stale label behind.
  const cfName = document.getElementById("calFileName");
  if (cfName) cfName.textContent = calImportFilename || t("fileNone");
  const cidEl = document.getElementById("calClientId");
  if (cidEl) {
    cidEl.placeholder = oAuth.client_id_masked || t("calClientIdPh");
    // Pre-fill the public default Client ID when nothing is stored yet,
    // so the field is never mysteriously empty (v1.11.4). Only once per
    // page load, never over a stored ID (masked placeholder) and never
    // while the user is typing in the field.
    if (!oAuth.client_id_masked && !calClientIdAutofilled && !cidEl.value && document.activeElement !== cidEl) {
      cidEl.value = DEFAULT_GOOGLE_CLIENT_ID;
      calClientIdAutofilled = true;
    }
  }
  const oEl = document.getElementById("calOAuthStatus");
  if (oEl) {
    oEl.textContent = oAuth.connected
      ? t("calOAuthConnected", { email: oAuth.email || "—", t: oAuth.expires_at ? fmtBackupTs(new Date(oAuth.expires_at * 1000).toISOString()) : "—" })
      : (oAuth.credentials_set ? t("calOAuthNotConnected") : t("calOAuthNoCreds"));
    // v1.11.16 (audit §5 item 1.4): Testing-mode refresh tokens live
    // 7 days — warn while there is still time to reconnect.
    if (oAuth.connected && oAuth.token_refresh_expires_soon) {
      oEl.textContent += " — " + t("calOAuthTokenSoon", { n: FA(oAuth.token_refresh_days_left != null ? oAuth.token_refresh_days_left : 1) });
    }
  }
  // v1.11.66 (Batch 7, M1): the Calendar tab's primary follows the
  // connection state — connection is the prerequisite of sync, so
  // while disconnected «اتصال به گوگل» is the primary and
  // «همگام‌سازی اکنون» is plain; once connected they swap.
  const ccBtn = document.getElementById("calConnectBtn");
  const csBtn = document.getElementById("calSyncBtn");
  if (ccBtn && csBtn) {
    ccBtn.classList.toggle("btn-primary", !oAuth.connected);
    ccBtn.classList.toggle("page-primary", !oAuth.connected);
    csBtn.classList.toggle("btn-primary", !!oAuth.connected);
    csBtn.classList.toggle("page-primary", !!oAuth.connected);
  }
  const pEl = document.getElementById("calPushStatus");
  if (pEl) {
    let txt = "";
    if (!push.connected) {
      txt = t("calPushNotConnected");
    } else {
      if (push.pending_count) txt += t("calPushPending", { n: FA(push.pending_count) });
      const lp = push.last_push;
      if (lp) {
        if (txt) txt += " · ";
        txt += t("calPushLast", { t: fmtBackupTs(lp.ts), s: lp.ok ? calPushSummaryText(lp.summary) : (errText(lp.error) || t("calError")) });
      } else if (!txt) {
        txt = t("calPushNever");
      }
    }
    pEl.textContent = txt;
  }
  const cfEl = document.getElementById("calConflicts");
  if (cfEl) {
    const conf = push.conflicts || [];
    cfEl.innerHTML = conf.length
      ? '<p><b>' + t("calConflictsTitle") + '</b></p>' + conf.map(c =>
          '<p class="muted">\u26a0 ' + esc(t("calConflictNote", { title: c.title || c.box_id })) + '</p>').join("")
      : "";
  }
  const logEl = document.getElementById("calLog");
  if (logEl) {
    const log = st.log || [];
    logEl.innerHTML = log.length ? log.slice().reverse().map(e =>
      '<div class="cal-log-row"><b>' + esc(fmtBackupTs(e.ts)) + ' · ' + esc(e.source || "") + '</b><br>' +
      esc(calSummaryText(e.summary || {})) +
      ((e.lines || []).length ? '<br><span class="muted">' + esc((e.lines || []).slice(0, 5).join(" | ")) + '</span>' : '') + '</div>').join("") : '<p class="muted">' + t("calLogEmpty") + '</p>';
    // v1.11.8: the log grows with auto-sync (up to 20 entries) — show
    // only the latest 3 by default; the rest hide behind the shared
    // «show more» toggle (same pattern as the backup version lists).
    // Display-only: the stored log payload is untouched.
    if (log.length) attachCollapsible(logEl, ".cal-log-row", 3);
  }
}
function readFileText(f) {
  return new Promise((resolve, reject) => {
    if (f.text) { f.text().then(resolve, () => {
      const r = new FileReader(); r.onload = () => resolve(r.result); r.onerror = reject; r.readAsText(f);
    }); return; }
    const r = new FileReader(); r.onload = () => resolve(r.result); r.onerror = reject; r.readAsText(f);
  });
}
// Opening the Google sign-in URL: window.open() from an async fetch
// callback is NOT a user gesture, so Chrome blocks it as a popup —
// silently, with no error and no status change (that was the dead
// «اتصال به گوگل» button: the handler ran, the popup died). Try a new
// tab first; when the browser blocks it, navigate this tab instead —
// the OAuth callback lands on this same server
// (127.0.0.1:8765/oauth/callback), so the flow completes either way.
function navigateTo(url) { window.location.href = url; }
function openAuthUrl(url) {
  let opened = null;
  try { opened = window.open(url, "_blank"); } catch (e) { opened = null; }
  if (!opened) navigateTo(url);
  return !!opened;
}
function wireCalendarPanel() {
  if (calWired) return; calWired = true;
  const saveBtn = document.getElementById("calSaveBtn");
  if (saveBtn) saveBtn.addEventListener("click", async () => {
    const st = document.getElementById("calStatus");
    const url = (document.getElementById("calIcsUrl").value || "").trim();
    const interval = parseInt((document.getElementById("calInterval").value || "30"), 10) || 30;
    const enabled = document.getElementById("calEnabled").checked;
    try {
      const res = await fetch("/api/calendar/config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ics_url: url, interval_minutes: interval, enabled }) });
      const j = await res.json();
      if (res.ok) { document.getElementById("calIcsUrl").value = ""; if (st) st.textContent = t("calSaved"); }
      else if (st) st.textContent = errText(j.error) || t("calError");
    } catch (e) { if (st) st.textContent = t("serverUnreachable"); }
    invalidateCalStatus(); // v1.11.55 (PERF-01): the config changed
    renderCalendarPanel();
  });
  const syncBtn = document.getElementById("calSyncBtn");
  if (syncBtn) syncBtn.addEventListener("click", async () => {
    // v1.11.45 (E-17): the Backup-tab button pulls AND pushes, like
    // the topbar pill — it used to pull only, so local edits never
    // reached Google from this button.
    const st = document.getElementById("calStatus");
    if (st) st.textContent = t("calSyncing");
    try {
      const res = await fetchWithTimeout("/api/calendar/sync", { method: "POST" });
      const j = await res.json();
      if (res.ok && j.summary) {
        let txt = calSummaryText(j.summary);
        try {
          const pr = await fetchWithTimeout("/api/calendar/push", { method: "POST" });
          const pj = await pr.json();
          if (pr.ok && pj.summary) txt += " · " + t("calSyncPushLabel") + ": " + calPushSummaryText(pj.summary);
          else {
            const firstErr = pj && pj.summary && pj.summary.errors && pj.summary.errors[0];
            txt += " · " + t("calSyncPushLabel") + ": " + (firstErr ? errText(firstErr) : (errText(pj.error) || t("calError")));
          }
        } catch (e2) { txt += " · " + t("calSyncPushLabel") + ": " + ((e2 && e2.name === "AbortError") ? t("syncTimeout") : t("serverUnreachable")); }
        if (st) st.textContent = txt;
        invalidateCalStatus(); // v1.11.55 (PERF-01)
        await renderCalendarPanel(); await refreshDataFromServer(); await refreshUnlinked();
      }
      else if (st) st.textContent = (errText(j.error) || t("calError"));
    } catch (e) { if (st) st.textContent = (e && e.name === "AbortError") ? t("syncTimeout") : t("serverUnreachable"); }
    renderCalendarPanel();
  });
  const clearBtn = document.getElementById("calClearBtn");
  if (clearBtn) clearBtn.addEventListener("click", async () => {
    if (!confirm(t("calClearConfirm"))) return;
    try { await fetch("/api/calendar/clear", { method: "POST" }); } catch (e) {}
    invalidateCalStatus(); // v1.11.55 (PERF-01)
    renderCalendarPanel();
  });
  // --- OAuth + push wiring (v1.11.0) ---
  const oSaveBtn = document.getElementById("calOAuthSaveBtn");
  if (oSaveBtn) oSaveBtn.addEventListener("click", async () => {
    const st = document.getElementById("calOAuthStatus");
    const cid = (document.getElementById("calClientId").value || "").trim() || DEFAULT_GOOGLE_CLIENT_ID;
    const csec = (document.getElementById("calClientSecret").value || "").trim();
    try {
      const res = await fetch("/api/calendar/oauth/credentials", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ client_id: cid, client_secret: csec }) });
      const j = await res.json();
      if (res.ok) {
        // The secret is never echoed back (by design); the Client ID is
        // public, so it stays visible in the field after saving.
        document.getElementById("calClientSecret").value = "";
        // Update from the response directly: a full panel re-render here
        // would immediately overwrite the "saved" confirmation.
        const cidEl = document.getElementById("calClientId");
        if (cidEl && j.client_id_masked) cidEl.placeholder = j.client_id_masked;
        if (st) st.textContent = t("calOAuthSaved");
      } else if (st) st.textContent = errText(j.error) || t("calError");
    } catch (e) { if (st) st.textContent = t("serverUnreachable"); }
  });
  const connBtn = document.getElementById("calConnectBtn");
  if (connBtn) connBtn.addEventListener("click", async () => {
    const st = document.getElementById("calOAuthStatus");
    if (st) st.textContent = t("calOAuthOpening");
    try {
      const res = await fetch("/api/calendar/oauth/auth-url");
      const j = await res.json();
      if (res.ok && j.url) openAuthUrl(j.url);
      else if (st) st.textContent = errText(j.error) || t("calOAuthNoClient");
    } catch (e) { if (st) st.textContent = t("serverUnreachable"); }
  });
  const disBtn = document.getElementById("calDisconnectBtn");
  if (disBtn) disBtn.addEventListener("click", async () => {
    if (!confirm(t("calOAuthDisconnectConfirm"))) return;
    const st = document.getElementById("calOAuthStatus");
    try {
      const res = await fetch("/api/calendar/oauth/disconnect", { method: "POST" });
      if (res.ok) {
        invalidateCalStatus(); // v1.11.55 (PERF-01)
        // v1.11.66 (Batch 7, M1): re-render the panel so the primary
        // swaps back to «اتصال به گوگل», then re-apply the
        // "disconnected" confirmation on top — a plain re-render would
        // show the generic not-connected status instead.
        await renderCalendarPanel();
        if (st) st.textContent = t("calOAuthDisconnected");
        const pEl = document.getElementById("calPushStatus");
        if (pEl) pEl.textContent = t("calPushNotConnected");
        const cfEl = document.getElementById("calConflicts");
        if (cfEl) cfEl.innerHTML = "";
      }
    } catch (e) { if (st) st.textContent = t("serverUnreachable"); }
  });
  const pushBtn = document.getElementById("calPushBtn");
  if (pushBtn) pushBtn.addEventListener("click", async () => {
    const st = document.getElementById("calPushStatus");
    if (st) st.textContent = t("calPushing");
    try {
      const res = await fetchWithTimeout("/api/calendar/push", { method: "POST" });
      const j = await res.json();
      if (res.ok && j.summary) { if (st) st.textContent = calPushSummaryText(j.summary); }
      else if (st) st.textContent = t("calPushFailed", { e: errText(j.error) || t("calError") });
    } catch (e) { if (st) st.textContent = (e && e.name === "AbortError") ? t("syncTimeout") : t("serverUnreachable"); }
    invalidateCalStatus(); // v1.11.55 (PERF-01): the push changed status
    renderCalendarPanel();
  });
  const fileEl = document.getElementById("calFile");
  const prevEl = document.getElementById("calImportPreview");
  const applyBtn = document.getElementById("calImportApplyBtn");
  const cancelBtn = document.getElementById("calImportCancelBtn");
  const hideImportActions = () => { if (applyBtn) applyBtn.hidden = true; if (cancelBtn) cancelBtn.hidden = true; };
  if (fileEl) fileEl.addEventListener("change", async () => {
    const f = fileEl.files && fileEl.files[0];
    if (!f) return;
    calImportFilename = f.name;
    const cfName = document.getElementById("calFileName");
    if (cfName) cfName.textContent = f.name;
    try { calImportContent = await readFileText(f); } catch (e) { if (prevEl) prevEl.textContent = t("calError"); return; }
    if (prevEl) prevEl.innerHTML = '<p class="muted">' + t("calSyncing") + '</p>';
    try {
      const res = await fetch("/api/calendar/import-preview", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ filename: f.name, content: calImportContent }) });
      const j = await res.json();
      if (!res.ok) { if (prevEl) prevEl.innerHTML = '<p class="muted">\u26a0 ' + esc(errText(j.error) || t("calError")) + '</p>'; hideImportActions(); return; }
      const sm = j.summary || {};
      if (prevEl) prevEl.innerHTML = '<p><b>' + t("calImportPreviewTitle") + ' — ' + esc(f.name) + '</b></p><p>' + calSummaryText(sm) + '</p>' +
        ((sm.added_titles || []).length ? '<p class="muted">+ ' + esc(sm.added_titles.join(" · ")) + '</p>' : '') +
        ((sm.updated_titles || []).length ? '<p class="muted">~ ' + esc(sm.updated_titles.join(" · ")) + '</p>' : '') +
        ((sm.removed_titles || []).length ? '<p class="muted">\\u2212 ' + esc(sm.removed_titles.join(" · ")) + '</p>' : '');
      if (applyBtn) applyBtn.hidden = false;
      if (cancelBtn) cancelBtn.hidden = false;
    } catch (e) { if (prevEl) prevEl.textContent = t("serverUnreachable"); hideImportActions(); }
  });
  if (applyBtn) applyBtn.addEventListener("click", async () => {
    const st = document.getElementById("calStatus");
    if (!calImportContent) return;
    try {
      const res = await fetch("/api/calendar/import", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ filename: calImportFilename, content: calImportContent }) });
      const j = await res.json();
      if (res.ok && j.summary) {
        if (st) st.textContent = calSummaryText(j.summary);
        if (prevEl) prevEl.innerHTML = '<p><b>' + t("calImportApplied") + '</b> — ' + calSummaryText(j.summary) + '</p>';
        await refreshDataFromServer();
      } else if (st) st.textContent = (errText(j.error) || t("calError"));
    } catch (e) { if (st) st.textContent = t("serverUnreachable"); }
    calImportContent = ""; calImportFilename = "";
    if (fileEl) fileEl.value = "";
    hideImportActions();
    renderCalendarPanel();
  });
  if (cancelBtn) cancelBtn.addEventListener("click", () => {
    calImportContent = ""; calImportFilename = "";
    if (fileEl) fileEl.value = "";
    const cfName = document.getElementById("calFileName");
    if (cfName) cfName.textContent = t("fileNone");
    if (prevEl) prevEl.innerHTML = "";
    hideImportActions();
  });
}


// ---------- v1.11.33 (P2-9): global search ----------
// One topbar box over boxes, exams and book topics. A result jumps to the
// right tab and row: a box to its study day in the programme (scrolled to
// the card), an exam to its detail, a book topic to its row in Testbook.
// The results panel is appended to document.body (fixed position under
// the input), so no topbar overflow rule can clip it.
let GS_PANEL = null;
let GS_TIMER = null;
// v1.11.43 (§17 idea 8): the grouped search — the SAME matching as
// P2-9 (topbar search), grouped by type so the Ctrl+K palette can
// show «باکس‌ها / آزمون‌ها / کتاب تست» sections. globalSearchResults
// is the old flat view (boxes + exams + topics, max 8) — kept for the
// topbar dropdown and its tests.
function globalSearchGrouped(q) {
  q = (q || "").trim();
  if (q.length < 2) return { boxes: [], exams: [], topics: [], asgs: [], errnbs: [] };
  const lower = q.toLowerCase();
  const hit = hay => hay.indexOf(q) >= 0 || hay.toLowerCase().indexOf(lower) >= 0;
  const boxes = [], exams = [], topics = [], asgs = [], errnbs = [];
  allBoxes().forEach(b => {
    if (hit([b.title, b.subject, b.topic].filter(Boolean).join(" ")))
      boxes.push({ kind: "box", label: b.title, sub: (boxStudyDay(b) || b.date) + " · " + subjName(b.subject), box: b });
  });
  allExams().forEach(ex => {
    // The display name of a Maz exam is just «مرحله ۵» — include the
    // group name too, so «ماز» finds the Maz exams.
    if (hit(examDisplayName(ex) + " " + t(examGroupKey(ex.group))))
      exams.push({ kind: "exam", label: examDisplayName(ex), sub: examDateText(ex), exam: ex });
  });
  (TESTBOOK.books || []).forEach(book => (book.chapters || []).forEach(ch => (ch.topics || []).forEach(tp => {
    if (hit(chapterTitle(ch) + " " + topicTitle(tp) + " " + bookName(book)))
      topics.push({ kind: "topic", label: topicTitle(tp), sub: bookName(book) + " — " + chapterTitle(ch), bookId: book.id, topicId: tp.id });
  })));
  // v1.11.52 (P-6): assignments — matched on the linked box's title /
  // subject (the assignment itself carries no title of its own).
  (state.assignments || []).forEach(a => {
    const b = allBoxes().find(x => x.id === a.boxId);
    if (!b) return;
    if (hit([b.title, b.subject, b.topic].filter(Boolean).join(" ")))
      asgs.push({ kind: "asg", label: b.title, sub: (boxStudyDay(b) || b.date) + " · " + subjName(b.subject), asg: a, boxId: b.id });
  });
  // v1.11.52 (P-6): error notebook — matched on subject, source,
  // question number and note. The notebook stays opt-in (see errNb);
  // search only READS entries, it never enables the subject.
  (state.errorLog || []).forEach(e => {
    if (hit([subjName(e.subject), e.source, e.q, e.note, t(ERR_TYPE_KEY[e.type] || "errTypeConcept")].filter(Boolean).join(" ")))
      errnbs.push({ kind: "errnb", label: (e.source || subjName(e.subject)) + (e.q ? " · " + t("errNbQ") + " " + e.q : ""),
                    sub: subjName(e.subject) + " · " + gregToJalali(e.d).text, errId: e.id });
  });
  return { boxes: boxes.slice(0, 5), exams: exams.slice(0, 5), topics: topics.slice(0, 5),
           asgs: asgs.slice(0, 5), errnbs: errnbs.slice(0, 5) };
}
function globalSearchResults(q) {
  const g = globalSearchGrouped(q);
  return g.boxes.concat(g.exams, g.topics, g.asgs, g.errnbs).slice(0, 8);
}
// ---------- Ctrl+K palette (v1.11.43, §17 idea 8) ----------
// A new palette UI on top of the P2-9 search — not a second engine.
// Ctrl+K / Cmd+K opens it anywhere; the topbar search opens it
// prefilled with its value. ↑/↓ moves across the grouped list, Enter
// jumps, Esc closes. v1.11.52 (U5): the palette carries
// role="dialog"/aria-modal + a Tab trap, like the modals. Closing
// never refocuses #globalSearch — its focus handler would reopen the
// palette.
let CMDK_OPEN = false, CMDK_SEL = 0, CMDK_ITEMS = [];
function cmdkFlat() {
  const q = (document.getElementById("cmdkInput") || {}).value || "";
  const g = globalSearchGrouped(q);
  return [].concat(
    g.boxes.map(r => ({ r, group: "cmdkBoxes" })),
    g.exams.map(r => ({ r, group: "cmdkExams" })),
    g.topics.map(r => ({ r, group: "cmdkTopics" })),
    g.asgs.map(r => ({ r, group: "cmdkAsgs" })),
    g.errnbs.map(r => ({ r, group: "cmdkErrNbs" })));
}
function renderCmdk() {
  const ov = document.getElementById("cmdkOverlay");
  if (!ov || !CMDK_OPEN) return;
  const list = document.getElementById("cmdkResults");
  const items = cmdkFlat();
  CMDK_ITEMS = items.map(x => x.r);
  if (CMDK_SEL >= items.length) CMDK_SEL = Math.max(0, items.length - 1);
  list.innerHTML = "";
  if (!items.length) {
    const d = document.createElement("div");
    d.className = "cmdk-empty";
    d.textContent = t("gsNoResults");
    list.appendChild(d);
    return;
  }
  const _inp = document.getElementById("cmdkInput");
  if (_inp) {
    if (items.length) _inp.setAttribute("aria-activedescendant", "cmdk-row-" + Math.min(CMDK_SEL, items.length - 1));
    else _inp.removeAttribute("aria-activedescendant");
  }
  let lastGroup = null;
  items.forEach((it, i) => {
    if (it.group !== lastGroup) {
      lastGroup = it.group;
      const h = document.createElement("div");
      h.className = "cmdk-group";
      h.textContent = t(it.group);
      list.appendChild(h);
    }
    const row = document.createElement("button");
    row.type = "button";
    row.className = "cmdk-row" + (i === CMDK_SEL ? " cmdk-sel" : "");
    row.setAttribute("role", "option");
    // v1.11.45 (U-04): the selected row is announced, and the input
    // points at it (aria-activedescendant).
    row.id = "cmdk-row-" + i;
    row.setAttribute("aria-selected", i === CMDK_SEL ? "true" : "false");
    row.innerHTML = '<span class="gs-kind">' + t({ box: "gsBox", exam: "gsExam", topic: "gsTopic", asg: "gsAsg", errnb: "gsErrNb" }[it.r.kind]) + '</span>' +
      '<span class="gs-label">' + esc(it.r.label) + '</span><span class="gs-sub">' + esc(it.r.sub || "") + '</span>';
    row.addEventListener("click", () => { const r = it.r; closeCmdk(); globalSearchJump(r); });
    list.appendChild(row);
  });
}
let CMDK_OPENER = null; // v1.11.45 (U-04): focus returns here on close
function openCmdk(prefill) {
  const ov = document.getElementById("cmdkOverlay");
  if (!ov) return;
  CMDK_OPENER = document.activeElement;
  CMDK_OPEN = true;
  CMDK_SEL = 0;
  ov.hidden = false;
  const input = document.getElementById("cmdkInput");
  if (input) {
    input.setAttribute("aria-controls", "cmdkResults");
    input.setAttribute("aria-expanded", "true");
    if (typeof prefill === "string") input.value = prefill;
    input.focus();
  }
  renderCmdk();
}
function closeCmdk() {
  const ov = document.getElementById("cmdkOverlay");
  if (ov) ov.hidden = true;
  CMDK_OPEN = false;
  CMDK_ITEMS = [];
  const input = document.getElementById("cmdkInput");
  if (input) { input.removeAttribute("aria-activedescendant"); input.setAttribute("aria-expanded", "false"); }
  // v1.11.45 (U-04): return focus to whatever opened the palette —
  // except #globalSearch: its focus handler would reopen the palette
  // (v1.11.43 invariant — closing never refocuses #globalSearch).
  if (CMDK_OPENER && CMDK_OPENER.id !== "globalSearch" && document.contains(CMDK_OPENER)) CMDK_OPENER.focus();
  CMDK_OPENER = null;
}
function wireCmdk() {
  const ov = document.getElementById("cmdkOverlay");
  if (!ov) return;
  const input = document.getElementById("cmdkInput");
  if (input) {
    input.addEventListener("input", () => { CMDK_SEL = 0; renderCmdk(); });
    input.addEventListener("keydown", e => {
      if (e.key === "ArrowDown") { e.preventDefault(); if (CMDK_ITEMS.length) { CMDK_SEL = Math.min(CMDK_SEL + 1, CMDK_ITEMS.length - 1); renderCmdk(); } }
      else if (e.key === "ArrowUp") { e.preventDefault(); if (CMDK_ITEMS.length) { CMDK_SEL = Math.max(CMDK_SEL - 1, 0); renderCmdk(); } }
      else if (e.key === "Enter") { e.preventDefault(); const r = CMDK_ITEMS[CMDK_SEL]; if (r) { closeCmdk(); globalSearchJump(r); } }
      else if (e.key === "Escape") { e.preventDefault(); closeCmdk(); }
    });
  }
  ov.addEventListener("click", e => { if (e.target === ov) closeCmdk(); });
  document.addEventListener("keydown", e => {
    if ((e.ctrlKey || e.metaKey) && (e.key === "k" || e.key === "K")) {
      e.preventDefault();
      if (CMDK_OPEN) closeCmdk();
      else openCmdk();
    } else if (e.key === "Escape" && CMDK_OPEN) { closeCmdk(); }
  });
  // The topbar search opens the palette prefilled with its value.
  const gs = document.getElementById("globalSearch");
  if (gs) {
    gs.addEventListener("focus", () => openCmdk(gs.value));
    gs.addEventListener("click", () => openCmdk(gs.value));
  }
}
function globalSearchJump(r) {
  closeCmdk();
  hideGsPanel();
  const input = document.getElementById("globalSearch");
  if (input) input.value = "";
  if (r.kind === "box") {
    const day = boxStudyDay(r.box) || r.box.date;
    navigate({ tab: "program", day });
    setTimeout(() => {
      const el = document.querySelector('#calDayBoxes [data-box-id="' + r.box.id + '"]');
      if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 150);
  } else if (r.kind === "exam") {
    openExamDetail(r.exam.id);
  } else if (r.kind === "topic") {
    // v1.11.34: open the drill-down to the section first (same as
    // jumpToTopic), so the topic row exists when the scroll fires.
    const found = topicById(r.topicId);
    if (found && found.book) {
      bookNav = { bookId: found.book.id,
        chapterId: found.legacy ? "legacy" : (found.chapter ? found.chapter.id : null),
        topicId: r.topicId };
    }
    navigate({ tab: "testbook", bookId: r.bookId });
    setTimeout(() => {
      const el = document.getElementById("topic-row-" + r.topicId);
      if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 150);
  } else if (r.kind === "asg") {
    // v1.11.52 (P-6): an assignment jumps to its card in the
    // assignments tab (cards are keyed by box id: asg-row-<boxId>).
    navigate({ tab: "assignments" });
    setTimeout(() => {
      const el = document.getElementById("asg-row-" + r.boxId);
      if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 150);
  } else if (r.kind === "errnb") {
    // v1.11.52 (P-6): an error-notebook entry jumps to its row in the
    // notebook section at the end of the testbook tab.
    navigate({ tab: "testbook" });
    setTimeout(() => {
      const el = document.getElementById("err-row-" + r.errId) ||
        document.getElementById("errNbBlock");
      if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 150);
  }
}
function hideGsPanel() {
  if (GS_PANEL) { GS_PANEL.remove(); GS_PANEL = null; }
  const _gs = document.getElementById("globalSearch");
  if (_gs) _gs.removeAttribute("aria-activedescendant");
}
let GS_SEL = 0; // v1.11.45 (U-07): keyboard selection in the GS panel, mirroring the Ctrl+K palette
function showGsPanel(results) {
  hideGsPanel();
  GS_SEL = 0;
  const input = document.getElementById("globalSearch");
  if (!input) return;
  const panel = document.createElement("div");
  panel.className = "gs-results";
  panel.id = "gsResults";
  if (!results.length) {
    panel.innerHTML = '<div class="gs-empty">' + t("gsNoResults") + '</div>';
  } else {
    results.forEach((r, i) => {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "gs-row" + (i === 0 ? " gs-sel" : "");
      row.setAttribute("role", "option");
      row.id = "gs-row-" + i;
      row.setAttribute("aria-selected", i === 0 ? "true" : "false");
      row.innerHTML = '<span class="gs-kind">' + t({ box: "gsBox", exam: "gsExam", topic: "gsTopic", asg: "gsAsg", errnb: "gsErrNb" }[r.kind]) + '</span>' +
        '<span class="gs-label">' + esc(r.label) + '</span><span class="gs-sub">' + esc(r.sub || "") + '</span>';
      row.addEventListener("click", () => globalSearchJump(r));
      panel.appendChild(row);
    });
    panel._results = results;
    input.setAttribute("aria-controls", "gsResults");
    input.setAttribute("aria-activedescendant", "gs-row-0");
  }
  document.body.appendChild(panel);
  const rect = input.getBoundingClientRect();
  panel.style.top = (rect.bottom + 6) + "px";
  panel.style.left = rect.left + "px";
  panel.style.width = Math.max(rect.width, 280) + "px";
  GS_PANEL = panel;
}
function wireGlobalSearch() {
  const input = document.getElementById("globalSearch");
  if (!input) return;
  input.addEventListener("input", () => {
    clearTimeout(GS_TIMER);
    GS_TIMER = setTimeout(() => {
      const q = input.value.trim();
      if (q.length < 2) { hideGsPanel(); return; }
      showGsPanel(globalSearchResults(q));
    }, 180);
  });
  input.addEventListener("keydown", e => {
    if (e.key === "Escape") { hideGsPanel(); input.blur(); }
    // v1.11.45 (U-07): ↑/↓ + Enter in the GS panel, like the palette.
    else if (GS_PANEL && (e.key === "ArrowDown" || e.key === "ArrowUp" || e.key === "Enter")) {
      const rows = [...GS_PANEL.querySelectorAll(".gs-row")];
      if (!rows.length) return;
      e.preventDefault();
      if (e.key === "Enter") { const r = GS_PANEL._results && GS_PANEL._results[GS_SEL]; if (r) globalSearchJump(r); return; }
      GS_SEL = e.key === "ArrowDown" ? Math.min(GS_SEL + 1, rows.length - 1) : Math.max(GS_SEL - 1, 0);
      rows.forEach((row, i) => {
        row.classList.toggle("gs-sel", i === GS_SEL);
        row.setAttribute("aria-selected", i === GS_SEL ? "true" : "false");
      });
      input.setAttribute("aria-activedescendant", "gs-row-" + GS_SEL);
    }
  });
  document.addEventListener("click", e => {
    if (GS_PANEL && !GS_PANEL.contains(e.target) && e.target !== input) hideGsPanel();
  });
}

wireCalendarPanel();
wireGlobalSearch();
wireMiniHero();
wireFloatTimer();
wireCmdk();
wirePagePrimaries(); // v1.11.55 (UX-1)
loadAll();
