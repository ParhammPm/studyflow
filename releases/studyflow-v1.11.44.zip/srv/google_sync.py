#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""StudyFlow server — Google Calendar sync client (v1.11.38, P3-10).

The Google API client (OAuth2 + PKCE, event listing, done-status
sync) and the ICS/JSON feed parsers. Moved verbatim from server.py,
except derive_subject_topic, which now reads subject names from the
single SUBJECTS table (P3-12) instead of the hardcoded
KNOWN_SUBJECTS list. The three-phase push/sync core
(push_to_google, box_api_push_one, run_calendar_sync,
merge_calendar_events) stays in server.py and calls into this
module. Behaviour is otherwise unchanged.
"""
import base64
import hashlib
import json
import os
import re
import secrets
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

try:
    from zoneinfo import ZoneInfo
except Exception:  # very old Python without zoneinfo
    ZoneInfo = None

from srv.common import (
    TEHRAN,
    _with_lock,
    iso_now,
    open_https_url,
    sha256_bytes,
)
from srv.repository import (
    _programme_range,
    load_oauth,
    load_programme,
    load_push_state,
    load_state,
    load_subjects,
    save_oauth,
    save_push_state,
    save_state,
)


SLEEP_MARKER = "گوشی رو بذار کنار"

GOOGLE_AUTH_URL = os.environ.get(
    "GOOGLE_OAUTH_AUTH_URL", "https://accounts.google.com/o/oauth2/v2/auth")
GOOGLE_TOKEN_URL = os.environ.get(
    "GOOGLE_OAUTH_TOKEN_URL", "https://oauth2.googleapis.com/token")
GOOGLE_REVOKE_URL = os.environ.get(
    "GOOGLE_OAUTH_REVOKE_URL", "https://oauth2.googleapis.com/revoke")
GOOGLE_API_BASE = os.environ.get(
    "GOOGLE_CALENDAR_API_BASE", "https://www.googleapis.com/calendar/v3")
GOOGLE_REDIRECT_URI = "http://127.0.0.1:8765/oauth/callback"
GOOGLE_SCOPE = "https://www.googleapis.com/auth/calendar.events"

_SUBJECT_NAMES_CACHE = None


def _subject_names():
    """fa names from the single SUBJECTS table (i18n.js), cached."""
    global _SUBJECT_NAMES_CACHE
    if _SUBJECT_NAMES_CACHE is None:
        _SUBJECT_NAMES_CACHE = [s["fa"] for s in load_subjects()]
    return _SUBJECT_NAMES_CACHE


def _core_subject_alt():
    """Regex alternation of the nine core subject names, from the
    SUBJECTS table (the state.subjects default list)."""
    return "|".join(re.escape(s["fa"]) for s in load_subjects()
                    if s.get("core"))


def _split_outside_parens(text):
    """Last ': ' outside any parentheses, or None (so '(پارت ۲: …)' never
    splits a topic but 'دیدن جلسه: §۸' does)."""
    depth = 0
    last = None
    i = 0
    while i < len(text) - 1:
        ch = text[i]
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth = max(0, depth - 1)
        elif ch == ":" and text[i + 1] == " " and depth == 0:
            last = i
        i += 1
    return last


def clean_event_title(title):
    t = (title or "").strip()
    t = re.sub(r"\s*\(مفید:[^)]*\)\s*$", "", t)
    t = re.sub(r"\s*\(انجام شد\)\s*$", "", t)
    return t.strip()


def derive_subject_topic(title):
    """Subject/topic for a calendar summary, matching how the shipped 318
    boxes were derived from their summaries (verified against data.json:
    'X: rest' -> subject X; 'X — rest' -> subject X; 'کلاس X …' and
    'X آفلاین پایه' -> subject X with the full cleaned title as topic;
    'X دهم/دوازدهم (آزمون) — rest' -> subject X, topic rest)."""
    t = clean_event_title(title)
    if not t:
        return ("", "")
    # 'تست آزمون ۷: <rest>' / 'تست آزمون ۲ (هفته ۳): <rest>' — the original
    # build stripped that planning prefix: topic is the whole remainder,
    # subject is derived from the remainder ('آزمون' when it names none).
    m = re.match(r"^تست آزمون\s*\d*\s*(\([^)]*\))?\s*:\s*(.+)$", t)
    if m:
        rest = m.group(2).strip()
        s2, _ = derive_subject_topic(rest)
        return (rest if s2 == rest else s2, rest) if s2 != rest else ("آزمون", rest)
    for special in ("مرور دفترچه خطا", "جلسه مشاور درسی", "مرور و جمع‌بندی آزمون"):
        if t == special:
            return (special, t)
        if t.startswith(special + " — "):
            return (special, t.split(" — ", 1)[1].strip())
        if t.startswith(special + " "):
            return (special, t)
    if t.startswith("تحلیل آزمون"):
        if " — " in t:
            return ("تحلیل آزمون", t.split(" — ", 1)[1].strip())
        return ("تحلیل آزمون", t)
    if t.startswith("آزمون"):
        return ("آزمون", t)
    if ":" in t:
        left, right = t.split(":", 1)
        if left.strip() in _subject_names():
            return (left.strip(), right.strip())
    if " — " in t:
        left, right = t.split(" — ", 1)
        left = left.strip()
        right = right.strip()
        if left in _subject_names():
            ci = _split_outside_parens(right)
            return (left, right[ci + 2:] if ci is not None else right)
        # 'کلاس [زنده|آفلاین] <subject> … — <rest>' -> topic is
        # 'کلاس <subject> — <rest>' with a trailing parenthetical dropped.
        mc = re.match(r"^کلاس\s+(?:زنده|آفلاین)?\s*"
                      r"(" + _core_subject_alt() + r")", left)
        if mc:
            r2 = re.sub(r"\s*\([^)]*\)\s*$", "", right).strip()
            return (mc.group(1), "کلاس " + mc.group(1) + (" — " + r2 if r2 else ""))
        for s in _subject_names():
            if s in left:
                # Left is only the subject + grade words / a parenthetical
                # qualifier (e.g. 'هندسه دوازدهم', 'حسابان (آزمون)',
                # 'هندسه دوازدهم و دهم (تکلیف و آزمون)') -> topic = right.
                rest = left.replace(s, "", 1).strip()
                if re.fullmatch(r"((دهم|یازدهم|دوازدهم)(\s+و\s+(دهم|یازدهم|دوازدهم))?)?"
                                r"\s*(\([^)]*\))?", rest):
                    ci = _split_outside_parens(right)
                    return (s, right[ci + 2:] if ci is not None else right)
                return (s, t)
    # 'کلاس [زنده|آفلاین] <subject> …' -> topic is 'کلاس <subject>'.
    m = re.match(r"^کلاس\s+(?:زنده|آفلاین)?\s*"
                 r"(" + _core_subject_alt() + r")", t)
    if m:
        return (m.group(1), "کلاس " + m.group(1))
    for s in _subject_names():
        if s in t:
            return (s, t)
    return (t, t)


def event_is_test(title):
    """Test box? The shipped boxes are test boxes when the title carries
    تست / تکلیف / آزمون — except a parenthesised '(آزمون)' qualifier, a
    'بدون تکلیف' class, or the 'کلاس جبرانی … + آزمون + دوره' class.
    (Checked against all 318 shipped boxes: 0 mismatches.)"""
    t = clean_event_title(title)
    # A parenthetical qualifier naming an exam ('(آزمون)',
    # '(پارت ۵: آزمون ۱ ساعته)') does not make the box a test box — but
    # '(آمادگی آزمون)' (preparation FOR an exam) and '(تست آزمون)' do count.
    def _strip_qualifier(m):
        inner = m.group(1)
        if "آزمون" in inner and "تست" not in inner and "آمادگی" not in inner:
            return ""
        return m.group(0)
    t2 = re.sub(r"\(([^)]*)\)", _strip_qualifier, t)
    if "بدون تکلیف" in t or t.startswith("کلاس جبرانی") \
            or t.startswith("مرور و جمع‌بندی آزمون"):
        return False
    return bool(re.search(r"تست|تکلیف|آزمون", t2))


def _ics_unfold(text):
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    out = []
    for ln in lines:
        if ln[:1] in (" ", "\t") and out:
            out[-1] += ln[1:]
        else:
            out.append(ln)
    return out


def _ics_split(line):
    """'DTSTART;TZID=Asia/Tehran:20261124T090000' -> ({'TZID': ...}, value)."""
    if ":" not in line:
        return {}, line
    head, value = line.split(":", 1)
    parts = head.split(";")
    params = {}
    for p in parts[1:]:
        if "=" in p:
            k, v = p.split("=", 1)
            params[k.strip().upper()] = v.strip()
    return params, value.strip()


def _parse_ics_dt(value, params):
    """Returns (aware datetime in Tehran, is_all_day) or (None, False)."""
    value = (value or "").strip()
    if not value:
        return None, False
    if params.get("VALUE", "").upper() == "DATE" or re.match(r"^\d{8}$", value):
        try:
            d = datetime.strptime(value[:8], "%Y%m%d").date()
        except Exception:
            return None, False
        return datetime(d.year, d.month, d.day, tzinfo=TEHRAN), True
    m = re.match(r"^(\d{8})T(\d{6})(Z)?$", value)
    if not m:
        try:
            dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=TEHRAN)
            return dt.astimezone(TEHRAN), False
        except Exception:
            return None, False
    base = datetime.strptime(m.group(1) + m.group(2), "%Y%m%d%H%M%S")
    if m.group(3) == "Z":
        return base.replace(tzinfo=timezone.utc).astimezone(TEHRAN), False
    tzid = (params.get("TZID") or "").upper()
    if tzid in ("UTC", "GMT", "ETC/UTC"):
        return base.replace(tzinfo=timezone.utc).astimezone(TEHRAN), False
    # A known TZID (e.g. Asia/Dubai, Europe/London) resolves through
    # zoneinfo; unknown/custom zone names and floating times fall back
    # to Tehran local (the previous behaviour for every non-UTC TZID).
    tzid_raw = (params.get("TZID") or "").strip()
    if tzid_raw and ZoneInfo is not None:
        try:
            return base.replace(tzinfo=ZoneInfo(tzid_raw)).astimezone(TEHRAN), False
        except Exception:
            pass
    return base.replace(tzinfo=TEHRAN), False


def _parse_rrule(value):
    out = {}
    for part in (value or "").split(";"):
        if "=" in part:
            k, v = part.split("=", 1)
            out[k.strip().upper()] = v.strip()
    return out


def _nth_weekday_of_month(year, month, weekday, n):
    """Date of the nth weekday (n >= 1) or the last one (n == -1) in a
    month, or None when that nth weekday does not exist (e.g. 5th Monday)."""
    first = datetime(year, month, 1).date()
    offset = (weekday - first.weekday()) % 7
    if n >= 1:
        try:
            return datetime(year, month, 1 + offset + (n - 1) * 7).date()
        except ValueError:
            return None
    if month == 12:
        nxt = datetime(year + 1, 1, 1).date()
    else:
        nxt = datetime(year, month + 1, 1).date()
    last = nxt - timedelta(days=1)
    return last - timedelta(days=(last.weekday() - weekday) % 7)


def _expand_rrule(start_dt, end_dt, rrule, exdates, range_start, range_end):
    """Expand one recurring master into (start, end) instances inside the
    date range. Day-by-day walk: simple, and correct for DAILY / WEEKLY /
    MONTHLY / YEARLY with INTERVAL, COUNT, UNTIL, BYDAY and EXDATE.
    HOURLY / MINUTELY walk in time steps (bounded). COUNT always counts
    from the recurrence start, never from the programme-range start, and
    UNTIL is compared as a datetime, not a date."""
    freq = (rrule.get("FREQ") or "").upper()
    if freq not in ("DAILY", "WEEKLY", "MONTHLY", "YEARLY", "HOURLY", "MINUTELY"):
        return [(start_dt, end_dt)]
    try:
        interval = max(1, int(rrule.get("INTERVAL") or 1))
    except Exception:
        interval = 1
    count = None
    try:
        if rrule.get("COUNT"):
            count = int(rrule["COUNT"])
    except Exception:
        count = None
    until_dt = None
    if rrule.get("UNTIL"):
        u, _ = _parse_ics_dt(rrule["UNTIL"], {})
        if u is not None:
            until_dt = u
    days = {"MO": 0, "TU": 1, "WE": 2, "TH": 3, "FR": 4, "SA": 5, "SU": 6}
    byday = None
    byday_ord = []
    if rrule.get("BYDAY"):
        for part in rrule["BYDAY"].split(","):
            m = re.fullmatch(r"(-?\d+)?(MO|TU|WE|TH|FR|SA|SU)", part.strip())
            if not m:
                continue
            if m.group(1):
                byday_ord.append((days[m.group(2)], int(m.group(1))))
            else:
                byday = byday or []
                byday.append(days[m.group(2)])
        if byday:
            byday = sorted(set(byday))
    duration = end_dt - start_dt
    start_date = start_dt.date()
    ex = set()
    for e in exdates or []:
        ex.add(e.date() if hasattr(e, "date") else e)
        if hasattr(e, "hour"):
            ex.add(e)
    out = []
    if freq in ("HOURLY", "MINUTELY"):
        step = timedelta(hours=interval) if freq == "HOURLY" \
            else timedelta(minutes=interval)
        range_end_dt = datetime(range_end.year, range_end.month, range_end.day,
                                23, 59, 59, tzinfo=TEHRAN)
        t = start_dt
        made = 0
        while t <= range_end_dt and made < 5000:
            if until_dt is not None and t > until_dt:
                break
            if count is not None and made >= count:
                break
            if t.date() >= range_start and t not in ex and t.date() not in ex:
                out.append((t, t + duration))
            made += 1
            t += step
        return out
    made = 0
    d = start_date
    while d <= range_end:
        if count is not None and made >= count:
            break
        ok = False
        delta_days = (d - start_date).days
        if freq == "DAILY":
            ok = delta_days % interval == 0
        elif freq == "WEEKLY":
            wanted = byday if byday else [start_dt.weekday()]
            ok = d.weekday() in wanted and (delta_days // 7) % interval == 0
        elif freq == "MONTHLY":
            months = (d.year - start_date.year) * 12 + (d.month - start_date.month)
            if months % interval != 0:
                ok = False
            elif byday_ord or byday:
                ok = any(_nth_weekday_of_month(d.year, d.month, wd, n) == d
                         for wd, n in byday_ord) or (bool(byday) and d.weekday() in byday)
            else:
                ok = d.day == start_date.day
        elif freq == "YEARLY":
            ok = (d.month == start_date.month and d.day == start_date.day
                  and (d.year - start_date.year) % interval == 0)
        if ok:
            inst_start = datetime(d.year, d.month, d.day, start_dt.hour,
                                  start_dt.minute, start_dt.second, tzinfo=TEHRAN)
            if until_dt is not None and inst_start > until_dt:
                break
            if inst_start not in ex and d not in ex:
                if d >= range_start:
                    out.append((inst_start, inst_start + duration))
                made += 1
            elif count is not None:
                made += 1
        d += timedelta(days=1)
    return out


def parse_ics(text):
    """Parse ICS text into raw events: {uid, title, start_dt, end_dt,
    status, all_day}. Recurring masters are expanded into instances
    (uid suffixed with the instance start); a cancelled master cancels
    all its instances. A VEVENT with RECURRENCE-ID is an exception for
    ONE instance of its master (moved or cancelled): it replaces that
    instance in place, keeping the instance UID, so the merge updates
    (or deletes) the same box instead of duplicating it."""
    raw = []
    exceptions = []
    rng = None  # programme range, read once (not per recurring master)
    cur = None
    for ln in _ics_unfold(text or ""):
        line = ln.strip()
        if line == "BEGIN:VEVENT":
            cur = {"props": []}
        elif line == "END:VEVENT" and cur is not None:
            props = {}
            for name, params, value in cur["props"]:
                props.setdefault(name, []).append((params, value))
            uid = ""
            for params, value in props.get("UID", []):
                uid = value
                break
            title = ""
            for params, value in props.get("SUMMARY", []):
                title = value
                break
            status = "confirmed"
            for params, value in props.get("STATUS", []):
                status = value.strip().lower()
                break
            s_dt, s_all = None, False
            e_dt = None
            for params, value in props.get("DTSTART", []):
                s_dt, s_all = _parse_ics_dt(value, params)
                break
            for params, value in props.get("DTEND", []):
                e_dt, _ = _parse_ics_dt(value, params)
                break
            if uid and title and s_dt is not None:
                if e_dt is None:
                    e_dt = s_dt + timedelta(hours=1)
                exdates = []
                for params, value in props.get("EXDATE", []):
                    for piece in value.split(","):
                        ed, _ = _parse_ics_dt(piece.strip(), params)
                        if ed is not None:
                            exdates.append(ed)
                rrules = [v for _, v in props.get("RRULE", [])]
                rec_id = None
                for params, value in props.get("RECURRENCE-ID", []):
                    rec_id, _ = _parse_ics_dt(value, params)
                    break
                if rec_id is not None:
                    # Exception for one instance of the master: apply it
                    # after the masters are expanded (below).
                    exceptions.append({"uid": uid, "rec_id": rec_id,
                                       "title": title, "start_dt": s_dt,
                                       "end_dt": e_dt, "status": status,
                                       "all_day": s_all})
                elif rrules:
                    if rng is None:
                        rng = _programme_range()
                    for inst_s, inst_e in _expand_rrule(
                            s_dt, e_dt, _parse_rrule(rrules[0]), exdates,
                            rng[0], rng[1]):
                        raw.append({"uid": uid + "#" + inst_s.strftime("%Y%m%dT%H%M"),
                                    "title": title, "start_dt": inst_s,
                                    "end_dt": inst_e, "status": status,
                                    "all_day": s_all})
                else:
                    raw.append({"uid": uid, "title": title, "start_dt": s_dt,
                                "end_dt": e_dt, "status": status,
                                "all_day": s_all})
            cur = None
        elif cur is not None and ":" in line:
            name = line.split(":", 1)[0].split(";", 1)[0].strip().upper()
            params, value = _ics_split(line)
            cur["props"].append((name, params, value))
    # Apply RECURRENCE-ID exceptions onto the expanded instances.
    for exc in exceptions:
        target_uid = exc["uid"] + "#" + exc["rec_id"].strftime("%Y%m%dT%H%M")
        replaced = False
        for ev in raw:
            if ev["uid"] == target_uid:
                # Keep the original instance UID so the merge updates
                # (or, when cancelled, deletes) the same box.
                ev["title"] = exc["title"]
                ev["start_dt"] = exc["start_dt"]
                ev["end_dt"] = exc["end_dt"]
                ev["status"] = exc["status"]
                ev["all_day"] = exc["all_day"]
                replaced = True
                break
        if not replaced:
            # Master instance outside the programme range (or an
            # unexpanded master): keep the exception under the instance
            # UID so a moved instance is not lost.
            raw.append({"uid": target_uid, "title": exc["title"],
                        "start_dt": exc["start_dt"], "end_dt": exc["end_dt"],
                        "status": exc["status"], "all_day": exc["all_day"]})
    return raw


def _iso_to_tehran(value):
    """ISO datetime (with offset, Z, or floating) -> Tehran datetime."""
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except Exception:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=TEHRAN)
    return dt.astimezone(TEHRAN)


def _hhmm(value):
    """HH:MM (or HHMM, e.g. "0900") -> (hour, minute)."""
    s = str(value or "").strip()
    if re.fullmatch(r"\d{4}", s):
        return int(s[:2]), int(s[2:])
    parts = (s.split(":") + ["0", "0"])[:2]
    return int(parts[0]), int(parts[1])


def parse_calendar_json(text):
    """Parse a calendar JSON export into the same raw-event shape as
    parse_ics. Accepts: (a) the Google Calendar API export
    ({items: [{id, iCalUID, summary, start: {dateTime}, end: {dateTime},
    status, recurringEventId}]}); (b) a plain array of events
    ({date, start, end, title}); (c) {boxes: [...]} in the same shape."""
    try:
        data = json.loads(text)
    except Exception as exc:
        raise ValueError("فایل JSON معتبر نیست: {}".format(exc))
    items = None
    if isinstance(data, dict) and isinstance(data.get("items"), list):
        items = data["items"]
    elif isinstance(data, list):
        items = data
    elif isinstance(data, dict) and isinstance(data.get("boxes"), list):
        items = data["boxes"]
    else:
        raise ValueError("ساختار JSON شناخته نشد — باید {items: [...]} یا آرایه‌ای از رویدادها باشد")
    raw = []
    rng = None
    # Explicit instances of a recurring master (Google API exports list
    # them with recurringEventId + originalStartTime): the master
    # expansion must skip those original times, or every instance is
    # counted twice (once expanded, once explicit).
    explicit = {}
    for it in items:
        if not isinstance(it, dict) or not it.get("recurringEventId"):
            continue
        orig = it.get("originalStartTime") or {}
        odt = _iso_to_tehran(orig.get("dateTime")) if orig.get("dateTime") else None
        if odt is None:
            s = it.get("start") or {}
            odt = _iso_to_tehran(s.get("dateTime")) if isinstance(s, dict) and s.get("dateTime") else None
        if odt is not None:
            explicit.setdefault(str(it["recurringEventId"]), set()).add(odt)
    for it in items:
        if not isinstance(it, dict):
            continue
        title = it.get("summary") or it.get("title") or ""
        status = str(it.get("status") or "confirmed").lower()
        uid = it.get("iCalUID") or it.get("uid") or it.get("id") or ""
        if it.get("recurringEventId"):
            uid = str(it.get("id") or uid)  # instances are unique by id
        start = it.get("start")
        end = it.get("end")
        s_dt = e_dt = None
        all_day = False
        if isinstance(start, dict):
            if start.get("dateTime"):
                s_dt = _iso_to_tehran(start["dateTime"])
            elif start.get("date"):
                all_day = True
                try:
                    d = datetime.strptime(start["date"][:10], "%Y-%m-%d").date()
                    s_dt = datetime(d.year, d.month, d.day, tzinfo=TEHRAN)
                except Exception:
                    s_dt = None
        elif isinstance(start, str):
            if "T" in start:
                s_dt = _iso_to_tehran(start)
            elif it.get("date"):
                try:
                    d = datetime.strptime(str(it["date"])[:10], "%Y-%m-%d").date()
                    hh, mm = _hhmm(start)
                    s_dt = datetime(d.year, d.month, d.day, hh, mm, tzinfo=TEHRAN)
                except Exception:
                    s_dt = None
        if isinstance(end, dict):
            if end.get("dateTime"):
                e_dt = _iso_to_tehran(end["dateTime"])
            elif end.get("date"):
                try:
                    d = datetime.strptime(end["date"][:10], "%Y-%m-%d").date()
                    e_dt = datetime(d.year, d.month, d.day, tzinfo=TEHRAN)
                except Exception:
                    e_dt = None
        elif isinstance(end, str):
            if "T" in end:
                e_dt = _iso_to_tehran(end)
            elif s_dt is not None:
                try:
                    hh, mm = _hhmm(end)
                    e_dt = datetime(s_dt.year, s_dt.month, s_dt.day, hh, mm, tzinfo=TEHRAN)
                except Exception:
                    e_dt = None
        if not title or s_dt is None:
            continue
        if e_dt is None:
            e_dt = s_dt + timedelta(hours=1)
        if not uid:
            uid = "manual-" + sha256_bytes(
                (s_dt.strftime("%Y-%m-%d %H:%M") + "|" + title).encode("utf-8"))[:12]
        # A Google item carrying its own RRULE (no expanded instances in
        # the file): expand it the same way as an ICS master.
        recurrence = it.get("recurrence") or []
        rrule = None
        for r in recurrence:
            if isinstance(r, str) and r.startswith("RRULE:"):
                rrule = _parse_rrule(r[len("RRULE:"):])
                break
        if rrule:
            if rng is None:
                rng = _programme_range()
            skip = explicit.get(str(it.get("id") or uid), set())
            for inst_s, inst_e in _expand_rrule(s_dt, e_dt, rrule, [], rng[0], rng[1]):
                if inst_s in skip:
                    continue
                raw.append({"uid": str(uid) + "#" + inst_s.strftime("%Y%m%dT%H%M"),
                            "title": title, "start_dt": inst_s, "end_dt": inst_e,
                            "status": status, "all_day": all_day})
        else:
            raw.append({"uid": str(uid), "title": title, "start_dt": s_dt,
                        "end_dt": e_dt, "status": status, "all_day": all_day})
    return raw


def normalize_events(raw):
    """Raw events -> present events [{uid, title, date, start, end}],
    cancelled uids, and skip counts. Filters the nightly sleep reminder
    and zero-duration events (the same filter the original build used),
    skips all-day events, and dedupes by UID."""
    events = []
    cancelled = set()
    counts = {"skipped_sleep": 0, "skipped_zero": 0, "skipped_allday": 0,
              "cancelled": 0, "duplicates": 0}
    seen = {}
    for ev in raw or []:
        uid = str(ev.get("uid") or "")
        title = (ev.get("title") or "").strip()
        s_dt = ev.get("start_dt")
        e_dt = ev.get("end_dt")
        if not uid or not title or s_dt is None or e_dt is None:
            continue
        if str(ev.get("status") or "").lower() in ("cancelled", "canceled"):
            cancelled.add(uid)
            counts["cancelled"] += 1
            continue
        if SLEEP_MARKER in title:
            counts["skipped_sleep"] += 1
            continue
        if e_dt <= s_dt:
            counts["skipped_zero"] += 1
            continue
        if ev.get("all_day"):
            counts["skipped_allday"] += 1
            continue
        key = uid
        if key in seen and (seen[key]["date"], seen[key]["start"]) != (
                s_dt.strftime("%Y-%m-%d"), s_dt.strftime("%H:%M")):
            key = uid + "#" + s_dt.strftime("%Y%m%dT%H%M")
        if key in seen:
            counts["duplicates"] += 1
            continue
        item = {"uid": key, "title": title, "date": s_dt.strftime("%Y-%m-%d"),
                "start": s_dt.strftime("%H:%M"), "end": e_dt.strftime("%H:%M")}
        seen[key] = item
        events.append(item)
    events.sort(key=lambda e: (e["date"], e["start"], e["title"]))
    return events, cancelled, counts


class GoogleNotFound(ValueError):
    """A Google event that no longer exists (404/410)."""


def _mask_client_id(cid):
    """First/last-4 mask for the OAuth CLIENT ID (v1.11.28, QA BUG-046
    note): unlike the Gemini key, a client ID is a public identifier,
    not a secret — the UI shows it as the input placeholder — so it
    keeps the old first/last-4 form. The Gemini key itself now masks
    to bullets only (srv/gemini.py masked_key)."""
    cid = (cid or "").strip()
    if not cid:
        return ""
    if len(cid) <= 8:
        return "••••••••"
    return cid[:4] + "••••••••" + cid[-4:]


def _pending_flows(cfg):
    """The pending OAuth flows, keyed by state (v1.11.28, QA BUG-045):
    two rapid «connect» clicks used to share one pending_state /
    pending_verifier singleton, so the first flow broke when the
    second overwrote it. Each flow now keeps its own state/verifier
    in cfg["pending_flows"][state] = {"verifier", "ts"}. Migrates
    the pre-1.11.28 singleton fields once, in place, and prunes
    flows older than the 10-minute callback window."""
    flows = cfg.get("pending_flows")
    if not isinstance(flows, dict):
        flows = {}
        cfg["pending_flows"] = flows
    legacy_state = (cfg.get("pending_state") or "").strip()
    if legacy_state and legacy_state not in flows:
        flows[legacy_state] = {
            "verifier": (cfg.get("pending_verifier") or "").strip(),
            "ts": int(cfg.get("pending_state_ts") or 0)}
    if legacy_state:
        cfg["pending_state"] = ""
        cfg["pending_state_ts"] = 0
        cfg["pending_verifier"] = ""
    now = int(time.time())
    for st in [s for s, f in flows.items()
               if now - int((f or {}).get("ts") or 0) > 600]:
        del flows[st]
    return flows


def masked_oauth_status():
    cfg = load_oauth()
    cid = (cfg.get("client_id") or "").strip()
    connected = bool((cfg.get("access_token") or "").strip())
    # v1.11.16 (audit §5 item 1.4): Testing-mode refresh tokens live
    # 7 days from the connect; warn while there is still time to
    # reconnect instead of failing with a raw Google error a week later.
    age_days = None
    try:
        ca = (cfg.get("connected_at") or "").strip()
        if ca:
            age_days = max(0, int((datetime.now(tz=TEHRAN)
                                   - datetime.fromisoformat(ca)).total_seconds() // 86400))
    except Exception:
        age_days = None
    return {"credentials_set": bool(cid and (cfg.get("client_secret") or "").strip()),
            "client_id_masked": _mask_client_id(cid) if cid else "",
            "connected": connected,
            "email": cfg.get("account_email") or "",
            "expires_at": int(cfg.get("expires_at") or 0),
            "connected_at": cfg.get("connected_at") or "",
            "token_age_days": age_days,
            "token_refresh_days_left": (max(0, 7 - age_days)
                                        if age_days is not None and connected else None),
            "token_refresh_expires_soon": bool(connected and age_days is not None
                                               and age_days >= 6),
            "last_error": cfg.get("last_error")}


def _google_request(method, url, headers=None, data=None):
    """One raw HTTPS call to Google. Returns (status, parsed_json).
    Network failures raise ValueError with a Persian message."""
    req = urllib.request.Request(url, data=data, headers=headers or {}, method=method)
    try:
        # v1.11.24 (QA BUG-012): redirects are re-checked for https.
        with open_https_url(req, timeout=30) as resp:
            raw = resp.read()
            if not raw:
                return resp.status, {}
            try:
                return resp.status, json.loads(raw.decode("utf-8"))
            except Exception:
                return resp.status, {"_raw": raw.decode("utf-8", "replace")}
    except urllib.error.HTTPError as exc:
        raw = exc.read()
        try:
            body = json.loads(raw.decode("utf-8"))
        except Exception:
            body = {"error": {"message": raw.decode("utf-8", "replace")[:300]}}
        return exc.code, body
    except Exception as exc:
        raise ValueError("ارتباط با گوگل ممکن نشد: {}".format(exc))


def _google_error_message(data, status):
    msg = ""
    err = data.get("error") if isinstance(data, dict) else None
    if isinstance(err, dict):
        msg = str(err.get("message") or "")
    elif isinstance(err, str):
        msg = err
    if not msg:
        msg = str(data)[:200]
    return "خطای گوگل ({}): {}".format(status, msg)


def _token_expired(cfg):
    if not (cfg.get("access_token") or "").strip():
        return True
    exp = int(cfg.get("expires_at") or 0)
    if not exp:
        return True
    return exp - 60 < int(time.time())


def refresh_access_token():
    """Exchange the stored refresh token for a fresh access token."""
    cfg = load_oauth()
    rt = (cfg.get("refresh_token") or "").strip()
    cid = (cfg.get("client_id") or "").strip()
    csec = (cfg.get("client_secret") or "").strip()
    if not rt or not cid or not csec:
        raise ValueError("توکن گوگل منقضی شده و توکن تمدید نیست — دوباره متصل شو")
    body = urllib.parse.urlencode({
        "grant_type": "refresh_token", "refresh_token": rt,
        "client_id": cid, "client_secret": csec}).encode("utf-8")
    status, data = _google_request(
        "POST", GOOGLE_TOKEN_URL,
        {"Content-Type": "application/x-www-form-urlencoded"}, body)
    if status >= 400:
        msg = _google_error_message(data, status)
        # v1.11.16 (audit §5 item 1.4): Testing-mode refresh tokens
        # expire after 7 days and Google answers invalid_grant — which
        # used to surface as a raw English error. Say plainly what
        # happened and what to do.
        if "invalid_grant" in msg:
            raise ValueError("توکن ۷روزه منقضی شد — دوباره وصل شو")
        raise ValueError(msg)
    cfg["access_token"] = str(data.get("access_token") or "")
    if data.get("refresh_token"):
        cfg["refresh_token"] = str(data.get("refresh_token"))
    cfg["expires_at"] = int(time.time()) + int(data.get("expires_in") or 3600) - 30
    cfg["last_error"] = None
    save_oauth(cfg)
    return cfg


def google_api(method, path, body=None):
    """One Calendar API call with automatic token refresh on 401.
    Raises ValueError (Persian) or GoogleNotFound on failure."""
    cfg = load_oauth()
    if not (cfg.get("access_token") or "").strip():
        raise ValueError("گوگل متصل نیست — اول «اتصال به گوگل» را بزن")
    if _token_expired(cfg):
        cfg = refresh_access_token()
    token = (cfg.get("access_token") or "").strip()
    payload = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
    headers = {"Authorization": "Bearer " + token}
    if payload is not None:
        headers["Content-Type"] = "application/json; charset=utf-8"
    status, data = _google_request(method, GOOGLE_API_BASE + path, headers, payload)
    if status == 401:
        cfg = refresh_access_token()
        token = (cfg.get("access_token") or "").strip()
        headers["Authorization"] = "Bearer " + token
        status, data = _google_request(method, GOOGLE_API_BASE + path, headers, payload)
        if status == 401:
            raise ValueError("توکن گوگل رد شد — دوباره متصل شو")
    if status in (404, 410):
        raise GoogleNotFound(_google_error_message(data, status))
    if status >= 400:
        raise ValueError(_google_error_message(data, status))
    return data


def _pkce_verifier():
    """RFC 7636 code_verifier: 43 URL-safe chars from 32 random bytes."""
    return base64.urlsafe_b64encode(
        secrets.token_bytes(32)).rstrip(b"=").decode("ascii")


def _pkce_challenge(verifier):
    """RFC 7636 S256 code_challenge for a verifier."""
    return base64.urlsafe_b64encode(
        hashlib.sha256(verifier.encode("ascii")).digest()
        ).rstrip(b"=").decode("ascii")


def build_auth_url():
    """The Google sign-in URL the browser opens. The random state and the
    PKCE verifier are stored server-side and checked/sent in
    /oauth/callback. Google requires the Client Secret for this Desktop
    client even with PKCE, so connecting needs it saved first."""
    cfg = load_oauth()
    cid = (cfg.get("client_id") or "").strip()
    csec = (cfg.get("client_secret") or "").strip()
    if not cid or not csec:
        raise ValueError("اول Client Secret را ذخیره کن")
    state = secrets.token_urlsafe(24)
    verifier = _pkce_verifier()
    # v1.11.28 (QA BUG-045): the flow is keyed by its own state — a
    # second rapid click no longer overwrites the first flow's
    # verifier (the old pending_state singleton did exactly that).
    flows = _pending_flows(cfg)
    flows[state] = {"verifier": verifier, "ts": int(time.time())}
    save_oauth(cfg)
    q = urllib.parse.urlencode({
        "client_id": cid, "redirect_uri": GOOGLE_REDIRECT_URI,
        "response_type": "code", "scope": GOOGLE_SCOPE,
        "access_type": "offline", "prompt": "consent",
        "include_granted_scopes": "true", "state": state,
        "code_challenge": _pkce_challenge(verifier),
        "code_challenge_method": "S256"})
    return GOOGLE_AUTH_URL + "?" + q


def exchange_code(code, state):
    """Exchange the callback code for tokens and remember the account email
    (the primary calendar's id IS the Google account email). Sends both
    the PKCE code_verifier and the Client Secret: Google enforces the
    secret for Desktop-app clients (verified 2026-11-24: without it the
    token endpoint answers 400 invalid_request «client_secret is missing»)."""
    cfg = load_oauth()
    # v1.11.28 (QA BUG-045): the flow is looked up by ITS OWN state —
    # a second flow started after this one no longer invalidates it.
    # The flow is single-use: it is consumed (popped) whether the
    # token exchange succeeds or not, since Google's code is too.
    flows = _pending_flows(cfg)
    flow = flows.get(state) or {}
    pts = int(flow.get("ts") or 0)
    if not flow or time.time() - pts > 600:
        raise ValueError("درخواست ورود معتبر نیست یا منقضی شده — دوباره «اتصال به گوگل» را بزن")
    cid = (cfg.get("client_id") or "").strip()
    csec = (cfg.get("client_secret") or "").strip()
    verifier = (flow.get("verifier") or "").strip()
    body = urllib.parse.urlencode({
        "grant_type": "authorization_code", "code": code,
        "redirect_uri": GOOGLE_REDIRECT_URI,
        "client_id": cid, "client_secret": csec,
        "code_verifier": verifier}).encode("utf-8")
    status, data = _google_request(
        "POST", GOOGLE_TOKEN_URL,
        {"Content-Type": "application/x-www-form-urlencoded"}, body)
    flows.pop(state, None)
    if status >= 400:
        save_oauth(cfg)
        raise ValueError(_google_error_message(data, status))
    cfg["access_token"] = str(data.get("access_token") or "")
    cfg["refresh_token"] = str(data.get("refresh_token") or "")
    cfg["expires_at"] = int(time.time()) + int(data.get("expires_in") or 3600) - 30
    cfg["connected_at"] = iso_now()
    cfg["last_error"] = None
    save_oauth(cfg)
    try:
        me = google_api("GET", "/users/me/calendarList/primary")
        cfg = load_oauth()
        cfg["account_email"] = str(me.get("id") or "")
        save_oauth(cfg)
    except Exception as exc:
        print("Could not fetch Google account email: {}".format(exc))
    return cfg


def revoke_google_tokens():
    """Revoke the token at Google (best effort) and clear stored tokens.
    Client ID/secret are kept so reconnecting is one click."""
    cfg = load_oauth()
    token = (cfg.get("refresh_token") or cfg.get("access_token") or "").strip()
    if token:
        try:
            body = urllib.parse.urlencode({"token": token}).encode("utf-8")
            _google_request("POST", GOOGLE_REVOKE_URL,
                            {"Content-Type": "application/x-www-form-urlencoded"}, body)
        except Exception as exc:
            print("Google revoke failed (ignored): {}".format(exc))
    cfg["access_token"] = ""
    cfg["refresh_token"] = ""
    cfg["expires_at"] = 0
    cfg["account_email"] = ""
    cfg["connected_at"] = ""
    save_oauth(cfg)


def _next_day_iso(d):
    return (datetime.strptime(d, "%Y-%m-%d").date() + timedelta(days=1)).isoformat()


def _api_event_date(part):
    """Jalali-free date (YYYY-MM-DD) from a Calendar API start/end part."""
    dt = str(part.get("dateTime") or "")
    if dt:
        return dt[:10]
    return str(part.get("date") or "")


def _api_event_time(part):
    """HH:MM from a Calendar API start/end part ('' for all-day events)."""
    dt = str(part.get("dateTime") or "")
    return dt[11:16] if dt else ""


def _api_event_done(item):
    """Done flag from the event's extended properties
    (studyflow.done = "1"/"0"), or None when the event carries none —
    no flag means "no information", never "not done"."""
    props = item.get("extendedProperties") or {}
    priv = props.get("private") or {}
    val = str(priv.get("studyflow.done") or "").strip().lower()
    if val in ("1", "true"):
        return True
    if val in ("0", "false"):
        return False
    return None


def _list_google_events(time_min, time_max):
    """List Google events in a window via the Calendar API (all pages).
    Returns {iCalUID: {id, title, date, start, end, done}} — the same
    shape the app's boxes use, so a live event can be compared with
    last_pushed; `done` is the studyflow.done extended property
    (True/False, or None when the event carries none)."""
    out = {}
    params = {"singleEvents": "true", "maxResults": 2500,
              "timeMin": time_min, "timeMax": time_max}
    page_token = None
    seen_tokens = set()
    for _ in range(20):  # capped: a runaway nextPageToken must end
        q = dict(params)
        if page_token:
            q["pageToken"] = page_token
        path = "/calendars/primary/events?" + urllib.parse.urlencode(q)
        data = google_api("GET", path)
        for item in data.get("items") or []:
            uid = str(item.get("iCalUID") or "")
            eid = str(item.get("id") or "")
            if not uid or not eid:
                continue
            out[uid] = {"id": eid, "title": str(item.get("summary") or ""),
                        "date": _api_event_date(item.get("start") or {}),
                        "start": _api_event_time(item.get("start") or {}),
                        "end": _api_event_time(item.get("end") or {}),
                        "done": _api_event_done(item)}
        page_token = data.get("nextPageToken")
        if not page_token or page_token in seen_tokens:
            break
        seen_tokens.add(page_token)
    return out


def refresh_event_id_map(time_min, time_max, base=None):
    """List events in a window and record iCalUID -> API event id.
    `base` (when given) is merged in first, so in-memory entries made
    earlier in the same push run are never lost. Returns the full map."""
    ps = load_push_state()
    imap = dict(base) if base is not None else dict(ps.get("ical_map") or {})
    for uid, ev in _list_google_events(time_min, time_max).items():
        imap[uid] = ev["id"]
    ps["ical_map"] = imap
    save_push_state(ps)
    return imap


def sync_done_from_google():
    """Pull done flags from Google (extendedProperties studyflow.done) and
    apply them to state.done. Loop-safe: a local change since the last
    sync is never silently overwritten — when both sides changed, Google
    wins (the house rule) and the conflict is recorded; when the local
    side is unchanged since the last sync, Google's value is applied.
    Events with no flag carry no information and are skipped, so a box
    Google never heard about keeps its local status. Changing done status
    never deletes the event or its history. No-op when not connected.
    Returns (applied, conflicts, error) — error is None on success.
    v1.11.16 (audit §5 item 1.4): a failed fetch used to vanish as a
    silent (0, 0); the error is now returned so the caller can show it
    in the sync log instead.
    v1.11.24 (QA BUG-019): split into a fetch phase and an apply phase.
    The Google list call used to run under STATE_LOCK, freezing every
    state save for the whole (up to 30 s) request. The fetch now runs
    with NO lock held; the apply re-loads state/push_state fresh under
    STATE_LOCK, so a tick landing during the fetch is seen (and
    protected by the pending check) instead of being overwritten."""
    cfg = load_oauth()
    if not (cfg.get("access_token") or "").strip() \
            and not (cfg.get("refresh_token") or "").strip():
        return 0, 0, None, 0
    try:
        first, last = _programme_range()
        live = _list_google_events(
            first.isoformat() + "T00:00:00+03:30",
            (last + timedelta(days=1)).isoformat() + "T00:00:00+03:30")
    except Exception as exc:
        err = "خطا در دریافت وضعیت انجام‌شده از گوگل: {}".format(exc)
        print("Done-status pull failed: {}".format(exc))
        return 0, 0, err, 0
    return _apply_done_from_google(live)


def _apply_done_from_google(live):
    """Apply a fetched live-event map to state.done (BUG-019: the
    locked half of sync_done_from_google). Re-loads programme, state
    and push_state fresh, so it never overwrites a tick that landed
    while the fetch was in flight. Returns
    (applied, conflicts, None, skipped_pending) — skipped_pending is
    the v1.11.28 (QA BUG-041) count of boxes the pull had to skip
    because a local tick is still waiting to be pushed: skipping is
    correct (the pull must not revert it), but it used to be
    invisible — (0, 0, None) looked exactly like «everything is in
    sync» while a stuck push silently starved the done flags."""
    prog = load_programme()
    uid_map = dict(prog.get("uid_map") or {})
    state = load_state()
    ps = load_push_state()
    done = dict(state.get("done") or {})
    done_synced = dict(ps.get("done_synced") or {})
    applied = 0
    conflicts = 0
    skipped_pending = 0
    conf_notes = []
    for uid, ev in live.items():
        bid = uid_map.get(uid)
        if not bid:
            continue
        gdone = ev.get("done")
        if gdone is None:
            continue
        # A local change waiting to be pushed (the box is in pending)
        # wins for now: the pull must not revert a tick the user just
        # made before the debounced push has sent it to Google.
        if bid in (ps.get("pending") or []):
            skipped_pending += 1
            continue
        ldone = bool(done.get(bid))
        synced = done_synced.get(bid)
        if gdone == ldone:
            if synced != ldone:
                done_synced[bid] = ldone
            continue
        if synced is not None and ldone != synced:
            # Both sides changed since the last sync: Google wins.
            conflicts += 1
            conf_notes.append({"box_id": bid, "title": ev.get("title") or bid,
                               "ts": iso_now()})
        if gdone:
            done[bid] = True
        else:
            # v1.11.30 (P1-1): a Google un-tick writes false, never
            # deletes the key — the same BUG-002 convention the frontend
            # uses for un-ticks, so the deep merge can tell "unticked"
            # from "never present". The value is still legacy `True`
            # when Google ticks it: Google stores only 1/0, no date.
            done[bid] = False
        done_synced[bid] = gdone
        applied += 1
    if applied:
        state["done"] = done
        save_state(state)
    if applied or conf_notes or done_synced != (ps.get("done_synced") or {}):
        ps["done_synced"] = done_synced
        if conf_notes:
            conf = list(ps.get("conflicts") or [])
            seen_c = {c.get("box_id") for c in conf}
            for c in conf_notes:
                if c["box_id"] not in seen_c:
                    conf.append(c)
            ps["conflicts"] = conf[-20:]
        save_push_state(ps)
    return applied, conflicts, None, skipped_pending


def seed_push_state_after_connect():
    """First-time setup after OAuth: build the iCalUID -> event-id map for
    the whole programme range and seed last_pushed from the PROGRAMME box
    values (raw, no app overlay) — so boxes the app never edited are not
    re-pushed, while app-edited boxes still differ from the seed and get
    pushed on the next push run."""
    try:
        first, last = _programme_range()
        refresh_event_id_map(first.isoformat() + "T00:00:00+03:30",
                             (last + timedelta(days=1)).isoformat() + "T00:00:00+03:30")
        prog = load_programme()
        ps = load_push_state()
        lp = dict(ps.get("last_pushed") or {})
        for b in prog.get("boxes") or []:
            bid = b.get("id")
            if bid and bid not in lp:
                lp[bid] = {"title": b.get("title"), "date": b.get("date"),
                           "start": b.get("start"), "end": b.get("end")}
        ps["last_pushed"] = lp
        save_push_state(ps)
    except Exception as exc:
        print("Push seed after connect failed: {}".format(exc))
        ps = load_push_state()
        ps["last_push"] = {"ts": iso_now(), "ok": False,
                           "error": "آماده‌سازی همگام‌سازی دوطرفه ممکن نشد: {}".format(exc),
                           "summary": None}
        save_push_state(ps)


# ---------- Sync provider interface + Link Store (v1.11.40, P3-13) ----------
# The sync layer used to be a bag of module functions with the box<->event
# identity spread over three maps (programme.uid_map, push_state.event_map,
# push_state.ical_map) and a per-box one-day list refresh inside
# _resolve_event_id (one Google list call per unmapped box — N+1).
# Now:
#   * SyncProvider is the interface a calendar backend must implement:
#     list_events / create_event / update_event / delete_event /
#     read_done / write_done. Only Google exists today
#     (GoogleSyncProvider); adding a second provider is an implementation
#     of this class, not a review of the push code. The methods are thin
#     wrappers over the existing primitives (_list_google_events,
#     google_api, _api_event_done) — same calls, same behaviour.
#   * LinkStore hides the three maps behind resolve(bid, uid) and owns
#     the window prefetch: the push reads the whole programme window
#     ONCE at its start (prefetch_window), and every resolution after
#     that is a map lookup. The prefetch reuses refresh_event_id_map —
#     the same function the old per-box code called, now once for the
#     whole window instead of once per box (the N+1 fix) — so the
#     existing test doubles, which patch server.refresh_event_id_map,
#     still drive it. Its push_state save is the pre-existing phase-B
#     behaviour the old code already had; phase C still commits the
#     working maps by diff.
# Priority everywhere: event_map[bid] first, then ical_map[uid], then
# the @google.com convention (Google-created events use
# <eventId>@google.com as their iCalUID).
class SyncProvider:
    """Calendar backend interface (v1.11.40, P3-13)."""

    def list_events(self, time_min, time_max):
        raise NotImplementedError

    def create_event(self, body):
        raise NotImplementedError

    def update_event(self, event_id, body):
        raise NotImplementedError

    def delete_event(self, event_id):
        raise NotImplementedError

    def read_done(self, event_id):
        raise NotImplementedError

    def write_done(self, event_id, done):
        raise NotImplementedError


class GoogleSyncProvider(SyncProvider):
    """The Google Calendar backend (the only provider today)."""

    def __init__(self, api=None):
        # api: the raw google_api callable. Defaults to this module's
        # google_api; server.py passes its own imported name so the
        # tests' server.google_api patch drives the provider too.
        self._api = api if api is not None else google_api

    def list_events(self, time_min, time_max):
        return _list_google_events(time_min, time_max)

    def create_event(self, body):
        return self._api("POST", "/calendars/primary/events", body)

    def update_event(self, event_id, body):
        return self._api("PATCH", "/calendars/primary/events/"
                         + urllib.parse.quote(event_id, safe=""), body)

    def delete_event(self, event_id):
        return self._api("DELETE", "/calendars/primary/events/"
                         + urllib.parse.quote(event_id, safe=""))

    def read_done(self, event_id):
        item = self._api("GET", "/calendars/primary/events/"
                         + urllib.parse.quote(event_id, safe=""))
        return _api_event_done(item)

    def write_done(self, event_id, done):
        return self._api(
            "PATCH", "/calendars/primary/events/"
            + urllib.parse.quote(event_id, safe=""),
            {"extendedProperties": {"private": {"studyflow.done": "1" if done else "0"}}})


def get_provider(api=None):
    """The calendar sync provider (Google only, today)."""
    return GoogleSyncProvider(api=api)


class LinkStore:
    """Box<->Google-event identity (v1.11.40, P3-13).

    Wraps the three maps the push used to juggle inline:
    programme.uid_map (iCalUID -> box id, written by the pull),
    push_state.event_map (box id -> Google event id) and
    push_state.ical_map (iCalUID -> Google event id). The store holds
    references to the push's WORKING copies, so note_created/drop
    mutate exactly what phase C commits — no second copy, no drift.
    """

    def __init__(self, uid_map, event_map, ical_map, provider=None,
                 refresh_fn=None):
        self.uid_map = uid_map if uid_map is not None else {}
        self.event_map = event_map if event_map is not None else {}
        self.ical_map = ical_map if ical_map is not None else {}
        self.provider = provider if provider is not None else get_provider()
        # refresh_fn: the window-list function. Defaults to this
        # module's refresh_event_id_map; server.py passes its own
        # imported name so the tests' server.refresh_event_id_map
        # patch drives the prefetch too.
        self._refresh_fn = (refresh_fn if refresh_fn is not None
                            else refresh_event_id_map)
        self._prefetched = None  # (time_min, time_max) already loaded

    def resolve(self, bid, uid=None):
        """Google API event id for a box, or None."""
        if bid and self.event_map.get(bid):
            return self.event_map[bid]
        if uid and self.ical_map.get(uid):
            return self.ical_map[uid]
        if uid and uid.endswith("@google.com"):
            return uid[:-len("@google.com")]
        return None

    def prefetch_window(self, time_min, time_max):
        """Read the whole window ONCE and merge it into ical_map.

        Returns the number of events found. A second call for the same
        window is a no-op — the push calls this once at its start, so
        no per-box refresh is ever needed afterwards. The refresh
        function is the refresh_event_id_map the old per-box code
        already called, now once for the whole window.
        """
        if self._prefetched == (time_min, time_max):
            return 0
        fresh = self._refresh_fn(time_min, time_max, base=self.ical_map) or {}
        self.ical_map.update(fresh)
        self._prefetched = (time_min, time_max)
        return len(fresh)

    def note_created(self, bid, event_id, ical_uid=None):
        """Record a freshly created Google event in all three maps."""
        if bid and event_id:
            self.event_map[bid] = event_id
        if ical_uid and event_id:
            self.ical_map[ical_uid] = event_id
            self.uid_map[ical_uid] = bid

    def drop(self, bid, uid=None):
        """Forget every link for a box (its Google event is gone)."""
        if bid:
            self.event_map.pop(bid, None)
        if uid:
            self.ical_map.pop(uid, None)
            self.uid_map.pop(uid, None)
