#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""StudyFlow server — Gemini client (audit §5 item 3.5, v1.11.20).

The stored key is NEVER logged and NEVER returned to the browser;
only the masked form ever leaves the server. Moved verbatim out of
server.py; behaviour is identical.
"""
import collections
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request

from srv.common import (DEFAULT_GEMINI_MODEL, GEMINI_API_BASE, KEY_FILE,
                        MODEL_FILE, open_https_url)

def read_key():
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE, encoding="utf-8") as f:
            return f.read().strip()
    return ""


# Gemini model names are used inside a URL path, so only the characters
# Google allows in a model id may pass (letters, digits, dot, dash, _).
MODEL_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$")


def read_model():
    if os.path.exists(MODEL_FILE):
        try:
            with open(MODEL_FILE, encoding="utf-8") as f:
                m = f.read().strip()
            if MODEL_RE.match(m):
                return m
        except Exception:
            pass
    return DEFAULT_GEMINI_MODEL


def valid_model(name):
    return bool(name) and bool(MODEL_RE.match(name))


def masked_key(key):
    # v1.11.28 (QA BUG-046): the old form leaked the first/last 4 chars
    # of the key to any caller of the status endpoint. A masked key now
    # carries NO key material at all — either "set" (bullets) or "unset"
    # (empty). (The OAuth client-id display in server.py keeps its own
    # first/last-4 mask: a client ID is a public identifier, not a
    # secret, and the UI shows it as the input placeholder.)
    return "••••••••" if key else ""


# ---------- Per-minute Gemini call cap (v1.11.28, QA BUG-048) ----------
# Gemini calls were uncapped: a runaway loop (or a flood of local
# requests) could burn the whole quota. At most 20 calls per rolling
# 60-second window; the 21st is refused locally with a rate_limit
# error instead of reaching Google. A single user never comes close
# to 20/min in normal use (weekly analysis, chat, model list).
GEMINI_MAX_CALLS_PER_MINUTE = 20
GEMINI_RATE_WINDOW_SECONDS = 60
_GEMINI_CALL_TIMES = collections.deque()


def check_gemini_rate_limit():
    """Count one call against the per-minute cap. Returns an error
    string when the cap is hit, else None (and the call is counted)."""
    now = time.monotonic()
    while _GEMINI_CALL_TIMES and _GEMINI_CALL_TIMES[0] <= now - GEMINI_RATE_WINDOW_SECONDS:
        _GEMINI_CALL_TIMES.popleft()
    if len(_GEMINI_CALL_TIMES) >= GEMINI_MAX_CALLS_PER_MINUTE:
        return "سقف فراخوانی جمینای (۲۰ در دقیقه) رد شد — کمی بعد دوباره تلاش کن"
    _GEMINI_CALL_TIMES.append(now)
    return None


# ---------- Gemini request core (shared by /api/gemini and /api/gemini-test) ----------
# The stored key is NEVER logged and NEVER returned to the browser; only the
# masked form (bullets, no key characters — v1.11.28) ever leaves the
# server. Error messages from Google do not contain the key.
TEST_PROMPT = "Reply with exactly this word: OK"
TEST_MAX_TOKENS = 8

# v1.11.45 (bug-hunt B-10): the /api/gemini chat path forwarded the
# whole prompt with no length cap (the body cap is 10 MB) and no
# maxOutputTokens at all. Prompts over 20 000 chars are refused by the
# handler before any Google call; an uncapped chat request defaults
# to 4096 output tokens instead of unbounded.
GEMINI_MAX_PROMPT_CHARS = 20000
GEMINI_DEFAULT_MAX_TOKENS = 4096


def _gemini_request(model, prompt, timeout=60, max_tokens=None):
    """One generateContent call with the stored key.

    Returns a dict: {"ok", "text", "kind", "code", "message"}.
    kind is None on success, else one of: auth | rate_limit | not_found |
    network | model | unknown. "message" is the exact upstream error text
    (or a local message for network/empty-response failures).
    """
    key = read_key()
    if not key:
        return {"ok": False, "text": "", "kind": "auth", "code": None,
                "message": "کلید API جمینای معتبر نیست"}
    # v1.11.28 (QA BUG-048): per-minute call cap, enforced before the
    # request leaves the server.
    rate_err = check_gemini_rate_limit()
    if rate_err:
        return {"ok": False, "text": "", "kind": "rate_limit", "code": 429,
                "message": rate_err}
    body = {"contents": [{"parts": [{"text": prompt}]}]}
    if max_tokens is None:
        # The chat path passes no cap: default instead of unbounded.
        max_tokens = GEMINI_DEFAULT_MAX_TOKENS
    if max_tokens:
        body["generationConfig"] = {"maxOutputTokens": max_tokens}
    payload = json.dumps(body).encode("utf-8")
    # v1.11.28 (QA BUG-046): the key used to ride in the URL as
    # ?key=... — it lands in server logs, proxy logs and browser
    # history. Google accepts the x-goog-api-key header instead, so
    # the key never appears in a URL again.
    req = urllib.request.Request(
        GEMINI_API_BASE + "/models/" + model + ":generateContent",
        data=payload,
        headers={"Content-Type": "application/json",
                 "x-goog-api-key": key},
        method="POST",
    )
    try:
        # v1.11.24 (QA BUG-012): redirects are re-checked for https.
        with open_https_url(req, timeout=timeout) as resp:
            result = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail_msg = ""
        try:
            detail = json.loads(exc.read().decode("utf-8", "replace"))
            detail_msg = str(((detail.get("error") or {}).get("message") or "")).strip()
        except Exception:
            pass
        if exc.code in (400, 401, 403):
            kind = "auth"
        elif exc.code == 404:
            kind = "not_found"
        elif exc.code == 429:
            kind = "rate_limit"
        elif exc.code >= 500:
            kind = "model"
        else:
            kind = "unknown"
        if not detail_msg:
            detail_msg = "خطای سرور جمینای: HTTP " + str(exc.code)
        return {"ok": False, "text": "", "kind": kind, "code": exc.code,
                "message": detail_msg}
    except Exception as exc:
        return {"ok": False, "text": "", "kind": "network", "code": None,
                "message": "ارتباط با جمینای برقرار نشد: " + str(exc)}
    # v1.11.45 (bug-hunt B-11): a 200 with non-dict JSON (e.g. a bare
    # list) used to raise AttributeError on result.get below — no HTTP
    # response at all. Treat it as the model returning nothing usable.
    if not isinstance(result, dict):
        return {"ok": False, "text": "", "kind": "model", "code": None,
                "message": "جمینای پاسخی نداد"}
    cands = result.get("candidates") or [{}]
    parts = cands[0].get("content", {}).get("parts", [])
    text = "".join(p.get("text", "") for p in parts).strip()
    if not text:
        return {"ok": False, "text": "", "kind": "model", "code": None,
                "message": "جمینای پاسخی نداد"}
    return {"ok": True, "text": text, "kind": None, "code": None, "message": ""}

