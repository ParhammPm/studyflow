#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""StudyFlow server — data layer (v1.11.38, P3-11): Repository.

All file access for state / programme / testbook / calendar config /
OAuth / push state goes through here. load_state() is split into a
side-effect-free read_state() + an explicit one-time migrate_state();
load_state() itself keeps the old behaviour (read + migrate if needed
+ recovery chain) so existing callers are unchanged. server.py keeps
thin re-exports of these names so tests and drivers keep working.
"""
import json
import os
import re
from datetime import datetime, timedelta

from srv.backup import (
    CLOUD_SYNC,
    cloud_restore_latest,
    create_backup,
    newest_verified_backup,
)
from srv.common import (
    APP_STATE_FILE,
    APP_TESTBOOK_FILE,
    BASE,
    CALENDAR_CONFIG_FILE,
    CALENDAR_DATA_FILE,
    GOOGLE_OAUTH_FILE,
    GOOGLE_PUSH_FILE,
    PUBLIC,
    STATE_FILE,
    STATE_LOCK,
    STATE_SCHEMA_VERSION,
    TEHRAN,
    TESTBOOK_FILE,
    DEFAULT_STATE,
    _preserve_corrupt,
    atomic_write_json,
    iso_now,
    merge_state,
    read_json_file,
    state_rejected_keys,
    valid_state,
    valid_testbook,
)


DEFAULT_GOOGLE_CLIENT_ID = ("695272599724-cv1g08aem3ajt079bj11dfdb96c1ibsg"
                            ".apps.googleusercontent.com")


def load_testbook():
    data, _ = read_json_file(TESTBOOK_FILE)
    if data is not None and valid_testbook(data):
        return data
    if os.path.isfile(TESTBOOK_FILE):
        # Corrupt (unparseable, or valid JSON with the wrong shape) —
        # preserve it before any recovery overwrites it (BUG-009).
        _preserve_corrupt(TESTBOOK_FILE)
        print("testbook.json is corrupt — restoring from backup")
    entry, backup = newest_verified_backup("testbook")
    if backup is not None:
        atomic_write_json(TESTBOOK_FILE, backup)
        print("Restored testbook.json from backup {}".format(entry["file"]))
        return backup
    data, _ = read_json_file(APP_TESTBOOK_FILE)
    if data is not None and valid_testbook(data):
        atomic_write_json(TESTBOOK_FILE, data)
        return data
    data = cloud_restore_latest("testbook")
    if data is not None:
        atomic_write_json(TESTBOOK_FILE, data)
        return data
    return {"books": []}


def save_testbook(data):
    with STATE_LOCK:
        atomic_write_json(TESTBOOK_FILE, data)
        create_backup("testbook")
        CLOUD_SYNC.request()
    return data


def read_state():
    """Side-effect-free state read (v1.11.38, P3-11): returns
    (data, status) where status is "ok", "missing", "corrupt" or
    "invalid". Reads the file and validates it — it never writes,
    migrates or restores anything. Callers that need the old
    load-then-migrate behaviour use load_state()."""
    data, _ = read_json_file(STATE_FILE)
    if data is not None and valid_state(data):
        return data, "ok"
    if os.path.isfile(STATE_FILE):
        return None, "corrupt"
    return None, "missing"


def migrate_state(data):
    """Explicit one-time state migration (v1.11.38, P3-11): merges
    `data` onto the schema and rewrites the file once when the stored
    version differs or rejected keys are present. Returns the merged
    state. Called only from load_state()."""
    merged = merge_state(data)
    # Migration on load (audit §5 item 1.9): a file written before
    # the schema existed (no version field) or carrying rejected
    # keys is rewritten once, migrated, so the disk copy is clean
    # and future loads need no migration.
    if data.get("version") != STATE_SCHEMA_VERSION or state_rejected_keys(data):
        try:
            atomic_write_json(STATE_FILE, merged)
            print("Migrated state.json to schema v{}".format(STATE_SCHEMA_VERSION))
        except Exception as exc:
            print("state migration write failed: {}".format(exc))
    return merged


def load_state():
    data, status = read_state()
    if status == "ok":
        return migrate_state(data)
    if status == "corrupt":
        # Corrupt (unparseable, or valid JSON with the wrong shape) —
        # preserve it before any recovery overwrites it (BUG-009).
        _preserve_corrupt(STATE_FILE)
        print("state.json is corrupt — restoring from backup")
    entry, backup = newest_verified_backup("state")
    if backup is not None:
        atomic_write_json(STATE_FILE, backup)
        print("Restored state.json from backup {}".format(entry["file"]))
        return merge_state(backup)
    data, _ = read_json_file(APP_STATE_FILE)
    if data is not None and valid_state(data):
        atomic_write_json(STATE_FILE, data)
        return merge_state(data)
    data = cloud_restore_latest("state")
    if data is not None:
        atomic_write_json(STATE_FILE, data)
        return merge_state(data)
    return dict(DEFAULT_STATE)


def save_state(data):
    with STATE_LOCK:
        merged = merge_state(data)
        atomic_write_json(STATE_FILE, merged)
        create_backup("state")
        CLOUD_SYNC.request()
    return merged


def _programme_range():
    """(first, last) programme dates, for recurring-event expansion."""
    data, _ = read_json_file(CALENDAR_DATA_FILE)
    boxes = []
    if isinstance(data, dict) and isinstance(data.get("boxes"), list):
        boxes = data["boxes"]
    else:
        shipped, _ = read_json_file(os.path.join(BASE, "data.json"))
        if isinstance(shipped, dict) and isinstance(shipped.get("boxes"), list):
            boxes = shipped["boxes"]
    if boxes:
        # v1.11.45 (bug-hunt B-07): one bad box date used to kill every
        # pull/push via unguarded strptime. Skip unparseable dates; the
        # range falls back to the remaining valid min/max (or today+180d
        # when none parses, as before).
        parsed = []
        for b in boxes:
            d = b.get("date")
            if not d:
                continue
            try:
                parsed.append(datetime.strptime(d, "%Y-%m-%d").date())
            except Exception:
                continue
        if parsed:
            return (min(parsed), max(parsed))
    today = datetime.now(tz=TEHRAN).date()
    return (today, today + timedelta(days=180))


class ProgrammeCorruptError(Exception):
    """calendar_data.json exists but is unreadable and no verified backup
    restores it (v1.11.25, QA BUG-024). The shipped seed must NEVER be
    substituted silently here: it would drop every Google link and every
    programme change since install, and the next save would persist the
    stale seed over the real data. Handlers turn this into a 500 with
    this message; the sync path records it in the sync log."""


def load_programme():
    data, _ = read_json_file(CALENDAR_DATA_FILE)
    if isinstance(data, dict) and isinstance(data.get("boxes"), list):
        data.setdefault("uid_map", {})
        data.setdefault("tombstone_uids", [])
        data.setdefault("tombstone_box_ids", [])
        data.setdefault("meta", {})
        return data
    had_file = os.path.isfile(CALENDAR_DATA_FILE)
    if had_file:
        # Corrupt (unparseable, or valid JSON with the wrong shape) —
        # preserve it before any recovery overwrites it (v1.11.23, QA
        # BUG-009). Without this, a corrupt programme silently fell
        # back to the shipped 318-box seed with an empty uid_map —
        # every Google link lost.
        _preserve_corrupt(CALENDAR_DATA_FILE)
        print("calendar_data.json is corrupt — restoring from backup")
    entry, backup = newest_verified_backup("programme")
    if backup is not None:
        atomic_write_json(CALENDAR_DATA_FILE, backup)
        print("Restored calendar programme from backup {}".format(entry["file"]))
        return backup
    if had_file:
        # v1.11.25 (QA BUG-024): corrupt WITH no backup — never fall back
        # to the shipped seed. The corrupt bytes are already preserved
        # as .corrupt-<ts>; the user restores a backup or repairs the
        # file by hand. The seed is only for a first install (no file
        # ever existed).
        raise ProgrammeCorruptError(
            "فایل برنامه (calendar_data.json) خراب است و بکاپی برای بازیابی نیست — "
            "فایل خراب حفظ شده است؛ یک بکاپ را restore کن یا فایل را دستی برگردان")
    shipped, _ = read_json_file(os.path.join(BASE, "data.json"))
    if isinstance(shipped, dict) and isinstance(shipped.get("boxes"), list):
        return {"meta": dict(shipped.get("meta") or {}),
                "boxes": shipped["boxes"], "uid_map": {},
                "tombstone_uids": [], "tombstone_box_ids": []}
    return {"meta": {}, "boxes": [], "uid_map": {},
            "tombstone_uids": [], "tombstone_box_ids": []}


def save_programme(prog):
    with STATE_LOCK:
        atomic_write_json(CALENDAR_DATA_FILE, prog)
        create_backup("programme")
        CLOUD_SYNC.request()
    return prog


def load_calendar_config():
    data, _ = read_json_file(CALENDAR_CONFIG_FILE)
    if isinstance(data, dict):
        data.setdefault("log", [])
        return data
    # v1.11.45 (bug-hunt B-08): a corrupt config used to be silently
    # replaced by defaults and the next save destroyed the corrupt
    # bytes for good (the BUG-009 fix never extended here). Preserve
    # it first, exactly like load_state does.
    _preserve_corrupt(CALENDAR_CONFIG_FILE)
    return {"ics_url": "", "interval_minutes": 30, "enabled": False,
            "last_sync": None, "last_error": None, "last_summary": None,
            "log": []}


def save_calendar_config(cfg):
    atomic_write_json(CALENDAR_CONFIG_FILE, cfg)


def load_oauth():
    data, _ = read_json_file(GOOGLE_OAUTH_FILE)
    if isinstance(data, dict):
        # Backfill the default Client ID for installs that saved an empty
        # one before it existed (e.g. a cleared-credentials file).
        if not (data.get("client_id") or "").strip():
            data["client_id"] = DEFAULT_GOOGLE_CLIENT_ID
        return data
    # v1.11.45 (bug-hunt B-08): preserve a corrupt OAuth file before
    # falling back to defaults (BUG-009 pattern) — the tokens are the
    # one thing that cannot be re-derived from anywhere else.
    _preserve_corrupt(GOOGLE_OAUTH_FILE)
    return {"client_id": DEFAULT_GOOGLE_CLIENT_ID, "client_secret": "",
            "access_token": "", "refresh_token": "", "expires_at": 0,
            "account_email": "", "connected_at": "", "last_error": None,
            "pending_state": "", "pending_state_ts": 0,
            "pending_verifier": "", "pending_flows": {}}


def save_oauth(cfg):
    # Credential file (holds the Google OAuth tokens): 0600, owner only
    # (audit §5 item 1.10).
    atomic_write_json(GOOGLE_OAUTH_FILE, cfg, mode=0o600)


def load_push_state():
    """Load google_push_state.json (the push bookkeeping: event_map,
    ical_map, created event ids, what the app edited, what is pending,
    last push, done_synced). v1.11.25 (QA BUG-025): this file had NO
    backup or recovery — losing it meant the next push re-created every
    event and duplicated Google's calendar. It now recovers exactly like
    the other stores: preserve the corrupt file (.corrupt-<ts>), restore
    the newest verified push backup."""
    data, _ = read_json_file(GOOGLE_PUSH_FILE)
    had_file = os.path.isfile(GOOGLE_PUSH_FILE)
    if not isinstance(data, dict):
        if had_file:
            _preserve_corrupt(GOOGLE_PUSH_FILE)
            print("google_push_state.json is corrupt — restoring from backup")
        entry, backup = newest_verified_backup("push")
        if backup is not None and isinstance(backup, dict):
            atomic_write_json(GOOGLE_PUSH_FILE, backup)
            print("Restored push state from backup {}".format(entry["file"]))
            data = backup
    if not isinstance(data, dict):
        data = {}
        if had_file:
            # v1.11.45 (bug-hunt B-20): corrupt with NO verified backup —
            # the maps reset to empty and the next push would silently
            # re-create every event (duplicates). Surface the reset in
            # last_push so push_status_payload shows it instead of
            # looking like a clean first run.
            data["last_push"] = {
                "ts": iso_now(), "ok": False,
                "error": "وضعیت همگام‌سازی خراب بود و بکاپی برای بازیابی نبود — پیوندها بازنشانی شدند؛ همگام‌سازی بعدی رویدادها را دوباره می‌سازد"}
    data.setdefault("event_map", {})
    data.setdefault("ical_map", {})
    data.setdefault("created_event_ids", [])
    data.setdefault("app_edited_at", {})
    data.setdefault("last_pushed", {})
    data.setdefault("pending", [])
    data.setdefault("conflicts", [])
    data.setdefault("last_push", None)
    # done_synced (v1.11.7): boxId -> the done value Google last had
    # (True/False). The loop-prevention record for the two-way done
    # sync: a push PATCHes only when local != done_synced, and a pull
    # applies Google's flag only when local == done_synced (or the
    # box was never synced — first sync, Google wins).
    data.setdefault("done_synced", {})
    return data


def save_push_state(ps):
    with STATE_LOCK:
        atomic_write_json(GOOGLE_PUSH_FILE, ps)
    # v1.11.25 (QA BUG-025): the push state is backed up like the other
    # stores now — create_backup dedupes identical content, so the
    # frequent small saves stay cheap.
    create_backup("push")



_SUBJECTS_FALLBACK = [
    {"id": "exam-analysis", "fa": "تحلیل آزمون", "en": "Exam Analysis", "type": "other"},
    {"id": "error-review", "fa": "مرور دفترچه خطا", "en": "Error Notebook Review", "type": "other"},
    {"id": "exam-review", "fa": "مرور و جمع‌بندی آزمون", "en": "Exam Review & Summary", "type": "other"},
    {"id": "advising", "fa": "جلسه مشاور درسی", "en": "Study Counselling Session", "type": "other"},
    {"id": "english", "fa": "زبان انگلیسی", "en": "English", "type": "general", "core": True},
    {"id": "calculus", "fa": "حسابان", "en": "Calculus", "type": "specialized", "core": True},
    {"id": "chemistry", "fa": "شیمی", "en": "Chemistry", "type": "specialized", "core": True},
    {"id": "physics", "fa": "فیزیک", "en": "Physics", "type": "specialized", "core": True},
    {"id": "geometry", "fa": "هندسه", "en": "Geometry", "type": "specialized", "core": True},
    {"id": "discrete", "fa": "گسسته", "en": "Discrete Math", "type": "specialized", "core": True},
    {"id": "literature", "fa": "ادبیات", "en": "Literature", "type": "general", "core": True},
    {"id": "persian", "fa": "فارسی", "en": "Persian", "type": "general"},
    {"id": "arabic", "fa": "عربی", "en": "Arabic", "type": "general", "core": True},
    {"id": "dini", "fa": "دینی", "en": "Religion", "type": "general", "core": True},
    {"id": "language", "fa": "زبان", "en": "Language", "type": "general"},
    {"id": "exam", "fa": "آزمون", "en": "Exam", "type": "exam"},
]
_SUBJECTS_CACHE = None


def load_subjects():
    """The single SUBJECTS table (v1.11.38, P3-12): read from
    public/i18n.js (between the SUBJECTS_TABLE_BEGIN/END markers —
    strict JSON), cached after the first read. Falls back to the
    embedded copy if the markers are missing (e.g. a hand-edited
    i18n.js) so ICS title parsing never breaks."""
    global _SUBJECTS_CACHE
    if _SUBJECTS_CACHE is not None:
        return _SUBJECTS_CACHE
    try:
        with open(os.path.join(PUBLIC, "i18n.js"), encoding="utf-8") as f:
            text = f.read()
        m = re.search(r"// SUBJECTS_TABLE_BEGIN\s*\nconst SUBJECTS = (\[.*?\]);\s*\n// SUBJECTS_TABLE_END",
                      text, re.S)
        if m:
            rows = json.loads(m.group(1))
            if isinstance(rows, list) and rows and all(
                    isinstance(r, dict) and r.get("fa") for r in rows):
                _SUBJECTS_CACHE = rows
                return rows
    except Exception as exc:
        print("load_subjects fell back to embedded table: {}".format(exc))
    _SUBJECTS_CACHE = list(_SUBJECTS_FALLBACK)
    return _SUBJECTS_CACHE
