#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""StudyFlow server — shared core (audit §5 item 3.5, v1.11.20).

Paths, locks, atomic writes, the state schema and the small pure
helpers. No HTTP, no sync, no updater logic: every other module
imports from here, and nothing here imports from them, so there is
no import cycle. server.py re-exports these names into its own
namespace, so the rest of the (unmoved) server code is unchanged.
"""
import hashlib
import ipaddress
import json
import os
import re
import shutil
import socket
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

# BASE is the app folder (the tree root): this module lives in srv/, so
# go one level up from __file__.
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PUBLIC = os.path.join(BASE, "public")
PORT = 8765
VERSION_FILE = os.path.join(BASE, "version.json")
GEMINI_API_BASE = "https://generativelanguage.googleapis.com/v1beta"
DEFAULT_GEMINI_MODEL = "gemini-2.5-flash"

# ---------- Layer 0: data directory (outside the app folder) ----------
APP_STATE_FILE = os.path.join(BASE, "state.json")          # legacy: migration source only
APP_TESTBOOK_FILE = os.path.join(BASE, "testbook.json")    # legacy: migration source only
APP_KEY_FILE = os.path.join(BASE, "gemini_key.txt")        # legacy: migration source only


def resolve_data_dir():
    override = os.environ.get("KONKUR_DATA_DIR")
    if override:
        return override
    appdata = os.environ.get("APPDATA")
    if appdata:
        return os.path.join(appdata, "KonkurApp")
    home = os.path.expanduser("~")
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", "KonkurApp")
    return os.path.join(home, ".local", "share", "KonkurApp")


DATA_DIR = resolve_data_dir()
STATE_FILE = os.path.join(DATA_DIR, "state.json")
TESTBOOK_FILE = os.path.join(DATA_DIR, "testbook.json")
KEY_FILE = os.path.join(DATA_DIR, "gemini_key.txt")
# The selected Gemini model is stored server-side (data dir) and used by /api/gemini.
MODEL_FILE = os.path.join(DATA_DIR, "gemini_model.txt")
B2_CONFIG_FILE = os.path.join(DATA_DIR, "b2_config.json")
CALENDAR_CONFIG_FILE = os.path.join(DATA_DIR, "calendar_config.json")
CALENDAR_DATA_FILE = os.path.join(DATA_DIR, "calendar_data.json")
GOOGLE_OAUTH_FILE = os.path.join(DATA_DIR, "google_oauth.json")
GOOGLE_PUSH_FILE = os.path.join(DATA_DIR, "google_push_state.json")
BACKUP_DIR = os.path.join(DATA_DIR, "backups")
BACKUP_META_FILE = os.path.join(DATA_DIR, "backup_meta.json")
MAX_BACKUPS_PER_KIND = 30
CLOUD_PREFIX = "konkur-backup/"
CLOUD_MANIFEST_KEY = "latest.json"

DEFAULT_STATE = {
    # State schema version (audit §5 item 1.9): stamped on every save and
    # migration; load_state() migrates older files in place.
    "version": 1,
    # Programme range (audit §5 item 1.7): state fields, not hardcoded
    # constants — the programme ends 2026-12-18 today and must extend to
    # next year when the user enters more programme.
    "programme_start": "2026-10-24",
    "programme_end": "2026-12-18",
    "done": {},
    "tests": {},
    "tests_total": {},
    "subjects": ["گسسته", "شیمی", "حسابان", "فیزیک", "هندسه", "عربی", "دینی", "ادبیات", "زبان انگلیسی"],
    "theme": "dark",
    "lang": "fa",
    "custom_boxes": [],
    "deleted": [],
    "edits": {},
    # Backlog view (v1.11.7): per-item hidden flags for the overdue list
    # only — hiding a box here never deletes it from the programme,
    # history or review-past; the flag is the only thing stored.
    "backlogHidden": {},
    # Backlog pins (v1.11.9): the user explicitly moved a box to the
    # backlog via its three-dot menu. Pinned boxes show in the backlog
    # view alongside the done past parts (the v1.6.0 rule is unchanged
    # except for explicitly pinned items); the flag is the only thing
    # stored, the box itself is never copied or moved.
    "backlogPinned": {},
    "daysDone": {},
    "topicLinks": {},
    # Book links per box (v1.11.45, bug-hunt B-13): boxBookLinks[boxId] =
    # {bookId, chapterId?} — the exam-topic <-> book linking. It was in
    # STATE_KEY_TYPES but missing from DEFAULT_STATE, so a fresh state
    # had no key for it at all.
    "boxBookLinks": {},
    "assignments": None,
    "assignmentsRemoved": [],
    # Real study time (v1.8.0): actualMinutes[boxId] = finished seconds
    # (timer stops + manual entries); timerSessions = the session records
    # behind that total; activeTimer = the running/paused session, stored
    # server-side so a restart resumes it honestly from its stored start.
    "actualMinutes": {},
    "timerSessions": [],
    "activeTimer": None,
    # Timed exam simulation (v1.11.55, F5): a running sim survives a
    # refresh — {examId, endsAt (ms epoch), rows: {subject: {correct,
    # wrong, unanswered}}} or null. The interval id is NOT stored
    # (module-level only); endsAt alone is enough to resume the clock.
    "sim": None,
    # Useful time (v1.11.21): usefulMinutes[boxId] = useful SECONDS
    # (same unit as actualMinutes, despite the name). Useful is
    # recorded independently of real time and must never exceed it;
    # an ABSENT entry means "not recorded" — never 0, never invented.
    # Per-session useful lives on the session records (useful: seconds
    # or null); the box total above is the source of truth.
    "usefulMinutes": {},
    # Pending useful-time prompt (v1.11.43, audit §16 item 22): the
    # "how useful was this session?" question survives a refresh —
    # {boxId, seconds} or null. Was module-level only (lost on
    # refresh); the session stays «ثبت نشده» until answered.
    "usefulPrompt": None,
    # Dismissed gentle nudges (v1.11.43, §17 idea 10): nudgeHidden[boxId]
    # = the study day it was hidden on. A nudge hidden today never
    # shows again that day; old entries are pruned on the next dismiss.
    "nudgeHidden": {},
    # Next-box reminder (v1.11.48, P-4): nextBoxRemind = the setting
    # (True = on, default on); nextBoxReminded[boxId] = the study day
    # the reminder already fired on — one toast per box per day.
    "nextBoxRemind": True,
    "nextBoxReminded": {},
    # Exams (state.exams): three independent stores {maz, zoodbist, school}.
    # Null = not migrated yet; the app seeds from public/exams.json on first
    # load and folds the old examResults into each exam's result field.
    "exams": None,
    "examsRemoved": [],
    # Seed exams already offered to the user (by id). ensureExams() only
    # seeds ids NOT in this list, so a Reset (which clears state.exams)
    # does not resurrect the seed exams, while a future version's NEW
    # seed exams still seed on first load.
    "examsSeededIds": [],
    # Exam results (state.examResults): only Maz stage 4 is pre-filled — the
    # user's verified result. Every other exam starts empty. Kept for the
    # migration into state.exams; new results live on the exam objects.
    "examResults": {"maz-4": {"taraz": 7411, "rank": 17664, "rankTotal": 52614,
                              "correct": 17, "wrong": 10, "unanswered": 68, "note": ""}},
    # Timestamped test entries (v1.11.20, audit §5 item 3.2): append-only
    # deltas {d, box?, topic?, solved, correct, wrong, src}. Totals stay
    # in state.tests / the book manual counts — the log is only for
    # trends. Old totals are NEVER converted into dated entries.
    "testLog": [],
    # Error notebook 2.0 (v1.11.20, audit §5 item 3.3): per-subject
    # opt-in, default OFF — an absent subject is disabled.
    "errorNotebook": {},
    # Wrong-question log entries {id, d, subject, source, q, type, note,
    # reviewed, nextReview, interval}.
    "errorLog": [],
    # Spaced repetition (v1.11.20, audit §5 item 3.4): per chapter id
    # {last, interval, ease}.
    "chapterSR": {},
    # Gemini history (v1.11.20, audit §5 item 3.6b): saved analyses
    # {id, d, model, question, text}, newest first, capped at 20.
    "geminiHistory": [],
    # Daily goal (v1.11.38, P3-9): the user's own target, display-only.
    # kind "useful" counts useful minutes, kind "boxes" counts ticked
    # boxes. Default: 8 useful hours.
    "dailyGoal": {"kind": "useful", "minutes": 480},
    # Exam-day pack checklist (v1.11.40, creative 1): examPack[examId] =
    # {bringCard: bool, bringPen: bool, bringId: bool} — what to bring
    # to the exam, ticked on the exam-day card in the Today tab.
    "examPack": {},
}

# ---------- State schema (audit §5 item 1.9) ----------
# Top-level state keys the app may store, with the type each one must
# have. POST /api/state rejects anything else (unknown keys like
# "__proto__" and wrong-typed values) so a corrupt or hostile body can
# never poison the state or wipe the renderer. Every key the frontend
# ever sets on `state` must be listed here — a missing entry would drop
# real user data, so keep this in sync with app.js.
STATE_SCHEMA_VERSION = 1
STATE_KEY_TYPES = {
    "version": int,
    "programme_start": str,
    "programme_end": str,
    "done": dict,
    "tests": dict,
    "tests_total": dict,
    "subjects": list,
    "theme": str,
    "lang": str,
    "custom_boxes": list,
    "deleted": list,
    "edits": dict,
    "backlogHidden": dict,
    "backlogPinned": dict,
    "daysDone": dict,
    "topicLinks": dict,
    "boxBookLinks": dict,
    "assignments": (list, type(None)),
    "assignmentsRemoved": list,
    "actualMinutes": dict,
    "timerSessions": list,
    "activeTimer": (dict, type(None)),
    "sim": (dict, type(None)),
    "usefulMinutes": dict,
    "usefulPrompt": (dict, type(None)),
    "nudgeHidden": dict,
    "nextBoxRemind": bool,
    "nextBoxReminded": dict,
    "exams": (dict, type(None)),
    "examsRemoved": list,
    "examsSeededIds": list,
    "examResults": dict,
    "testLog": list,
    "errorNotebook": dict,
    "errorLog": list,
    "chapterSR": dict,
    "geminiHistory": list,
    "dailyGoal": dict,
    "examPack": dict,
}

def state_rejected_keys(data):
    """Top-level keys in `data` that the schema rejects (unknown keys and
    wrong-typed values). Returns a list of key names."""
    if not isinstance(data, dict):
        return []
    return [k for k, v in data.items()
            if k not in STATE_KEY_TYPES or not isinstance(v, STATE_KEY_TYPES[k])]


def state_wrong_typed_keys(data):
    """Known keys whose value has the wrong type (v1.11.23, QA BUG-001).
    Unknown keys are NOT included: they are harmless — sanitize_state
    drops them and the stored value survives — so the POST handler only
    rejects the case that actually wipes data (a known key with a wrong
    type, which merge_state would drop and fall back to DEFAULT_STATE)."""
    if not isinstance(data, dict):
        return []
    return [k for k, v in data.items()
            if k in STATE_KEY_TYPES and not isinstance(v, STATE_KEY_TYPES[k])]


def sanitize_state(data):
    """Return a copy of `data` with only schema-valid top-level keys.
    Unknown keys and wrong-typed values are dropped (the caller merges
    onto DEFAULT_STATE, so dropped keys fall back to their defaults)."""
    if not isinstance(data, dict):
        return {}
    return {k: v for k, v in data.items()
            if k in STATE_KEY_TYPES and isinstance(v, STATE_KEY_TYPES[k])}


# ---------- Small helpers ----------
def sha256_bytes(raw):
    return hashlib.sha256(raw).hexdigest()


def now_ts():
    return int(time.time())


def iso_now():
    return datetime.now(tz=TEHRAN).isoformat(timespec="seconds")


def ensure_data_dir():
    os.makedirs(BACKUP_DIR, exist_ok=True)


# One lock for every load-modify-save sequence on server-side data
# (ThreadingHTTPServer serves each request on its own thread). RLock:
# save_state() is called from inside locked sequences (merge, box API),
# so the same thread must be able to re-enter it.
STATE_LOCK = threading.RLock()


def _with_lock(fn):
    """Decorator: run a load-modify-save function under STATE_LOCK."""
    def wrapper(*args, **kwargs):
        with STATE_LOCK:
            return fn(*args, **kwargs)
    wrapper.__name__ = fn.__name__
    return wrapper


# v1.11.16 (audit §5 item 1.2): the three sync entry points must never
# overlap. Two concurrent pushes both see an unmapped box, both POST a
# new Google event (duplicate), and the second save_push_state
# overwrites the first's event_map (lost update); a pull landing
# mid-push has the same shape. STATE_LOCK (via @_with_lock) serializes
# them against state/push_state saves too, and SYNC_LOCK is the
# push-specific mutex — both are always taken in the same order
# (STATE_LOCK first, then SYNC_LOCK), so no deadlock. The functions
# never call each other, so the plain Lock is never re-entered.
SYNC_LOCK = threading.Lock()


def _with_sync_lock(fn):
    """Decorator: run a sync entry point under SYNC_LOCK."""
    def wrapper(*args, **kwargs):
        with SYNC_LOCK:
            return fn(*args, **kwargs)
    wrapper.__name__ = fn.__name__
    return wrapper


class _DebouncedWorker:
    """Shared debounced-worker loop (v1.11.54, D-6): PushSync
    (server) and CloudSync (backup) had the same shape —
    _event/_immediate Events, request(), a run loop with a 15 s
    debounce + periodic wake. Subclasses supply the wait timeout,
    the work callable and the error handler; the loop itself lives
    here once."""

    def __init__(self, wait_timeout, work, on_error):
        self._event = threading.Event()
        self._immediate = threading.Event()
        self._wait_timeout = wait_timeout
        self._work = work
        self._on_error = on_error

    def request(self, immediate=False):
        self._event.set()
        if immediate:
            self._immediate.set()

    def run(self):
        while True:
            self._event.wait(timeout=self._wait_timeout)
            self._event.clear()
            if self._immediate.is_set():
                self._immediate.clear()
            else:
                time.sleep(15)
            try:
                self._work()
            except Exception as exc:
                self._on_error(exc)


# Per-box in-flight guard (audit §5 item 1.2): a box is never pushed
# twice at the same time. Whole-run serialization (SYNC_LOCK) already
# makes this unreachable today — the set is belt-and-braces for any
# future caller that bypasses the lock. Only touched under STATE_LOCK.
_PUSH_IN_FLIGHT = set()


# ---------- HTTPS-only redirects (v1.11.24, QA BUG-012) ----------
# ---------- SSRF guard (v1.11.28, QA BUG-043) ----------
# The server fetches attacker-influenced URLs (the ICS feed address,
# the update manifest, the manual update URL): an address pointing at
# 169.254.169.254, localhost or a private LAN IP used to be fetched
# without any check. Every server-side fetch goes through
# open_https_url(), so the check lives here — once, for all of them.
# A hostname is resolved and EVERY resolved address must be a public
# (global) unicast IP; an IP literal is checked directly. Fail closed
# on anything that resolves non-public; an unresolvable host is left
# to fail at connect time (it connects to nothing). Legitimate fetches
# are all public hosts (calendar.google.com, raw.githubusercontent.com,
# generativelanguage.googleapis.com, Google's OAuth/API hosts), so
# they are unaffected.
def validate_public_url(url):
    """Raise ValueError unless url's host resolves only to public IPs.
    An unresolvable host is NOT an error here: the fetch itself fails
    on it (URLError) without ever connecting anywhere, so there is
    nothing to guard — rejecting it would only turn a DNS outage into
    a different error. Any host that DOES resolve to a private,
    loopback, link-local, multicast, reserved or unspecified address
    (or a mix containing one) is rejected before any connection."""
    try:
        host = urllib.parse.urlparse(str(url or "")).hostname
    except Exception:
        host = None
    if not host:
        raise ValueError("آدرس معتبر نیست — میزبان ندارد")
    try:
        ips = [str(ipaddress.ip_address(host))]
    except ValueError:
        try:
            infos = socket.getaddrinfo(host, None, proto=socket.IPPROTO_TCP)
        except Exception:
            return True  # unresolvable: the fetch fails on its own
        ips = []
        for info in infos:
            try:
                ips.append(str(info[4][0]))
            except Exception:
                continue
    if not ips:
        return True  # nothing resolved: nothing to connect to
    for ip in ips:
        try:
            addr = ipaddress.ip_address(ip)
        except ValueError:
            raise ValueError("آدرس IP نامعتبر برای میزبان: {}".format(host)) from None
        # is_global is False for private, loopback, link-local,
        # multicast, reserved and unspecified addresses alike.
        if not addr.is_global:
            raise ValueError(
                "آدرس غیرعمومی مجاز نیست: {} ({})".format(host, ip))
    return True


# urllib follows redirects blindly: an https URL that 302s to http
# silently downgrades the download (ICS / manifest / update zip) to
# plain HTTP, where it can be tampered with on the path. Every
# server-side fetch goes through open_https_url(), whose redirect
# handler re-checks the scheme on EVERY hop — a redirect to anything
# but https is refused. Relative Location headers resolve against the
# request URL, so they stay https.
class _HttpsOnlyRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        target = urllib.parse.urljoin(req.get_full_url(), newurl)
        if urllib.parse.urlparse(target).scheme != "https":
            raise urllib.error.HTTPError(
                target, code,
                "redirect to a non-https URL is not allowed", headers, fp)
        # v1.11.28 (QA BUG-043): a redirect hop to a private IP is the
        # same SSRF as a direct fetch of one — check the target too.
        validate_public_url(target)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def open_https_url(req, timeout=None):
    """urlopen with the https-only redirect guard (BUG-012). The
    initial URL's scheme is the caller's job (fetch_ics etc. check
    https:// up front); this guards every redirect hop after it.
    v1.11.28 (QA BUG-043): the destination host is resolved and
    rejected unless it is public, before any connection is made."""
    url = req.get_full_url() if hasattr(req, "get_full_url") else str(req)
    validate_public_url(url)
    opener = urllib.request.build_opener(_HttpsOnlyRedirectHandler())
    return opener.open(req, timeout=timeout)


def atomic_write(path, raw, mode=0o644):
    """Write bytes atomically: unique temp file in the same dir + os.replace.
    The temp name is unique per call (tempfile.mkstemp) — a shared
    '{path}.{pid}.tmp' let two threads write the same temp file and
    corrupt each other's data. `mode` is the final permission bits:
    credential files pass 0o600 (audit §5 item 1.10)."""
    ensure_data_dir()
    fd, tmp = tempfile.mkstemp(prefix=".tmp-", dir=os.path.dirname(path) or ".")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(raw)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        try:
            os.chmod(tmp, mode)
        except OSError:
            pass
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


def atomic_write_json(path, obj, mode=0o644):
    atomic_write(path, json.dumps(obj, ensure_ascii=False, indent=2).encode("utf-8"), mode=mode)


def read_json_file(path):
    """Returns (obj or None, error or None)."""
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f), None
    except Exception as exc:
        return None, exc


def _preserve_corrupt(path):
    """Copy a corrupt data file aside as <file>.corrupt-<ts> BEFORE any
    recovery overwrites it (v1.11.23, QA BUG-009). The auto-restore used
    to overwrite the corrupt bytes with a backup (or defaults) and the
    next save destroyed them for good. Returns the preserved path or
    None (missing file is not corrupt — first run — and is not preserved).
    Lives here (not srv.repository) so every store loader — state,
    programme, push state, calendar config, OAuth, B2, update config —
    can reuse it without an import cycle."""
    try:
        if not os.path.isfile(path):
            return None
        dst = "{}.corrupt-{}".format(path, int(time.time()))
        shutil.copyfile(path, dst)
        print("Preserved corrupt file as {}".format(dst))
        return dst
    except Exception as exc:
        print("Could not preserve corrupt file {}: {}".format(path, exc))
        return None


def valid_state(data):
    return isinstance(data, dict)


def valid_testbook(data):
    return isinstance(data, dict) and isinstance(data.get("books"), list)


def clamp_useful_minutes(data):
    """v1.11.21: useful time must never exceed real time, and never be
    invented. Clamps usefulMinutes[boxId] to actualMinutes[boxId]
    (both in seconds), drops invalid per-box entries, and clamps each
    session's `useful` to its own `seconds` (non-numeric useful becomes
    null = not recorded). Called from merge_state, the single save
    path, so every POST /api/state and every load is covered."""
    useful = data.get("usefulMinutes")
    if not isinstance(useful, dict):
        data["usefulMinutes"] = {}
        useful = data["usefulMinutes"]
    actual = data.get("actualMinutes")
    if not isinstance(actual, dict):
        actual = {}
    for bid in list(useful.keys()):
        v = useful[bid]
        if isinstance(v, bool) or not isinstance(v, (int, float)) or v < 0:
            del useful[bid]
            continue
        # Clamp only against a KNOWN stored real total. When the stored
        # real is 0/absent the timer may still be running (its live
        # seconds are not in actualMinutes yet) — clamping to 0 would
        # delete legitimately recorded useful time. The frontend setter
        # (which sees the live timer) is the primary validator.
        real = actual.get(bid)
        if isinstance(real, (int, float)) and not isinstance(real, bool) and real > 0:
            useful[bid] = min(v, real)
    sessions = data.get("timerSessions")
    if isinstance(sessions, list):
        for s in sessions:
            if not isinstance(s, dict):
                continue
            u = s.get("useful")
            if u is None:
                continue
            if isinstance(u, bool) or not isinstance(u, (int, float)) or u < 0:
                s["useful"] = None
                continue
            secs = s.get("seconds")
            if isinstance(secs, (int, float)) and not isinstance(secs, bool) and secs >= 0:
                s["useful"] = min(u, secs)


# ---------- Nested state validation (v1.11.24, QA BUG-013) ----------
# sanitize_state only checks top-level types: nested garbage survived
# (tests {"b171": null}, actualMinutes {"b171": "60"} — the "60"
# string then concatenated with live seconds in the frontend).
# Length caps were missing too (a 2 MB title grew state.json to
# 6.3 MB). This runs inside merge_state, so every save path is
# covered. Invalid nested values are DROPPED (never coerced — a
# string where a number belongs is garbage, not a number); over-long
# text is TRUNCATED to its cap so the entry survives usable.
TITLE_MAX_LEN = 500
NOTE_MAX_LEN = 5000
SUBJECT_MAX_LEN = 100


def _is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _clean_num_map(d):
    """{boxId: number} in place — drop non-numeric / negative entries."""
    if not isinstance(d, dict):
        return
    for k in list(d.keys()):
        if not _is_num(d[k]) or d[k] < 0:
            del d[k]


def _clean_bool_map(d):
    """{key: bool} in place — drop non-boolean entries."""
    if not isinstance(d, dict):
        return
    for k in list(d.keys()):
        if not isinstance(d[k], bool):
            del d[k]


def _is_done_date(v):
    """A valid tick-date value: an ISO YYYY-MM-DD string, or None."""
    if not isinstance(v, str):
        return False
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", v):
        return False
    try:
        datetime.strptime(v, "%Y-%m-%d")
    except ValueError:
        return False
    return True


def _clean_done_map(d):
    """state.done in place (v1.11.30, P1-1): {boxId: tick} where a tick
    is `false` (explicitly unticked — BUG-002: false, never delete),
    `true` (legacy tick from before dates were recorded — done, date
    unknown, never fabricated and never dropped), or
    {"d": "YYYY-MM-DD"} (the study day the box was ticked). Anything
    else (a wrong-typed value, a dict without a valid d) is dropped —
    it can only come from a tampered file or a stale client."""
    if not isinstance(d, dict):
        return
    for k in list(d.keys()):
        v = d[k]
        if isinstance(v, bool):
            continue
        if isinstance(v, dict) and _is_done_date(v.get("d")):
            d[k] = {"d": v["d"]}
            continue
        del d[k]


def _trunc_str(v, cap):
    """A string truncated to `cap`, or None when not a string."""
    if not isinstance(v, str):
        return None
    return v[:cap] if len(v) > cap else v


# Caps for the append-only state logs (v1.11.45, bug-hunt B-14).
# geminiHistory's own documented cap is 20 (same as the frontend
# GM_HISTORY_MAX); the test/error/timer logs keep a few thousand.
GEMINI_HISTORY_MAX = 20
STATE_LOG_MAX = 2000


def _sanitize_tests_entries(data):
    """tests: {boxId: {completed, correct}} — non-dict entries dropped;
    non-numeric fields dropped (a tests entry is always a dict)."""
    # tests: {boxId: {completed, correct}} — non-dict entries dropped;
    # non-numeric fields dropped (a tests entry is always a dict; the
    # frontend writes {completed, correct} and nothing else).
    tests = data.get("tests")
    if isinstance(tests, dict):
        for bid in list(tests.keys()):
            tr = tests[bid]
            if not isinstance(tr, dict):
                del tests[bid]
                continue
            for f in ("completed", "correct"):
                if f in tr and (not _is_num(tr[f]) or tr[f] < 0):
                    del tr[f]


def _sanitize_edits_overlay(data):
    """edits overlay: only the keys the UI/box API write; text capped."""
    # edits overlay: only the keys the UI/box API write; text capped.
    edits = data.get("edits")
    if isinstance(edits, dict):
        for bid in list(edits.keys()):
            ov = edits[bid]
            if not isinstance(ov, dict):
                del edits[bid]
                continue
            for k in list(ov.keys()):
                if k in ("title", "subject", "date", "start", "end", "note", "type"):
                    cap = (TITLE_MAX_LEN if k == "title" else
                           NOTE_MAX_LEN if k == "note" else
                           SUBJECT_MAX_LEN if k == "subject" else 200)
                    v = _trunc_str(ov[k], cap)
                    if v is None:
                        del ov[k]
                    else:
                        ov[k] = v
                else:
                    del ov[k]


def _sanitize_custom_boxes(data):
    """custom boxes: drop non-dict entries; a box without a string title
    is garbage; text capped."""
    # custom boxes: drop non-dict entries; a box without a string title
    # is garbage; text capped.
    cbs = data.get("custom_boxes")
    if isinstance(cbs, list):
        kept = []
        for b in cbs:
            if not isinstance(b, dict):
                continue
            t = _trunc_str(b.get("title"), TITLE_MAX_LEN)
            if t is None or not t.strip():
                continue
            b["title"] = t
            if "subject" in b:
                s = _trunc_str(b.get("subject"), SUBJECT_MAX_LEN)
                if s is None:
                    del b["subject"]
                else:
                    b["subject"] = s
            if "note" in b:
                n = _trunc_str(b.get("note"), NOTE_MAX_LEN)
                if n is None:
                    del b["note"]
                else:
                    b["note"] = n
            if "tests_total" in b and (not _is_num(b["tests_total"])
                                       or b["tests_total"] < 0):
                del b["tests_total"]
            kept.append(b)
        data["custom_boxes"] = kept


def _sanitize_subjects_links_sr(data):
    """subjects (strings only, capped), topicLinks ({key: sectionId
    string}) and chapterSR ({chapter: {last, interval, ease}})."""
    # subjects: strings only, capped.
    subs = data.get("subjects")
    if isinstance(subs, list):
        data["subjects"] = [s[:SUBJECT_MAX_LEN] for s in subs
                            if isinstance(s, str)]
    # topicLinks: {key: sectionId string}.
    tl = data.get("topicLinks")
    if isinstance(tl, dict):
        for k in list(tl.keys()):
            if not isinstance(tl[k], str):
                del tl[k]
    # chapterSR: {chapter: {last, interval, ease}}.
    sr = data.get("chapterSR")
    if isinstance(sr, dict):
        for k in list(sr.keys()):
            v = sr[k]
            if not isinstance(v, dict):
                del sr[k]
                continue
            for f in ("interval", "ease"):
                if f in v and not _is_num(v[f]):
                    del v[f]
            if "last" in v and not isinstance(v["last"], str):
                del v["last"]


def _sanitize_logs(data):
    """list-of-dict logs: drop non-dict entries, cap the unbounded logs
    keeping the NEWEST entries (v1.11.45, B-14)."""
    # List-of-dict logs: drop non-dict entries. Timer sessions also
    # need numeric seconds (a session without them is garbage).
    # v1.11.45 (bug-hunt B-14): cap the unbounded logs, keeping the
    # NEWEST entries — a runaway client could otherwise grow these
    # lists without limit on every save. geminiHistory is capped at
    # 20 (its own documented cap, same as the frontend GM_HISTORY_MAX);
    # the append-only logs at 2000 entries each.
    for key in ("testLog", "errorLog", "assignments", "geminiHistory"):
        v = data.get(key)
        if isinstance(v, list):
            data[key] = [e for e in v if isinstance(e, dict)]
    if isinstance(data.get("geminiHistory"), list):
        data["geminiHistory"] = data["geminiHistory"][-GEMINI_HISTORY_MAX:]
    for key in ("testLog", "errorLog"):
        if isinstance(data.get(key), list):
            data[key] = data[key][-STATE_LOG_MAX:]
    ts = data.get("timerSessions")
    if isinstance(ts, list):
        data["timerSessions"] = [
            s for s in ts if isinstance(s, dict)
            and _is_num(s.get("seconds")) and s["seconds"] >= 0][-STATE_LOG_MAX:]


def _sanitize_id_lists_results(data):
    """string id lists (strings only) and examResults (cap the note)."""
    # String id lists: strings only.
    for key in ("deleted", "examsRemoved", "examsSeededIds"):
        v = data.get(key)
        if isinstance(v, list):
            data[key] = [x for x in v if isinstance(x, str)]
    # examResults: {examId: {...}} — cap the note.
    er = data.get("examResults")
    if isinstance(er, dict):
        for k in list(er.keys()):
            v = er[k]
            if not isinstance(v, dict):
                del er[k]
                continue
            if "note" in v:
                n = _trunc_str(v.get("note"), NOTE_MAX_LEN)
                if n is None:
                    del v["note"]
                else:
                    v["note"] = n


def sanitize_nested_state(data):
    """Validate nested values + length caps in place (BUG-013). `data`
    is the merged state dict (DEFAULT_STATE + sanitized top level)."""
    if not isinstance(data, dict):
        return data
    # Per-box numeric maps: numbers only, never negative.
    _clean_num_map(data.get("tests_total"))
    _clean_num_map(data.get("actualMinutes"))
    # usefulMinutes is clamped by clamp_useful_minutes (drops non-numeric).
    # done: tick values — false / legacy true / {"d": date} (v1.11.30,
    # P1-1) — NOT a plain bool map anymore; _clean_done_map keeps the
    # new shape and drops garbage.
    _clean_done_map(data.get("done"))
    # backlog / daysDone / errorNotebook: boolean flags only.
    _clean_bool_map(data.get("backlogHidden"))
    _clean_bool_map(data.get("backlogPinned"))
    _clean_bool_map(data.get("daysDone"))
    _clean_bool_map(data.get("errorNotebook"))
    _sanitize_tests_entries(data)
    _sanitize_edits_overlay(data)
    _sanitize_custom_boxes(data)
    _sanitize_subjects_links_sr(data)
    _sanitize_logs(data)
    _sanitize_id_lists_results(data)
    # activeTimer: {boxId, ...} — boxId must be a string.
    at = data.get("activeTimer")
    if isinstance(at, dict) and "boxId" in at \
            and not isinstance(at["boxId"], str):
        data["activeTimer"] = None
    # sim (v1.11.55, F5): {examId: str, endsAt: ms epoch, rows:
    # {subject: {correct, wrong, unanswered: non-negative numbers}}}.
    # Anything else (or a row count past the cap) drops the whole sim —
    # a stale sim is rebuilt by starting a new run, never repaired.
    _sanitize_sim(data)
    return data


def _sanitize_sim(data):
    sim = data.get("sim")
    if sim is None:
        return
    if not isinstance(sim, dict):
        data["sim"] = None
        return
    if not isinstance(sim.get("examId"), str) or not sim["examId"]:
        data["sim"] = None
        return
    if not isinstance(sim.get("endsAt"), (int, float)) or isinstance(sim.get("endsAt"), bool):
        data["sim"] = None
        return
    rows = sim.get("rows")
    if not isinstance(rows, dict) or len(rows) > 50:
        data["sim"] = None
        return
    clean = {}
    for subj, r in rows.items():
        if not isinstance(subj, str) or not isinstance(r, dict):
            continue
        clean[subj] = {
            f: (r[f] if isinstance(r.get(f), (int, float)) and not isinstance(r.get(f), bool) and r[f] >= 0 else 0)
            for f in ("correct", "wrong", "unanswered")
        }
    if not clean:
        data["sim"] = None
        return
    sim["rows"] = clean


def merge_state(data):
    # Schema first (audit §5 item 1.9): unknown keys and wrong-typed
    # values never enter the state — dropped keys fall back to the
    # DEFAULT_STATE value via the merge below.
    merged = dict(DEFAULT_STATE)
    merged.update(sanitize_state(data))
    merged["version"] = STATE_SCHEMA_VERSION
    sanitize_nested_state(merged)
    clamp_useful_minutes(merged)
    return merged


# v1.11.23 (QA BUG-002): per-box deep merge for the POST /api/state
# save path. Two tabs editing DIFFERENT boxes no longer overwrite each
# other's ticks/tests/minutes: the merge keeps both tabs' per-box
# entries (new wins per box, old entries for other boxes survive).
# Deliberately SCOPED to the dict keys whose entries are only ever SET
# by the client (never deleted, except by purgeBoxState for a deleted
# box — inert): done, tests, edits, actualMinutes, tests_total. The
# other dict keys are NOT merged — the client DELETES entries from them
# (clear useful, unlink, unpin, unmark day, opt out), and a key-level
# merge would resurrect the deleted entry on the next save, even
# single-tab. A full 3-way merge (client base snapshot + seq) is the
# correct general fix for those keys; it is a bigger design change and
# is NOT attempted here. Same-box concurrent edits stay last-writer-
# wins; list-valued keys (assignments, timerSessions, testLog,
# errorLog, custom_boxes, deleted) stay whole-replace, as before.
# NOTE on `done`: un-tick must set `false`, never `delete` the key —
# the merge cannot tell a deleted key from a never-present one, so the
# frontend was changed (v1.11.23) to write false on un-tick; every
# done consumer already reads truthiness (isDone / bool(...)).
_MERGED_STATE_KEYS = ("done", "tests", "edits", "actualMinutes", "tests_total")


def merge_state_update_scoped(old, new):
    """Merge an incoming POST /api/state body onto the CURRENT stored
    state (both plain dicts). Returns the merged dict (NOT yet passed
    through merge_state — the caller still saves via save_state, which
    sanitizes + clamps)."""
    merged = dict(old)
    for k, v in new.items():
        old_v = old.get(k)
        if k in _MERGED_STATE_KEYS and isinstance(old_v, dict) and isinstance(v, dict):
            nv = dict(old_v)
            nv.update(v)
            merged[k] = nv
        elif k == "activeTimer" and v is None and isinstance(old_v, dict) and old_v:
            # Never let a stale tab's null wipe a running timer: accept
            # the null only when the saver banked more real seconds for
            # that box — i.e. it stopped the timer (timerStopCurrent
            # banks actualMinutes and clears activeTimer in one save).
            bid = old_v.get("boxId")
            old_real = (old.get("actualMinutes") or {}).get(bid) or 0
            new_real = (new.get("actualMinutes") or {}).get(bid) or 0
            if (isinstance(new_real, (int, float)) and not isinstance(new_real, bool)
                    and isinstance(old_real, (int, float)) and not isinstance(old_real, bool)
                    and new_real > old_real):
                merged[k] = None
            else:
                merged[k] = old_v
        else:
            merged[k] = v
    return merged

TEHRAN = timezone(timedelta(hours=3, minutes=30))

def read_version():
    data, _ = read_json_file(VERSION_FILE)
    if isinstance(data, dict) and data.get("version"):
        return {"version": str(data["version"]),
                "build_date": str(data.get("build_date") or "")}
    return {"version": "dev", "build_date": ""}

