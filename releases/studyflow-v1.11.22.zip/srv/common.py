#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""StudyFlow server — shared core (audit §5 item 3.5, v1.11.20).

Paths, locks, atomic writes, the state schema and the small pure
helpers. No HTTP, no sync, no updater logic: every other module
imports from here, and nothing here imports from them, so there is
no import cycle. server.py re-exports these names into its own
namespace, so the rest of the (unmoved) server code is unchanged.
"""
import hashlib
import json
import os
import sys
import tempfile
import threading
import time
from datetime import datetime, timedelta, timezone

# BASE is the app folder (the tree root): this module lives in srv/, so
# go one level up from __file__.
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PUBLIC = os.path.join(BASE, "public")
PORT = 8765
VERSION_FILE = os.path.join(BASE, "version.json")
GEMINI_API_BASE = "https://generativelanguage.googleapis.com/v1beta"
DEFAULT_GEMINI_MODEL = "gemini-2.5-flash"

# ---------- Layer 0: data directory (outside the app folder) ----------
APP_STATE_FILE = os.path.join(BASE, "state.json")          # legacy: migration source only
APP_TESTBOOK_FILE = os.path.join(BASE, "testbook.json")    # legacy: migration source only
APP_KEY_FILE = os.path.join(BASE, "gemini_key.txt")        # legacy: migration source only


def resolve_data_dir():
    override = os.environ.get("KONKUR_DATA_DIR")
    if override:
        return override
    appdata = os.environ.get("APPDATA")
    if appdata:
        return os.path.join(appdata, "KonkurApp")
    home = os.path.expanduser("~")
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", "KonkurApp")
    return os.path.join(home, ".local", "share", "KonkurApp")


DATA_DIR = resolve_data_dir()
STATE_FILE = os.path.join(DATA_DIR, "state.json")
TESTBOOK_FILE = os.path.join(DATA_DIR, "testbook.json")
KEY_FILE = os.path.join(DATA_DIR, "gemini_key.txt")
# The selected Gemini model is stored server-side (data dir) and used by /api/gemini.
MODEL_FILE = os.path.join(DATA_DIR, "gemini_model.txt")
B2_CONFIG_FILE = os.path.join(DATA_DIR, "b2_config.json")
BACKUP_DIR = os.path.join(DATA_DIR, "backups")
BACKUP_META_FILE = os.path.join(DATA_DIR, "backup_meta.json")
MAX_BACKUPS_PER_KIND = 30
CLOUD_PREFIX = "konkur-backup/"
CLOUD_MANIFEST_KEY = "latest.json"

DEFAULT_STATE = {
    # State schema version (audit §5 item 1.9): stamped on every save and
    # migration; load_state() migrates older files in place.
    "version": 1,
    # Programme range (audit §5 item 1.7): state fields, not hardcoded
    # constants — the programme ends 2026-12-18 today and must extend to
    # next year when the user enters more programme.
    "programme_start": "2026-10-24",
    "programme_end": "2026-12-18",
    "done": {},
    "tests": {},
    "tests_total": {},
    "subjects": ["گسسته", "شیمی", "حسابان", "فیزیک", "هندسه", "عربی", "دینی", "ادبیات", "زبان انگلیسی"],
    "theme": "dark",
    "lang": "fa",
    "custom_boxes": [],
    "deleted": [],
    "edits": {},
    # Backlog view (v1.11.7): per-item hidden flags for the overdue list
    # only — hiding a box here never deletes it from the programme,
    # history or review-past; the flag is the only thing stored.
    "backlogHidden": {},
    # Backlog pins (v1.11.9): the user explicitly moved a box to the
    # backlog via its three-dot menu. Pinned boxes show in the backlog
    # view alongside the done past parts (the v1.6.0 rule is unchanged
    # except for explicitly pinned items); the flag is the only thing
    # stored, the box itself is never copied or moved.
    "backlogPinned": {},
    "daysDone": {},
    "topicLinks": {},
    "assignments": None,
    "assignmentsRemoved": [],
    # Real study time (v1.8.0): actualMinutes[boxId] = finished seconds
    # (timer stops + manual entries); timerSessions = the session records
    # behind that total; activeTimer = the running/paused session, stored
    # server-side so a restart resumes it honestly from its stored start.
    "actualMinutes": {},
    "timerSessions": [],
    "activeTimer": None,
    # Useful time (v1.11.21): usefulMinutes[boxId] = useful SECONDS
    # (same unit as actualMinutes, despite the name). Useful is
    # recorded independently of real time and must never exceed it;
    # an ABSENT entry means "not recorded" — never 0, never invented.
    # Per-session useful lives on the session records (useful: seconds
    # or null); the box total above is the source of truth.
    "usefulMinutes": {},
    # Exams (state.exams): three independent stores {maz, zoodbist, school}.
    # Null = not migrated yet; the app seeds from public/exams.json on first
    # load and folds the old examResults into each exam's result field.
    "exams": None,
    "examsRemoved": [],
    # Seed exams already offered to the user (by id). ensureExams() only
    # seeds ids NOT in this list, so a Reset (which clears state.exams)
    # does not resurrect the seed exams, while a future version's NEW
    # seed exams still seed on first load.
    "examsSeededIds": [],
    # Exam results (state.examResults): only Maz stage 4 is pre-filled — the
    # user's verified result. Every other exam starts empty. Kept for the
    # migration into state.exams; new results live on the exam objects.
    "examResults": {"maz-4": {"taraz": 7411, "rank": 17664, "rankTotal": 52614,
                              "correct": 17, "wrong": 10, "unanswered": 68, "note": ""}},
    # Timestamped test entries (v1.11.20, audit §5 item 3.2): append-only
    # deltas {d, box?, topic?, solved, correct, wrong, src}. Totals stay
    # in state.tests / the book manual counts — the log is only for
    # trends. Old totals are NEVER converted into dated entries.
    "testLog": [],
    # Error notebook 2.0 (v1.11.20, audit §5 item 3.3): per-subject
    # opt-in, default OFF — an absent subject is disabled.
    "errorNotebook": {},
    # Wrong-question log entries {id, d, subject, source, q, type, note,
    # reviewed, nextReview, interval}.
    "errorLog": [],
    # Spaced repetition (v1.11.20, audit §5 item 3.4): per chapter id
    # {last, interval, ease}.
    "chapterSR": {},
    # Gemini history (v1.11.20, audit §5 item 3.6b): saved analyses
    # {id, d, model, question, text}, newest first, capped at 20.
    "geminiHistory": [],
}

# ---------- State schema (audit §5 item 1.9) ----------
# Top-level state keys the app may store, with the type each one must
# have. POST /api/state rejects anything else (unknown keys like
# "__proto__" and wrong-typed values) so a corrupt or hostile body can
# never poison the state or wipe the renderer. Every key the frontend
# ever sets on `state` must be listed here — a missing entry would drop
# real user data, so keep this in sync with app.js.
STATE_SCHEMA_VERSION = 1
STATE_KEY_TYPES = {
    "version": int,
    "programme_start": str,
    "programme_end": str,
    "done": dict,
    "tests": dict,
    "tests_total": dict,
    "subjects": list,
    "theme": str,
    "lang": str,
    "custom_boxes": list,
    "deleted": list,
    "edits": dict,
    "backlogHidden": dict,
    "backlogPinned": dict,
    "daysDone": dict,
    "topicLinks": dict,
    "boxBookLinks": dict,
    "assignments": (list, type(None)),
    "assignmentsRemoved": list,
    "actualMinutes": dict,
    "timerSessions": list,
    "activeTimer": (dict, type(None)),
    "usefulMinutes": dict,
    "exams": (dict, type(None)),
    "examsRemoved": list,
    "examsSeededIds": list,
    "examResults": dict,
    "testLog": list,
    "errorNotebook": dict,
    "errorLog": list,
    "chapterSR": dict,
    "geminiHistory": list,
}

def state_rejected_keys(data):
    """Top-level keys in `data` that the schema rejects (unknown keys and
    wrong-typed values). Returns a list of key names."""
    if not isinstance(data, dict):
        return []
    return [k for k, v in data.items()
            if k not in STATE_KEY_TYPES or not isinstance(v, STATE_KEY_TYPES[k])]


def sanitize_state(data):
    """Return a copy of `data` with only schema-valid top-level keys.
    Unknown keys and wrong-typed values are dropped (the caller merges
    onto DEFAULT_STATE, so dropped keys fall back to their defaults)."""
    if not isinstance(data, dict):
        return {}
    return {k: v for k, v in data.items()
            if k in STATE_KEY_TYPES and isinstance(v, STATE_KEY_TYPES[k])}


# ---------- Small helpers ----------
def sha256_bytes(raw):
    return hashlib.sha256(raw).hexdigest()


def now_ts():
    return int(time.time())


def iso_now():
    return datetime.now(tz=TEHRAN).isoformat(timespec="seconds")


def ensure_data_dir():
    os.makedirs(BACKUP_DIR, exist_ok=True)


# One lock for every load-modify-save sequence on server-side data
# (ThreadingHTTPServer serves each request on its own thread). RLock:
# save_state() is called from inside locked sequences (merge, box API),
# so the same thread must be able to re-enter it.
STATE_LOCK = threading.RLock()


def _with_lock(fn):
    """Decorator: run a load-modify-save function under STATE_LOCK."""
    def wrapper(*args, **kwargs):
        with STATE_LOCK:
            return fn(*args, **kwargs)
    wrapper.__name__ = fn.__name__
    return wrapper


# v1.11.16 (audit §5 item 1.2): the three sync entry points must never
# overlap. Two concurrent pushes both see an unmapped box, both POST a
# new Google event (duplicate), and the second save_push_state
# overwrites the first's event_map (lost update); a pull landing
# mid-push has the same shape. STATE_LOCK (via @_with_lock) serializes
# them against state/push_state saves too, and SYNC_LOCK is the
# push-specific mutex — both are always taken in the same order
# (STATE_LOCK first, then SYNC_LOCK), so no deadlock. The functions
# never call each other, so the plain Lock is never re-entered.
SYNC_LOCK = threading.Lock()


def _with_sync_lock(fn):
    """Decorator: run a sync entry point under SYNC_LOCK."""
    def wrapper(*args, **kwargs):
        with SYNC_LOCK:
            return fn(*args, **kwargs)
    wrapper.__name__ = fn.__name__
    return wrapper


# Per-box in-flight guard (audit §5 item 1.2): a box is never pushed
# twice at the same time. Whole-run serialization (SYNC_LOCK) already
# makes this unreachable today — the set is belt-and-braces for any
# future caller that bypasses the lock. Only touched under STATE_LOCK.
_PUSH_IN_FLIGHT = set()


def atomic_write(path, raw, mode=0o644):
    """Write bytes atomically: unique temp file in the same dir + os.replace.
    The temp name is unique per call (tempfile.mkstemp) — a shared
    '{path}.{pid}.tmp' let two threads write the same temp file and
    corrupt each other's data. `mode` is the final permission bits:
    credential files pass 0o600 (audit §5 item 1.10)."""
    ensure_data_dir()
    fd, tmp = tempfile.mkstemp(prefix=".tmp-", dir=os.path.dirname(path) or ".")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(raw)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        try:
            os.chmod(tmp, mode)
        except OSError:
            pass
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


def atomic_write_json(path, obj, mode=0o644):
    atomic_write(path, json.dumps(obj, ensure_ascii=False, indent=2).encode("utf-8"), mode=mode)


def read_json_file(path):
    """Returns (obj or None, error or None)."""
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f), None
    except Exception as exc:
        return None, exc


def valid_state(data):
    return isinstance(data, dict)


def valid_testbook(data):
    return isinstance(data, dict) and isinstance(data.get("books"), list)


def clamp_useful_minutes(data):
    """v1.11.21: useful time must never exceed real time, and never be
    invented. Clamps usefulMinutes[boxId] to actualMinutes[boxId]
    (both in seconds), drops invalid per-box entries, and clamps each
    session's `useful` to its own `seconds` (non-numeric useful becomes
    null = not recorded). Called from merge_state, the single save
    path, so every POST /api/state and every load is covered."""
    useful = data.get("usefulMinutes")
    if not isinstance(useful, dict):
        data["usefulMinutes"] = {}
        useful = data["usefulMinutes"]
    actual = data.get("actualMinutes")
    if not isinstance(actual, dict):
        actual = {}
    for bid in list(useful.keys()):
        v = useful[bid]
        if isinstance(v, bool) or not isinstance(v, (int, float)) or v < 0:
            del useful[bid]
            continue
        # Clamp only against a KNOWN stored real total. When the stored
        # real is 0/absent the timer may still be running (its live
        # seconds are not in actualMinutes yet) — clamping to 0 would
        # delete legitimately recorded useful time. The frontend setter
        # (which sees the live timer) is the primary validator.
        real = actual.get(bid)
        if isinstance(real, (int, float)) and not isinstance(real, bool) and real > 0:
            useful[bid] = min(v, real)
    sessions = data.get("timerSessions")
    if isinstance(sessions, list):
        for s in sessions:
            if not isinstance(s, dict):
                continue
            u = s.get("useful")
            if u is None:
                continue
            if isinstance(u, bool) or not isinstance(u, (int, float)) or u < 0:
                s["useful"] = None
                continue
            secs = s.get("seconds")
            if isinstance(secs, (int, float)) and not isinstance(secs, bool) and secs >= 0:
                s["useful"] = min(u, secs)


def merge_state(data):
    # Schema first (audit §5 item 1.9): unknown keys and wrong-typed
    # values never enter the state — dropped keys fall back to the
    # DEFAULT_STATE value via the merge below.
    merged = dict(DEFAULT_STATE)
    merged.update(sanitize_state(data))
    merged["version"] = STATE_SCHEMA_VERSION
    clamp_useful_minutes(merged)
    return merged

TEHRAN = timezone(timedelta(hours=3, minutes=30))

def read_version():
    data, _ = read_json_file(VERSION_FILE)
    if isinstance(data, dict) and data.get("version"):
        return {"version": str(data["version"]),
                "build_date": str(data.get("build_date") or "")}
    return {"version": "dev", "build_date": ""}

