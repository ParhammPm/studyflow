#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""StudyFlow server — self-updater (audit §5 item 3.5, v1.11.20).

Code backups, zip validation, install/rollback, restart and the
auto-update manifest check. Moved verbatim out of server.py;
behaviour is identical. UPDATE_REQUIRED now also lists the srv/
modules: a zip without them would restart into a broken tree, so
the validator refuses it instead.
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from datetime import datetime

from srv.common import (BASE, DATA_DIR, VERSION_FILE, atomic_write_json,
                        ensure_data_dir, iso_now, now_ts, read_json_file,
                        read_version)

# ---------- In-app self-update (Part 5) ----------
# The app folder holds ONLY code. User data (state.json, testbook.json,
# gemini_key.txt, gemini_model.txt, b2_config.json) lives in the data dir and
# is never touched by an update. Before every install the current code folder
# is copied to a versioned backup inside the data dir, so a bad update can be
# rolled back from the UI.
CODE_BACKUP_DIR = os.path.join(DATA_DIR, "code-backups")
UPDATE_STAGING_DIR = os.path.join(DATA_DIR, "update-staging")
MAX_UPDATE_ZIP_BYTES = 50 * 1024 * 1024
MAX_CODE_BACKUPS = 3
UPDATE_REQUIRED = ("server.py", "public/index.html", "public/app.js",
                   "srv/__init__.py", "srv/common.py", "srv/gemini.py",
                   "srv/update.py")
# Data files that must never be overwritten or deleted inside the app folder,
# even if an update zip (or an old install) contains them there.
PROTECTED_APP_FILES = ("state.json", "testbook.json", "gemini_key.txt",
                       "gemini_model.txt", "b2_config.json",
                       "google_oauth.json", "google_push_state.json",
                       "calendar_config.json", "calendar_data.json")
# Top-level files/dirs an update must never DELETE. They are NOT in the
# release zip (which only restores code), so wiping them would lose them
# for good. Deliberately separate from PROTECTED_APP_FILES: the pre-wipe
# move loop in install_update_zip() relocates protected files into the
# data dir, where nothing reads data.json (the programme seed the server
# falls back to) or tools/ (the release builder).
KEEP_APP_FILES = ("data.json", "exams.json", "tools")


def validate_update_zip(path):
    """Returns (version_dict, error_str). error_str is None when valid."""
    if not os.path.exists(path) or not zipfile.is_zipfile(path):
        return None, "فایل zip معتبر نیست"
    try:
        with zipfile.ZipFile(path) as zf:
            names = zf.namelist()
            for n in names:
                parts = n.replace("\\", "/").split("/")
                if n.startswith("/") or n.startswith("\\") or ".." in parts \
                        or (len(n) > 1 and n[1] == ":"):
                    return None, "فایل zip مسیرهای غیرمجاز دارد"
            missing = [r for r in UPDATE_REQUIRED if r not in names]
            if missing:
                return None, "این فایل zip کامل نیست — کم دارد: " + ", ".join(missing)
            if zf.testzip() is not None:
                return None, "فایل zip خراب است"
            version = {"version": "dev", "build_date": ""}
            if "version.json" in names:
                try:
                    v = json.loads(zf.read("version.json").decode("utf-8"))
                    if isinstance(v, dict) and v.get("version"):
                        version = {"version": str(v["version"]),
                                   "build_date": str(v.get("build_date") or "")}
                except Exception:
                    pass
            return version, None
    except Exception as exc:
        return None, "خواندن فایل zip ممکن نشد: " + str(exc)


def _wipe_app_folder():
    """Delete everything in the app folder except protected data files
    and the KEEP list (data.json seed, tools/). Missing-file errors are
    ignored (a running server.py may be locked on Windows — extraction
    overwrites it anyway)."""
    for entry in os.listdir(BASE):
        if entry in PROTECTED_APP_FILES or entry in KEEP_APP_FILES:
            continue
        p = os.path.join(BASE, entry)
        try:
            if os.path.isdir(p):
                shutil.rmtree(p, ignore_errors=True)
            else:
                os.remove(p)
        except Exception:
            pass


def _verify_app_tree():
    return [r for r in UPDATE_REQUIRED
            if not os.path.exists(os.path.join(BASE, r))]


def create_code_backup():
    ensure_data_dir()
    os.makedirs(CODE_BACKUP_DIR, exist_ok=True)
    v = read_version()
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    safe_v = re.sub(r"[^A-Za-z0-9._-]+", "_", v["version"]) or "dev"
    name = "code-backup-{}-{}".format(ts, safe_v)
    dest = os.path.join(CODE_BACKUP_DIR, name)
    # Two installs in the same second with the same version must not collide.
    n = 2
    while os.path.exists(dest):
        name = "code-backup-{}-{}-{}".format(ts, safe_v, n)
        dest = os.path.join(CODE_BACKUP_DIR, name)
        n += 1

    def _ignore(d, names):
        return [n for n in names if n == "__pycache__" or n.endswith(".pyc")]

    shutil.copytree(BASE, dest, ignore=_ignore)
    meta = {"name": name, "version": v["version"], "build_date": v["build_date"],
            "ts": now_ts(), "ts_iso": iso_now()}
    try:
        with open(os.path.join(dest, "code-backup-meta.json"),
                  "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)
    except Exception:
        pass
    prune_code_backups()
    return meta


def list_code_backups():
    if not os.path.isdir(CODE_BACKUP_DIR):
        return []
    out = []
    for name in sorted(os.listdir(CODE_BACKUP_DIR), reverse=True):
        p = os.path.join(CODE_BACKUP_DIR, name)
        if not os.path.isdir(p):
            continue
        meta = None
        try:
            with open(os.path.join(p, "code-backup-meta.json"),
                      encoding="utf-8") as f:
                meta = json.load(f)
        except Exception:
            pass
        out.append(meta if isinstance(meta, dict) and meta.get("name")
                   else {"name": name, "version": "?", "build_date": "",
                         "ts": 0, "ts_iso": ""})
    return out


def prune_code_backups():
    for b in list_code_backups()[MAX_CODE_BACKUPS:]:
        shutil.rmtree(os.path.join(CODE_BACKUP_DIR, b["name"]),
                      ignore_errors=True)


def restore_code_backup(name):
    """Copy a code backup over the app folder. Returns (ok, error_str)."""
    src = os.path.join(CODE_BACKUP_DIR, name)
    if not os.path.isdir(src):
        return False, "پشتیبان کد پیدا نشد"
    _wipe_app_folder()

    def _ignore(d, names):
        return [n for n in names if n == "code-backup-meta.json"]

    try:
        shutil.copytree(src, BASE, dirs_exist_ok=True, ignore=_ignore)
    except Exception as exc:
        return False, "بازگردانی ممکن نشد: " + str(exc)
    missing = _verify_app_tree()
    if missing:
        return False, "پس از بازگشت، این فایل‌ها پیدا نشدند: " + ", ".join(missing)
    return True, None


def install_update_zip(zip_path):
    """Validate, back up current code, extract over the app folder.
    Returns (new_version_dict, backup_meta, error_str). On any failure
    after the wipe, the code backup is restored immediately — the server
    is never left half-installed and never restarts into a broken tree."""
    version, err = validate_update_zip(zip_path)
    if err:
        return None, None, err
    ensure_data_dir()
    # Legacy data files still sitting in the app folder (pre-backup builds):
    # move them to the data dir first so the wipe cannot touch them.
    for fname in PROTECTED_APP_FILES:
        app_path = os.path.join(BASE, fname)
        data_path = os.path.join(DATA_DIR, fname)
        if os.path.exists(app_path) and not os.path.exists(data_path):
            try:
                shutil.move(app_path, data_path)
            except Exception:
                pass
    backup = None
    try:
        backup = create_code_backup()
    except Exception as exc:
        return None, None, "ساخت پشتیبان کد ممکن نشد: " + str(exc)
    try:
        _wipe_app_folder()
        with zipfile.ZipFile(zip_path) as zf:
            for info in zf.infolist():
                if info.is_dir():
                    continue
                parts = info.filename.replace("\\", "/").split("/")
                if "__pycache__" in parts:
                    continue
                if len(parts) == 1 and parts[0] in PROTECTED_APP_FILES:
                    continue  # never extract a data file into the app folder
                zf.extract(info, BASE)
    except Exception as exc:
        restore_code_backup(backup["name"])
        return None, backup, "نصب ناتمام ماند و نسخه‌ی قبل برگردانده شد: " + str(exc)
    missing = _verify_app_tree()
    if missing:
        restore_code_backup(backup["name"])
        return None, backup, "پس از استخراج، این فایل‌ها پیدا نشدند: " + ", ".join(missing)
    return version, backup, None


def schedule_restart():
    """Spawn a detached helper that waits for this process to exit, then
    re-launches the server (same interpreter, same data dir via the
    inherited environment). The current process exits ~1s later, after the
    HTTP response has reached the browser."""
    ensure_data_dir()
    py = sys.executable or "python"
    if sys.platform == "win32":
        helper = os.path.join(DATA_DIR, "restart-helper.bat")
        content = ("@echo off\r\n"
                   "timeout /t 3 /nobreak >nul\r\n"
                   "cd /d \"" + BASE + "\"\r\n"
                   "start \"\" /min \"" + py + "\" -u server.py\r\n")
        try:
            with open(helper, "w", encoding="utf-8", newline="") as f:
                f.write(content)
            subprocess.Popen(
                ["cmd", "/c", helper],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                creationflags=getattr(subprocess, "DETACHED_PROCESS", 0)
                | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
                close_fds=True)
        except Exception as exc:
            print("Restart helper failed: {}".format(exc))
            return
    else:
        helper = os.path.join(DATA_DIR, "restart-helper.sh")
        log_path = os.path.join(DATA_DIR, "server.log")
        content = ("#!/bin/sh\nsleep 3\ncd \"" + BASE + "\"\n"
                   "nohup \"" + py + "\" -u server.py >> \"" + log_path + "\" 2>&1 &\n")
        try:
            with open(helper, "w", encoding="utf-8") as f:
                f.write(content)
            os.chmod(helper, 0o755)
            subprocess.Popen(["/bin/sh", helper],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             stdin=subprocess.DEVNULL, start_new_session=True,
                             close_fds=True)
        except Exception as exc:
            print("Restart helper failed: {}".format(exc))
            return

    def _exit_later():
        time.sleep(1)
        os._exit(0)

    threading.Thread(target=_exit_later, daemon=True).start()


# ---------- One-click auto-update (v1.10.0) ----------
# The release channel is a public GitHub repo (ParhammPm/studyflow) with a
# manifest (latest.json) at its root:
#   {"version": "1.10.0",
#    "zip_url": "https://raw.githubusercontent.com/ParhammPm/studyflow/main/releases/studyflow-v1.10.0.zip",
#    "sha256": "<hex>", "notes": "...", "min_version": "1.5.0"}
# The app NEVER auto-installs: one check runs shortly after server start and
# only records the result (the Backup tab shows the notice); installing
# always needs the user's click on «دانلود و نصب». The download is streamed
# (<=50 MB), its SHA-256 is verified against the manifest (a mismatch refuses
# the install and leaves the current version untouched), and the install then
# reuses install_update_zip + schedule_restart from Part 5 exactly — the
# manual file-upload and pasted-URL paths stay as fallbacks.
# The manifest URL is configurable (update_config.json in the data dir);
# the default is the StudyFlow repo above.
DEFAULT_MANIFEST_URL = ("https://raw.githubusercontent.com/ParhammPm/"
                        "studyflow/main/latest.json")
UPDATE_CONFIG_FILE = os.path.join(DATA_DIR, "update_config.json")
UPDATE_MANIFEST_TIMEOUT = 15
UPDATE_DOWNLOAD_TIMEOUT = 60


def load_update_config():
    data, _ = read_json_file(UPDATE_CONFIG_FILE)
    if isinstance(data, dict):
        return {"manifest_url": str(data.get("manifest_url") or DEFAULT_MANIFEST_URL),
                "last_check": data.get("last_check"),
                "last_result": data.get("last_result") if isinstance(data.get("last_result"), dict) else None,
                "last_error": data.get("last_error")}
    return {"manifest_url": DEFAULT_MANIFEST_URL, "last_check": None,
            "last_result": None, "last_error": None}


def save_update_config(cfg):
    atomic_write_json(UPDATE_CONFIG_FILE, cfg)


def _version_tuple(v):
    parts = []
    for piece in str(v or "").strip().split("."):
        m = re.match(r"(\d+)", piece)
        parts.append(int(m.group(1)) if m else 0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:4])


def compare_versions(a, b):
    """-1 when a<b, 0 when equal, 1 when a>b (numeric dotted versions)."""
    ta, tb = _version_tuple(a), _version_tuple(b)
    return (ta > tb) - (ta < tb)


def validate_manifest(obj):
    """Returns (manifest_dict, error_str). error_str is None when valid."""
    if not isinstance(obj, dict):
        return None, "مانیفست معتبر نیست — فایل JSON یک آبجکت نیست"
    version = str(obj.get("version") or "").strip()
    if not version:
        return None, "مانیفست نسخه ندارد"
    zip_url = str(obj.get("zip_url") or "").strip()
    # HTTPS only, and the zip must come from the official release channel:
    # an http:// manifest (or a MITM-rewritten one) could otherwise point
    # the updater at an attacker zip with a matching sha256.
    if not zip_url.startswith("https://"):
        return None, "مانیفست لینک zip معتبر ندارد"
    if urllib.parse.urlparse(zip_url).netloc != "raw.githubusercontent.com":
        return None, "مانیفست لینک zip معتبر ندارد"
    sha256 = str(obj.get("sha256") or "").strip().lower()
    if not re.fullmatch(r"[0-9a-f]{64}", sha256):
        return None, "مانیفست هش SHA-256 معتبر ندارد"
    return {"version": version, "zip_url": zip_url, "sha256": sha256,
            "notes": str(obj.get("notes") or ""),
            "min_version": str(obj.get("min_version") or "").strip()}, None


def fetch_manifest(url):
    """Returns (manifest_dict, error_str)."""
    if not str(url or "").strip().startswith("https://"):
        return None, "آدرس مانیفست باید با https:// شروع شود"
    try:
        req = urllib.request.Request(
            url, headers={"User-Agent": "StudyFlow-Updater"}, method="GET")
        with urllib.request.urlopen(req, timeout=UPDATE_MANIFEST_TIMEOUT) as resp:
            raw = resp.read(1024 * 1024)
    except urllib.error.HTTPError as exc:
        return None, "دریافت مانیفست ممکن نشد: HTTP {}".format(exc.code)
    except Exception as exc:
        return None, "دریافت مانیفست ممکن نشد: {}".format(exc)
    try:
        obj = json.loads(raw.decode("utf-8"))
    except Exception:
        return None, "مانیفست خوانده نشد — فایل JSON معتبر نیست"
    return validate_manifest(obj)


def run_update_check():
    """Fetch the manifest, compare with the installed version, remember the
    result. Never installs anything. Returns a result dict."""
    cfg = load_update_config()
    url = (cfg.get("manifest_url") or DEFAULT_MANIFEST_URL).strip()
    manifest, err = fetch_manifest(url)
    now = iso_now()
    if err:
        cfg["last_check"] = now
        cfg["last_error"] = err
        cfg["last_result"] = None
        try:
            save_update_config(cfg)
        except Exception:
            pass
        return {"ok": False, "error": err, "checked_at": now}
    current = read_version()
    available = compare_versions(manifest["version"], current["version"]) > 0
    blocked_min = None
    if available and manifest.get("min_version"):
        if compare_versions(current["version"], manifest["min_version"]) < 0:
            blocked_min = manifest["min_version"]
    result = {"ok": True,
              "update_available": available and not blocked_min,
              "blocked_min_version": blocked_min,
              "current_version": current["version"],
              "version": manifest["version"],
              "notes": manifest["notes"],
              "zip_url": manifest["zip_url"],
              "sha256": manifest["sha256"],
              "checked_at": now}
    cfg["last_check"] = now
    cfg["last_error"] = None
    cfg["last_result"] = {k: v for k, v in result.items() if k != "ok"}
    try:
        save_update_config(cfg)
    except Exception:
        pass
    return result


AUTO_UPDATE_STATE = {"phase": "idle", "percent": 0, "downloaded": 0,
                     "total": None, "version": None, "error": None}
AUTO_UPDATE_LOCK = threading.Lock()
AUTO_UPDATE_ACTIVE = {"running": False}


def _auto_update_set(**kw):
    with AUTO_UPDATE_LOCK:
        AUTO_UPDATE_STATE.update(kw)


def auto_update_status():
    with AUTO_UPDATE_LOCK:
        return dict(AUTO_UPDATE_STATE)


def download_and_install_auto(manifest):
    """Background thread: stream the release zip, verify its SHA-256 against
    the manifest, then run the standard install + restart flow. A hash
    mismatch (or any failure) refuses the install and leaves the current
    version untouched. Never runs twice at once (guarded by the caller)."""
    version = manifest["version"]
    _auto_update_set(phase="downloading", percent=0, downloaded=0,
                     total=None, version=version, error=None)
    ensure_data_dir()
    os.makedirs(UPDATE_STAGING_DIR, exist_ok=True)
    staged = os.path.join(
        UPDATE_STAGING_DIR,
        "auto-update-{}.zip".format(datetime.now().strftime("%Y%m%d-%H%M%S")))
    digest = hashlib.sha256()
    try:
        req = urllib.request.Request(
            manifest["zip_url"],
            headers={"User-Agent": "StudyFlow-Updater"}, method="GET")
        with urllib.request.urlopen(req, timeout=UPDATE_DOWNLOAD_TIMEOUT) as resp:
            try:
                expected = int(resp.headers.get("Content-Length") or 0) or None
            except Exception:
                expected = None
            if expected and expected > MAX_UPDATE_ZIP_BYTES:
                raise ValueError("فایل به‌روزرسانی خیلی بزرگ است")
            _auto_update_set(total=expected)
            downloaded = 0
            with open(staged, "wb") as f:
                while True:
                    chunk = resp.read(65536)
                    if not chunk:
                        break
                    downloaded += len(chunk)
                    if downloaded > MAX_UPDATE_ZIP_BYTES:
                        raise ValueError("فایل به‌روزرسانی خیلی بزرگ است")
                    digest.update(chunk)
                    f.write(chunk)
                    pct = int(downloaded * 100 / expected) if expected else 0
                    _auto_update_set(downloaded=downloaded,
                                     percent=min(99, pct))
        _auto_update_set(phase="verifying", percent=100)
        if digest.hexdigest() != manifest["sha256"]:
            raise ValueError("هش فایل دانلودشده با مانیفست مطابقت ندارد — نصب انجام نشد")
        _auto_update_set(phase="installing", percent=100)
        new_version, backup, err = install_update_zip(staged)
        if err:
            raise ValueError(err)
        _auto_update_set(phase="done", percent=100,
                         version=new_version["version"])
        schedule_restart()
    except Exception as exc:
        _auto_update_set(phase="error", error=str(exc))
    finally:
        try:
            os.remove(staged)
        except Exception:
            pass
        AUTO_UPDATE_ACTIVE["running"] = False


def update_startup_check():
    """One manifest check shortly after server start. Records the result
    only — installing always needs the user's click."""
    time.sleep(10)
    try:
        run_update_check()
    except Exception as exc:
        print("Update startup check failed: {}".format(exc))
