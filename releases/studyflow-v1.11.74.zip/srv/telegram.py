#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""StudyFlow server — Telegram client (v1.11.64, Batch 5, م-۸).

The bot token is stored server-side only (telegram_token.txt) and is
NEVER logged and NEVER returned to the browser; only booleans leave
the server. The chat id is a plain number in state.telegramChatId.
The ONLY message this module ever sends is the weekly report, only
when the user clicks «ارسال به تلگرام» — never automatic.
"""
import json
import os
import re
import urllib.error
import urllib.request

from srv.common import TG_TOKEN_FILE, open_https_url

# A Telegram bot token is "<digits>:<~35 chars of [A-Za-z0-9_-]>".
TOKEN_RE = re.compile(r"^\d{6,}:[A-Za-z0-9_-]{30,}$")
CHAT_ID_RE = re.compile(r"^-?\d{1,20}$")


def read_token():
    if os.path.exists(TG_TOKEN_FILE):
        with open(TG_TOKEN_FILE, encoding="utf-8") as f:
            return f.read().strip()
    return ""


def valid_token(token):
    return bool(token) and bool(TOKEN_RE.match(token))


def valid_chat_id(chat_id):
    return bool(chat_id) and bool(CHAT_ID_RE.match(str(chat_id)))


def send_message(token, chat_id, text):
    """POST one message to api.telegram.org. Returns (ok, error):
    ok=True on a Telegram {"ok": true}; otherwise ok=False and a
    short error string (Telegram's description, or a network-error
    note — never the token, never the message body)."""
    if not valid_token(token):
        return False, "توکن معتبر نیست"
    if not valid_chat_id(chat_id):
        return False, "شناسه چت معتبر نیست"
    if not text or not str(text).strip():
        return False, "متن خالی است"
    url = "https://api.telegram.org/bot%s/sendMessage" % token
    body = json.dumps({"chat_id": str(chat_id), "text": str(text)[:4000]},
                      ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=body, method="POST",
                                 headers={"Content-Type": "application/json"})
    try:
        with open_https_url(req, timeout=15) as r:
            j = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        try:
            j = json.loads(exc.read().decode("utf-8"))
            desc = (j.get("description") or "").strip()
        except Exception:
            desc = ""
        return False, desc or ("خطای تلگرام (HTTP %d)" % exc.code)
    except Exception:
        return False, "ارتباط با تلگرام برقرار نشد"
    if j.get("ok"):
        return True, ""
    return False, (j.get("description") or "خطای تلگرام").strip()
