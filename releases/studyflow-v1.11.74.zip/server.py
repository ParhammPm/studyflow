#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Konkur local site server — Python standard library only, no pip installs.
Run:  python server.py        (or start.bat on Windows)
Then open http://localhost:8765

DATA LIVES OUTSIDE THE APP FOLDER (Layer 0):
  Windows:  %APPDATA%\\KonkurApp\\   (state.json, testbook.json,
            gemini_key.txt, b2_config.json, google_oauth.json,
            google_push_state.json, calendar_config.json,
            calendar_data.json, backups\\)
  Linux:    ~/.local/share/KonkurApp/   macOS: ~/Library/Application Support/KonkurApp/
  Override for tests:  KONKUR_DATA_DIR env var.
  On first run the server MIGRATES any state.json / testbook.json /
  gemini_key.txt found in the app folder into the data dir (move, not copy),
  so extracting a new zip over the old folder can never lose data. The app
  folder itself is replaceable code only — the shipped zip contains NO
  state.json / testbook.json / gemini_key.txt / b2_config.json.

BACKUPS (Layer 1): every save is atomic (temp file + os.replace) and creates
a versioned local backup (backups/<kind>-<ts>-<sha8>.json, ~30 kept per kind,
SHA-256 in backup_meta.json). A missing/corrupt state.json or testbook.json
is auto-restored from the newest VERIFIED backup (local first, then cloud)
before empty defaults are ever served.

CLOUD (Layer 2): Backblaze B2, S3-compatible, pure-stdlib SigV4 (b2.py).
A background thread uploads versioned snapshots + a latest.json manifest.
The cloud layer is DISABLED until B2 credentials are entered in the app's
Backup tab (saved server-side in the data dir, never shipped, never sent to
the browser). On conflict the remote version is kept and the local one is
uploaded as a new version — nothing is ever auto-overwritten.

Endpoints:
  GET  /                -> public/index.html
  GET  /api/health      -> {"ok": true}
  GET  /api/state       -> saved state (ticks, test counts, edits, subjects, theme, daysDone, topicLinks, assignments, examResults)
  POST /api/state       -> save state (atomic + versioned backup + cloud sync request)
  GET  /api/testbook    -> test books (chapters/topics, tests_total, manual_solved)
  POST /api/testbook    -> save test books (atomic + versioned backup + cloud sync request)
  GET  /api/gemini-key  -> {"has_key": bool} (only a boolean, v1.11.28 — the old masked form leaked key chars)
  POST /api/gemini-key  -> {"key": "..."} saves the key to gemini_key.txt (server-side only)
  GET  /api/gemini-model -> {"model": "..."} (selected model, default gemini-2.5-flash)
  POST /api/gemini-model -> {"model": "..."} saves the selected model to gemini_model.txt
  GET  /api/gemini-models -> {"models": [...]} lists the models this key can use (generateContent)
  POST /api/gemini      -> {"prompt": "..."} proxies to Gemini with the selected model, returns {"text": "..."}
  GET  /api/telegram-status -> {"has_token": bool, "has_chat_id": bool} (only booleans, v1.11.64)
  POST /api/telegram-token  -> {"token": "...", "chat_id": "..."} saves the token to telegram_token.txt (server-side only)
  POST /api/telegram-send   -> {"text": "..."} sends the weekly report via the bot (user click only)
  GET  /api/backup      -> backup status (data dir, local counts, cloud state)
  GET  /api/backup/list -> local versions + cloud manifest entries
  POST /api/backup/now  -> snapshot both files now + request immediate cloud sync
  POST /api/backup/restore       -> {"kind": "state"|"testbook", "file": "..."} restore a local version
  POST /api/backup/restore-cloud -> {"kind": ..., "key": "..."} restore a cloud version
  GET  /api/backup/b2-config -> masked B2 settings (never secrets)
  POST /api/backup/b2-config -> save B2 settings {endpoint, key_id, application_key, bucket, enabled}
  POST /api/backup/b2-test    -> read-only connection test (list 1 object)
  POST /api/backup/b2-clear   -> delete the stored B2 credentials
  GET  /api/version           -> current app version {version, build_date} (from version.json)
  GET  /data.json            -> merged programme (calendar_data.json) when present, else shipped data.json
  GET  /api/calendar/status  -> masked calendar config + programme stats + sync log + OAuth/push status
  GET  /api/calendar/config  -> masked calendar config (ICS URL never in full)
  POST /api/calendar/config  -> save {ics_url, interval_minutes, enabled}
  POST /api/calendar/sync    -> fetch the ICS URL now and merge (PULL)
  POST /api/calendar/import-preview -> dry-run merge of an uploaded .ics/.json file
  POST /api/calendar/import  -> apply the uploaded file's merge (after preview)
  POST /api/calendar/clear   -> remove the calendar config (programme data kept)
  GET  /api/calendar/oauth/status -> OAuth credentials status (masked) + push status
  POST /api/calendar/oauth/credentials -> save {client_id, client_secret} (server-side only)
  POST /api/calendar/oauth/clear-credentials -> revoke + delete the stored OAuth credentials
  GET  /api/calendar/oauth/auth-url -> the Google sign-in URL (opened by the browser)
  GET  /oauth/callback        -> Google OAuth redirect: exchanges the code, stores tokens
  POST /api/calendar/oauth/disconnect -> revoke the token at Google, clear stored tokens
  POST /api/calendar/push     -> push app-side box changes to Google Calendar now
  GET  /api/calendar/push-status -> pending push count, last push result, conflicts
  GET  /api/boxes            -> effective boxes (programme + edits + custom), sorted by date/time
  POST /api/boxes/create     -> {title, date, start, end, subject?, topic?, note?, is_test?, tests_total?, type?} new custom box
  POST /api/boxes/update     -> {id, title?, subject?, topic?, date?, start?, end?, note?, is_test?, tests_total?, type?} edit/move a box
  POST /api/boxes/delete     -> {id} delete a box (programme or custom -> state.deleted; the push deletes its Google event too, v1.11.12)
  POST /api/boxes/reconnect  -> {boxId, uid} link a programme box to an EXISTING Google event (manual reconnect)
  POST /api/boxes/push-one   -> {box_id} create ONE Google event for a disconnected box (programme or custom); idempotent
  GET  /api/update/status     -> {version, backups:[code-backup metas]} (code backups live in the data dir)
  POST /api/update/upload     -> raw .zip bytes in the body; validate, back up current code, install, restart
  POST /api/update/url        -> {url} download a .zip, then the same install flow
  POST /api/update/rollback   -> {backup?} restore the newest (or named) code backup, then restart
  GET  /api/update/auto       -> auto-update status: manifest URL, last check result, live install state
  GET  /api/update/auto-progress -> live download/install progress {phase, percent, ...}
  POST /api/update/check      -> fetch the release manifest now and compare (never installs)
  POST /api/update/auto-config -> save {manifest_url} (empty resets to the default)
  POST /api/update/install-auto -> start a background download (SHA-256 verified) + install + restart
  An update NEVER touches the data dir (state.json, testbook.json, gemini_key.txt,
  gemini_model.txt, b2_config.json, google_oauth.json, google_push_state.json,
  calendar_config.json, calendar_data.json) — it only replaces the code/app folder, after
  copying the current code to a versioned backup inside the data dir.
"""
import json
import os
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
try:
    from zoneinfo import ZoneInfo
except Exception:  # very old Python without zoneinfo
    ZoneInfo = None

try:
    import b2 as b2mod
except Exception:
    b2mod = None

# Audit §5 item 3.5 (v1.11.20): the server is split into modules.
# Shared core (paths, locks, state schema, pure helpers) lives in
# srv.common, the Gemini client in srv.gemini, the self-updater in
# srv.update. The names are re-exported here so the rest of this
# file — handler, calendar sync, backup/cloud, main() — is unchanged.
# v1.11.26 (QA BUG-033): the lists below hold only names this file
# actually uses — plus sanitize_state, kept as a re-export because
# verify1117_driver calls server.sanitize_state. (The full check
# lives in tests/run_tests.py as TestUnusedImports.)
from srv.common import (
    B2_CONFIG_FILE,
    BACKUP_DIR,
    CALENDAR_CONFIG_FILE,
    CALENDAR_DATA_FILE,
    BASE,
    CLOUD_MANIFEST_KEY,
    CLOUD_PREFIX,
    DATA_DIR,
    DEFAULT_STATE,
    GEMINI_API_BASE,
    GOOGLE_OAUTH_FILE,
    GOOGLE_PUSH_FILE,
    KEY_FILE,
    MODEL_FILE,
    NOTE_MAX_LEN,
    PORT,
    PUBLIC,
    PUSH_RUN_LOCK,
    STATE_FILE,
    STATE_LOCK,
    STATE_SCHEMA_VERSION,
    SUBJECT_MAX_LEN,
    TEHRAN,
    TESTBOOK_FILE,
    TG_TOKEN_FILE,
    TITLE_MAX_LEN,
    _DebouncedWorker,
    _MERGED_STATE_KEYS,
    _PUSH_IN_FLIGHT,
    _preserve_corrupt,
    _with_lock,
    _with_push_run_lock,
    _with_sync_lock,
    atomic_write,
    atomic_write_json,
    ensure_data_dir,
    iso_now,
    merge_state_update_scoped,
    now_ts,
    open_https_url,
    read_json_file,
    read_version,
    sanitize_state,
    sha256_bytes,
    state_rejected_keys,
    state_wrong_typed_keys,
    valid_state,
    valid_testbook,
)
from srv.gemini import (
    GEMINI_MAX_PROMPT_CHARS,
    TEST_MAX_TOKENS,
    TEST_PROMPT,
    _gemini_request,
    check_gemini_rate_limit,
    read_key,
    read_model,
    valid_model,
)
# v1.11.64 (Batch 5, م-۸): the Telegram client — token server-side
# only, the weekly report is the only message it ever sends.
from srv.telegram import (
    read_token as read_tg_token,
    send_message as tg_send_message,
    valid_chat_id as tg_valid_chat_id,
    valid_token as tg_valid_token,
)
from srv.update import (
    DEFAULT_MANIFEST_URL,
    MAX_UPDATE_ZIP_BYTES,
    UPDATE_STAGING_DIR,
    _auto_update_set,
    auto_update_release,
    auto_update_status,
    auto_update_try_claim,
    download_and_install_auto,
    install_update_zip,
    list_code_backups,
    load_update_config,
    restore_code_backup,
    run_update_check,
    save_update_config,
    schedule_restart,
    staging_zip_name,
    update_startup_check,
)

# v1.11.38 (P3-10/P3-11): the backup, repository and Google-sync
# layers live in srv/ now; server.py re-exports the names its own
# code and the tests/drivers still reach as server.<name>.
from srv.backup import (
    CLOUD_SYNC,
    backup_entry_verified,
    backup_status_payload,
    create_backup,
    list_local_versions,
    load_b2_config,
    masked_b2_config,
    migrate_legacy_files,
    newest_verified_backup,
    save_b2_config,
    verify_backup_entry,
)
from srv.google_sync import (
    GoogleNotFound,
    LinkStore,
    _apply_done_from_google,
    _google_request,
    _list_google_events,
    build_auth_url,
    derive_subject_topic,
    event_is_test,
    exchange_code,
    get_provider,
    google_api,
    masked_oauth_status,
    normalize_events,
    parse_calendar_json,
    parse_ics,
    refresh_event_id_map,
    revoke_google_tokens,
    seed_push_state_after_connect,
    sync_done_from_google,
)
from srv.repository import (
    DEFAULT_GOOGLE_CLIENT_ID,
    ProgrammeCorruptError,
    _compute_testbook_merge,
    _programme_range,
    adopt_seq,
    bump_seq,
    load_calendar_config,
    load_oauth,
    load_programme,
    load_push_state,
    load_state,
    load_subjects,
    read_seq,
    save_calendar_config,
    save_oauth,
    save_programme,
    save_push_state,
    save_state,
    save_state_if_changed,
    save_testbook,
    save_testbook_if_changed,
    load_testbook,
)


# v1.11.38 (P3-10/P3-11): the backup, repository and Google-sync layers
# live in srv/backup.py, srv/repository.py and srv/google_sync.py.
# server.py keeps the routes (Handler + GET_ROUTES/POST_ROUTES), the
# three-phase push/sync core, and thin re-exports for tests/drivers.

# ---------- Calendar sync (Part A, v1.8.0; two-way since v1.11.0) ----------
# Google Calendar sync. The merged programme lives in the DATA DIR
# (calendar_data.json), never in the shipped data.json, because the app folder
# is replaceable code (self-update wipes it). The shipped data.json stays the
# seed: the first sync matches its 318 boxes to feed events and persists the
# UID -> boxId mapping, so later syncs are stable.
#
# PULL (read path, unchanged): the private ICS feed, or a manually imported
# .ics/.json file. Google Calendar is ALWAYS the plan's source of truth (he
# plans with Muse + Gemini and the changes land in Google Calendar), so a
# pull applies Google's changes to the app's calendar UNCONDITIONALLY: if
# the same box was edited in the app AND changed in Google since the last
# pull, GOOGLE WINS — the app's conflicting local edit is dropped (never
# pushed over Google's version) and the dropped edit is noted in the sync
# log and the conflicts list, so nothing disappears silently.
#
# PUSH (write path, v1.11.0): OAuth 2.0 with a Desktop-app client. Client ID
# is pre-filled (the StudyFlow client, a public identifier); the Client
# Secret is pasted once by the user in settings and, like the tokens, lives
# ONLY in the data dir (google_oauth.json); the browser never sees them.
# The sign-in uses PKCE (RFC 8252, S256). The push compares the EFFECTIVE
# boxes (programme + state.edits overlay + custom boxes) with the
# last-pushed snapshot and only calls the API for what changed — and only
# when Google has not changed that box since the last pull: before PATCHing,
# the push reads the event's CURRENT values from Google and skips the box
# (leaving it for the next pull to resolve) if Google moved first.
# Deletions only ever touch Google events the app itself created. A
# debounced auto-push runs ~15s after any state save that changed a box
# (title/time/new/delete); a manual «ارسال تغییرات به گوگل» button pushes
# immediately. Push errors are recorded in Persian and nothing is lost
# locally.
#
# Sources (all parsed server-side, stdlib only):
#   * Auto sync: the private ICS ("Secret address in iCal format") the user
#     pastes once. Fetched on demand, on server start, and on a schedule.
#   * Manual import: an uploaded .ics file, or a JSON export in the Google
#     Calendar API shape ({items: [...]} — the shape the programme was built
#     from) or a plain array of {date, start, end, title} events. Works
#     offline, with no ICS URL configured.
# Both paths run the SAME merge (merge_calendar_events). Imports first run a
# dry-run preview; applying needs a second, explicit call.
#
# Merge rules (never lose his work):
#   * New event -> new box, fresh id continuing after the highest bNNN,
#     tests_total 0, subject/topic/is_test derived from the title.
#   * Moved/renamed event -> the matching box gets the new date/time/title,
#     but state is NEVER touched (done, tests, tests_total, edits, notes,
#     daysDone all live in state.json and the merge never writes there).
#   * Cancelled/missing event -> the box is removed ONLY if it was never
#     touched in the app (no tick, no tests, no edit, no tests_total). A
#     touched box is kept and unlinked instead. Removals are scoped to the
#     feed's own date span, so a partial export (e.g. 23 Nov-18 Dec) can
#     never delete boxes outside its range. For file imports, mere absence
#     never removes (the file may be partial) — only events the file marks
#     cancelled do; the live sync (the feed IS the whole calendar) also
#     removes events that disappeared from the feed.
#   * A box the user deleted in the app (state.deleted) tombstones its UID:
#     the event is never recreated by a later sync, and the UID stays in
#     tombstone_uids in the data dir.
#   * CONFLICT (Google always wins, 2026-11-24): if a box was edited in the
#     app after the last pull AND Google changed it too, the pull applies
#     Google's title/date/time unconditionally, the app's conflicting edit
#     is dropped (overlay reconciled to Google's values, app_edited_at
#     cleared, last_pushed set to Google's values so the push never
#     re-sends it), and the dropped edit is noted in the sync log and the
#     conflicts list. An app edit with NO Google change is untouched by the
#     pull and is pushed to Google as before.
# Every applied sync appends a summary + decision lines to the sync log
# (calendar_config.json, last 100 entries).
CALENDAR_LOG_MAX = 100
# v1.11.48 (F1): the single daily cap (14 h, set by the user 25 Nov) —
# the client has the same constant (DAY_CAP_MIN in app.js); the old
# 12 h cap is retired on both sides. The warning kind stays "over12h"
# (historical name, pinned by verify1119 + its driver).
DAY_CAP_MIN = 14 * 60
CALENDAR_FETCH_TIMEOUT = 25
CALENDAR_MAX_BYTES = 5 * 1024 * 1024










# ---------- ICS parsing (stdlib only) ----------














# ---------- JSON export parsing ----------








# ---------- Programme store (data dir) ----------




class _BadJsonBody(Exception):
    """Raised by _read_json when the request body is unusable (v1.11.26,
    QA BUG-030). The three cases used to collapse into one misleading
    {} — invalid JSON, an over-large body and an empty body all looked
    the same to the handler. Now each carries its own HTTP status and
    message, and handle() answers with it instead of letting the
    handler guess: invalid JSON → 400 «JSON نامعتبر», too large → 413,
    empty → 400 «بدنه خالی»."""
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status
        self.message = message






def _box_touched(state, box_id):
    """Was this box ever touched in the app? (tick, tests, edit, total)."""
    if (state.get("done") or {}).get(box_id):
        return True
    tr = (state.get("tests") or {}).get(box_id) or {}
    if (tr.get("completed") or 0) > 0:
        return True
    if box_id in (state.get("edits") or {}):
        return True
    if box_id in (state.get("tests_total") or {}):
        return True
    return False


def _hhmm_to_min(value):
    """'HH:MM' -> minutes since midnight, or None when unparsable."""
    try:
        h, m = str(value or "").split(":")
        h, m = int(h), int(m)
    except (ValueError, AttributeError):
        return None
    if not (0 <= h <= 23 and 0 <= m <= 59):
        return None
    return h * 60 + m


def _intervals_overlap(a_start, a_end, b_start, b_end):
    """Do two 'HH:MM' intervals overlap? An end <= start is an overnight
    interval (past midnight), so that end is read as +24h."""
    a0, a1 = _hhmm_to_min(a_start), _hhmm_to_min(a_end)
    b0, b1 = _hhmm_to_min(b_start), _hhmm_to_min(b_end)
    if a0 is None or a1 is None or b0 is None or b1 is None:
        return False
    if a1 <= a0:
        a1 += 1440
    if b1 <= b0:
        b1 += 1440
    return a0 < b1 and b0 < a1


def _study_day_of(date_iso, start):
    """Study day of a box: the day starts at 03:30 — a box starting
    before 03:30 belongs to the previous day (the same rule as
    app.js boxStudyDay)."""
    m = _hhmm_to_min(start)
    if m is None or m >= 210:
        return date_iso
    try:
        d = datetime.strptime(date_iso, "%Y-%m-%d").date() - timedelta(days=1)
        return d.isoformat()
    except Exception:
        return date_iso


def _box_minutes(start, end):
    """Planned minutes of one box; end <= start means overnight (+24h),
    and a zero-length box counts 0 (never 1440 — audit §5 item 1.5)."""
    a0, a1 = _hhmm_to_min(start), _hhmm_to_min(end)
    if a0 is None or a1 is None:
        return 0
    return (a1 - a0) % 1440


# ---------- Programme-issue detection (audit §5 item 2.8) ----------
# The server-side twin of app.js dayIssues(): (a) overlapping boxes in
# a study day, (b) a day over 12h planned, (c) more than 2 boxes of one
# subject in a day, (d) the hardest lesson in the day's last box.
# Warnings only — the box API never refuses a create/update because of
# them; the response just carries a "warnings" list for the caller.
# "Hardest" is the subject with the lowest test accuracy (attempted >= 10
# tests) — the only honest proxy the data supports; with no test data
# the rule is skipped silently instead of guessing.
def programme_issues(prog, state, day, extra=None, exclude_id=None):
    boxes = [b for b in _public_boxes_list(prog, state)
             if _study_day_of(b.get("date") or "", b.get("start") or "") == day
             and b.get("id") != exclude_id]
    if extra:
        boxes.append(extra)

    def _order(b):
        m = _hhmm_to_min(b.get("start") or "")
        return (m - 210 + 1440) % 1440 if m is not None else 0
    boxes.sort(key=_order)
    issues = []
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            a, b = boxes[i], boxes[j]
            if _intervals_overlap(a.get("start"), a.get("end"),
                                  b.get("start"), b.get("end")):
                issues.append({"kind": "overlap",
                               "titles": [a.get("title") or "",
                                          b.get("title") or ""]})
    total = sum(_box_minutes(b.get("start"), b.get("end")) for b in boxes)
    if total > DAY_CAP_MIN:
        issues.append({"kind": "over12h", "minutes": total})
    counts = {}
    for b in boxes:
        counts[b.get("subject") or ""] = counts.get(b.get("subject") or "", 0) + 1
    for s, n in counts.items():
        if n > 2:
            issues.append({"kind": "over2", "subject": s, "count": n})
    tests = state.get("tests") or {}
    by_subj = {}
    for b in _public_boxes_list(prog, state):
        tr = tests.get(b.get("id")) or {}
        v = by_subj.setdefault(b.get("subject") or "", {"tests": 0, "correct": 0})
        v["tests"] += tr.get("completed") or 0
        v["correct"] += tr.get("correct") or 0
    worst = None
    worst_acc = None
    for s, v in by_subj.items():
        if v["tests"] < 10:
            continue
        acc = v["correct"] / v["tests"]
        if worst_acc is None or acc < worst_acc:
            worst_acc = acc
            worst = s
    if worst and boxes and (boxes[-1].get("subject") or "") == worst:
        issues.append({"kind": "hardest", "subject": worst})
    return issues


# (v1.11.9: _title_similarity was removed with the title-similarity
# matcher — the merge never links by similarity any more. Only the UID
# or an exact (date+start+title) match links a feed event to a box.)
@_with_lock
def _find_exact_matches(boxes, deleted, uid_set, date, start, title):
    """v1.11.9: the ONLY first-time linking mechanism besides the UID.
    An exact (date + start time + title) triple — how the 318 seed
    boxes get their Event IDs on the first pull. Returns EVERY match;
    the caller links only when there is exactly one, so an ambiguous
    triple links nothing and waits for manual reconnect. No similarity
    of any kind is ever used to link (user spec §4).
    v1.11.65 (Batch 6, L-PERF7/R6): extracted from
    merge_calendar_events; the linked-id check is a set lookup now —
    the old `b["id"] in uid_map.values()` was a linear scan per box
    per event (0.26 s on the first pull with 318 boxes)."""
    out = []
    for b in boxes:
        if b["id"] in deleted or b["id"] in uid_set:
            continue
        if b["date"] == date and b["start"] == start and b["title"] == title:
            out.append(b)
    return out


def _find_deleted_match(boxes, deleted, date, start, title):
    """A box the user already deleted in the app: match it ONLY to
    tombstone the UID — its event must never be recreated as a new box.
    v1.11.65 (Batch 6, R6): extracted from merge_calendar_events."""
    for b in boxes:
        if b["id"] in deleted and b["date"] == date \
                and b["start"] == start and b["title"] == title:
            return b
    return None


def _merge_would_orphan(boxes, by_id, uid_map, seen_uids, deleted,
                        tomb_box, span):
    """The feed-freshness guard's count (v1.11.28, QA BUG-042),
    extracted from merge_calendar_events (v1.11.65, Batch 6, R6):
    which boxes WOULD be orphaned by this pull — unmapped in-span
    boxes plus mapped UIDs absent from the feed (both span-scoped;
    deleted and already-orphaned boxes excluded). Returns
    (would_orphan_ids, mapped_in_span). Pure: reads only, never
    mutates — the caller decides what the count means."""
    would_orphan_ids = set()
    mapped_in_span = 0
    if span[0]:
        uid_bids = set(uid_map.values())
        for b in boxes:
            if b["id"] in deleted or b["id"] in tomb_box or b.get("orphaned"):
                continue
            if not (span[0] <= b.get("date", "") <= span[1]):
                continue
            if b["id"] not in uid_bids:
                would_orphan_ids.add(b["id"])
        for uid, bid in list(uid_map.items()):
            box = by_id.get(bid)
            if box is None or bid in deleted:
                continue
            if not (span[0] <= box.get("date", "") <= span[1]):
                continue
            mapped_in_span += 1
            if uid not in seen_uids:
                would_orphan_ids.add(bid)
    return would_orphan_ids, mapped_in_span


def merge_calendar_events(events, cancelled_uids, source_label, apply=True,
                          remove_missing=True):
    """The single merge used by auto sync AND manual import. With
    apply=False it is a dry run (preview): nothing is written, no log.
    remove_missing: True for the live auto/manual sync (the ICS feed IS
    the whole calendar, so an absent event was deleted in Google);
    False for file imports (a file may be a partial export — there only
    events explicitly marked cancelled in the file unlink boxes).
    A box is NEVER deleted by a pull (rules 2/5): a box whose Google
    event is gone is unlinked and flagged `orphaned`, so its record stays
    where it was — the dashboard is the primary source of task data and
    the calendar is only an external link (v1.11.9). The box stays in
    its section with no connection badge; only the user moves or deletes
    it, by hand. A later pull (or a manual reconnect) re-links it and
    clears the flag. Linking is by UID first, else by an exact
    (date+start+title) triple — and only when that triple is unambiguous.
    No similarity of any kind is ever used to link (v1.11.9, spec §4).
    Returns a summary dict with counts and capped title lists."""
    prog = load_programme()
    boxes = prog["boxes"]
    uid_map = dict(prog.get("uid_map") or {})
    tomb_uids = set(prog.get("tombstone_uids") or [])
    tomb_box = set(prog.get("tombstone_box_ids") or [])
    state = load_state()
    deleted = set(state.get("deleted") or [])
    edits = state.get("edits") or {}
    # Two-way bookkeeping (v1.11.0): Google is ALWAYS the authority for
    # programme content. last_pull_ts is an epoch float stored in prog
    # meta (see the apply block below). A box edited in the app AFTER the
    # last successful pull AND changed in Google too is a conflict — the
    # pull applies Google's values unconditionally and the app's edit is
    # dropped (see the conflict branch below); it is never pushed over
    # Google's version. An app edit with no Google change is untouched
    # by the pull and is pushed as before.
    pstate = load_push_state()
    last_pull_ts = (prog.get("meta") or {}).get("last_pull_ts") or 0
    push_last_updates = {}
    overlay_updates = {}
    conflict_notes = []
    push_forget = set()   # drop last_pushed + app_edited_at (keep event_map)
    push_unmap = set()    # also drop event_map (the Google event is gone)
    pstate_dirty = False
    # Boxes deleted in the app tombstone their UID: never resurrected.
    for uid, bid in list(uid_map.items()):
        if bid in deleted:
            tomb_uids.add(uid)
            tomb_box.add(bid)
            del uid_map[uid]
    tomb_box |= deleted
    by_id = {b["id"]: b for b in boxes}
    # v1.11.65 (Batch 6, L-PERF7): the linked-id set, built once and
    # kept in sync with uid_map below — the first-pull merge used to
    # scan uid_map.values() linearly per box per event (0.26 s with
    # 318 boxes); the set lookup is ~0.008 s. Every uid_map mutation
    # in the event loop updates it (add on link, discard on unlink).
    uid_set = set(uid_map.values())
    # v1.11.69 (Audit #2 Batch 2, L16): exact-triple indexes, built
    # ONCE before the event loop. The first pull used to linearly
    # scan all 318 boxes per unlinked event TWICE (_find_deleted_match
    # + _find_exact_matches — 58 ms of a 104 ms profile, ~26 ms
    # median for the dry-run first pull). The indexes carry the same
    # semantics as the helpers: exact_index lists every non-deleted
    # box per (date, start, title) triple — the live uid_set filter
    # is applied at lookup, so a box linked mid-loop is never
    # re-matched; deleted_index holds the FIRST deleted box per
    # triple (boxes order, like _find_deleted_match). Boxes created
    # mid-loop are linked immediately (in uid_set), so they can never
    # match via the index either; a box whose triple Google-wins
    # rewrites mid-loop is already linked (or deleted), so the
    # snapshot cannot go stale. The helpers stay as the tested
    # single-call API (tests pin them); the loop uses the indexes.
    exact_index = {}
    for _b in boxes:
        if _b["id"] in deleted:
            continue
        exact_index.setdefault(
            (_b.get("date"), _b.get("start"), _b.get("title")), []).append(_b)
    deleted_index = {}
    for _b in boxes:
        if _b["id"] in deleted:
            deleted_index.setdefault(
                (_b.get("date"), _b.get("start"), _b.get("title")), _b)
    dates = sorted({e["date"] for e in events})
    span = (dates[0], dates[-1]) if dates else (None, None)
    log = []
    added, updated, removed, unlinked = [], [], [], []
    # v1.11.45 (bug-hunt B-17): `removed` is intentionally always []
    # — a pull never deletes boxes (only unlinks them), so the
    # "removed" count in the summary below is always 0 by design,
    # not a missing append.
    skipped_tomb = 0
    kept_touched = 0
    next_num = 318
    for b in boxes:
        m = re.match(r"^b(\d+)$", b.get("id") or "")
        if m:
            next_num = max(next_num, int(m.group(1)))

    seen_uids = set()
    for ev in events:
        uid = ev["uid"]
        seen_uids.add(uid)
        if uid in tomb_uids:
            skipped_tomb += 1
            log.append("رد شد (حذف‌شده در برنامه): {}".format(ev["title"]))
            continue
        bid = uid_map.get(uid)
        box = by_id.get(bid) if bid else None
        if bid and box is None:
            del uid_map[uid]
            uid_set.discard(bid)
            bid = None
        if box is None:
            # v1.11.69 (L16): index lookup, not the linear scans. When
            # `deleted` is empty the deleted check is skipped entirely
            # (it can never match); otherwise the deleted_index gives
            # the first deleted box for the triple, like
            # _find_deleted_match.
            if deleted:
                dm = deleted_index.get((ev["date"], ev["start"], ev["title"]))
            else:
                dm = None
            if dm is not None:
                tomb_uids.add(uid)
                tomb_box.add(dm["id"])
                skipped_tomb += 1
                log.append("رد شد (حذف‌شده در برنامه): {}".format(ev["title"]))
                continue
            ms = [b for b in exact_index.get(
                (ev["date"], ev["start"], ev["title"]), [])
                if b["id"] not in uid_set]
            if len(ms) == 1:
                m = ms[0]
                uid_map[uid] = m["id"]
                uid_set.add(m["id"])
                box = m
                bid = m["id"]
                log.append("تطبیق اول: {} -> {}".format(ev["title"], bid))
            elif len(ms) > 1:
                # Ambiguous exact triple: link NOTHING — the user reconnects
                # manually (spec §4). v1.11.25 (QA BUG-020): the event is
                # SKIPPED entirely — it used to fall through and be
                # created as a third duplicate box (b171, b900 AND b901)
                # even though the comment said it "waits for manual
                # reconnect". It still lands in meta["last_feed"] (every
                # feed event is recorded there), so the reconnect picker
                # can still suggest it.
                log.append("تطبیق دقیق مبهم ({} نامزد) — بدون پیوند، بدون باکس جدید: {}".format(
                    len(ms), ev["title"]))
                continue
        if box is not None:
            if bid in deleted:
                tomb_uids.add(uid)
                uid_map.pop(uid, None)
                uid_set.discard(bid)
                skipped_tomb += 1
                log.append("رد شد (حذف‌شده در برنامه): {}".format(ev["title"]))
                continue
            # Re-linked: the Google event exists again, so the box is no
            # longer orphaned — it returns to the current programme.
            if box.pop("orphaned", None) is not None:
                log.append("وصل شد دوباره: {} ({})".format(ev["title"], bid))
            subj, topic = derive_subject_topic(ev["title"])
            # Effective values: what the user actually sees (programme box
            # + the state.edits overlay). The pull compares against these.
            ov = edits.get(bid) or {}
            eff = {"title": ov.get("title", box.get("title")),
                   "date": ov.get("date", box.get("date")),
                   "start": ov.get("start", box.get("start")),
                   "end": ov.get("end", box.get("end"))}
            evv = {"title": ev["title"], "date": ev["date"],
                   "start": ev["start"], "end": ev["end"]}
            if eff == evv:
                # Fully in sync with Google: any pending app edit is done.
                if (pstate.get("app_edited_at") or {}).pop(bid, None) is not None:
                    pstate_dirty = True
                if apply:
                    push_last_updates[bid] = evv
                continue
            edited_after_pull = (pstate.get("app_edited_at") or {}).get(bid, 0) > (last_pull_ts or 0)
            if edited_after_pull:
                last_google = (pstate.get("last_pushed") or {}).get(bid)
                if isinstance(last_google, dict) and last_google == evv:
                    # Google has NOT changed since the last pull — the
                    # only difference is the app's own edit. Keep it:
                    # the pending push sends it to Google. (Previously
                    # this was misread as a conflict and the app edit
                    # was dropped even when Google was byte-identical.)
                    log.append("حفظ شد (ویرایش برنامه؛ تقویم تغییری نکرده): {}".format(ov.get("title") or ev["title"]))
                    continue
                # CONFLICT (Google always wins, 2026-11-24): the box was
                # edited in the app after the last pull AND Google changed
                # it too. The app's edit is DROPPED — it is never pushed
                # over Google's version. Fall through to the Google-wins
                # application below, which overwrites the programme box
                # and reconciles the overlay to Google's values (so the
                # next push cannot re-send the dropped edit); this log
                # line and the conflicts list are the only trace of it.
                dropped_title = ov.get("title") or ev["title"]
                log.append("تعارض — نسخه‌ی تقویم اعمال شد؛ ویرایش برنامه برای «{}» کنار گذاشته شد".format(dropped_title))
                conflict_notes.append({"box_id": bid, "title": dropped_title, "ts": iso_now()})
            # Google wins: apply the event to the programme box AND to the
            # app-edit overlay (otherwise the overlay would mask the pull
            # and the next push would send the old values back to Google).
            changes = {k: v for k, v in evv.items() if box.get(k) != v}
            ov_changes = {k: v for k, v in evv.items()
                          if bid in edits and ov.get(k) != v}
            if changes or ov_changes:
                for k, v in changes.items():
                    box[k] = v
                if "title" in changes:
                    box["subject"] = subj
                    box["topic"] = topic
                    box["is_test"] = event_is_test(ev["title"])
                if ov_changes:
                    overlay_updates[bid] = evv
                if apply:
                    push_last_updates[bid] = evv
                if (pstate.get("app_edited_at") or {}).pop(bid, None) is not None:
                    pstate_dirty = True
                updated.append(ev["title"])
                log.append("به‌روز شد: {} ({})".format(ev["title"], bid))
            continue
        # Brand-new event -> brand-new box.
        next_num += 1
        nid = "b{}".format(next_num)
        subj, topic = derive_subject_topic(ev["title"])
        nb = {"id": nid, "date": ev["date"], "start": ev["start"],
              "end": ev["end"], "subject": subj, "topic": topic,
              "title": ev["title"], "is_test": event_is_test(ev["title"]),
              "tests_total": 0, "note": ""}
        boxes.append(nb)
        by_id[nid] = nb
        uid_map[uid] = nid
        uid_set.add(nid)
        added.append(ev["title"])
        if apply:
            push_last_updates[nid] = {"title": ev["title"], "date": ev["date"],
                                      "start": ev["start"], "end": ev["end"]}
        log.append("اضافه شد: {} ({})".format(ev["title"], nid))
    # Orphaned boxes (v1.11.7, kept in v1.11.9): a programme box with no
    # UID link that falls inside the feed's date span and has no feed
    # event claiming it is stale — Google deleted it or replaced it with
    # a renamed/moved event (which the loop above created anew, since the
    # merge never links by similarity). After the event loop every live
    # feed event is linked to exactly one box, so "unmapped" already means
    # "no event claims this box". The record is NEVER deleted (rules 2/5):
    # it is only flagged `orphaned`. v1.11.9: the box STAYS in its section
    # (dashboard / programme / review-past) with no connection badge —
    # only the user moves or deletes it, by hand. A later pull re-links
    # it and clears the flag. Live sync only: file imports never orphan
    # unmapped boxes (remove_missing=False) — a file may be a partial
    # export. Custom boxes live in state.custom_boxes and are untouched
    # here. This pass runs BEFORE the mapped loop below: a box the mapped
    # loop unlinks (touched) must not be counted a second time here.
    # Feed-freshness guard (v1.11.28, QA BUG-042): a stale/partial ICS
    # used to orphan every in-span box it did not mention — one bad
    # fetch cut the link for a whole stretch of the programme, and
    # those boxes could not push or sync done flags until the next
    # good pull. Count what this pull WOULD orphan first: unmapped
    # in-span boxes plus mapped UIDs absent from the feed (both
    # span-scoped; deleted and already-orphaned boxes excluded). The
    # feed is suspicious when that is 3+ boxes AND more than half of
    # the mapped in-span boxes, or 5+ boxes outright. A genuinely
    # deleted event orphans 1–2 boxes and stays well under the bar.
    # When suspicious, the adds/updates above still apply, but NO
    # link is dropped and no box is flagged — the previous links are
    # kept and the feed is flagged. The one exception: the SAME boxes
    # missing on two consecutive pulls means the feed is consistently
    # without them (genuine deletions, not a stale fetch), so the
    # orphaning applies on the second one and the flag clears.
    # Explicitly cancelled events in a file import
    # (remove_missing=False) are deliberate deletions, so the guard
    # only covers the absence-based orphaning of the live sync.
    # v1.11.65 (Batch 6, R6): the count itself lives in
    # _merge_would_orphan now — the guard logic below is unchanged.
    would_orphan_ids = set()
    mapped_in_span = 0
    if remove_missing:
        would_orphan_ids, mapped_in_span = _merge_would_orphan(
            boxes, by_id, uid_map, seen_uids, deleted, tomb_box, span)
    would_orphan = len(would_orphan_ids)
    suspicious_feed = (
        (would_orphan >= 3 and mapped_in_span > 0
         and would_orphan * 2 > mapped_in_span)
        or would_orphan >= 5)
    if suspicious_feed and apply:
        prev_blocked = set(((prog.get("meta") or {}).get("feed_guard_blocked") or []))
        if prev_blocked and prev_blocked <= would_orphan_ids:
            suspicious_feed = False
    if suspicious_feed:
        log.append("فید مشکوک — {} باکس یتیم می‌شد؛ لینک‌های قبلی حفظ شد".format(would_orphan))
    if remove_missing and not suspicious_feed:
        for b in list(boxes):
            bid = b["id"]
            if bid in uid_set:
                continue
            if bid in deleted or bid in tomb_box:
                continue
            if b.get("orphaned"):
                continue
            if span[0] and not (span[0] <= b.get("date", "") <= span[1]):
                continue
            b["orphaned"] = True
            if _box_touched(state, bid):
                kept_touched += 1
            push_unmap.add(bid)
            unlinked.append(b.get("title") or bid)
            log.append("حفظ شد (رویداد از تقویم حذف شده): {} ({})".format(
                b.get("title"), bid))
    # Unlinking (v1.11.7): mapped UIDs absent from the feed, scoped to the
    # feed's own date span (a partial export never unlinks outside its
    # range). With remove_missing=False (file imports) only events the
    # file marks cancelled are unlink candidates — mere absence means
    # nothing there. No box is ever deleted here (rules 2/5): the link is
    # dropped and the box is flagged orphaned, so its record stays in
    # history / review-past.
    for uid, bid in list(uid_map.items()):
        if uid in seen_uids:
            continue
        if not remove_missing and uid not in (cancelled_uids or set()):
            continue
        box = by_id.get(bid)
        if box is None:
            del uid_map[uid]
            continue
        if span[0] and not (span[0] <= box.get("date", "") <= span[1]):
            continue
        if bid in deleted:
            tomb_uids.add(uid)
            del uid_map[uid]
            push_forget.add(bid)
            continue
        if _box_touched(state, bid):
            if suspicious_feed:
                # Guarded (BUG-042): keep the link, flag nothing.
                continue
            del uid_map[uid]  # orphan: keep the box, drop the link
            box["orphaned"] = True
            kept_touched += 1
            push_unmap.add(bid)
            unlinked.append(box.get("title") or bid)
            log.append("حفظ شد (در برنامه لمس شده): {} ({})".format(box.get("title"), bid))
            continue
        # Never delete a box because Google deleted its event (rules 2/5):
        # keep the record in place, drop only the link, and flag it
        # orphaned — the box stays in its section with no connection badge
        # (v1.11.9: no hiding, no auto-move; the user decides by hand).
        if suspicious_feed:
            # Guarded (BUG-042): keep the link, flag nothing.
            continue
        del uid_map[uid]
        box["orphaned"] = True
        push_unmap.add(bid)
        unlinked.append(box.get("title") or bid)
        log.append("حفظ شد (رویداد از تقویم حذف شده): {} ({})".format(box.get("title"), bid))
    summary = {"added": len(added), "updated": len(updated),
               "removed": len(removed), "unlinked": len(unlinked),
               "skipped_tombstone": skipped_tomb,
               "kept_touched": kept_touched,
               "cancelled": len(cancelled_uids or []),
               "conflicts": len(conflict_notes),
               "suspicious_feed": suspicious_feed,
               "orphaned_blocked": would_orphan if suspicious_feed else 0,
               "dropped_titles": [c.get("title") for c in conflict_notes][:20],
               "span_from": span[0], "span_to": span[1],
               "box_count": len(boxes),
               "added_titles": added[:20], "updated_titles": updated[:20],
               "removed_titles": removed[:20],
               "unlinked_titles": unlinked[:20]}
    if apply:
        prog["boxes"] = boxes
        prog["uid_map"] = uid_map
        prog["tombstone_uids"] = sorted(tomb_uids)
        prog["tombstone_box_ids"] = sorted(tomb_box)
        meta = dict(prog.get("meta") or {})
        meta["last_sync"] = iso_now()
        meta["last_source"] = source_label
        meta["last_pull_ts"] = now_ts()
        # v1.11.9: remember the last successful pull's feed (uid/title/
        # date/start/end per event) so the reconnect picker can list the
        # currently-unlinked Google events without re-fetching. This is
        # feed data, not user data — it is replaced on every pull.
        meta["last_feed"] = [{"uid": e["uid"], "title": e["title"],
                              "date": e["date"], "start": e["start"],
                              "end": e["end"]} for e in events]
        meta["last_feed_ts"] = iso_now()
        # v1.11.28 (QA BUG-042): remember the blocked set so a second
        # consecutive pull missing the SAME boxes can confirm genuine
        # deletions; a clean pull clears it.
        if suspicious_feed:
            meta["feed_guard_blocked"] = sorted(would_orphan_ids)
        else:
            meta.pop("feed_guard_blocked", None)
        prog["meta"] = meta
        # Push-state bookkeeping from this pull: boxes now in sync with
        # Google, conflicts to push, overlay reconciliation, and cleanup
        # for boxes that left the programme.
        if push_last_updates:
            lp = dict(pstate.get("last_pushed") or {})
            lp.update(push_last_updates)
            pstate["last_pushed"] = lp
            pstate_dirty = True
        if conflict_notes:
            # Dropped local edits are recorded for the UI, but they are
            # RESOLVED — never queued for push (Google's version stands).
            conf = list(pstate.get("conflicts") or [])
            seen_c = {c.get("box_id") for c in conf}
            for c in conflict_notes:
                if c["box_id"] not in seen_c:
                    conf.append(c)
            pstate["conflicts"] = conf[-20:]
            pend = set(pstate.get("pending") or [])
            pend -= {c["box_id"] for c in conflict_notes}
            pstate["pending"] = sorted(pend)
            pstate_dirty = True
        if push_forget or push_unmap:
            lp = dict(pstate.get("last_pushed") or {})
            em = dict(pstate.get("event_map") or {})
            ae = dict(pstate.get("app_edited_at") or {})
            for bid in push_forget:
                lp.pop(bid, None)
                ae.pop(bid, None)
            for bid in push_unmap:
                lp.pop(bid, None)
                ae.pop(bid, None)
                em.pop(bid, None)
            pstate["last_pushed"] = lp
            pstate["event_map"] = em
            pstate["app_edited_at"] = ae
            pstate_dirty = True
        if overlay_updates:
            st = load_state()
            ed = st.get("edits") or {}
            for bid, vals in overlay_updates.items():
                if bid in ed:
                    ed[bid].update(vals)
            st["edits"] = ed
            save_state(st)
        if pstate_dirty:
            save_push_state(pstate)
        save_programme(prog)
        append_calendar_log(source_label, summary, log)
    return summary


# ---------- Calendar config + log ----------




def masked_ics_url(url):
    url = (url or "").strip()
    if not url:
        return ""
    m = re.match(r"^(https?://[^/]+/).*$", url)
    if not m:
        return "•••"
    # Only the scheme + host: the path carries the private token, and
    # even its last 8 characters are part of that secret.
    return m.group(1) + "•••"


def masked_calendar_config(cfg):
    # v1.11.45 (bug-hunt B-02): a corrupt non-numeric interval_minutes
    # used to raise ValueError here and kill the status endpoint with
    # no HTTP response (same class as BUG-004). Corrupt means unknown
    # -> the 30-minute default.
    try:
        interval = int(cfg.get("interval_minutes") or 30)
    except (TypeError, ValueError):
        interval = 30
    return {"configured": bool((cfg.get("ics_url") or "").strip()),
            "enabled": bool(cfg.get("enabled")),
            "ics_url_masked": masked_ics_url(cfg.get("ics_url") or ""),
            "interval_minutes": interval,
            "last_sync": cfg.get("last_sync"),
            "last_error": cfg.get("last_error"),
            "last_summary": cfg.get("last_summary")}


def append_calendar_log(source, summary, lines):
    cfg = load_calendar_config()
    log = cfg.get("log") or []
    log.append({"ts": iso_now(), "source": source, "summary": summary,
                "lines": (lines or [])[:60]})
    cfg["log"] = log[-CALENDAR_LOG_MAX:]
    try:
        save_calendar_config(cfg)
    except Exception as exc:
        print("Could not save calendar log: {}".format(exc))


def calendar_status_payload():
    cfg = load_calendar_config()
    prog = load_programme()
    # v1.11.10: the frontend's boxes (data.json seed + state.edits) carry
    # no Google Event ID, so boxConnected() was false for every box and
    # the «متصل» badge never showed (user-reported bug, 24 Nov 20:09).
    # The status payload now ships the REAL per-box link data — the full
    # uid_map (Google Event ID -> boxId, the server's native shape) and
    # the orphaned box ids — so the frontend can stamp them onto the
    # rendered boxes (it inverts uid_map to boxId -> Event ID).
    return {"config": masked_calendar_config(cfg),
            "programme": {"box_count": len(prog.get("boxes") or []),
                          "mapped": len(prog.get("uid_map") or {}),
                          "tombstones": len(prog.get("tombstone_uids") or []),
                          "last_source": (prog.get("meta") or {}).get("last_source"),
                          "uid_map": dict(prog.get("uid_map") or {}),
                          "orphaned": [b.get("id") for b in (prog.get("boxes") or [])
                                       if b.get("orphaned") and b.get("id")]},
            "log": (cfg.get("log") or [])[-20:],
            "oauth": masked_oauth_status(),
            "push": push_status_payload()}


# ---------- Google Calendar two-way sync (Part B, v1.11.0) ----------
# OAuth 2.0 (Desktop-app client «StudyFlow Desktop», Google Cloud project
# «StudyFlow»). The Client ID is pre-filled as a default (a public
# identifier, not a secret); the Client Secret is pasted once by the user in
# settings. The secret is REQUIRED for this client: verified 2026-11-24
# against the real token endpoint — without it Google answers 400
# invalid_request «client_secret is missing». The sign-in uses PKCE
# (RFC 8252, code_challenge_method=S256) on top of the secret.
# Client Secret + access/refresh tokens live ONLY in the data dir
# (google_oauth.json) and are never sent to the browser; the UI only ever
# sees masked values. Google endpoints are overridable through env vars
# (GOOGLE_OAUTH_AUTH_URL / GOOGLE_OAUTH_TOKEN_URL / GOOGLE_OAUTH_REVOKE_URL /
# GOOGLE_CALENDAR_API_BASE) so tests can point the server at a local fake
# Google; production defaults are the real Google URLs.
# The StudyFlow Desktop OAuth client (Google Cloud project «StudyFlow»).
# A client ID is a public identifier, not a secret, so it ships as the
# default — the user only ever has to paste the Client Secret once.


















def _invalidate_push_tracking():
    """After a state/programme restore the push bookkeeping (what Google
    last had, what the app edited, what is pending) describes content
    that no longer exists — clear it so the next push re-syncs from the
    restored values instead of PATCHing stale ones. The event map
    (box -> Google event id) is kept: box ids survive a restore."""
    with STATE_LOCK:
        ps = load_push_state()
        ps["last_pushed"] = {}
        ps["app_edited_at"] = {}
        ps["pending"] = []
        save_push_state(ps)


def push_status_payload():
    ps = load_push_state()
    cfg = load_oauth()
    return {"connected": bool((cfg.get("access_token") or "").strip()),
            "pending_count": len(ps.get("pending") or []),
            "pending": (ps.get("pending") or [])[:20],
            "last_push": ps.get("last_push"),
            "conflicts": (ps.get("conflicts") or [])[-5:],
            "mapped_events": len(ps.get("event_map") or {})}




































@_with_lock




def effective_boxes(prog, state):
    """{boxId: {title, date, start, end, uid, is_custom}} — what the user
    actually sees: programme boxes with the state.edits overlay, plus
    custom boxes. Deleted boxes are excluded."""
    deleted = set(state.get("deleted") or [])
    edits = state.get("edits") or {}
    uid_by_box = {}
    for uid, bid in (prog.get("uid_map") or {}).items():
        uid_by_box[bid] = uid
    out = {}
    for b in prog.get("boxes") or []:
        bid = b.get("id")
        if not bid or bid in deleted:
            continue
        ov = edits.get(bid) or {}
        out[bid] = {"title": ov.get("title", b.get("title")),
                    "date": ov.get("date", b.get("date")),
                    "start": ov.get("start", b.get("start")),
                    "end": ov.get("end", b.get("end")),
                    "uid": uid_by_box.get(bid), "is_custom": False}
    for cb in state.get("custom_boxes") or []:
        bid = cb.get("id")
        if not bid or bid in deleted:
            continue
        out[bid] = {"title": cb.get("title"), "date": cb.get("date"),
                    "start": cb.get("start"), "end": cb.get("end"),
                    "uid": None, "is_custom": True}
    return out


def _box_event_times(box):
    """(start_iso, end_iso) for a box, Asia/Tehran. An end at/before the
    start (e.g. 23:30-01:00) rolls to the next calendar day."""
    s = datetime.strptime("{} {}".format(box["date"], box["start"]),
                          "%Y-%m-%d %H:%M").replace(tzinfo=TEHRAN)
    e = datetime.strptime("{} {}".format(box["date"], box["end"]),
                          "%Y-%m-%d %H:%M").replace(tzinfo=TEHRAN)
    if e <= s:
        e += timedelta(days=1)
    return s.isoformat(timespec="seconds"), e.isoformat(timespec="seconds")


def _google_event_body(eff, done=None):
    """Event body for a create/PATCH. `done` (True/False) adds the
    studyflow.done extended property; None leaves it untouched."""
    s_iso, e_iso = _box_event_times(eff)
    body = {"summary": eff["title"],
            "start": {"dateTime": s_iso, "timeZone": "Asia/Tehran"},
            "end": {"dateTime": e_iso, "timeZone": "Asia/Tehran"}}
    if done is not None:
        body["extendedProperties"] = {"private": {"studyflow.done": "1" if done else "0"}}
    return body


def _resolve_event_id(imap, eff, link_store=None, bid=None):
    """Google API event id for a mapped box, or None.
    v1.11.40 (P3-13): the per-box one-day refresh is GONE — the push
    prefetches the whole programme window once at its start
    (LinkStore.prefetch_window), so this is a pure map lookup now.
    With a LinkStore, resolve through it (event_map first, then
    ical_map, then the @google.com convention); without one, the old
    ical_map-only lookup (kept for any other caller)."""
    if link_store is not None:
        return link_store.resolve(bid, eff.get("uid"))
    uid = eff.get("uid")
    if not uid:
        return None
    if imap.get(uid):
        return imap[uid]
    if uid.endswith("@google.com"):
        return uid[:-len("@google.com")]
    return None


# ---------- Internal box API (v1.11.0) ----------
# Targeted endpoints for changing the programme calendar (create / update
# incl. move / delete a box). They mutate state EXACTLY the way the UI
# does — programme boxes via the state.edits overlay, new boxes via
# state.custom_boxes, deletions via state.deleted — then save through
# save_state + note_app_edits, so the debounced auto-push sees them just
# like a UI edit. The pull-sync path (merge_calendar_events) is NOT used
# here: it writes programme values FROM Google, and a bare programme edit
# would be overwritten by the next pull. Same localhost-only server
# (127.0.0.1), no auth change: anything that can reach the port can call
# these, exactly like /api/state.
_BOX_TIME_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")
_BOX_TEST_RE = re.compile(r"تست|تکلیف|آزمون")


def _box_time_range_error(start, end):
    """v1.11.52 (F4): a reversed interval (end before start) is a genuine
    overnight box ONLY when it is short (<= 12h wrapped) AND ends by the
    03:30 study-day boundary. 10:00->09:00 wraps to 1380 minutes and ends
    at 09:00, past the boundary — that is a typo, not an overnight box.
    23:00->01:00 (120 min, ends 01:00) stays valid. Forward intervals
    are never reversed, so the boundary check applies only when end <
    start — the first version of this guard checked end > "03:30" for
    every interval and rejected every daytime box. Zero-length is
    reported by the == check in _box_field_error (create) or the
    effective-values check in box_api_update, not here."""
    if start is None or end is None:
        return None
    a0, a1 = _hhmm_to_min(start), _hhmm_to_min(end)
    if a0 is None or a1 is None:
        return None
    if a1 >= a0:
        return None
    mins = (a1 - a0) % 1440
    if mins > 720 or end > "03:30":
        return "بازه‌ی زمانی باکس معکوس است (پایان باید بعد از شروع باشد یا حداکثر تا ۰۳:۳۰ ادامه یابد)"
    return None


def _box_field_error(date, start, end):
    if date is not None:
        try:
            datetime.strptime(date or "", "%Y-%m-%d")
        except Exception:
            return "تاریخ باید به شکل YYYY-MM-DD باشد"
    for t in (start, end):
        if t is not None and not _BOX_TIME_RE.match(t or ""):
            return "ساعت باید به شکل HH:MM باشد"
    # v1.11.16 (audit §5 item 1.5): a zero-length box used to count as
    # 1440 minutes everywhere — refuse it (both values supplied here;
    # box_api_update also checks the effective values for partial edits).
    if start is not None and end is not None and start == end:
        return "شروع و پایان باکس نمی‌توانند برابر باشند"
    err = _box_time_range_error(start, end)
    if err:
        return err
    return None


def _programme_box(prog, bid):
    for b in prog.get("boxes") or []:
        if b.get("id") == bid:
            return b
    return None


def _box_type(stored, title):
    """Effective activity type (v1.11.5): an explicit stored "class" /
    "normal" wins; otherwise the v1.8.0 title rule backfills it (title
    contains «کلاس» -> "class", else "normal"). Same rule as the client's
    boxIsClass() — the server and the UI must agree on every box."""
    if stored in ("class", "normal"):
        return stored
    return "class" if "کلاس" in (title or "") else "normal"


def _box_uid(prog, bid):
    """Stored Google Event ID (ICS uid) for a programme box, or None.
    This is the ONLY connection signal the UI may use — never a
    title/date guess (v1.11.9, spec §4)."""
    for u, b in (prog.get("uid_map") or {}).items():
        if b == bid:
            return u
    return None


def _custom_box_dict(cb):
    """Public dict for a custom box (shared by _public_box and
    _public_boxes_list, v1.11.54 D-4). Same keys, same order."""
    return {"id": cb.get("id"), "title": cb.get("title"),
            "subject": cb.get("subject"), "topic": cb.get("topic"),
            "date": cb.get("date"), "start": cb.get("start"),
            "end": cb.get("end"), "is_test": bool(cb.get("is_test")),
            "tests_total": cb.get("tests_total") or 0,
            "note": cb.get("note") or "", "is_custom": True,
            "uid": None, "connected": False,
            # v1.11.52 (F3): the idempotency key, so the client can
            # adopt the server box after a lost create response.
            "client_id": cb.get("client_id"),
            "type": _box_type(cb.get("type"), cb.get("title"))}


def _programme_box_dict(pb, ov, tests_total, uid):
    """Public dict for a programme box + edits overlay (shared by
    _public_box and _public_boxes_list, v1.11.54 D-4). `tests_total`
    and `uid` are already resolved by the caller. Same keys, same
    order."""
    return {"id": pb.get("id"),
            "title": ov.get("title", pb.get("title")),
            "subject": ov.get("subject", pb.get("subject")),
            "topic": pb.get("topic"),
            "date": ov.get("date", pb.get("date")),
            "start": ov.get("start", pb.get("start")),
            "end": ov.get("end", pb.get("end")),
            "is_test": bool(pb.get("is_test")),
            "tests_total": tests_total,
            "note": ov.get("note", pb.get("note") or ""),
            "is_custom": False,
            "uid": uid, "connected": bool(uid) and not pb.get("orphaned"),
            "type": _box_type(ov.get("type", pb.get("type")),
                              ov.get("title", pb.get("title")))}


def _public_box(prog, state, bid):
    """The box as the UI shows it: programme values + overlay, or the
    custom-box entry. None if the box does not exist or is deleted."""
    if bid in (state.get("deleted") or []):
        return None
    cb = next((b for b in (state.get("custom_boxes") or [])
               if b.get("id") == bid), None)
    if cb is not None:
        return _custom_box_dict(cb)
    pb = _programme_box(prog, bid)
    if pb is None:
        return None
    ov = (state.get("edits") or {}).get(bid) or {}
    return _programme_box_dict(
        pb, ov, (state.get("tests_total") or {}).get(
            bid, pb.get("tests_total") or 0), _box_uid(prog, bid))


def _public_boxes_list(prog, state):
    """All public boxes in one pass (same shape as _public_box): the
    GET /api/boxes handler used to call _public_box per box, which
    re-scanned the programme + custom lists for every one of the 318."""
    eff = effective_boxes(prog, state)
    by_id = {b.get("id"): b for b in prog.get("boxes") or [] if b.get("id")}
    cb_by_id = {b.get("id"): b for b in (state.get("custom_boxes") or [])
                if b.get("id")}
    tests_total = state.get("tests_total") or {}
    edits = state.get("edits") or {}
    boxes = []
    for bid in sorted(eff, key=lambda b: (eff[b]["date"] or "",
                                          eff[b]["start"] or "", b)):
        e = eff[bid]
        if bid in cb_by_id:
            cb = cb_by_id[bid]
            boxes.append(_custom_box_dict(cb))
        else:
            pb = by_id.get(bid)
            if pb is None:
                continue
            ov = edits.get(bid) or {}
            boxes.append(_programme_box_dict(
                pb, ov, tests_total.get(bid, pb.get("tests_total") or 0),
                e.get("uid")))
    return boxes


def _note_app_edits_safe(old_state, saved):
    try:
        note_app_edits(old_state, saved)
    except Exception as exc:
        print("note_app_edits failed: {}".format(exc))


@_with_lock
def box_api_create(payload):
    """Create a custom box. Returns (http_status, payload)."""
    title = str(payload.get("title") or "").strip()
    if not title:
        return 400, {"error": "عنوان باکس خالی است"}
    date = str(payload.get("date") or "").strip()
    start = str(payload.get("start") or "09:00").strip()
    end = str(payload.get("end") or "10:30").strip()
    if not date:
        return 400, {"error": "تاریخ باکس خالی است"}
    err = _box_field_error(date, start, end)
    if err:
        return 400, {"error": err}
    subject = str(payload.get("subject") or "").strip()
    if not subject:
        # v1.11.45 (bug-hunt B-15): the old prefix split invented a
        # subject from any title ("مرور شیمی" -> phantom subject
        # "مرور شیمی"). Only a prefix that IS a known subject counts;
        # anything else is a general box.
        prefix = title.split(":")[0].split("—")[0].strip()
        known = {s.get("fa") for s in load_subjects()}
        subject = prefix if prefix in known else "عمومی"
    topic = str(payload.get("topic") or "").strip() or title
    is_test = payload.get("is_test")
    is_test = bool(_BOX_TEST_RE.search(title)) if is_test is None else bool(is_test)
    try:
        total = max(0, int(payload.get("tests_total") or 0))
    except Exception:
        return 400, {"error": "tests_total باید عدد باشد"}
    note = str(payload.get("note") or "")
    # v1.11.52 (F3): idempotency key. The client generates one client_id
    # per create attempt and sends it here; if the server already has a
    # custom box with that key (the first attempt succeeded but its
    # response was lost), the existing box is returned instead of a
    # duplicate. Without a client_id the behaviour is unchanged.
    client_id = payload.get("client_id")
    if client_id is not None:
        client_id = str(client_id).strip()
        if len(client_id) > 64:
            return 400, {"error": "client_id خیلی طولانی است"}
        if not client_id:
            client_id = None
    # v1.11.24 (QA BUG-013): length caps at the API boundary (the
    # merge_state sanitizer truncates as a backstop for /api/state).
    if len(title) > TITLE_MAX_LEN:
        return 400, {"error": "عنوان باکس خیلی طولانی است"}
    if len(subject) > SUBJECT_MAX_LEN:
        return 400, {"error": "نام درس خیلی طولانی است"}
    if len(note) > NOTE_MAX_LEN:
        return 400, {"error": "یادداشت باکس خیلی طولانی است"}
    box_type = "class" if str(payload.get("type") or "").strip() == "class" else "normal"
    state = load_state()
    old_state = json.loads(json.dumps(state))
    if client_id:
        dup = next((b for b in (state.get("custom_boxes") or [])
                    if b.get("client_id") == client_id), None)
        if dup is not None:
            prog = load_programme()
            return 200, {"ok": True, "box": _public_box(prog, state, dup.get("id")),
                         "warnings": [], "duplicate": True}
    nid = "custom-" + str(int(time.time() * 1000))
    existing = {b.get("id") for b in (state.get("custom_boxes") or [])}
    while nid in existing:
        nid += "x"
    nb = {"id": nid, "date": date, "start": start, "end": end,
          "subject": subject, "topic": topic, "title": title,
          "is_test": is_test, "tests_total": total, "note": note,
          "type": box_type}
    if client_id:
        nb["client_id"] = client_id
    cbs = list(state.get("custom_boxes") or [])
    cbs.append(nb)
    state["custom_boxes"] = cbs
    saved = save_state(state)
    _note_app_edits_safe(old_state, saved)
    # (2.8) non-blocking warnings for the new box's study day.
    prog = load_programme()
    warn = programme_issues(prog, saved, _study_day_of(date, start))
    return 200, {"ok": True, "box": _public_box(prog, saved, nid), "warnings": warn}


@_with_lock
def box_api_update(payload):
    """Edit a box (title/subject/date/start/end/note/type); a new date/time
    IS the move. Programme boxes go through the edits overlay (same keys
    the UI's edit form writes); custom boxes are edited in place.
    Returns (http_status, payload)."""
    bid = str(payload.get("id") or "").strip()
    if not bid:
        return 400, {"error": "شناسه‌ی باکس خالی است"}
    prog = load_programme()
    state = load_state()
    if bid in (state.get("deleted") or []):
        return 404, {"error": "این باکس حذف شده است"}
    cb = next((b for b in (state.get("custom_boxes") or [])
               if b.get("id") == bid), None)
    pb = _programme_box(prog, bid) if cb is None else None
    if cb is None and pb is None:
        return 404, {"error": "باکسی با این شناسه پیدا نشد"}
    fields = {}
    for k in ("title", "subject", "note"):
        if payload.get(k) is not None:
            fields[k] = str(payload.get(k))
    for k in ("date", "start", "end"):
        if payload.get(k) is not None:
            fields[k] = str(payload.get(k)).strip()
    if "title" in fields and not fields["title"].strip():
        return 400, {"error": "عنوان باکس خالی است"}
    # v1.11.24 (QA BUG-013): length caps at the API boundary (the
    # merge_state sanitizer truncates as a backstop for /api/state).
    if "title" in fields and len(fields["title"]) > TITLE_MAX_LEN:
        return 400, {"error": "عنوان باکس خیلی طولانی است"}
    if "subject" in fields and len(fields["subject"]) > SUBJECT_MAX_LEN:
        return 400, {"error": "نام درس خیلی طولانی است"}
    if "note" in fields and len(fields["note"]) > NOTE_MAX_LEN:
        return 400, {"error": "یادداشت باکس خیلی طولانی است"}
    err = _box_field_error(fields.get("date"), fields.get("start"),
                           fields.get("end"))
    if err:
        return 400, {"error": err}
    # v1.11.16 (audit §5 item 1.5): a partial update can also make a
    # zero-length box (start moved onto the existing end) — check the
    # effective start/end, not only the supplied fields.
    if "start" in fields or "end" in fields:
        if cb is not None:
            eff_start = fields.get("start", cb.get("start"))
            eff_end = fields.get("end", cb.get("end"))
        else:
            ov = (state.get("edits") or {}).get(bid) or {}
            eff_start = fields.get("start", ov.get("start", pb.get("start")))
            eff_end = fields.get("end", ov.get("end", pb.get("end")))
        if eff_start is not None and eff_end is not None and eff_start == eff_end:
            return 400, {"error": "شروع و پایان باکس نمی‌توانند برابر باشند"}
        # v1.11.52 (F4): the same reversed-range guard on the effective
        # values — a partial edit can also create a reversed interval
        # (e.g. end moved before the existing start).
        eff_err = _box_time_range_error(eff_start, eff_end)
        if eff_err:
            return 400, {"error": eff_err}
    if not fields and "is_test" not in payload \
            and "tests_total" not in payload and "topic" not in payload \
            and "type" not in payload:
        return 400, {"error": "هیچ فیلدی برای تغییر داده نشده است"}
    if cb is None and ("topic" in payload or "is_test" in payload):
        # v1.11.24 (QA BUG-011): one rule for immutable fields — a
        # combined update used to silently DROP topic/is_test for
        # programme boxes (only the topic/is_test-only payload 400d),
        # so a caller believed the topic was saved when it was not.
        # Either field now 400s with its name, alone or combined.
        bad = "topic" if "topic" in payload else "is_test"
        return 400, {"error": "{} برای باکس برنامه قابل تغییر نیست".format(bad)}
    old_state = json.loads(json.dumps(state))
    if cb is not None:
        for k in ("title", "subject", "topic", "date", "start", "end", "note"):
            if k in fields:
                cb[k] = fields[k]
        if payload.get("topic") is not None:
            cb["topic"] = str(payload.get("topic"))
        if "is_test" in payload:
            cb["is_test"] = bool(payload.get("is_test"))
        if "type" in payload:
            cb["type"] = "class" if str(payload.get("type") or "").strip() == "class" else "normal"
        if "tests_total" in payload:
            try:
                cb["tests_total"] = max(0, int(payload.get("tests_total")))
            except Exception:
                return 400, {"error": "tests_total باید عدد باشد"}
    else:
        # Programme box: the overlay carries exactly the keys the UI's
        # edit form writes (topic/is_test stay on the programme box).
        ov = dict((state.get("edits") or {}).get(bid) or {})
        for k in ("title", "subject", "date", "start", "end", "note"):
            if k in fields:
                ov[k] = fields[k]
        if "type" in payload:
            ov["type"] = "class" if str(payload.get("type") or "").strip() == "class" else "normal"
        state.setdefault("edits", {})[bid] = ov
        if "tests_total" in payload:
            try:
                state.setdefault("tests_total", {})[bid] = max(
                    0, int(payload.get("tests_total")))
            except Exception:
                return 400, {"error": "tests_total باید عدد باشد"}
    saved = save_state(state)
    _note_app_edits_safe(old_state, saved)
    # (2.8) non-blocking warnings for the box's (possibly new) study day.
    eff = next((b for b in _public_boxes_list(prog, saved) if b.get("id") == bid), None)
    warn = []
    if eff is not None:
        warn = programme_issues(prog, saved,
                                _study_day_of(eff.get("date") or "", eff.get("start") or ""))
    return 200, {"ok": True, "box": _public_box(prog, saved, bid), "warnings": warn}


@_with_lock
def _purge_box_state_rows(state, bid):
    """Server-side mirror of the client's purgeBoxState (public/app.js):
    drop every per-box row of `bid` from the stored state — the nine
    keys the audit lists (done/tests/edits/actualMinutes/tests_total/
    usefulMinutes/timerSessions/testLog/assignments) plus the three
    purgeBoxState also handles (topicLinks, boxBookLinks, and a
    usefulPrompt naming this box). v1.11.71 (audit #2, L9)."""
    if (isinstance(state.get("usefulPrompt"), dict)
            and state["usefulPrompt"].get("boxId") == bid):
        state["usefulPrompt"] = None
    for k in ("done", "tests", "actualMinutes", "edits", "tests_total",
              "topicLinks", "boxBookLinks", "usefulMinutes"):
        d = state.get(k)
        if isinstance(d, dict) and bid in d:
            del d[bid]
    if isinstance(state.get("assignments"), list):
        state["assignments"] = [
            x for x in state["assignments"]
            if not (isinstance(x, dict) and x.get("boxId") == bid)]
    if isinstance(state.get("timerSessions"), list):
        state["timerSessions"] = [
            s for s in state["timerSessions"]
            if not (isinstance(s, dict) and s.get("boxId") == bid)]
    if isinstance(state.get("testLog"), list):
        state["testLog"] = [
            x for x in state["testLog"]
            if not (isinstance(x, dict) and x.get("box") == bid)]


def box_api_delete(payload):
    """Delete a box: it goes to state.deleted (programme or custom —
    exactly like the UI's delete, and like the T7 e2e case). The push
    then deletes its Google event too (v1.11.12 — any mapped event, not
    only app-created ones), and the merge tombstones its UID so the next
    pull never resurrects it. Returns (http_status, payload)."""
    bid = str(payload.get("id") or "").strip()
    if not bid:
        return 400, {"error": "شناسه‌ی باکس خالی است"}
    state = load_state()
    # v1.11.71 (audit #2, L8): idempotent delete — a box already in
    # state.deleted returns 200 BEFORE the existence check. The
    # L-DATA1 fix removed its custom_boxes row, so the second delete
    # used to fall to 404 (programme boxes still returned 200 because
    # their programme row still exists).
    if bid in (state.get("deleted") or []):
        return 200, {"ok": True, "id": bid}
    prog = load_programme()
    is_custom = any(b.get("id") == bid
                    for b in (state.get("custom_boxes") or []))
    if not is_custom and _programme_box(prog, bid) is None:
        return 404, {"error": "باکسی با این شناسه پیدا نشد"}
    deleted = list(state.get("deleted") or [])
    old_state = json.loads(json.dumps(state))
    deleted.append(bid)
    state["deleted"] = deleted
    # v1.11.60 (L-DATA1): a custom box also leaves custom_boxes — the
    # `deleted` tombstone above stays, so a later pull can never
    # resurrect it, and the push deletion still runs off the mapping.
    if is_custom:
        state["custom_boxes"] = [b for b in (state.get("custom_boxes") or [])
                                 if b.get("id") != bid]
    # v1.11.71 (audit #2, L9): purge the box's state rows server-side
    # (same key set as purgeBoxState, above). This is a DIRECT stored-
    # state write via save_state — not the merge path — so the five
    # merged keys really go. The UI path's purge stays as documented:
    # applyBoxDeletion + a full saveState resurrects the five merged
    # keys through the server's per-box deep merge (known limitation
    # in version.json — «بی‌اثر — باکس حذف شده است»); only
    # non-merged keys are really purged by a full save. That
    # limitation is about the UI path, not this handler.
    _purge_box_state_rows(state, bid)
    saved = save_state(state)
    _note_app_edits_safe(old_state, saved)
    return 200, {"ok": True, "id": bid}


def _box_has_user_data(state, bid):
    """Does this box hold any user data (ticks, tests, edits, minutes,
    links, assignments)? Used by reconnect: a duplicate box holding user
    data must NEVER be absorbed automatically (409 — the user chooses).
    v1.11.23 (QA BUG-022): the guard also sees usefulMinutes,
    timerSessions and testLog — all added after the guard was written
    (1.11.20/21). errorLog is deliberately NOT here: its entries carry
    no box reference (subject-scoped: {id, d, subject, source, q,
    type, ...}), so no per-box check is possible — and absorb never
    deletes errorLog entries either (it is not in the cleanup list), so
    no data-loss path exists for it through reconnect."""
    if (state.get("done") or {}).get(bid):
        return True
    tr = (state.get("tests") or {}).get(bid) or {}
    if (tr.get("completed") or 0) > 0 or (tr.get("correct") or 0) > 0:
        return True
    if bid in (state.get("edits") or {}):
        return True
    if bid in (state.get("tests_total") or {}):
        return True
    if (state.get("actualMinutes") or {}).get(bid):
        return True
    if (state.get("usefulMinutes") or {}).get(bid):
        return True
    if any((s or {}).get("boxId") == bid
           for s in (state.get("timerSessions") or [])):
        return True
    if any((e or {}).get("box") == bid
           for e in (state.get("testLog") or [])):
        return True
    if bid in (state.get("topicLinks") or {}):
        return True
    if bid in (state.get("boxBookLinks") or {}):
        return True
    if any((a or {}).get("boxId") == bid
           for a in (state.get("assignments") or [])):
        return True
    return False


def unlinked_calendar_payload(ids_only=False):
    """Reconnect picker data: Google events from the last successful pull
    that no box is linked to, plus programme boxes with no Event ID.
    Both lists come from stored link data only — never from title/date
    similarity (v1.11.9, spec §4). Empty when no pull has run yet.
    ids_only (v1.11.74, audit #3 P-105): unlinked_boxes carries only
    {id} entries (the client already has the boxes via /api/boxes) —
    plus the suggestion fields (+ date/start/end) where a suggestion
    exists. The default keeps the full objects (back-compat).
    v1.11.25 (QA BUG-021): when an unlinked event's (date+start) matches
    EXACTLY ONE orphaned box, the event carries suggested_box_id /
    suggested_box_title — the picker shows a one-click «looks like the
    same task — move history?» row for it. (date+start) only: the title
    may have changed (that is the whole bug — a delete + recreate in
    Google with a new title splits the history). Reconnecting that box
    to the event keeps its ticks/tests/minutes and absorbs the empty
    box the pull created, via the existing reconnect path."""
    prog = load_programme()
    state = load_state()
    uid_map = prog.get("uid_map") or {}
    tomb_uids = set(prog.get("tombstone_uids") or [])
    deleted = set(state.get("deleted") or [])
    feed = ((prog.get("meta") or {}).get("last_feed") or [])
    linked = set(uid_map)
    unlinked_events = [dict(e) for e in feed
                       if e.get("uid") not in linked
                       and e.get("uid") not in tomb_uids]
    unlinked_boxes_full = [{"id": b.get("id"), "title": b.get("title"),
                       "date": b.get("date"), "start": b.get("start"),
                       "end": b.get("end"), "subject": b.get("subject"),
                       "orphaned": bool(b.get("orphaned"))}
                      for b in (prog.get("boxes") or [])
                      if b.get("id") not in deleted
                      and b.get("id") not in uid_map.values()]
    if ids_only:
        # v1.11.74 (audit #3, P-105): the client already holds the
        # same 318 boxes via GET /api/boxes at boot and only joins
        # on id (boxSuggestion) plus the suggestion row the picker
        # renders. Sending the full objects again was 65KB per call
        # (at boot and after every sync). Ids only — the suggestion
        # fields (+ the slot the picker renders) are added below,
        # only where a suggestion exists.
        unlinked_boxes = [{"id": b.get("id")} for b in unlinked_boxes_full]
    else:
        unlinked_boxes = unlinked_boxes_full
    # Orphaned boxes keyed by (date, start) — the delete+recreate
    # fingerprint. Only orphaned boxes (their event vanished) and only
    # an unambiguous single match: two orphans in the same slot mean
    # the user must choose by hand.
    by_slot = {}
    for b in (prog.get("boxes") or []):
        if not b.get("orphaned"):
            continue
        if b.get("id") in deleted or b.get("id") in uid_map.values():
            continue
        by_slot.setdefault((b.get("date"), b.get("start")), []).append(b)
    for e in unlinked_events:
        cands = by_slot.get((e.get("date"), e.get("start")), [])
        if len(cands) == 1:
            e["suggested_box_id"] = cands[0].get("id")
            e["suggested_box_title"] = cands[0].get("title")
    # The other direction — the one that fires in the real delete +
    # recreate case: the recreated event is LINKED (to the empty box the
    # pull just created), so it never appears in unlinked_events, and
    # the orphaned old box cannot even open the picker (canReconnect
    # needs an unlinked event). For each orphaned box, look for a feed
    # event in the same (date+start) slot that is linked to a DIFFERENT
    # box — the pull-created duplicate. The suggestion is offered only
    # when that box holds NO user data (the same rule box_api_reconnect
    # uses to absorb): tapping it can only merge an empty duplicate,
    # never swallow real work. The picker shows it one-click.
    linked_by_slot = {}
    for e in feed:
        bid = uid_map.get(e.get("uid"))
        if bid:
            linked_by_slot.setdefault((e.get("date"), e.get("start")), []).append(e)
    # The suggestion is computed from the full entries (the ids_only
    # entries carry no orphaned/date/start of their own) and copied
    # onto the returned entry — with the slot fields too in ids_only
    # mode, because the picker renders the suggestion's date + start–end.
    for i, ub_full in enumerate(unlinked_boxes_full):
        if not ub_full.get("orphaned"):
            continue
        cands = [e for e in linked_by_slot.get(
            (ub_full.get("date"), ub_full.get("start")), [])
            if uid_map.get(e.get("uid")) not in (None, ub_full.get("id"))
            and not _box_has_user_data(state, uid_map.get(e.get("uid")))]
        if len(cands) == 1:
            ub = unlinked_boxes[i]
            ub["suggested_event_uid"] = cands[0].get("uid")
            ub["suggested_event_title"] = cands[0].get("title")
            if ids_only:
                ub["date"] = ub_full.get("date")
                ub["start"] = ub_full.get("start")
                ub["end"] = ub_full.get("end")
    return {"unlinked_events": unlinked_events,
            "unlinked_boxes": unlinked_boxes,
            # v1.11.29 (PI-04): the reconnect picker shows a clear-tombstones
            # action only when deleted-event IDs are stored.
            "tombstones": len(tomb_uids),
            "last_feed_ts": (prog.get("meta") or {}).get("last_feed_ts")}


@_with_lock
def clear_calendar_tombstones():
    """Clear all stored tombstones (v1.11.29, PI-04). A deleted box's UID
    stays tombstoned forever otherwise, so a restored Google event with
    the same ID is skipped on every pull. Clearing is explicit, one-click
    from the reconnect picker, and a verified programme backup is taken
    BEFORE the mutation (same rule as reconnect)."""
    prog = load_programme()
    n_uids = len(prog.get("tombstone_uids") or [])
    n_boxes = len(prog.get("tombstone_box_ids") or [])
    if not n_uids and not n_boxes:
        return 200, {"ok": True, "cleared_uids": 0, "cleared_boxes": 0}
    entry = create_backup("programme", force=True)
    if entry is None or verify_backup_entry(entry) is None:
        return 500, {"error": "پشتیبان‌گیری قبل از پاک کردن ممکن نشد — هیچ تغییری اعمال نشد"}
    prog["tombstone_uids"] = []
    prog["tombstone_box_ids"] = []
    save_programme(prog)
    return 200, {"ok": True, "cleared_uids": n_uids, "cleared_boxes": n_boxes}


@_with_lock
def box_api_reconnect(payload):
    """Manually reconnect a programme box to an existing Google event
    (spec §3.4). The user picks the event — the server never guesses.
    The box takes the event's values (title/date/time), the orphaned
    flag clears, and the UID is stored. If another box already holds
    that UID: absorb it ONLY when it holds no user data (it was created
    by a pull); when it holds user data, refuse with 409 and let the
    user choose. Reconnecting the same box+uid twice is a no-op.
    A verified programme backup is taken BEFORE any mutation."""
    bid = str(payload.get("boxId") or "").strip()
    uid = str(payload.get("uid") or "").strip()
    if not bid:
        return 400, {"error": "شناسه‌ی باکس خالی است"}
    if not uid:
        return 400, {"error": "شناسه‌ی رویداد خالی است"}
    prog = load_programme()
    state = load_state()
    if bid in (state.get("deleted") or []):
        return 404, {"error": "این باکس حذف شده است"}
    if any(b.get("id") == bid for b in (state.get("custom_boxes") or [])):
        return 400, {"error": "باکس دستی به رویداد تقویم وصل نمی‌شود"}
    box = _programme_box(prog, bid)
    if box is None:
        return 404, {"error": "باکسی با این شناسه پیدا نشد"}
    feed = ((prog.get("meta") or {}).get("last_feed") or [])
    ev = next((e for e in feed if e.get("uid") == uid), None)
    if ev is None:
        return 400, {"error": "رویدادی با این شناسه در آخرین سینک پیدا نشد"}
    uid_map = dict(prog.get("uid_map") or {})
    if uid in (prog.get("tombstone_uids") or []):
        return 400, {"error": "این رویداد قبلاً در برنامه حذف شده است"}
    if uid_map.get(uid) == bid:
        # Idempotent: already linked — just make sure the flag is clear.
        changed = box.pop("orphaned", None) is not None
        if changed:
            save_programme(prog)
        return 200, {"ok": True, "already": True,
                     "box": _public_box(load_programme(), load_state(), bid)}
    # Backup BEFORE any mutation, and verify it (spec §7).
    entry = create_backup("programme", force=True)
    if entry is None or verify_backup_entry(entry) is None:
        return 500, {"error": "پشتیبان‌گیری قبل از اتصال ممکن نشد — هیچ تغییری اعمال نشد"}
    absorbed = None
    other_bid = uid_map.get(uid)
    if other_bid and other_bid != bid:
        other = _programme_box(prog, other_bid)
        if other is None:
            del uid_map[uid]  # stale mapping, drop it
        elif other_bid in (state.get("deleted") or []):
            # Already deleted by the user: absorb unconditionally.
            prog["boxes"] = [b for b in prog["boxes"]
                             if b.get("id") != other_bid]
            absorbed = other_bid
        elif _box_has_user_data(state, other_bid):
            return 409, {"error": "این رویداد به باکس «{}» وصل است که داده‌ی کاربر دارد — اول آن را حذف یا جابه‌جا کن".format(
                other.get("title") or other_bid),
                "other_box": {"id": other_bid, "title": other.get("title")}}
        else:
            # Duplicate created by a pull, no user data: absorb it.
            prog["boxes"] = [b for b in prog["boxes"]
                             if b.get("id") != other_bid]
            for k in ("done", "tests", "actualMinutes", "edits",
                      "tests_total", "topicLinks", "boxBookLinks",
                      "usefulMinutes"):
                if isinstance(state.get(k), dict):
                    state[k].pop(other_bid, None)
            if isinstance(state.get("timerSessions"), list):
                state["timerSessions"] = [s for s in state["timerSessions"]
                                          if (s or {}).get("boxId") != other_bid]
            if isinstance(state.get("testLog"), list):
                state["testLog"] = [e for e in state["testLog"]
                                    if (e or {}).get("box") != other_bid]
            if isinstance(state.get("assignments"), list):
                state["assignments"] = [a for a in state["assignments"]
                                        if (a or {}).get("boxId") != other_bid]
            absorbed = other_bid
    # Drop the box's previous link, if any (the old event is gone — that
    # is why the box was disconnected).
    for u, b in list(uid_map.items()):
        if b == bid and u != uid:
            del uid_map[u]
    # Apply the event's values to the box (the event is the authority;
    # the user explicitly chose this link) and clear the orphaned flag.
    subj, topic = derive_subject_topic(ev["title"])
    box["title"] = ev["title"]
    box["date"] = ev["date"]
    box["start"] = ev["start"]
    box["end"] = ev["end"]
    box["subject"] = subj
    box["topic"] = topic
    box["is_test"] = event_is_test(ev["title"])
    box.pop("orphaned", None)
    uid_map[uid] = bid
    prog["uid_map"] = uid_map
    # Reconcile the app-edit overlay, so it cannot mask the reconnect.
    ed = state.get("edits") or {}
    if bid in ed:
        ed[bid].update({"title": ev["title"], "date": ev["date"],
                        "start": ev["start"], "end": ev["end"]})
        state["edits"] = ed
    # Push bookkeeping: the box now matches the event, so the next push
    # has nothing to send for it; drop the old event-id mapping (it
    # resolves on demand) and the old done baseline.
    ps = load_push_state()
    lp = dict(ps.get("last_pushed") or {})
    lp[bid] = {"title": ev["title"], "date": ev["date"],
               "start": ev["start"], "end": ev["end"]}
    ps["last_pushed"] = lp
    ae = dict(ps.get("app_edited_at") or {})
    ae.pop(bid, None)
    ps["app_edited_at"] = ae
    em = dict(ps.get("event_map") or {})
    em.pop(bid, None)
    ps["event_map"] = em
    ds = dict(ps.get("done_synced") or {})
    ds.pop(bid, None)
    ps["done_synced"] = ds
    save_push_state(ps)
    save_state(state)
    save_programme(prog)
    return 200, {"ok": True, "absorbed": absorbed,
                 "box": _public_box(load_programme(), load_state(), bid)}


@_with_push_run_lock
@_with_sync_lock
def box_api_push_one(payload):
    """Create ONE Google Calendar event for a single disconnected box
    (v1.11.11, per-box «افزودن به تقویم»). Works for programme boxes
    and custom boxes. Idempotent: a box that is already linked (a
    uid_map entry — the pull's link — or the push event_map) creates
    NOTHING and returns already:true. On success the event id is
    recorded in event_map, created_ids, ical_map AND uid_map (so the
    corner box flips to «در تقویم ✓» via the status payload), plus
    last_pushed / done_synced; an orphaned flag on a programme box is
    cleared. OAuth not connected returns the same Persian error
    push_to_google uses and creates nothing. The three-dot
    «reconnect» (pick an EXISTING event) is untouched — this is the
    other direction (create a NEW event).

    v1.11.16 (audit §5 item 1.2): serialized under PUSH_RUN_LOCK
    (v1.11.69, M4) with push_to_google and run_calendar_sync — a
    concurrent push can no longer create a duplicate event for the
    same box. (SYNC_LOCK alone no longer serializes whole runs: PR6
    dropped it from push_to_google in 1.11.65.)
    v1.11.24 (QA BUG-019): three phases like push_to_google — the
    Google POST no longer runs under STATE_LOCK (a slow POST used to
    freeze every state save). Phase A validates + takes the
    per-box in-flight guard under a short lock; phase B POSTs with
    no state lock held; phase C persists the mapping onto FRESHLY
    re-loaded push_state/programme under a short lock."""
    bid = str(payload.get("box_id") or payload.get("boxId") or "").strip()
    if not bid:
        return 400, {"error": "شناسه‌ی باکس خالی است"}
    cfg = load_oauth()
    if not (cfg.get("access_token") or "").strip() \
            and not (cfg.get("refresh_token") or "").strip():
        return 200, {"ok": False,
                     "error": "گوگل متصل نیست — اول «اتصال به گوگل» را بزن"}
    # ---- Phase A: validate + in-flight guard (short, locked) ----
    with STATE_LOCK:
        prog = load_programme()
        state = load_state()
        if bid in (state.get("deleted") or []):
            return 404, {"error": "این باکس حذف شده است"}
        eff = effective_boxes(prog, state)
        e = eff.get(bid)
        if e is None:
            return 404, {"error": "باکسی با این شناسه پیدا نشد"}
        ps = load_push_state()
        emap = dict(ps.get("event_map") or {})
        if e.get("uid") or bid in emap:
            # Already linked — create nothing (idempotent). The merge
            # drops uid_map + event_map entries when it orphans a box,
            # so a disconnected box never reaches this branch.
            return 200, {"ok": True, "already": True,
                         "event_id": emap.get(bid),
                         "box": _public_box(prog, state, bid)}
        done_local = bool((state.get("done") or {}).get(bid))
        # Per-box in-flight guard (v1.11.16, audit §5 item 1.2): never
        # POST a second event for a box that is already being pushed.
        # Whole-run serialization (PUSH_RUN_LOCK, v1.11.69) makes this
        # unreachable today; the set is belt-and-braces for any future
        # caller that bypasses the lock.
        if bid in _PUSH_IN_FLIGHT:
            return 200, {"ok": False,
                         "error": "این باکس در حال همگام‌سازی است — چند لحظه دیگر دوباره تلاش کن"}
        _PUSH_IN_FLIGHT.add(bid)
    # ---- Phase B: the Google POST (PUSH_RUN_LOCK + SYNC_LOCK, NO STATE_LOCK) ----
    # v1.11.23 (QA BUG-003): the guard is released in a `finally` — a
    # bookkeeping exception after the Google POST used to escape the
    # handler (no try in do_POST), swallowing the HTTP response and
    # leaving the box locked until a server restart, with an orphan
    # Google event and no saved mapping. Bookkeeping failures now return
    # an error payload instead of raising.
    try:
        try:
            data = get_provider(api=google_api).create_event(_google_event_body(e, done=done_local))
        except Exception as exc:
            return 200, {"ok": False,
                         "error": "ساخت «{}»: {}".format(e["title"], exc)}
        eid = str(data.get("id") or "")
        ical_uid = str(data.get("iCalUID") or "")
        if not eid:
            return 200, {"ok": False, "error": "گوگل شناسه‌ی رویداد نداد"}
        # ---- Phase C: persist the mapping onto FRESH state ----
        # Re-load push_state fresh: an edit or a pull that landed
        # during the POST is never overwritten (BUG-019). Only this
        # box's entries are set, so nothing else can be clobbered.
        try:
            with STATE_LOCK:
                fresh_ps = load_push_state()
                f_emap = dict(fresh_ps.get("event_map") or {})
                f_emap[bid] = eid
                fresh_ps["event_map"] = f_emap
                f_imap = dict(fresh_ps.get("ical_map") or {})
                if ical_uid:
                    f_imap[ical_uid] = eid
                fresh_ps["ical_map"] = f_imap
                f_created = set(fresh_ps.get("created_event_ids") or [])
                f_created.add(eid)
                fresh_ps["created_event_ids"] = sorted(f_created)
                f_lp = dict(fresh_ps.get("last_pushed") or {})
                f_lp[bid] = {"title": e["title"], "date": e["date"],
                             "start": e["start"], "end": e["end"]}
                fresh_ps["last_pushed"] = f_lp
                f_ds = dict(fresh_ps.get("done_synced") or {})
                f_ds[bid] = done_local
                fresh_ps["done_synced"] = f_ds
                save_push_state(fresh_ps)
        except Exception as exc:
            # The mapping was NOT persisted: remove the orphan event
            # best-effort so a retry does not create a duplicate.
            # (Outside the lock — a network call, never under STATE_LOCK.)
            try:
                get_provider(api=google_api).delete_event(eid)
            except Exception:
                pass
            return 200, {"ok": False,
                         "error": "ذخیره‌ی پیوند «{}» ممکن نشد — رویداد ساخته‌شده پاک شد، دوباره تلاش کن: {}".format(e["title"], exc)}
        # Clear the orphaned flag so the status payload (and the corner
        # box) sees the box as connected, and persist the uid_map.
        try:
            with STATE_LOCK:
                fresh_prog = load_programme()
                pb = _programme_box(fresh_prog, bid)
                if pb is not None:
                    pb.pop("orphaned", None)
                if ical_uid:
                    f_uid_map = dict(fresh_prog.get("uid_map") or {})
                    f_uid_map[ical_uid] = bid
                    fresh_prog["uid_map"] = f_uid_map
                save_programme(fresh_prog)
        except Exception as exc:
            # The mapping IS persisted (event_map has it); only the
            # programme save failed. Report the error — the box is
            # linked and the next pull/push reconciles the flag.
            return 200, {"ok": False, "event_id": eid,
                         "error": "رویداد ساخته شد ولی ذخیره‌ی برنامه ممکن نشد: {}".format(exc)}
        with STATE_LOCK:
            box = _public_box(load_programme(), load_state(), bid)
        return 200, {"ok": True, "already": False, "event_id": eid,
                     "box": box}
    finally:
        _PUSH_IN_FLIGHT.discard(bid)


def _apply_map_diff(fresh, final, snap):
    """Apply a phase-B map diff onto a freshly loaded map (v1.11.24,
    QA BUG-019). Keys the phase-B run set or changed win; keys it
    removed are removed only when the fresh value still equals the
    phase-A snapshot — a concurrent writer's newer value always wins.
    (The only concurrent push_state writer during a push is
    note_app_edits, which touches app_edited_at + pending only; the
    pull can also pop last_pushed/event_map/app_edited_at entries.)"""
    for k, v in final.items():
        fresh[k] = v
    for k in list(fresh):
        if k in snap and k not in final and fresh[k] == snap[k]:
            del fresh[k]
    return fresh


def _apply_set_diff(fresh, final, snap):
    """Set version of _apply_map_diff: phase-B additions win;
    removals apply only to members the snapshot had (a member added
    by a concurrent run during phase B is never removed)."""
    fresh |= (final - snap)
    fresh -= (snap - final)
    return fresh


@_with_sync_lock
def _push_deletions(prog, state, deleted, emap, imap, uid_map, link_store,
                    provider, first, last, _prefetch_listed, last_pushed,
                    app_edited, pending, done_synced, created_ids, errors):
    """Phase-B deletions of push_to_google (v1.11.54, MQ-1): deleting
    a box in the app deletes its Google event too (v1.11.12, every
    mapped box). Returns (removed, prog_dirty). The tracking dicts
    and sets are mutated in place; only the two scalars come back."""
    removed = 0
    prog_dirty = False
    # --- deletions (v1.11.12): deleting a box in the app deletes its
    # Google event too — for EVERY mapped box, not only events the
    # app itself created (user request, 24 Nov 22:06). A box with no
    # event mapping still makes no API call. A delete failure keeps
    # the mapping (the `continue` below) so the next push retries.
    # v1.11.16 (audit §5 item 1.3): the pull records a link ONLY in
    # programme.uid_map, never in push_state.event_map — so a
    # pull-linked box was skipped by the old `bid not in emap`
    # gate and its Google event survived deletion. Resolve the
    # event id from uid_map / ical_map for those boxes instead of
    # skipping them.
    for bid in sorted(deleted):
        title = bid
        date = None
        raw = _programme_box(prog, bid)
        if raw is not None:
            ov = (state.get("edits") or {}).get(bid) or {}
            title = ov.get("title", raw.get("title")) or bid
            date = ov.get("date", raw.get("date"))
        else:
            cb = next((c for c in (state.get("custom_boxes") or [])
                       if c.get("id") == bid), None)
            title = (cb or {}).get("title") or bid
            date = (cb or {}).get("date")
        eid = emap.get(bid)
        uid = None
        if not eid:
            uid = _box_uid(prog, bid)
            if uid:
                if imap.get(uid):
                    eid = imap[uid]
                elif date:
                    eid = _resolve_event_id(imap, {"uid": uid, "date": date}, link_store, bid)
                elif uid.endswith("@google.com"):
                    eid = uid[:-len("@google.com")]
        if not eid:
            if uid is None:
                # No link of any kind: no Google event can exist
                # for this box — never linked, never created, or
                # already deleted and cleaned up (BUG-039), or the
                # pull already dropped the link because the event
                # is gone from the feed (orphan path). Nothing to
                # delete and nothing to retry: drop the tracking
                # silently, as before.
                last_pushed.pop(bid, None)
                app_edited.pop(bid, None)
                pending.discard(bid)
                done_synced.pop(bid, None)
                continue
            # v1.11.27 (user-reported dashboard-delete bug, 25 Nov):
            # the box still HAS a pull link (uid_map), so a Google
            # event should exist — but its id resolves from nowhere
            # (not in ical_map, not in the day's refresh, and no
            # @google.com suffix to derive it from). The old code
            # dropped the tracking silently here, so the push still
            # reported ok: True with zero errors while the event
            # survived forever, with no signal anywhere. Record
            # the failure so last_push carries it (the Calendar tab
            # shows last_push.error and the pending count) and KEEP
            # all tracking: the bid stays in the phase-B pending
            # set, so the phase-C consumed() rule does not drop it
            # and the next auto-push retries the resolution.
            # Nothing is popped — the successful-DELETE branch
            # below still cleans up.
            # v1.11.45 (bug-hunt B-06): except when the event is
            # provably ALREADY gone from Google — the whole
            # programme window was listed (the prefetch found
            # events) and this box's date is inside that window,
            # yet the uid resolves to nothing. The desired end
            # state is already achieved: drop the tracking and
            # count it removed instead of erroring and staying
            # pending on every push forever. Only when the window
            # was not listed at all (prefetch failed, or it listed
            # nothing) or the box date is outside it does the
            # error-and-retry above stay. The pull link goes too,
            # exactly like the successful-DELETE branch below —
            # otherwise the next push would count it removed again.
            if (_prefetch_listed > 0 and date
                    and first.isoformat() <= date <= last.isoformat()):
                removed += 1
                last_pushed.pop(bid, None)
                app_edited.pop(bid, None)
                pending.discard(bid)
                done_synced.pop(bid, None)
                uid_map.pop(uid, None)
                imap.pop(uid, None)
                prog_dirty = True
                continue
            errors.append(
                "حذف «{}»: رویدادش در تقویم پیدا نشد — حذف دوباره تلاش می‌شود".format(title))
            continue
        try:
            provider.delete_event(eid)
            removed += 1
        except GoogleNotFound:
            removed += 1  # already gone on Google
        except Exception as exc:
            errors.append("حذف «{}»: {}".format(title, exc))
            continue
        created_ids.discard(eid)
        emap.pop(bid, None)
        last_pushed.pop(bid, None)
        app_edited.pop(bid, None)
        pending.discard(bid)
        done_synced.pop(bid, None)
        # v1.11.26 (QA BUG-039): the pull link must go regardless
        # of which map the event id came from. When eid came from
        # event_map, uid stayed None and the uid_map/imap entries
        # survived — the next push resolved the same dead event
        # again and counted another DELETE (404) as «removed».
        if uid is None:
            uid = _box_uid(prog, bid)
        if uid:
            # The event is gone: drop the pull link too, so a later
            # push never re-DELETEs a dead event (the merge would
            # drop it as an orphan anyway).
            uid_map.pop(uid, None)
            imap.pop(uid, None)
            prog_dirty = True

    return removed, prog_dirty


def _push_update_one(provider, eid, body, title, emap, last_pushed,
                     done_synced, app_edited, pending, errors, bid,
                     sig, done_local):
    """One box update to Google (v1.11.65, Batch 6, R5): the mapped-box
    and resolved-box paths in _push_creates_updates shared this whole
    arm — the _push_update_event call, the ok/gone/error branching and
    the success tail (last_pushed / app_edited / pending). Returns 1
    when the event was updated (the caller counts it), 0 when it was
    skipped or failed — on "gone" the link is already dropped by
    _drop_push_link, on "error" the message is already appended."""
    status, msg = _push_update_event(provider, eid, body, title)
    if status == "ok":
        done_synced[bid] = done_local
        last_pushed[bid] = sig
        app_edited.pop(bid, None)
        pending.discard(bid)
        return 1
    if status == "gone":
        _drop_push_link(emap, last_pushed, done_synced, errors, bid, title)
        return 0
    errors.append(msg)
    return 0


def _push_creates_updates(eff, emap, imap, state, provider, link_store,
                          last_pushed, app_edited, pending, done_synced,
                          errors, eff_sig, live_sig, google_moved_first,
                          created_ids):
    """Phase-B creates + updates of push_to_google (v1.11.54, MQ-1).
    Returns (created, updated, prog_dirty). The live-check closures (eff_sig,
    live_sig, google_moved_first) are push_to_google's — they close
    over its live-read cache.
    v1.11.65 (Batch 6, R5): the two update arms shared ~20 lines
    (the _push_update_event call, the ok/gone/error branching and the
    success tail) — they now share _push_update_one. The creates arm
    also takes created_ids as a parameter now: the 1.11.54 extraction
    left it (and prog_dirty) referring to push_to_google's locals, so
    creating a custom box's event raised NameError and the whole push
    failed — the phase-C uid_map commit for it never ran either."""
    created = 0
    updated = 0
    prog_dirty = False
    # --- creates + updates ---
    for bid in sorted(eff):
        e = eff[bid]
        sig = eff_sig(e)
        done_local = bool((state.get("done") or {}).get(bid))
        if bid in emap:
            if last_pushed.get(bid) == sig:
                pending.discard(bid)
                continue
            eid = emap[bid]
            if e.get("uid") and live_sig(e.get("uid")) == "unknown":
                # The live read failed: cannot tell whether Google
                # moved this box first — defer the update (it stays
                # pending) instead of PATCHing blind over Google.
                errors.append("بررسی زنده‌ی تقویم ممکن نشد — ویرایش «{}» فرستاده نشد؛ در همگام‌سازی بعدی دوباره تلاش می‌شود".format(e["title"]))
                continue
            if google_moved_first(bid, sig, e.get("uid")):
                # Google changed this box after the last pull: do NOT
                # overwrite it. The next pull applies Google's version
                # and drops this local edit (with a note). Keep it
                # pending so the push retries until the pull resolves it.
                errors.append("«{}» در تقویم عوض شده بود — ویرایش برنامه فرستاده نشد؛ در همگام‌سازی بعدی نسخه‌ی تقویم اعمال می‌شود".format(e["title"]))
                continue
            updated += _push_update_one(
                provider, eid, _google_event_body(e, done=done_local),
                e["title"], emap, last_pushed, done_synced, app_edited,
                pending, errors, bid, sig, done_local)
            continue
        if e["is_custom"]:
            # A box made in the app -> a brand-new Google event.
            try:
                data = provider.create_event(_google_event_body(e, done=done_local))
            except Exception as exc:
                errors.append("ساخت «{}»: {}".format(e["title"], exc))
                continue
            eid = str(data.get("id") or "")
            ical_uid = str(data.get("iCalUID") or "")
            if eid:
                link_store.note_created(bid, eid, ical_uid)
                created_ids.add(eid)
                if ical_uid:
                    prog_dirty = True
                last_pushed[bid] = sig
                done_synced[bid] = done_local
                app_edited.pop(bid, None)
                pending.discard(bid)
                created += 1
            continue
        # A mapped programme box with no stored event id (e.g. mapped
        # before the OAuth connection): resolve it, then update.
        eid = _resolve_event_id(imap, e, link_store, bid)
        if not eid:
            if not e.get("uid"):
                # v1.11.23 (QA BUG-006): never linked to Google — there
                # is nothing to push, and it is NOT an error. Every
                # unlinked programme box used to append an error here,
                # so `ok` was False on every push (316 phantom errors
                # on a fresh seed) and a real push failure was
                # indistinguishable from the noise.
                continue
            errors.append("رویداد «{}» در گوگل پیدا نشد".format(e["title"]))
            continue
        emap[bid] = eid
        if last_pushed.get(bid) == sig:
            pending.discard(bid)
            continue
        if google_moved_first(bid, sig, e.get("uid")):
            errors.append("«{}» در تقویم عوض شده بود — ویرایش برنامه فرستاده نشد؛ در همگام‌سازی بعدی نسخه‌ی تقویم اعمال می‌شود".format(e["title"]))
            continue
        updated += _push_update_one(
            provider, eid, _google_event_body(e, done=done_local),
            e["title"], emap, last_pushed, done_synced, app_edited,
            pending, errors, bid, sig, done_local)

    return created, updated, prog_dirty


def _push_done(eff, emap, state, provider, last_pushed, done_synced,
               pending, errors, live_done):
    """Phase-B done-status push of push_to_google (v1.11.54, MQ-1).
    Returns done_updated."""
    # --- done-status push (v1.11.7): a tick/untick is not a shape
    # change, so the loop above never PATCHes it. Boxes whose local
    # done differs from what Google last had get their
    # extendedProperties patched (no other field touched). A box never
    # synced before uses Google's live flag as the baseline — no flag
    # means not done, so an unticked box needs no PATCH at all.
    # Loop-safe: a successful PATCH records the value in done_synced,
    # so the next pull (Google == local) applies nothing and the next
    # push PATCHes nothing.
    done_updated = 0
    for bid in sorted(eff):
        e = eff[bid]
        eid = emap.get(bid)
        if not eid:
            continue
        done_local = bool((state.get("done") or {}).get(bid))
        synced = done_synced.get(bid)
        if synced is None:
            ld = live_done(e.get("uid")) if e.get("uid") else None
            synced = ld if ld is not None else False
        if synced == done_local:
            done_synced[bid] = done_local
            continue
        try:
            provider.write_done(eid, done_local)
            done_synced[bid] = done_local
            done_updated += 1
            pending.discard(bid)
        except GoogleNotFound:
            _drop_push_link(emap, last_pushed, done_synced, errors, bid, e["title"])
            continue
        except Exception as exc:
            pending.add(bid)
            errors.append("به‌روز وضعیت «{}»: {}".format(e["title"], exc))
            continue

    return done_updated


def _drop_push_link(emap, last_pushed, done_synced, errors, bid, title):
    """D-1: a Google event vanished — drop the push link and record
    it. The same 4-line arm was inlined in all three phase-B loops."""
    emap.pop(bid, None)
    last_pushed.pop(bid, None)
    done_synced.pop(bid, None)
    errors.append("رویداد «{}» در گوگل پیدا نشد — پیوندش برداشته شد".format(title))


def _push_update_event(provider, eid, body, title):
    """One provider.update_event call with the push's standard
    handling (D-2 — the whole try/except was duplicated between the
    mapped-box and resolved-box update paths). Returns ("ok", None),
    ("gone", None) when the event vanished on Google (caller drops
    the link), or ("error", message) for anything else."""
    try:
        provider.update_event(eid, body)
        return "ok", None
    except GoogleNotFound:
        return "gone", None
    except Exception as exc:
        return "error", "به‌روز «{}»: {}".format(title, exc)


def push_to_google(manual=False):
    """Push app-side box changes to Google Calendar. Compares the effective
    boxes (programme + app edits + custom boxes) against last_pushed and
    only calls the API for what actually changed — and only when Google
    has not changed that box since the last pull: before PATCHing, the
    event's CURRENT values are read from Google, and a box Google moved
    first is skipped (the next pull then applies Google's version and
    drops the local edit, with a note). Deletions delete the Google event
    for every mapped box (v1.11.12 — user request: deleting a box in the
    app deletes its Google event too, not only events the app created).
    On any failure nothing is lost locally: the error is recorded in
    Persian and the push can be retried.
    v1.11.24 (QA BUG-019): three phases. The whole push used to run
    under STATE_LOCK, so a slow Google round-trip froze every state
    save (ticks, timer) for the entire push. Now: (A) a short locked
    snapshot of programme/state/push_state; (B) all Google calls with
    NO state lock held (PUSH_RUN_LOCK, v1.11.69, M4, serializes whole
    push/pull/push-one runs — it is released only around each
    _push_deletions chunk so a queued pull/push-one slips in between
    chunks; SYNC_LOCK is held only per deletion chunk and at
    pull/push-one entry, NOT across the run); (C) a short locked
    commit that applies only the DIFFS of phase B onto freshly
    re-loaded tracking — so an edit or a pull that landed during
    phase B is never overwritten."""
    cfg = load_oauth()
    if not (cfg.get("access_token") or "").strip() \
            and not (cfg.get("refresh_token") or "").strip():
        return {"ok": False, "error": "گوگل متصل نیست — اول «اتصال به گوگل» را بزن"}
    # v1.11.69 (M4): whole-run serialization via PUSH_RUN_LOCK —
    # acquired here, released in the finally below. The OAuth check
    # above runs lock-free (no shared state touched). The lock is
    # released around each _push_deletions chunk call inside phase B
    # (see the chunk loop) so a queued pull/push-one slips in there.
    PUSH_RUN_LOCK.acquire()
    try:
        # ---- Phase A: snapshot (short, locked) ----
        # Snapshots (suffix _s) are the phase-A values; the plain names
        # are phase B's working copies. Only note_app_edits can write
        # push_state during phase B (STATE_LOCK only, app_edited_at +
        # pending only) — every other push_state/programme writer
        # (pull, push-one, reconnect) takes PUSH_RUN_LOCK (+ SYNC_LOCK)
        # and is blocked.
        with STATE_LOCK:
            prog = load_programme()
            state = load_state()
            ps = load_push_state()
            eff = effective_boxes(prog, state)
            deleted = set(state.get("deleted") or [])
            emap_s = dict(ps.get("event_map") or {})
            imap_s = dict(ps.get("ical_map") or {})
            created_s = set(ps.get("created_event_ids") or [])
            last_pushed_s = dict(ps.get("last_pushed") or {})
            app_edited_s = dict(ps.get("app_edited_at") or {})
            pending_s = set(ps.get("pending") or [])
            done_synced_s = dict(ps.get("done_synced") or {})
            uid_map_s = dict(prog.get("uid_map") or {})
            first, last = _programme_range()
            emap = dict(emap_s)
            imap = dict(imap_s)
            created_ids = set(created_s)
            last_pushed = dict(last_pushed_s)
            app_edited = dict(app_edited_s)
            pending = set(pending_s)
            done_synced = dict(done_synced_s)
            uid_map = dict(uid_map_s)
            # Prune tracking for boxes that no longer exist anywhere.
            pending &= (set(eff) | deleted)
            for bid in list(app_edited):
                if bid not in eff and bid not in deleted:
                    del app_edited[bid]

        # ---- Phase B: Google calls (PUSH_RUN_LOCK only, NO STATE_LOCK) ----
        errors = []

        # v1.11.40 (P3-13): the sync provider + Link Store. The whole
        # programme window is read ONCE here (one list call) and every
        # box resolution after this is a map lookup — the old per-box
        # one-day refresh inside _resolve_event_id (N+1 Google calls)
        # is gone. The prefetch runs ONLY when some box actually needs
        # it (a uid no map resolves yet): a push with nothing to
        # resolve makes no list call at all. It reuses
        # refresh_event_id_map — the same function the old per-box code
        # called — with the whole window, and the store's
        # refresh_fn injection keeps the tests' server.refresh_event_id_map
        # patch driving it. The provider is built with server.google_api
        # so the tests' server.google_api patch drives the mutations too.
        provider = get_provider(api=google_api)
        link_store = LinkStore(uid_map, emap, imap, provider,
                               refresh_fn=refresh_event_id_map)
        _needs_prefetch = False
        for _bid in deleted:
            _uid = _box_uid(prog, _bid)
            if _uid and not link_store.resolve(_bid, _uid):
                _needs_prefetch = True
                break
        if not _needs_prefetch:
            for _bid, _e in eff.items():
                if _e.get("uid") and not link_store.resolve(_bid, _e["uid"]):
                    _needs_prefetch = True
                    break
        if _needs_prefetch:
            try:
                _prefetch_listed = link_store.prefetch_window(
                    first.isoformat() + "T00:00:00+03:30",
                    (last + timedelta(days=1)).isoformat() + "T00:00:00+03:30")
            except Exception as exc:
                print("Event-id window prefetch failed: {}".format(exc))
                _prefetch_listed = 0
        else:
            _prefetch_listed = 0

        def eff_sig(e):
            return {"title": e["title"], "date": e["date"],
                    "start": e["start"], "end": e["end"]}

        # v1.11.65 (Batch 6, L-PERF6/PR6): deletions run in chunks of
        # 25 — _push_deletions holds SYNC_LOCK for one call, so a
        # queued pull or push-one slips in between chunks instead of
        # waiting out a whole slow push (dozens of sequential Google
        # calls). The chunks share the phase-B working copies, so the
        # phase-C diff commit is unchanged.
        removed = 0
        prog_dirty = False
        _deleted_sorted = sorted(deleted)
        for _ci in range(0, len(_deleted_sorted), 25):
            # v1.11.69 (M4): release the push-run lock around each
            # deletion chunk so a queued pull/push-one slips in
            # between chunks (PR6 behaviour, kept intact).
            # _push_deletions takes SYNC_LOCK for the chunk itself;
            # this thread holds NO lock while waiting for it.
            PUSH_RUN_LOCK.release()
            try:
                _r, _d = _push_deletions(
                    prog, state, set(_deleted_sorted[_ci:_ci + 25]), emap,
                    imap, uid_map, link_store, provider, first, last,
                    _prefetch_listed, last_pushed, app_edited, pending,
                    done_synced, created_ids, errors)
            finally:
                PUSH_RUN_LOCK.acquire()
            removed += _r
            prog_dirty = prog_dirty or _d

        # Live Google check (Google-wins rule): before PATCHing a box,
        # read the events' CURRENT values from Google. An app edit is
        # pushed only if Google has not changed that box since the last
        # pull. Fetched lazily — only when a real update is about to be
        # pushed — and only once per push run. If the live read fails,
        # updates are DEFERRED (kept pending for the next push) instead
        # of PATCHing blind on the last_pushed comparison.
        live = None  # None = not fetched yet, False = fetch failed

        def ensure_live():
            """Fetch the live event list once per push run (or False).
            Uses the phase-A programme range snapshot (BUG-019) — the
            range cannot change under the push anyway."""
            nonlocal live
            if live is None:
                try:
                    live = _list_google_events(
                        first.isoformat() + "T00:00:00+03:30",
                        (last + timedelta(days=1)).isoformat() + "T00:00:00+03:30")
                except Exception as exc:
                    print("Live Google check failed, pushing on last_pushed: {}".format(exc))
                    live = False
            return live

        def live_sig(uid):
            """Current Google {title, date, start, end} for a UID, or
            None if the event is not in the live list, or "unknown" if
            the live read failed."""
            lv = ensure_live()
            if not lv:
                return "unknown"
            ev = lv.get(uid)
            if not ev:
                return None
            return {"title": ev["title"], "date": ev["date"],
                    "start": ev["start"], "end": ev["end"]}

        def live_done(uid):
            """Current Google done flag for a UID (True/False), or None
            when the event is not in the live list or the live read
            failed. Used as the first-sync baseline for the done push."""
            lv = ensure_live()
            if not lv:
                return None
            ev = lv.get(uid)
            if not ev:
                return None
            return ev.get("done")

        def google_moved_first(bid, sig, uid):
            """True if Google changed this box after the last pull: the
            live event differs from BOTH last_pushed and the app's edit.
            No UID, an event missing from the live list, or a failed live
            read all mean 'cannot tell' -> False (push as before)."""
            if not uid:
                return False
            ls = live_sig(uid)
            if ls == "unknown" or ls is None:
                return False
            return ls != last_pushed.get(bid) and ls != sig

        created, updated, _cu_dirty = _push_creates_updates(
            eff, emap, imap, state, provider, link_store, last_pushed,
            app_edited, pending, done_synced, errors, eff_sig, live_sig,
            google_moved_first, created_ids)
        prog_dirty = prog_dirty or _cu_dirty

        done_updated = _push_done(
            eff, emap, state, provider, last_pushed, done_synced, pending,
            errors, live_done)

        summary = {"created": created, "updated": updated, "removed": removed,
                   "done_updated": done_updated,
                   "errors": errors[:10], "error_count": len(errors)}
        # ---- Phase C: commit the DIFFS (short, locked) ----
        # Re-load fresh and apply only what phase B changed, so an edit
        # (note_app_edits) or a pull that landed during phase B is
        # never overwritten. A phase-B removal applies only when the
        # fresh value still equals the phase-A snapshot — a concurrent
        # writer's newer value always wins.
        with STATE_LOCK:
            fresh_ps = load_push_state()
            fresh_ps["event_map"] = _apply_map_diff(
                dict(fresh_ps.get("event_map") or {}), emap, emap_s)
            fresh_ps["ical_map"] = _apply_map_diff(
                dict(fresh_ps.get("ical_map") or {}), imap, imap_s)
            fresh_ps["created_event_ids"] = sorted(_apply_set_diff(
                set(fresh_ps.get("created_event_ids") or {}),
                created_ids, created_s))
            fresh_ps["last_pushed"] = _apply_map_diff(
                dict(fresh_ps.get("last_pushed") or {}),
                last_pushed, last_pushed_s)
            fresh_ps["done_synced"] = _apply_map_diff(
                dict(fresh_ps.get("done_synced") or {}),
                done_synced, done_synced_s)
            f_app_edited = _apply_map_diff(
                dict(fresh_ps.get("app_edited_at") or {}),
                app_edited, app_edited_s)
            fresh_ps["app_edited_at"] = f_app_edited
            f_pending = set(fresh_ps.get("pending") or [])
            for bid in (pending_s - pending):
                # consumed() rule: drop only if no NEW edit landed
                # during phase B. A new edit sets a fresh app_edited_at
                # timestamp; the pull popping the entry (Google-wins)
                # also means the push is moot.
                if bid not in f_app_edited \
                        or f_app_edited[bid] == app_edited_s.get(bid):
                    f_pending.discard(bid)
            f_pending |= (pending - pending_s)
            fresh_ps["pending"] = sorted(f_pending)
            fresh_ps["last_push"] = {"ts": iso_now(), "ok": not errors,
                                     "summary": summary,
                                     "error": errors[0] if errors else None}
            save_push_state(fresh_ps)
            if prog_dirty:
                fresh_prog = load_programme()
                fresh_prog["uid_map"] = _apply_map_diff(
                    dict(fresh_prog.get("uid_map") or {}), uid_map, uid_map_s)
                save_programme(fresh_prog)
        return {"ok": not errors, "summary": summary}
    except Exception as exc:
        with STATE_LOCK:
            ps = load_push_state()
            ps["last_push"] = {"ts": iso_now(), "ok": False, "summary": None,
                               "error": str(exc)}
            save_push_state(ps)
        return {"ok": False, "error": str(exc)}
    finally:
        # v1.11.69 (M4): release the whole-run lock on every exit
        # (success, error, or an exception inside a chunk re-acquire).
        PUSH_RUN_LOCK.release()


def note_app_edits(old_state, new_state):
    """After a state save: record which boxes changed (edit / custom box /
    delete / tick) with a timestamp, and queue a debounced auto-push.
    Ticks reach here too (a tick/untick queues a done-status push);
    test counts and real minutes never do — only box-shape changes and
    done changes do."""
    changed = set()
    old_edits = old_state.get("edits") or {}
    new_edits = new_state.get("edits") or {}
    for bid in set(old_edits) | set(new_edits):
        if old_edits.get(bid) != new_edits.get(bid):
            changed.add(bid)
    # Ticks (v1.11.7): a tick/untick is a done change — queue the box so
    # the debounced auto-push PATCHes its extendedProperties.
    old_done = old_state.get("done") or {}
    new_done = new_state.get("done") or {}
    for bid in set(old_done) | set(new_done):
        if bool(old_done.get(bid)) != bool(new_done.get(bid)):
            changed.add(bid)
    old_cb = {b["id"]: b for b in (old_state.get("custom_boxes") or []) if b.get("id")}
    new_cb = {b["id"]: b for b in (new_state.get("custom_boxes") or []) if b.get("id")}
    for bid in set(old_cb) | set(new_cb):
        if old_cb.get(bid) != new_cb.get(bid):
            changed.add(bid)
    changed |= (set(new_state.get("deleted") or []) - set(old_state.get("deleted") or []))
    if not changed:
        return
    with STATE_LOCK:
        ps = load_push_state()
        ea = dict(ps.get("app_edited_at") or {})
        now = time.time()
        for bid in changed:
            ea[bid] = now
        ps["app_edited_at"] = ea
        pend = set(ps.get("pending") or [])
        pend |= changed
        ps["pending"] = sorted(pend)
        save_push_state(ps)
    PUSH_SYNC.request()


class PushSync(_DebouncedWorker):
    """Debounced auto-push: runs ~15s after a state save that changed a box,
    so a burst of edits becomes one push. The loop is shared with the
    B2 CloudSync via _DebouncedWorker (v1.11.54, D-6)."""

    def __init__(self):
        super().__init__(3600, self._do_push, self._on_push_error)

    def _do_push(self):
        cfg = load_oauth()
        if not ((cfg.get("access_token") or "").strip()
                or (cfg.get("refresh_token") or "").strip()):
            return
        # Nothing pending: the hourly wake is a no-op (pushing
        # with no changes only re-reads Google for nothing).
        if not (load_push_state().get("pending") or []):
            return
        get_sync_provider().push(manual=False)

    @staticmethod
    def _on_push_error(exc):
        print("Calendar auto-push error: {}".format(exc))


PUSH_SYNC = PushSync()


# ---------- ICS fetch + sync runs ----------
def fetch_ics(url):
    # HTTPS only: the ICS URL carries the calendar's private token.
    if not str(url or "").strip().startswith("https://"):
        raise ValueError("آدرس ICS باید با https:// شروع شود")
    req = urllib.request.Request(
        url, headers={"User-Agent": "KonkurApp-CalendarSync/1.8"}, method="GET")
    # v1.11.24 (QA BUG-012): redirects are re-checked for https.
    with open_https_url(req, timeout=CALENDAR_FETCH_TIMEOUT) as resp:
        raw = resp.read(CALENDAR_MAX_BYTES + 1)
    if len(raw) > CALENDAR_MAX_BYTES:
        raise ValueError("فایل ICS خیلی بزرگ است")
    return raw.decode("utf-8", "replace")


def _record_sync_error(source_label, err, log=True):
    """Record a failed sync (fetch/parse/empty feed) in the calendar
    config (and, unless log=False, the sync log). No state is touched,
    so no lock is needed (v1.11.24, QA BUG-019)."""
    cfg = load_calendar_config()
    cfg["last_error"] = err
    save_calendar_config(cfg)
    if log:
        append_calendar_log(source_label, {"added": 0, "updated": 0, "removed": 0,
                                           "error": err}, [err])


@_with_push_run_lock
@_with_sync_lock
def run_calendar_sync(source_label):
    """Fetch the configured ICS URL and merge it. On any failure the last
    good programme is kept untouched and the error is recorded.
    v1.11.24 (QA BUG-019): the ICS fetch (up to 25 s) used to run under
    STATE_LOCK, freezing every state save for the whole request.
    The fetch + parse now run with NO lock held; STATE_LOCK is taken
    only around the load-merge-save section. PUSH_RUN_LOCK (v1.11.69,
    M4) serializes whole sync/push runs against each other."""
    cfg = load_calendar_config()
    url = (cfg.get("ics_url") or "").strip()
    if not url:
        return {"ok": False, "error": "آدرس ICS تنظیم نشده است"}
    try:
        text = fetch_ics(url)  # network — NO lock held (BUG-019)
    except Exception as exc:
        err = "دریافت ICS ممکن نشد: {}".format(exc)
        _record_sync_error(source_label, err)
        return {"ok": False, "error": err}
    try:
        raw = parse_ics(text)
    except Exception as exc:
        err = "خواندن ICS ممکن نشد: {}".format(exc)
        # Same as before the split: a parse error is recorded in the
        # config only, with no log entry.
        _record_sync_error(source_label, err, log=False)
        return {"ok": False, "error": err}
    events, cancelled, counts = normalize_events(raw)
    if not events and not cancelled:
        err = "در فید هیچ رویداد درسی پیدا نشد — داده‌ی قبلی حفظ شد"
        _record_sync_error(source_label, err)
        return {"ok": False, "error": err}
    # Load-merge-save only — the one short locked section (BUG-019).
    try:
        with STATE_LOCK:
            summary = merge_calendar_events(events, cancelled, source_label, apply=True)
            summary["skipped"] = counts
    except ProgrammeCorruptError as exc:
        # v1.11.25 (QA BUG-024): a corrupt programme must fail the sync
        # LOUDLY (recorded in the sync log + config) instead of silently
        # merging into a substituted seed.
        err = str(exc)
        _record_sync_error(source_label, err)
        return {"ok": False, "error": err}
    # Two-way done-status sync (v1.11.7): pull the done flags Google
    # carries (extendedProperties) and apply them to the dashboard.
    # Best-effort — a failed done pull never fails the ICS sync itself.
    # v1.11.16 (audit §5 item 1.4): a failed done pull used to vanish
    # as a silent (0, 0) — the error is now recorded in the sync log
    # so the user sees it.
    try:
        done_applied, done_conflicts, done_error, done_skipped = sync_done_from_google()
        summary["done_applied"] = done_applied
        summary["done_conflicts"] = done_conflicts
        # v1.11.28 (QA BUG-041): boxes skipped because a local tick is
        # still pending are counted in the summary AND the sync log —
        # a stuck push used to be invisible ((0, 0) looked like «in
        # sync» while the tick never reached Google).
        summary["done_skipped_pending"] = done_skipped
        if done_skipped:
            append_calendar_log(
                source_label,
                {"added": 0, "updated": 0, "removed": 0,
                 "done_skipped_pending": done_skipped},
                ["{} باکس در انتظار push رد شد — تیک محلی حفظ شد".format(done_skipped)])
        if done_error:
            summary["done_pull_error"] = done_error
            append_calendar_log(source_label,
                                {"added": 0, "updated": 0, "removed": 0,
                                 "done_pull_error": done_error},
                                [done_error])
    except Exception as exc:
        print("Done-status pull failed: {}".format(exc))
        summary["done_applied"] = 0
        summary["done_conflicts"] = 0
        summary["done_skipped_pending"] = 0
        summary["done_pull_error"] = str(exc)
        append_calendar_log(source_label,
                            {"added": 0, "updated": 0, "removed": 0,
                             "done_pull_error": str(exc)},
                            [str(exc)])
    cfg = load_calendar_config()
    cfg["last_sync"] = iso_now()
    cfg["last_error"] = None
    cfg["last_summary"] = summary
    save_calendar_config(cfg)
    return {"ok": True, "summary": summary, "counts": counts}


def run_calendar_import(content, filename, source_label, apply):
    """Parse uploaded file content (ICS or JSON) and merge it. With
    apply=False this is the preview: nothing is written and nothing is
    logged. Returns (ok, payload)."""
    name = (filename or "").lower()
    text = content or ""
    try:
        if name.endswith(".json") or text.lstrip()[:1] in ("{", "["):
            raw = parse_calendar_json(text)
            fmt = "json"
        else:
            raw = parse_ics(text)
            fmt = "ics"
    except ValueError as exc:
        return False, {"error": str(exc)}
    except Exception as exc:
        return False, {"error": "خواندن فایل ممکن نشد: {}".format(exc)}
    events, cancelled, counts = normalize_events(raw)
    if not events and not cancelled:
        return False, {"error": "در فایل هیچ رویداد درسی پیدا نشد"}
    summary = merge_calendar_events(events, cancelled, source_label, apply=apply,
                                   remove_missing=False)
    summary["skipped"] = counts
    if apply:
        cfg = load_calendar_config()
        cfg["last_sync"] = iso_now()
        cfg["last_error"] = None
        cfg["last_summary"] = summary
        save_calendar_config(cfg)
    return True, {"format": fmt, "summary": summary, "counts": counts}


CAL_SYNC_STATE = {"last_attempt": 0.0}


# ---------- Sync provider abstraction (audit §5 item 3.6a) ----------
# The sync seam: everything the app does with a calendar goes through a
# provider object ({name, pull(source_label), push(manual)}). Google is
# the only provider today (ICS pull + OAuth push — the provider delegates
# to the exact functions below, it does not reimplement anything), but a
# second provider can register itself in SYNC_PROVIDERS without touching
# the Handler, the auto-sync loop or the push thread.
class SyncProvider:
    """Interface a calendar provider must satisfy."""
    name = "base"

    def pull(self, source_label):
        raise NotImplementedError

    def push(self, manual=False):
        raise NotImplementedError


class GoogleSyncProvider(SyncProvider):
    """Google Calendar: ICS feed for the pull, OAuth for the push."""
    name = "google"

    def pull(self, source_label):
        return run_calendar_sync(source_label)

    def push(self, manual=False):
        return push_to_google(manual=manual)


SYNC_PROVIDERS = {"google": GoogleSyncProvider()}


def get_sync_provider(name="google"):
    """The provider by name; KeyError for an unknown name."""
    return SYNC_PROVIDERS[name]


def calendar_sync_loop():
    """Background thread: auto-sync on the configured interval, plus one
    sync shortly after server start when a URL is configured."""
    time.sleep(5)
    while True:
        try:
            cfg = load_calendar_config()
            if cfg.get("enabled") and (cfg.get("ics_url") or "").strip():
                interval = max(5, int(cfg.get("interval_minutes") or 30)) * 60
                now = time.time()
                if now - CAL_SYNC_STATE["last_attempt"] >= interval:
                    CAL_SYNC_STATE["last_attempt"] = now
                    get_sync_provider().pull("auto")
        except Exception as exc:
            print("Calendar auto-sync error: {}".format(exc))
        time.sleep(60)


# v1.11.28 (QA BUG-048): at most 10 request-handler threads run at
# once — see Handler.handle(). One user's browser opens a handful of
# parallel connections; 10 leaves ample headroom while a flood can no
# longer grow threads without bound.
_REQUEST_SEMAPHORE = threading.BoundedSemaphore(10)


# ---------- v1.11.67 (PR1, seq/ETag): save-protocol helpers ----------
def _parse_seq(v):
    """Parse a client-sent sequence (header or body field) to an int,
    or None when absent/unparseable. A garbage value is treated as
    absent (legacy path), never as a hard error."""
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, int):
        return v
    if isinstance(v, float) and v.is_integer():
        return int(v)
    if isinstance(v, str):
        s = v.strip()
        if s.isdigit():
            return int(s)
    return None


def _truthy(v):
    """True for a JSON true, 1, or the header string "1"/"true"."""
    if v is True or v == 1:
        return True
    if isinstance(v, str):
        return v.strip() in ("1", "true", "True")
    return False


def _is_full_state_body(data):
    """A body is FULL iff it carries at least 90% of the DEFAULT_STATE
    keys. The 1.11.67 client always sends full state (its boot literal
    + Object.assign from the server state has all keys), so a partial
    body is either a legacy client, a probe, or a bug — never a
    genuine full save. The 10% tolerance is deliberate: a whole-state
    save may omit a few server-managed keys (the drivers' GOOD_STATE
    fixture omits version / programme_start / programme_end) and is
    still a full save. A body missing MORE keys is a targeted update
    and is patched instead. Note the merge itself never wipes a key
    absent from the body (merge_state_update_scoped only overwrites
    keys the body carries) — the tolerance is safe: it only decides
    whether the PRESENT non-merged keys apply."""
    present = len(set(data.keys()) & set(DEFAULT_STATE.keys()))
    return present * 10 >= len(DEFAULT_STATE) * 9


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=PUBLIC, **kwargs)

    def log_message(self, fmt, *args):
        pass  # keep the console quiet

    def send_error(self, code, message=None, explain=None):
        # v1.11.74 (audit #3, C2): unknown /api/* routes answer JSON,
        # not the BaseHTTPRequestHandler HTML error page — GET
        # /api/nonexistent used to 404 with text/html while POST
        # already returned 404 JSON. Scoped to /api/* only: a missing
        # static file keeps its current HTML 404.
        if code == 404 and urllib.parse.urlparse(self.path).path.startswith("/api/"):
            body = json.dumps({"error": "not found"}).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        super().send_error(code, message, explain)

    def version_string(self):
        # v1.11.28 (QA BUG-047): never advertise the Python version —
        # the default banner is "SimpleHTTP/0.6 Python/3.12.3".
        return "StudyFlow"

    def handle(self):
        # v1.11.28 (QA BUG-048): cap concurrent request threads at 10.
        # ThreadingHTTPServer spawns one thread per connection with no
        # limit; a flood of parallel requests used to grow threads
        # without bound. The semaphore is per-request only — the
        # PushSync thread, the auto-sync loop and the update thread are
        # separate threads and are unaffected. A request that cannot
        # get a slot within 30 s gets a 503 instead of queueing
        # forever.
        if not _REQUEST_SEMAPHORE.acquire(timeout=30):
            self.close_connection = True
            try:
                self._send_json(503, {"error": "سرور شلوغ است — دوباره تلاش کن"})
            except Exception:
                pass
            return
        try:
            self._handle_guarded()
        finally:
            _REQUEST_SEMAPHORE.release()

    def _handle_guarded(self):
        # v1.11.25 (QA BUG-024): a corrupt programme file (no backup)
        # raises ProgrammeCorruptError from load_programme() deep inside
        # a handler. CPython's BaseHTTPRequestHandler has NO handle_error
        # hook and handle_one_request() has no generic except (only
        # TimeoutError) — an earlier handle_error override here was dead
        # code: the exception reached the server, which only printed a
        # traceback and closed the socket, so the client saw a bare
        # "connection closed". Catch it HERE (handle() wraps the whole
        # request loop) and answer with a readable 500 instead, so the
        # UI shows what happened. (v1.11.52, CQ-03: the generic
        # `except Exception` below covers every OTHER handler error
        # with a 500 JSON, so no request ever drops the socket.)
        try:
            super().handle()
        except ProgrammeCorruptError as exc:
            self.close_connection = True
            try:
                self._send_json(500, {"error": str(exc)})
            except Exception:
                pass
        except _BadJsonBody as exc:
            # v1.11.26 (QA BUG-030): same pattern as ProgrammeCorruptError
            # above — answer with the body's own status/message instead
            # of closing the socket silently.
            self.close_connection = True
            try:
                self._send_json(exc.status, {"error": exc.message})
            except Exception:
                pass
        except Exception as exc:
            # v1.11.52 (CQ-03): any OTHER handler exception used to drop
            # the connection (BaseHTTPRequestHandler has no generic
            # except in handle_one_request) — the client saw a bare
            # "connection closed" with no status and no message. Answer
            # with a 500 JSON instead, same pattern as the catches
            # above; the traceback still goes to stderr via print.
            print("handler error: {}: {}".format(type(exc).__name__, exc))
            self.close_connection = True
            try:
                self._send_json(500, {"error": "خطای داخلی سرور"})
            except Exception:
                pass

    def end_headers(self):
        # v1.11.28 (QA BUG-047): basic security headers on EVERY
        # response (this runs after send_response/send_header, so it
        # covers static files, JSON and error pages alike). The CSP
        # keeps 'unsafe-inline' for scripts/styles because index.html
        # carries one small inline script (the mobile nav drawer) and
        # the app uses inline styles — everything else is 'self',
        # which is all this local single-page app loads.
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
            "connect-src 'self'; font-src 'self'; object-src 'none'; "
            "base-uri 'self'; frame-ancestors 'none'")
        # v1.11.4 — never let the browser cache app files: a stale
        # cached app.js after an update leaves buttons in fresh HTML
        # without handlers (and a stale i18n.js shows raw keys).
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def _send_json(self, status, obj, headers=None):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _parse_json_body(self, raw):
        # v1.11.74 (audit #3, Q-211): the decode shared by the chunked
        # and the Content-Length paths — a non-dict JSON value is
        # rejected here too (the old code returned it as-is and the
        # handler then crashed on .get).
        try:
            data = json.loads(raw.decode("utf-8"))
        except Exception:
            raise _BadJsonBody(400, "JSON نامعتبر")
        if not isinstance(data, dict):
            raise _BadJsonBody(400, "JSON نامعتبر")
        return data

    def _read_json(self):
        # v1.11.26 (QA BUG-030): the three failure modes are distinct
        # errors, not one {}. Every POST endpoint that reads a body
        # requires one (all 24 call sites do data.get(...) next), so
        # raising here is safe — no handler legitimately runs on an
        # empty body. A non-dict JSON value is also rejected: the old
        # code returned it as-is and the handler then crashed on .get.
        # v1.11.74 (audit #3, L19): Transfer-Encoding: chunked is
        # decoded too — BaseHTTPRequestHandler does NOT do it for us,
        # so a chunked POST (Node http.request / undici fetch with no
        # Content-Length, a proxy that re-chunks) used to 400 with
        # «بدنه خالی». The 10MB cap is enforced while accumulating,
        # so a chunked body over the limit still 413s.
        if "chunked" in (self.headers.get("Transfer-Encoding") or "").lower():
            raw = self._read_chunked_body()
            if not raw:
                raise _BadJsonBody(400, "بدنه خالی")
            return self._parse_json_body(raw)
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except Exception:
            raise _BadJsonBody(400, "طول بدنه نامعتبر است")
        if length <= 0:
            raise _BadJsonBody(400, "بدنه خالی")
        if length > 10 * 1024 * 1024:
            raise _BadJsonBody(413, "بدنه خیلی بزرگ است")
        raw = self.rfile.read(length)
        return self._parse_json_body(raw)

    def _read_chunked_body(self):
        """Decode a Transfer-Encoding: chunked request body (RFC 9112
        §7.1) into bytes. Raises _BadJsonBody(413) when the accumulated
        body passes the 10MB cap, (400) on a malformed chunk framing.
        The caller closes the connection on any _BadJsonBody, so a
        half-read oversized body can never desync the next request."""
        total = bytearray()
        while True:
            line = self.rfile.readline(65536)
            if not line:
                break
            size_str = line.split(b";", 1)[0].strip()
            try:
                size = int(size_str, 16)
            except ValueError:
                raise _BadJsonBody(400, "JSON نامعتبر")
            if size == 0:
                # Trailers until an empty line, then the body is done.
                while True:
                    trailer = self.rfile.readline(65536)
                    if not trailer or trailer in (b"\r\n", b"\n"):
                        break
                break
            remaining = size
            while remaining > 0:
                chunk = self.rfile.read(min(65536, remaining))
                if not chunk:
                    raise _BadJsonBody(400, "بدنه خالی")
                total += chunk
                if len(total) > 10 * 1024 * 1024:
                    raise _BadJsonBody(413, "بدنه خیلی بزرگ است")
                remaining -= len(chunk)
            # Trailing CRLF after the chunk data (chunked framing is
            # always CRLF — a bare LF here would eat the next size
            # line, so it is rejected, not tolerated).
            crlf = self.rfile.read(2)
            if crlf != b"\r\n":
                raise _BadJsonBody(400, "JSON نامعتبر")
        return bytes(total)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path  # match routes without the query string
        if parsed.path == "/oauth/callback":
            self._handle_oauth_callback(parsed)
            return
        handler = GET_ROUTES.get(path)
        if handler is not None:
            handler(self)
            return
        super().do_GET()

    def _get_api_health(self):
        self._send_json(200, {"ok": True, "port": PORT})
        return

    def _get_api_state(self):
        # v1.11.67 (PR1): the current state seq rides in the response
        # header so the client can send it back with its next save.
        self._send_json(200, load_state(),
                        {"X-State-Seq": str(read_seq("state"))})
        return

    def _get_api_testbook(self):
        # v1.11.67 (PR1): same as _get_api_state, for the testbook.
        self._send_json(200, load_testbook(),
                        {"X-Testbook-Seq": str(read_seq("testbook"))})
        return

    def _get_api_gemini_key(self):
        # v1.11.28 (QA BUG-046): only a boolean leaves the server —
        # the old "masked" field leaked the first/last 4 chars of
        # the key to any caller of this endpoint.
        self._send_json(200, {"has_key": bool(read_key())})
        return

    def _get_api_gemini_model(self):
        self._send_json(200, {"model": read_model()})
        return

    def _get_api_gemini_models(self):
        # Diagnostic for the 404: list the models THIS key can actually use.
        key = read_key()
        if not key:
            self._send_json(400, {"error": "کلید API جمینای معتبر نیست"})
            return
        # v1.11.28 (QA BUG-048): the model list counts against the
        # same per-minute Gemini cap as generateContent calls.
        rate_err = check_gemini_rate_limit()
        if rate_err:
            self._send_json(429, {"error": rate_err})
            return
        # v1.11.28 (QA BUG-046): the key goes in the x-goog-api-key
        # header, never in the URL (?key= lands in logs/history).
        req = urllib.request.Request(
            GEMINI_API_BASE + "/models?pageSize=100",
            headers={"x-goog-api-key": key}, method="GET")
        try:
            # v1.11.24 (QA BUG-012): redirects are re-checked for https.
            with open_https_url(req, timeout=30) as resp:
                result = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            if exc.code in (400, 401, 403):
                self._send_json(400, {"error": "کلید API جمینای معتبر نیست"})
            else:
                self._send_json(502, {"error": "خطای سرور جمینای: HTTP " + str(exc.code)})
            return
        except Exception as exc:
            self._send_json(502, {"error": "ارتباط با جمینای برقرار نشد: " + str(exc)})
            return
        models = []
        for m in result.get("models", []) or []:
            name = str(m.get("name") or "")
            if name.startswith("models/"):
                name = name[len("models/"):]
            methods = m.get("supportedGenerationMethods") or []
            if name and "generateContent" in methods:
                # Full API metadata: the test panel shows the exact id,
                # display name, version and context limits from Google.
                models.append({
                    "id": name,
                    "displayName": str(m.get("displayName") or name),
                    "description": str(m.get("description") or ""),
                    "version": str(m.get("version") or ""),
                    "inputTokenLimit": m.get("inputTokenLimit"),
                    "outputTokenLimit": m.get("outputTokenLimit"),
                    "methods": methods,
                })
        models.sort(key=lambda x: x["id"])
        self._send_json(200, {"models": models})
        return

    def _get_api_backup(self):
        self._send_json(200, backup_status_payload())
        return

    def _get_api_backup_list(self):
        versions = []
        for v in list_local_versions():
            versions.append(dict(v, verified=backup_entry_verified(v)))
        cloud = None
        cfg = load_b2_config()
        if cfg and cfg.get("enabled") and b2mod:
            try:
                client = b2mod.B2Client(cfg)
                manifest = client.get_json(CLOUD_MANIFEST_KEY) or {}
                cloud = {"manifest": manifest}
            except Exception as exc:
                cloud = {"error": str(exc)}
        self._send_json(200, {"versions": versions, "cloud": cloud})
        return

    def _get_api_backup_b2_config(self):
        self._send_json(200, masked_b2_config(load_b2_config()))
        return

    def _get_api_version(self):
        self._send_json(200, read_version())
        return

    def _get_api_update_status(self):
        self._send_json(200, {"version": read_version(),
                              "backups": list_code_backups()})
        return

    def _get_api_update_auto(self):
        cfg = load_update_config()
        self._send_json(200, {
            "config": {"manifest_url": cfg.get("manifest_url") or DEFAULT_MANIFEST_URL},
            "current": read_version(),
            "last_check": cfg.get("last_check"),
            "last_result": cfg.get("last_result"),
            "last_error": cfg.get("last_error"),
            "state": auto_update_status()})
        return

    def _get_api_update_auto_progress(self):
        self._send_json(200, auto_update_status())
        return

    def _get_data_json(self):
        try:
            prog, _ = read_json_file(CALENDAR_DATA_FILE)
            if isinstance(prog, dict) and isinstance(prog.get("boxes"), list):
                # v1.11.9: attach the stored Google Event ID (uid) to
                # each box, so the UI can show the REAL connection
                # status (connected = has a uid and is not orphaned).
                # uid_map is the only source of truth — never a
                # title/date guess.
                uid_by_box = {}
                for u, bid in (prog.get("uid_map") or {}).items():
                    uid_by_box[bid] = u
                boxes = []
                for b in prog["boxes"]:
                    nb = dict(b)
                    nb["uid"] = uid_by_box.get(b.get("id"))
                    boxes.append(nb)
                self._send_json(200, {"meta": prog.get("meta") or {},
                                      "boxes": boxes})
                return
            if os.path.isfile(CALENDAR_DATA_FILE):
                # v1.11.45 (bug-hunt B-03): the file EXISTS but is
                # unparseable or wrong-shaped — never serve the shipped
                # seed for it (BUG-024 bypass: the frontend falls back
                # to this seed when /api/boxes 500s, silently dropping
                # every Google link and programme change). Fail loudly.
                self._send_json(500, {"error":
                    "فایل برنامه (calendar_data.json) خراب است — "
                    "فایل خراب حفظ شده است؛ یک بکاپ را restore کن یا "
                    "فایل را دستی برگردان"})
                return
            try:
                with open(os.path.join(BASE, "data.json"), encoding="utf-8") as f:
                    data = json.load(f)
            except FileNotFoundError:
                # v1.11.74 (audit #3, P-1172-03): a fresh release-zip
                # install has no shipped seed — data.json is
                # deliberately excluded from the release zip (it is
                # the update channel over an existing install; fresh
                # installs come from the chat zip). A missing seed is
                # an empty programme, not a 500.
                self._send_json(200, {"meta": {}, "boxes": []})
                return
            except Exception as exc:
                print("GET /data.json seed read failed: {}".format(exc))
                self._send_json(500, {"error": "خطا در خواندن داده‌های برنامه"})
                return
            self._send_json(200, data)
        except Exception as exc:
            # v1.11.74 (audit #3, P-1172-03): an API error must never
            # surface a raw errno string or an absolute server path —
            # log the detail server-side, answer a clean message.
            print("GET /data.json failed: {}".format(exc))
            self._send_json(500, {"error": "خطا در خواندن داده‌های برنامه"})
        return

    def _get_api_calendar_unlinked(self):
        # v1.11.74 (audit #3, P-105): ?ids=1 returns only box ids
        # (the client joins on its own /api/boxes list); the default
        # keeps the full objects.
        parsed = urllib.parse.urlparse(self.path)
        ids_only = (urllib.parse.parse_qs(parsed.query).get("ids", ["0"])[0] == "1")
        self._send_json(200, unlinked_calendar_payload(ids_only=ids_only))
        return

    def _get_api_calendar_status(self):
        self._send_json(200, calendar_status_payload())
        return

    def _get_api_calendar_config(self):
        self._send_json(200, masked_calendar_config(load_calendar_config()))
        return

    def _get_api_calendar_oauth_status(self):
        self._send_json(200, {"oauth": masked_oauth_status(),
                              "push": push_status_payload()})
        return

    def _get_api_calendar_push_status(self):
        self._send_json(200, push_status_payload())
        return

    def _get_api_boxes(self):
        boxes = _public_boxes_list(load_programme(), load_state())
        self._send_json(200, {"boxes": boxes, "count": len(boxes)})
        return

    def _get_api_calendar_oauth_auth_url(self):
        try:
            self._send_json(200, {"url": build_auth_url()})
        except Exception as exc:
            self._send_json(400, {"error": str(exc)})
        return

    def _esc_html(self, s):
        return (str(s).replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace('"', "&quot;"))

    def _handle_oauth_callback(self, parsed):
        """Google redirects here after sign-in. Exchanges the code for
        tokens (server-side only) and shows a plain Persian result page."""
        qs = urllib.parse.parse_qs(parsed.query)
        code = (qs.get("code") or [""])[0]
        state = (qs.get("state") or [""])[0]
        err = (qs.get("error") or [""])[0]
        if err:
            ok, msg = False, "گوگل ورود را رد کرد: {}".format(err)
        elif not code:
            ok, msg = False, "کد ورود از گوگل نرسید — دوباره تلاش کن"
        else:
            try:
                cfg = exchange_code(code, state)
                email = cfg.get("account_email") or ""
                msg = "اتصال به گوگل برقرار شد" + (" ({})".format(email) if email else "") \
                    + " — می‌توانی این برگه را ببندی و به برنامه برگردی."
                ok = True
                threading.Thread(target=seed_push_state_after_connect, daemon=True).start()
            except Exception as exc:
                ok, msg = False, str(exc)
        heading = "اتصال برقرار شد" if ok else "اتصال ممکن نشد"
        page = ("<!DOCTYPE html><html lang=\"fa\" dir=\"rtl\"><head><meta charset=\"utf-8\">"
                "<title>StudyFlow — اتصال به گوگل</title>"
                "<style>body{font-family:tahoma,sans-serif;max-width:560px;margin:60px auto;"
                "padding:0 20px}h1{font-size:20px}p{line-height:1.9}</style></head><body>"
                "<h1>" + ("✅ " if ok else "⚠ ") + heading + "</h1><p>"
                + self._esc_html(msg) + "</p>"
                "<p><a href=\"/\">بازگشت به برنامه</a></p></body></html>")
        raw = page.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        # Match routes without the query string (a "?..." suffix used to
        # break every POST route that compared against self.path).
        path = urllib.parse.urlparse(self.path).path
        handler = POST_ROUTES.get(path)
        if handler is not None:
            handler(self)
            return
        self._send_json(404, {"error": "not found"})

    def _post_api_state(self):
        data = self._read_json()
        if not data:
            # Never let an empty/unreadable body wipe real data to defaults.
            self._send_json(400, {"error": "empty body"})
            return
        if not isinstance(data, dict):
            self._send_json(400, {"error": "bad body"})
            return
        # v1.11.67 (PR1, seq/ETag): the save protocol fields ride in
        # the X-State-Seq / X-State-Full headers on fetch and as _seq
        # / _full / _beacon in the JSON body on sendBeacon (which
        # cannot set headers). Pop the body fields BEFORE validation
        # so they never trip state_rejected_keys. The header wins
        # when both are present.
        client_seq = _parse_seq(self.headers.get("X-State-Seq"))
        if client_seq is None:
            client_seq = _parse_seq(data.pop("_seq", None))
        else:
            data.pop("_seq", None)
        is_full = _truthy(self.headers.get("X-State-Full"))
        if not is_full:
            is_full = _truthy(data.pop("_full", None))
        else:
            data.pop("_full", None)
        is_beacon = _truthy(data.pop("_beacon", None))
        # v1.11.23 (QA BUG-001): a known key with the wrong type must
        # be rejected WITHOUT saving — merge_state would drop it and
        # fall back to DEFAULT_STATE, silently wiping the stored
        # value (live repro: {"done": "bad-string"} wiped done to
        # {} with HTTP 200). Unknown keys stay log-and-drop (they
        # cannot wipe anything: sanitize removes them and the merge
        # below keeps the stored value).
        wrong_typed = state_wrong_typed_keys(data)
        if wrong_typed:
            print("POST /api/state wrong-typed keys: {}".format(wrong_typed))
            self._send_json(400, {"error": "نوع داده‌ی این فیلدها درست نیست: " + ", ".join(wrong_typed),
                                  "rejected": wrong_typed})
            return
        rejected = state_rejected_keys(data)
        if rejected:
            # The schema drops these on save (merge_state sanitizes);
            # log them so a client sending bad keys is visible.
            # v1.11.71 (audit #2, L10): the dropped keys are also
            # returned in the response as "warnings" — a client typo
            # ("delete" for "deleted", "box_id" for "id") used to look
            # successful (200 {"ok": true}) while doing nothing. The
            # warnings are ADDITIVE only: the success response stays
            # {"ok": true}; nothing becomes a 400. (Wrong-typed KNOWN
            # keys already 400'd above, so by here `rejected` can only
            # be unknown keys.)
            print("POST /api/state rejected keys: {}".format(rejected))
        # v1.11.67 (PR1): the server assigns a monotonic sequence per
        # save (seq.json, bumped inside save_state). The client sends
        # the last-seen seq with every save; the decision is made
        # under STATE_LOCK so two concurrent saves cannot both pass
        # the check:
        #  * FULL save + stale seq (client < server), non-beacon:
        #    409 with the CURRENT state — the client rebases its own
        #    changes onto it (3-way merge against its last-synced
        #    snapshot) and retries. A genuine deletion is never
        #    resurrected: the rebase only takes the server's value
        #    for keys/entries the client did NOT touch.
        #  * STALE seq + beacon (any _full marking — the pagehide
        #    beacon always sends _full: true): no 409 is readable at
        #    pagehide, so the beacon falls back to a beacon-only
        #    merge — merged keys + activeTimer guards ONLY (v1.11.68,
        #    audit #2 M1). Scalars and nullables are ignored too: the
        #    1.11.67 notes claimed the beacon drops the closing tab's
        #    day-flags/useful changes, but patch_only let scalars
        #    (theme, lang, telegramChatId) and nulls (assignments,
        #    sim, lastErrorReview) pass through and overwrite NEWER
        #    values. The beacon's only job is rescuing the closing
        #    tab's ticks/minutes.
        #  * FULL save + seq AHEAD of the server: seq.json was lost
        #    — trust the client and adopt its exact seq (v1.11.68:
        #    adopt used to set client+1 and the save's bump made it
        #    client+2; now adopt sets client and the bump makes it
        #    client+1).
        #  * FULL save + current/absent seq: authoritative apply
        #    (present non-merged keys replace, so genuine deletions
        #    in a full body apply). A legacy client sends no _full
        #    marker and no meaningful seq (its per-tab counter is
        #    ignored): a full body is applied as before, a partial
        #    body is PATCHED — a partial POST can never whole-replace
        #    daysDone or any other non-merged key (audit repro:
        #    POST {"daysDone": {}} used to wipe the flag).
        # The 1.11.17 per-tab X-State-Seq counter is gone: the header
        # now carries the SERVER-assigned seq.
        status = 200
        # v1.11.71 (audit #2, L10): dropped unknown keys ride along
        # as "warnings" (see above) — additive only, the success
        # response stays {"ok": true}.
        payload = ({"ok": True, "warnings": rejected} if rejected
                   else {"ok": True})
        resp_headers = None
        with STATE_LOCK:
            old_state = load_state()
            server_seq = read_seq("state")
            if (client_seq is not None and client_seq < server_seq
                    and is_beacon):
                # v1.11.68 (M1): stale beacon — merged keys +
                # activeTimer guards only, whatever _full says.
                merged = merge_state_update_scoped(
                    old_state, data, patch_only=True, beacon_only=True)
                # v1.11.71 (audit #2, L14): a no-op stale beacon
                # (nothing in the merged keys changed) must not bump
                # the counter either — skip the write when the merged
                # state is byte-identical to the stored one.
                saved, changed = save_state_if_changed(old_state, merged)
                if changed:
                    # v1.11.74 (audit #3, Q-211): the shared helper —
                    # the same try/except was inlined here and in the
                    # normal branch below.
                    _note_app_edits_safe(old_state, saved)
                resp_headers = {"X-State-Seq": str(read_seq("state"))}
            elif is_full and client_seq is not None and client_seq < server_seq:
                print("POST /api/state stale seq={} server={} -> 409"
                      .format(client_seq, server_seq))
                status = 409
                payload = {"error": "stale save — state changed since "
                                    "your last sync; re-fetch and retry",
                           "seq": server_seq, "state": old_state}
                resp_headers = {"X-State-Seq": str(server_seq)}
            else:
                adopted = False
                if (is_full and client_seq is not None
                        and client_seq > server_seq):
                    print("POST /api/state seq ahead client={} server={} "
                          "-> adopting seq={} (save bumps to {})"
                          .format(client_seq, server_seq, client_seq,
                                  client_seq + 1))
                    adopt_seq("state", client_seq)
                    adopted = True
                # A body is FULL when the client marks it, or when it
                # carries every DEFAULT_STATE key (legacy full save).
                full = is_full or _is_full_state_body(data)
                # v1.11.74 (audit #3, L2): a marker-less body that is
                # near-complete (>= 80% of the DEFAULT_STATE keys,
                # i.e. >= 36/45) but falls below the 90% full
                # threshold is PATCHED, not full — its deletions
                # silently do not apply. Say so in the response
                # (additive, like L10's "warnings"): "patched": true
                # plus the non-merged keys a full save would have
                # deleted (kept by the patch instead). The _full
                # marker — not key counting — is the contract for
                # "this is a full save"; the 80%/90% thresholds are
                # only a legacy heuristic for unmarked bodies.
                if (not is_full and not full
                        and len(set(data.keys()) & set(DEFAULT_STATE.keys())) * 5
                        >= len(DEFAULT_STATE) * 4):
                    payload["patched"] = True
                    payload["patched_kept"] = sorted(
                        k for k in old_state
                        if k not in data and k not in _MERGED_STATE_KEYS
                        and k in DEFAULT_STATE)
                merged = merge_state_update_scoped(
                    old_state, data, patch_only=not full)
                # v1.11.71 (audit #2, L14): server-side no-op
                # short-circuit — see save_state_if_changed. A skipped
                # save leaves the seq untouched, so a second tab's next
                # full save with the same seq is still current.
                # EXCEPTION: the adopt path above — the L6 contract is
                # that adopt + the save's bump land the counter on
                # client+1, so an adopted save always writes + bumps
                # even when its body is a no-op (the adopt tests pin
                # client+1; the no-op skip must not silently move the
                # adopt landing to client).
                if adopted:
                    saved = save_state(merged)
                    changed = True
                else:
                    saved, changed = save_state_if_changed(old_state, merged)
                if changed:
                    _note_app_edits_safe(old_state, saved)
                resp_headers = {"X-State-Seq": str(read_seq("state"))}
        # v1.11.61 (L-PERF8): the response body is only {"ok": true} —
        # the whole saved state (~117KB) used to come back with every
        # save and the client discarded it (it only ever read res.ok;
        # the fire-and-forget POST at the reset flow does not read it
        # either). GET /api/state stays the only full-read path. The
        # new seq rides in the X-State-Seq response header instead.
        self._send_json(status, payload, resp_headers)
        return

    def _post_api_boxes_create(self):
        data = self._read_json()
        status, payload = box_api_create(data or {})
        self._send_json(status, payload)
        return

    def _post_api_boxes_update(self):
        data = self._read_json()
        status, payload = box_api_update(data or {})
        self._send_json(status, payload)
        return

    def _post_api_boxes_delete(self):
        data = self._read_json()
        status, payload = box_api_delete(data or {})
        self._send_json(status, payload)
        return

    def _post_api_boxes_reconnect(self):
        data = self._read_json()
        status, payload = box_api_reconnect(data or {})
        self._send_json(status, payload)
        return

    def _post_api_calendar_tombstones_clear(self):
        # v1.11.29 (PI-04): no body needed — clears every stored tombstone.
        status, payload = clear_calendar_tombstones()
        self._send_json(status, payload)
        return

    def _post_api_boxes_push_one(self):
        data = self._read_json()
        status, payload = box_api_push_one(data or {})
        self._send_json(status, payload)
        return

    def _post_api_testbook(self):
        data = self._read_json()
        if not data:
            self._send_json(400, {"error": "empty body"})
            return
        # v1.11.67 (PR1): same protocol as /api/state, on its own
        # counter. The seq rides in X-Testbook-Seq / _seq, the full
        # marker in X-Testbook-Full / _full, the beacon marker in
        # _beacon. Pop the body fields BEFORE validation so they never
        # trip valid_testbook (which only checks the books list).
        client_seq = _parse_seq(self.headers.get("X-Testbook-Seq"))
        if client_seq is None:
            client_seq = _parse_seq(data.pop("_seq", None))
        else:
            data.pop("_seq", None)
        is_full = _truthy(self.headers.get("X-Testbook-Full"))
        if not is_full:
            is_full = _truthy(data.pop("_full", None))
        else:
            data.pop("_full", None)
        is_beacon = _truthy(data.pop("_beacon", None))
        if not valid_testbook(data):
            self._send_json(400, {"error": "testbook نامعتبر است"})
            return
        # A seq-matched full save REPLACES the testbook wholesale
        # (mode="replace") — no book-level merge, so a deliberately
        # deleted book is never resurrected. A stale full save is
        # rejected (409) with the current testbook for a client-side
        # rebase; a stale beacon falls back to the book-level merge
        # (mode="merge"), which now respects the tombstones recorded
        # by replace saves (v1.11.68, audit #2 M2 — the 1.11.67 claim
        # that the merge was safe there because "no book-delete UI
        # exists" was wrong: a stale beacon body still carries the
        # deleted book and the merge resurrected it). A legacy save
        # (no _full marker) keeps the 1.11.61 book-level merge. A
        # client seq ahead of the server's (seq.json lost) is trusted
        # and adopted (adopt sets the exact client seq; the save's
        # bump makes it client+1 — v1.11.68, audit #2 L6).
        status = 200
        payload = None
        resp_headers = None
        # v1.11.74 (audit #3, L24): load (and, if the file is corrupt,
        # restore) the testbook BEFORE taking STATE_LOCK — load_testbook()
        # can reach cloud_restore_latest, a network call, and holding
        # the global lock through a slow/blocked restore stalls every
        # state and testbook save. The value is only a fallback below:
        # the comparison base and the 409 payload are re-read from the
        # file INSIDE the lock (cheap), so a save that landed in
        # between is never clobbered by a stale base.
        old_tb = load_testbook()
        with STATE_LOCK:
            server_seq = read_seq("testbook")
            if is_full and client_seq is not None and client_seq < server_seq:
                if is_beacon:
                    current, _ = read_json_file(TESTBOOK_FILE)
                    merged = _compute_testbook_merge(data, "merge", current)
                    # A no-op stale beacon must not bump the counter
                    # either (same L14 rule as the state path).
                    save_testbook_if_changed(current, merged)
                    resp_headers = {"X-Testbook-Seq":
                                    str(read_seq("testbook"))}
                else:
                    print("POST /api/testbook stale seq={} server={} -> 409"
                          .format(client_seq, server_seq))
                    status = 409
                    tb, _ = read_json_file(TESTBOOK_FILE)
                    if tb is None:
                        tb = old_tb
                    # v1.11.68 (audit #2, L1): read the seq AFTER the
                    # payload is built — load_testbook() (before the
                    # lock) may have restored a corrupt file from
                    # backup and bumped the counter, so the pre-build
                    # seq is stale and the client would burn one of
                    # its 3 retries on a gratuitous extra 409. The
                    # state path already orders it this way (load_state
                    # before read_seq).
                    server_seq = read_seq("testbook")
                    payload = {"error": "stale testbook save — re-fetch "
                                        "and retry",
                               "seq": server_seq,
                               "testbook": tb}
                    resp_headers = {"X-Testbook-Seq": str(server_seq)}
            else:
                adopted = False
                if (is_full and client_seq is not None
                        and client_seq > server_seq):
                    print("POST /api/testbook seq ahead client={} "
                          "server={} -> adopting seq={} (save bumps to {})"
                          .format(client_seq, server_seq, client_seq,
                                  client_seq + 1))
                    adopt_seq("testbook", client_seq)
                    adopted = True
                current, _ = read_json_file(TESTBOOK_FILE)
                merged = _compute_testbook_merge(
                    data, "replace" if is_full else "merge", current)
                # v1.11.73 (audit #3, P-102): server-side no-op
                # short-circuit — see save_testbook_if_changed. A
                # skipped save leaves the seq untouched, so a second
                # tab's next full save with the same seq is still
                # current. EXCEPTION: the adopt path above — the L6
                # contract is that adopt + the save's bump land the
                # counter on client+1, so an adopted save always
                # writes + bumps even when its body is a no-op (the
                # adopt tests pin client+1; the no-op skip must not
                # silently move the adopt landing to client).
                if adopted:
                    save_testbook(merged, mode="replace")
                else:
                    # v1.11.74 (audit #3, L24): compare against
                    # `current`, read from the file inside the lock —
                    # the pre-lock old_tb may be stale if another
                    # thread saved in between.
                    save_testbook_if_changed(current, merged)
                resp_headers = {"X-Testbook-Seq": str(read_seq("testbook"))}
        # v1.11.71 (audit #2, L13): same L-PERF8 slimming as
        # /api/state (1.11.61) — a 200 returns only {"ok": true} with
        # the seq in the X-Testbook-Seq header (~103KB saved per
        # debounced save; no client code ever read the 200 body, only
        # res.ok + the header). The 409 branch still returns the full
        # testbook for the client-side rebase.
        if status == 200:
            payload = {"ok": True}
        self._send_json(status, payload, resp_headers)
        return

    def _post_api_gemini_key(self):
        data = self._read_json()
        key = str(data.get("key") or "").strip()
        if not key:
            self._send_json(400, {"error": "کلید خالی است"})
            return
        atomic_write(KEY_FILE, key.encode("utf-8"), mode=0o600)  # credential: owner only (1.10)
        # v1.11.28 (QA BUG-046): only a boolean — no masked form.
        self._send_json(200, {"has_key": True})
        return

    def _post_api_gemini_model(self):
        data = self._read_json()
        model = str(data.get("model") or "").strip()
        if not valid_model(model):
            self._send_json(400, {"error": "نام مدل معتبر نیست"})
            return
        atomic_write(MODEL_FILE, model.encode("utf-8"))
        self._send_json(200, {"model": model})
        return

    # ---------- v1.11.64 (Batch 5, م-۸): Telegram ----------
    # The bot token is stored server-side only (telegram_token.txt,
    # mode 0o600 — like the Gemini key) and NEVER returned to the
    # browser; only booleans leave the server. The chat id is a plain
    # number in state.telegramChatId. The only message ever sent
    # through here is the weekly report, only when the user clicks
    # «ارسال به تلگرام» — never automatic.
    def _get_api_telegram_status(self):
        st = load_state()
        self._send_json(200, {"has_token": bool(read_tg_token()),
                              "has_chat_id": bool(st.get("telegramChatId"))})
        return

    def _post_api_telegram_token(self):
        data = self._read_json()
        token = str(data.get("token") or "").strip()
        chat_id = str(data.get("chat_id") or "").strip()
        if not tg_valid_token(token):
            self._send_json(400, {"error": "توکن بات معتبر نیست"})
            return
        if not tg_valid_chat_id(chat_id):
            self._send_json(400, {"error": "شناسه چت معتبر نیست"})
            return
        atomic_write(TG_TOKEN_FILE, token.encode("utf-8"), mode=0o600)  # credential: owner only (1.10)
        # Persist the chat id server-side too, so the status endpoint
        # is correct at once (the client's debounced saveState may not
        # have landed yet). Same value the client stores — no conflict.
        with STATE_LOCK:
            st = load_state()
            st["telegramChatId"] = chat_id
            save_state(st)
        self._send_json(200, {"ok": True, "has_token": True, "has_chat_id": True})
        return

    def _post_api_telegram_send(self):
        data = self._read_json()
        text = str(data.get("text") or "")
        token = read_tg_token()
        chat_id = load_state().get("telegramChatId") or ""
        if not token or not chat_id:
            self._send_json(400, {"error": "تلگرام تنظیم نشده است"})
            return
        ok, err = tg_send_message(token, chat_id, text)
        if ok:
            self._send_json(200, {"ok": True})
        else:
            self._send_json(502, {"error": err or "ارسال به تلگرام نشد"})
        return

    def _post_api_backup_now(self):
        # v1.11.26 (QA BUG-031): snapshot under STATE_LOCK so the
        # three files are a consistent set — a concurrent save can
        # no longer slip between two snapshots.
        with STATE_LOCK:
            create_backup("state", force=True)
            create_backup("testbook", force=True)
            create_backup("programme", force=True)
        CLOUD_SYNC.request(immediate=True)
        self._send_json(200, backup_status_payload())
        return

    def _post_api_backup_restore(self):
        data = self._read_json()
        kind = data.get("kind")
        fname = data.get("file") or ""
        if kind not in ("state", "testbook", "programme", "push") or "/" in fname or "\\" in fname:
            self._send_json(400, {"error": "bad request"})
            return
        entry = None
        for v in list_local_versions(kind):
            if v.get("file") == fname:
                entry = v
                break
        if entry is None:
            self._send_json(404, {"error": "version not found"})
            return
        restored = verify_backup_entry(entry)
        if restored is None:
            self._send_json(400, {"error": "backup failed verification"})
            return
        # Audit §5 item 1.10: if the CURRENT file is corrupt, keep it
        # as <file>.corrupt-<ts> instead of silently overwriting it.
        target = {"state": STATE_FILE, "testbook": TESTBOOK_FILE,
                  "programme": CALENDAR_DATA_FILE,
                  "push": GOOGLE_PUSH_FILE}[kind]
        # v1.11.26 (QA BUG-031): the replace runs inside STATE_LOCK,
        # so a concurrent save cannot land mid-restore and be lost.
        # (STATE_LOCK is an RLock and _invalidate_push_tracking()
        # takes it too, so that nested acquisition is safe; the
        # cloud-sync thread never holds CLOUD_SYNC._lock while
        # taking STATE_LOCK, so the nested CLOUD_SYNC._lock below
        # cannot invert the lock order.)
        with STATE_LOCK:
            cur, _ = read_json_file(target)
            cur_ok = (cur is not None and
                      (valid_state(cur) if kind == "state" else
                       valid_testbook(cur) if kind == "testbook" else
                       isinstance(cur, dict) and isinstance(cur.get("boxes"), list)
                       if kind == "programme" else
                       isinstance(cur, dict)))
            if cur_ok:
                # Snapshot the GOOD current file before replacing
                # it, so a mistaken restore can be undone from
                # backups/ (force=True: always a new version).
                create_backup(kind, force=True)
            if os.path.exists(target) and not cur_ok:
                # v1.11.73 (audit #3, L11): use the shared helper —
                # the inline second-precision copy overwrote the
                # first preserved copy when two restores landed in
                # the same second (L-DATA2 fixed the helper with ms
                # + counter; this site bypassed it).
                _preserve_corrupt(target)
            if kind == "state":
                atomic_write_json(STATE_FILE, restored)
                bump_seq("state")  # v1.11.67 (PR1): a restore is a persisted change
                with CLOUD_SYNC._lock:
                    CLOUD_SYNC.last_synced_sha["state"] = None
                _invalidate_push_tracking()
            elif kind == "programme":
                atomic_write_json(CALENDAR_DATA_FILE, restored)
                with CLOUD_SYNC._lock:
                    CLOUD_SYNC.last_synced_sha["programme"] = None
                _invalidate_push_tracking()
            elif kind == "push":
                # Restoring the push bookkeeping itself — do NOT call
                # _invalidate_push_tracking() here (that would wipe the
                # bookkeeping we just restored). Push state is local-only
                # (never cloud-synced), so no CLOUD_SYNC touch either.
                atomic_write_json(GOOGLE_PUSH_FILE, restored)
            else:
                atomic_write_json(TESTBOOK_FILE, restored)
                bump_seq("testbook")  # v1.11.67 (PR1): a restore is a persisted change
                with CLOUD_SYNC._lock:
                    CLOUD_SYNC.last_synced_sha["testbook"] = None
        self._send_json(200, {"ok": True, "restored": entry["file"]})
        return

    def _require_b2(self):
        """True when the B2 module is available; otherwise answers
        the 500 and returns False (v1.11.54, D-5 — the same guard
        was inlined in three backup handlers)."""
        if not b2mod:
            self._send_json(500, {"error": "cloud module unavailable"})
            return False
        return True

    def _require_b2_config(self):
        """The enabled B2 config, or None after answering the error
        (v1.11.74, audit #3 Q-211 — the module guard + config load +
        enabled check was inlined in two backup handlers)."""
        if not self._require_b2():
            return None
        cfg = load_b2_config()
        if not cfg or not cfg.get("enabled"):
            self._send_json(400, {"error": "cloud not configured"})
            return None
        return cfg

    def _post_api_backup_resolve_conflict(self):
        # Explicit user choice after a cloud conflict: upload the LOCAL
        # version as the newest cloud snapshot. The remote versioned
        # object is never deleted, so both versions stay in the cloud.
        data = self._read_json()
        kind = data.get("kind")
        # v1.11.26 (QA BUG-032): a programme conflict is resolvable
        # too — it was rejected by the allowlist even though the
        # cloud sync can produce one for any of the three kinds.
        if kind not in ("state", "testbook", "programme"):
            self._send_json(400, {"error": "bad request"})
            return
        # v1.11.45 (bug-hunt B-16): the conflict used to be cleared
        # FIRST, and only then was the upload attempted — with B2
        # disabled the handler still answered {"ok": True} with the
        # conflict already gone. Only clear it after a successful
        # upload; when B2 is unavailable or disabled, answer an error
        # and keep the conflict (the next sync re-surfaces it).
        cfg = self._require_b2_config()
        if cfg is None:
            return
        # Force the manifest to accept ours next sync: temporarily clear
        # the remote-newer check by uploading now, directly.
        try:
            client = b2mod.B2Client(cfg)
            manifest = client.get_json(CLOUD_MANIFEST_KEY) or {}
            path = (STATE_FILE if kind == "state" else
                    CALENDAR_DATA_FILE if kind == "programme" else
                    TESTBOOK_FILE)
            with open(path, "rb") as f:
                raw = f.read()
            digest = sha256_bytes(raw)
            ts = now_ts()
            key = "{}-{}-{}.json".format(
                kind, datetime.fromtimestamp(ts).strftime("%Y%m%d-%H%M%S"), digest[:8])
            client.put_object(CLOUD_PREFIX + key, raw, "application/json")
            manifest[kind] = {"key": CLOUD_PREFIX + key, "sha256": digest, "ts": ts}
            manifest["updated_ts"] = ts
            client.put_object(CLOUD_MANIFEST_KEY,
                              json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8"),
                              "application/json")
            with CLOUD_SYNC._lock:
                if CLOUD_SYNC.conflict and CLOUD_SYNC.conflict.get("kind") == kind:
                    CLOUD_SYNC.conflict = None
                CLOUD_SYNC.last_synced_sha[kind] = digest
                CLOUD_SYNC.last_sync = {"ts": now_ts(), "ts_iso": iso_now(),
                                      "ok": True, "error": None}
            self._send_json(200, {"ok": True, "uploaded": key})
            return
        except Exception as exc:
            self._send_json(502, {"error": str(exc)})
            return

    def _post_api_backup_restore_cloud(self):
        data = self._read_json()
        kind = data.get("kind")
        key = data.get("key") or ""
        if kind not in ("state", "testbook", "programme") or not key.startswith(CLOUD_PREFIX):
            self._send_json(400, {"error": "bad request"})
            return
        cfg = self._require_b2_config()
        if cfg is None:
            return
        try:
            client = b2mod.B2Client(cfg)
            manifest = client.get_json(CLOUD_MANIFEST_KEY) or {}
            entry = manifest.get(kind) or {}
            if entry.get("key") != key:
                self._send_json(404, {"error": "cloud version not found"})
                return
            raw = client.get_object(key)
            if sha256_bytes(raw) != entry.get("sha256"):
                self._send_json(400, {"error": "cloud version failed verification"})
                return
            parsed = json.loads(raw.decode("utf-8"))
            if kind == "state" and not valid_state(parsed):
                self._send_json(400, {"error": "cloud version failed verification"})
                return
            if kind == "testbook" and not valid_testbook(parsed):
                self._send_json(400, {"error": "cloud version failed verification"})
                return
            if kind == "programme" and not (
                    isinstance(parsed, dict) and isinstance(parsed.get("boxes"), list)):
                self._send_json(400, {"error": "cloud version failed verification"})
                return
            # v1.11.45 (bug-hunt B-09): the local restore takes a
            # pre-restore snapshot under STATE_LOCK (BUG-031); the cloud
            # restore had neither. Mirror it: snapshot first, then
            # replace — all inside STATE_LOCK, so a concurrent save
            # cannot land mid-restore and be lost.
            with STATE_LOCK:
                create_backup(kind, force=True)
                if kind == "state":
                    atomic_write_json(STATE_FILE, parsed)
                    bump_seq("state")  # v1.11.67 (PR1): a restore is a persisted change
                    _invalidate_push_tracking()
                elif kind == "programme":
                    atomic_write_json(CALENDAR_DATA_FILE, parsed)
                    _invalidate_push_tracking()
                else:
                    atomic_write_json(TESTBOOK_FILE, parsed)
                    bump_seq("testbook")  # v1.11.67 (PR1): a restore is a persisted change
            with CLOUD_SYNC._lock:
                CLOUD_SYNC.last_synced_sha[kind] = None
                CLOUD_SYNC.conflict = None
            self._send_json(200, {"ok": True, "restored": key})
        except Exception as exc:
            self._send_json(502, {"error": str(exc)})
        return

    def _post_api_backup_b2_config(self):
        data = self._read_json()
        cfg = load_b2_config() or {}
        endpoint = str(data.get("endpoint") or cfg.get("endpoint") or
                       (b2mod.DEFAULT_ENDPOINT if b2mod else "")).strip()
        endpoint = re.sub(r"^https?://", "", endpoint).strip("/ ")
        key_id = str(data.get("key_id") or "").strip()
        app_key = str(data.get("application_key") or "").strip()
        bucket = str(data.get("bucket") or cfg.get("bucket") or "konkur-backup").strip()
        enabled = bool(data.get("enabled"))
        # Keep existing secrets when the form sends them back masked/empty.
        if not key_id and cfg.get("key_id"):
            key_id = cfg["key_id"]
        if not app_key and cfg.get("application_key"):
            app_key = cfg["application_key"]
        if enabled and (not key_id or not app_key):
            self._send_json(400, {"error": "key_id و application_key لازم است"})
            return
        new_cfg = {"endpoint": endpoint, "key_id": key_id,
                   "application_key": app_key, "bucket": bucket,
                   "enabled": enabled}
        save_b2_config(new_cfg)
        with CLOUD_SYNC._lock:
            CLOUD_SYNC.conflict = None
            CLOUD_SYNC.last_synced_sha = {"state": None, "testbook": None, "programme": None}
        if enabled:
            CLOUD_SYNC.request(immediate=True)
        self._send_json(200, masked_b2_config(new_cfg))
        return

    def _post_api_backup_b2_test(self):
        if not self._require_b2():
            return
        cfg = load_b2_config()
        if not cfg or not cfg.get("key_id"):
            self._send_json(400, {"error": "B2 تنظیم نشده است"})
            return
        try:
            client = b2mod.B2Client(cfg)
            ok, err = client.test_connection()
            self._send_json(200, {"ok": ok, "error": err})
        except Exception as exc:
            self._send_json(200, {"ok": False, "error": str(exc)})
        return

    def _post_api_backup_b2_clear(self):
        try:
            if os.path.exists(B2_CONFIG_FILE):
                os.remove(B2_CONFIG_FILE)
        except Exception:
            pass
        with CLOUD_SYNC._lock:
            CLOUD_SYNC.conflict = None
            CLOUD_SYNC.last_synced_sha = {"state": None, "testbook": None, "programme": None}
        self._send_json(200, {"ok": True})
        return

    def _post_api_gemini(self):
        key = read_key()
        if not key:
            self._send_json(400, {"error": "کلید API جمینای معتبر نیست"})
            return
        data = self._read_json()
        prompt = str(data.get("prompt") or "").strip()
        if not prompt:
            self._send_json(400, {"error": "متن خالی است"})
            return
        # v1.11.45 (bug-hunt B-10): the whole prompt was forwarded with
        # no length cap (the body cap is 10 MB). Refuse oversized
        # prompts before any Google call.
        if len(prompt) > GEMINI_MAX_PROMPT_CHARS:
            self._send_json(400, {"error":
                "متن خیلی طولانی است — حداکثر {} کاراکتر".format(
                    GEMINI_MAX_PROMPT_CHARS)})
            return
        r = _gemini_request(read_model(), prompt, timeout=60)
        if not r["ok"]:
            # Response shapes preserved exactly (the client checks for
            # "معتبر نیست" and "HTTP 404" in the error text).
            if r["kind"] == "auth":
                self._send_json(400, {"error": "کلید API جمینای معتبر نیست"})
            elif r["kind"] == "network":
                self._send_json(502, {"error": r["message"]})
            elif r["kind"] == "model" and r["code"] is None:
                self._send_json(502, {"error": "جمینای پاسخی نداد"})
            elif r["code"]:
                self._send_json(502, {"error": "خطای سرور جمینای: HTTP " + str(r["code"])})
            else:
                self._send_json(502, {"error": r["message"]})
            return
        self._send_json(200, {"text": r["text"]})
        return

    def _post_api_gemini_test(self):
        # Live per-model test: one tiny, cheap request (max 8 output
        # tokens) to the named model with the stored key. Never changes
        # the default selected model. Returns latency + classified error.
        data = self._read_json()
        model = str(data.get("model") or "").strip()
        if not valid_model(model):
            self._send_json(400, {"error": "نام مدل معتبر نیست"})
            return
        t0 = time.time()
        r = _gemini_request(model, TEST_PROMPT, timeout=30,
                            max_tokens=TEST_MAX_TOKENS)
        latency_ms = int(round((time.time() - t0) * 1000))
        self._send_json(200, {
            "ok": r["ok"],
            "model": model,
            "latencyMs": latency_ms,
            "errorKind": r["kind"] or "",
            "errorMessage": "" if r["ok"] else r["message"],
        })
        return

    def _finish_update_install(self, staged):
        """Shared tail of _post_api_update_upload / _post_api_update_url
        (v1.11.54, D-7): install the staged zip, drop the staged file,
        answer 200/400, flush, then schedule the restart."""
        version, backup, err = install_update_zip(staged)
        try:
            os.remove(staged)
        except Exception:
            pass
        if err:
            self._send_json(400, {"error": err})
            return
        self._send_json(200, {"ok": True, "version": version, "backup": backup})
        try:
            self.wfile.flush()
        except Exception:
            pass
        schedule_restart()

    def _post_api_update_upload(self):
        # Raw .zip bytes in the body (Content-Type: application/zip).
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except Exception:
            length = 0
        if length <= 0 or length > MAX_UPDATE_ZIP_BYTES:
            self._send_json(400, {"error": "فایل zip خالی است یا خیلی بزرگ است"})
            return
        ensure_data_dir()
        os.makedirs(UPDATE_STAGING_DIR, exist_ok=True)
        staged = os.path.join(
            UPDATE_STAGING_DIR, staging_zip_name("update"))
        try:
            with open(staged, "wb") as f:
                remaining = length
                while remaining > 0:
                    chunk = self.rfile.read(min(65536, remaining))
                    if not chunk:
                        break
                    f.write(chunk)
                    remaining -= len(chunk)
        except Exception as exc:
            self._send_json(400, {"error": "دریافت فایل ممکن نشد: " + str(exc)})
            return
        self._finish_update_install(staged)
        return

    def _post_api_update_url(self):
        data = self._read_json()
        url = str(data.get("url") or "").strip()
        if not url.startswith("https://"):
            self._send_json(400, {"error": "لینک باید با https:// شروع شود"})
            return
        ensure_data_dir()
        os.makedirs(UPDATE_STAGING_DIR, exist_ok=True)
        staged = os.path.join(
            UPDATE_STAGING_DIR, staging_zip_name("update"))
        try:
            req = urllib.request.Request(url, method="GET",
                                         headers={"User-Agent": "KonkurApp-Updater"})
            # v1.11.24 (QA BUG-012): redirects are re-checked for https.
            with open_https_url(req, timeout=60) as resp:
                total = 0
                with open(staged, "wb") as f:
                    while True:
                        chunk = resp.read(65536)
                        if not chunk:
                            break
                        total += len(chunk)
                        if total > MAX_UPDATE_ZIP_BYTES:
                            raise ValueError("فایل zip خیلی بزرگ است")
                        f.write(chunk)
        except ValueError as exc:
            self._send_json(400, {"error": str(exc)})
            return
        except Exception as exc:
            self._send_json(502, {"error": "دانلود فایل ممکن نشد: " + str(exc)})
            return
        self._finish_update_install(staged)
        return

    def _post_api_update_rollback(self):
        data = self._read_json()
        backups = list_code_backups()
        name = str(data.get("backup") or "").strip()
        if not name:
            if not backups:
                self._send_json(400, {"error": "نسخه‌ی قبلی برای بازگشت وجود ندارد"})
                return
            name = backups[0]["name"]
        ok, err = restore_code_backup(name)
        if not ok:
            self._send_json(400, {"error": err})
            return
        restored = None
        for b in backups:
            if b["name"] == name:
                restored = b
                break
        self._send_json(200, {"ok": True, "version": {
            "version": (restored or {}).get("version", "dev"),
            "build_date": (restored or {}).get("build_date", "")},
            "backup": restored})
        try:
            self.wfile.flush()
        except Exception:
            pass
        schedule_restart()
        return

    def _post_api_update_check(self):
        result = run_update_check()
        self._send_json(200 if result.get("ok") else 502, result)
        return

    def _post_api_update_auto_config(self):
        data = self._read_json()
        url = str(data.get("manifest_url") or "").strip()
        if not url:
            url = DEFAULT_MANIFEST_URL
        if not url.startswith("https://"):
            self._send_json(400, {"error": "آدرس مانیفست باید با https:// شروع شود"})
            return
        cfg = load_update_config()
        cfg["manifest_url"] = url
        cfg["last_check"] = None
        cfg["last_result"] = None
        cfg["last_error"] = None
        save_update_config(cfg)
        self._send_json(200, {"manifest_url": url})
        return

    def _post_api_update_install_auto(self):
        # The manifest is re-fetched fresh here — the client never
        # supplies the zip URL or hash, so a stale or tampered claim
        # cannot steer the install.
        # v1.11.29 (PI-01): the check-and-set on AUTO_UPDATE_ACTIVE
        # was not atomic — two concurrent requests could both see
        # "not running" during the slow manifest fetch and both start
        # a download thread. The claim is taken atomically via
        # auto_update_try_claim() BEFORE the fetch; every failure
        # path below releases it again (the background thread's
        # finally releases it on the success path).
        if not auto_update_try_claim():
            self._send_json(409, {"error": "یک به‌روزرسانی در حال انجام است"})
            return
        result = run_update_check()
        if not result.get("ok"):
            auto_update_release()
            self._send_json(502, {"error": result.get("error") or "بررسی ممکن نشد"})
            return
        if result.get("blocked_min_version"):
            auto_update_release()
            self._send_json(400, {"error": "این نسخه به نسخه‌ی {} یا جدیدتر نیاز دارد؛ اول به‌صورت دستی به‌روز کن".format(result["blocked_min_version"])})
            return
        if not result.get("update_available"):
            auto_update_release()
            self._send_json(400, {"error": "به‌روز هستید"})
            return
        manifest = {"version": result["version"],
                    "zip_url": result["zip_url"],
                    "sha256": result["sha256"],
                    "notes": result.get("notes") or ""}
        _auto_update_set(phase="downloading", percent=0, downloaded=0,
                         total=None, version=manifest["version"], error=None)
        threading.Thread(target=download_and_install_auto,
                         args=(manifest,), daemon=True).start()
        self._send_json(200, {"ok": True, "started": True,
                              "version": manifest["version"]})
        return

    def _post_api_calendar_config(self):
        data = self._read_json()
        cfg = load_calendar_config()
        url = str(data.get("ics_url") or "").strip()
        if url and not url.startswith("https://"):
            self._send_json(400, {"error": "آدرس ICS باید با https:// شروع شود"})
            return
        try:
            interval = int(data.get("interval_minutes") or cfg.get("interval_minutes") or 30)
        except Exception:
            interval = 30
        interval = max(5, min(1440, interval))
        enabled = bool(data.get("enabled")) if "enabled" in data else bool(cfg.get("enabled"))
        if url:
            cfg["ics_url"] = url
        elif "ics_url" in data:
            cfg["ics_url"] = ""
        cfg["interval_minutes"] = interval
        cfg["enabled"] = enabled and bool(cfg.get("ics_url"))
        save_calendar_config(cfg)
        self._send_json(200, masked_calendar_config(cfg))
        return

    def _post_api_calendar_oauth_credentials(self):
        data = self._read_json()
        cfg = load_oauth()
        cid = str(data.get("client_id") or "").strip()
        csec = str(data.get("client_secret") or "").strip()
        if cid:
            cfg["client_id"] = cid
        if csec:
            cfg["client_secret"] = csec
        if not (cfg.get("client_id") or "").strip():
            self._send_json(400, {"error": "Client ID خالی است"})
            return
        save_oauth(cfg)
        self._send_json(200, masked_oauth_status())
        return

    def _post_api_calendar_oauth_clear_credentials(self):
        try:
            revoke_google_tokens()
        except Exception:
            pass
        try:
            if os.path.exists(GOOGLE_OAUTH_FILE):
                os.remove(GOOGLE_OAUTH_FILE)
        except Exception:
            pass
        self._send_json(200, masked_oauth_status())
        return

    def _post_api_calendar_oauth_disconnect(self):
        revoke_google_tokens()
        self._send_json(200, masked_oauth_status())
        return

    def _post_api_calendar_push(self):
        result = get_sync_provider().push(manual=True)
        self._send_json(200 if result.get("ok") else 502, result)
        return

    def _post_api_calendar_sync(self):
        result = get_sync_provider().pull("manual")
        self._send_json(200 if result.get("ok") else 502, result)
        return

    def _post_api_calendar_import_body(self, source_label, apply):
        # v1.11.74 (audit #3, Q-211): the shared body of the preview
        # and the real import — they differ only in the source label
        # and whether the changes are applied.
        data = self._read_json()
        content = str(data.get("content") or "")
        if not content.strip():
            self._send_json(400, {"error": "فایل خالی است"})
            return
        ok, payload = run_calendar_import(
            content, str(data.get("filename") or ""), source_label, apply=apply)
        self._send_json(200 if ok else 400, payload)
        return

    def _post_api_calendar_import_preview(self):
        self._post_api_calendar_import_body("import-preview", apply=False)
        return

    def _post_api_calendar_import(self):
        self._post_api_calendar_import_body("import", apply=True)
        return

    def _post_api_calendar_clear(self):
        try:
            if os.path.exists(CALENDAR_CONFIG_FILE):
                os.remove(CALENDAR_CONFIG_FILE)
        except Exception:
            pass
        self._send_json(200, {"ok": True})
        return


# v1.11.38 (P3-10): table-driven dispatch — do_GET/do_POST look the
# handler up by path; adding a route means adding one method
# and one line here, never another elif in the dispatcher.
GET_ROUTES = {
    '/api/health': Handler._get_api_health,
    '/api/health/': Handler._get_api_health,
    '/api/state': Handler._get_api_state,
    '/api/state/': Handler._get_api_state,
    '/api/testbook': Handler._get_api_testbook,
    '/api/testbook/': Handler._get_api_testbook,
    '/api/gemini-key': Handler._get_api_gemini_key,
    '/api/gemini-key/': Handler._get_api_gemini_key,
    '/api/telegram-status': Handler._get_api_telegram_status,
    '/api/telegram-status/': Handler._get_api_telegram_status,
    '/api/gemini-model': Handler._get_api_gemini_model,
    '/api/gemini-model/': Handler._get_api_gemini_model,
    '/api/gemini-models': Handler._get_api_gemini_models,
    '/api/gemini-models/': Handler._get_api_gemini_models,
    '/api/backup': Handler._get_api_backup,
    '/api/backup/': Handler._get_api_backup,
    '/api/backup/list': Handler._get_api_backup_list,
    '/api/backup/list/': Handler._get_api_backup_list,
    '/api/backup/b2-config': Handler._get_api_backup_b2_config,
    '/api/backup/b2-config/': Handler._get_api_backup_b2_config,
    '/api/version': Handler._get_api_version,
    '/api/version/': Handler._get_api_version,
    '/api/update/status': Handler._get_api_update_status,
    '/api/update/status/': Handler._get_api_update_status,
    '/api/update/auto': Handler._get_api_update_auto,
    '/api/update/auto/': Handler._get_api_update_auto,
    '/api/update/auto-progress': Handler._get_api_update_auto_progress,
    '/api/update/auto-progress/': Handler._get_api_update_auto_progress,
    '/data.json': Handler._get_data_json,
    '/data.json/': Handler._get_data_json,
    '/api/calendar/unlinked': Handler._get_api_calendar_unlinked,
    '/api/calendar/unlinked/': Handler._get_api_calendar_unlinked,
    '/api/calendar/status': Handler._get_api_calendar_status,
    '/api/calendar/status/': Handler._get_api_calendar_status,
    '/api/calendar/config': Handler._get_api_calendar_config,
    '/api/calendar/config/': Handler._get_api_calendar_config,
    '/api/calendar/oauth/status': Handler._get_api_calendar_oauth_status,
    '/api/calendar/oauth/status/': Handler._get_api_calendar_oauth_status,
    '/api/calendar/push-status': Handler._get_api_calendar_push_status,
    '/api/calendar/push-status/': Handler._get_api_calendar_push_status,
    '/api/boxes': Handler._get_api_boxes,
    '/api/boxes/': Handler._get_api_boxes,
    '/api/calendar/oauth/auth-url': Handler._get_api_calendar_oauth_auth_url,
    '/api/calendar/oauth/auth-url/': Handler._get_api_calendar_oauth_auth_url,
}


# v1.11.38 (P3-10): table-driven dispatch — do_GET/do_POST look the
# handler up by path; adding a route means adding one method
# and one line here, never another elif in the dispatcher.
POST_ROUTES = {
    '/api/state': Handler._post_api_state,
    '/api/state/': Handler._post_api_state,
    '/api/boxes/create': Handler._post_api_boxes_create,
    '/api/boxes/create/': Handler._post_api_boxes_create,
    '/api/boxes/update': Handler._post_api_boxes_update,
    '/api/boxes/update/': Handler._post_api_boxes_update,
    '/api/boxes/delete': Handler._post_api_boxes_delete,
    '/api/boxes/delete/': Handler._post_api_boxes_delete,
    '/api/boxes/reconnect': Handler._post_api_boxes_reconnect,
    '/api/boxes/reconnect/': Handler._post_api_boxes_reconnect,
    '/api/calendar/tombstones/clear': Handler._post_api_calendar_tombstones_clear,
    '/api/calendar/tombstones/clear/': Handler._post_api_calendar_tombstones_clear,
    '/api/boxes/push-one': Handler._post_api_boxes_push_one,
    '/api/boxes/push-one/': Handler._post_api_boxes_push_one,
    '/api/testbook': Handler._post_api_testbook,
    '/api/testbook/': Handler._post_api_testbook,
    '/api/gemini-key': Handler._post_api_gemini_key,
    '/api/gemini-key/': Handler._post_api_gemini_key,
    '/api/gemini-model': Handler._post_api_gemini_model,
    '/api/gemini-model/': Handler._post_api_gemini_model,
    '/api/backup/now': Handler._post_api_backup_now,
    '/api/backup/now/': Handler._post_api_backup_now,
    '/api/backup/restore': Handler._post_api_backup_restore,
    '/api/backup/restore/': Handler._post_api_backup_restore,
    '/api/backup/resolve-conflict': Handler._post_api_backup_resolve_conflict,
    '/api/backup/resolve-conflict/': Handler._post_api_backup_resolve_conflict,
    '/api/backup/restore-cloud': Handler._post_api_backup_restore_cloud,
    '/api/backup/restore-cloud/': Handler._post_api_backup_restore_cloud,
    '/api/backup/b2-config': Handler._post_api_backup_b2_config,
    '/api/backup/b2-config/': Handler._post_api_backup_b2_config,
    '/api/backup/b2-test': Handler._post_api_backup_b2_test,
    '/api/backup/b2-test/': Handler._post_api_backup_b2_test,
    '/api/backup/b2-clear': Handler._post_api_backup_b2_clear,
    '/api/backup/b2-clear/': Handler._post_api_backup_b2_clear,
    '/api/gemini': Handler._post_api_gemini,
    '/api/gemini/': Handler._post_api_gemini,
    '/api/telegram-token': Handler._post_api_telegram_token,
    '/api/telegram-token/': Handler._post_api_telegram_token,
    '/api/telegram-send': Handler._post_api_telegram_send,
    '/api/telegram-send/': Handler._post_api_telegram_send,
    '/api/gemini-test': Handler._post_api_gemini_test,
    '/api/gemini-test/': Handler._post_api_gemini_test,
    '/api/update/upload': Handler._post_api_update_upload,
    '/api/update/upload/': Handler._post_api_update_upload,
    '/api/update/url': Handler._post_api_update_url,
    '/api/update/url/': Handler._post_api_update_url,
    '/api/update/rollback': Handler._post_api_update_rollback,
    '/api/update/rollback/': Handler._post_api_update_rollback,
    '/api/update/check': Handler._post_api_update_check,
    '/api/update/check/': Handler._post_api_update_check,
    '/api/update/auto-config': Handler._post_api_update_auto_config,
    '/api/update/auto-config/': Handler._post_api_update_auto_config,
    '/api/update/install-auto': Handler._post_api_update_install_auto,
    '/api/update/install-auto/': Handler._post_api_update_install_auto,
    '/api/calendar/config': Handler._post_api_calendar_config,
    '/api/calendar/config/': Handler._post_api_calendar_config,
    '/api/calendar/oauth/credentials': Handler._post_api_calendar_oauth_credentials,
    '/api/calendar/oauth/credentials/': Handler._post_api_calendar_oauth_credentials,
    '/api/calendar/oauth/clear-credentials': Handler._post_api_calendar_oauth_clear_credentials,
    '/api/calendar/oauth/clear-credentials/': Handler._post_api_calendar_oauth_clear_credentials,
    '/api/calendar/oauth/disconnect': Handler._post_api_calendar_oauth_disconnect,
    '/api/calendar/oauth/disconnect/': Handler._post_api_calendar_oauth_disconnect,
    '/api/calendar/push': Handler._post_api_calendar_push,
    '/api/calendar/push/': Handler._post_api_calendar_push,
    '/api/calendar/sync': Handler._post_api_calendar_sync,
    '/api/calendar/sync/': Handler._post_api_calendar_sync,
    '/api/calendar/import-preview': Handler._post_api_calendar_import_preview,
    '/api/calendar/import-preview/': Handler._post_api_calendar_import_preview,
    '/api/calendar/import': Handler._post_api_calendar_import,
    '/api/calendar/import/': Handler._post_api_calendar_import,
    '/api/calendar/clear': Handler._post_api_calendar_clear,
    '/api/calendar/clear/': Handler._post_api_calendar_clear,
}

# ---------- Credential hardening (audit §5 item 1.10) ----------
def harden_credential_files():
    """Tighten permissions on credential files written before 1.11.17
    (they were 0644): google_oauth.json, gemini_key.txt, b2_config.json.
    Best-effort — a missing file or a failed chmod is not fatal."""
    for path in (GOOGLE_OAUTH_FILE, KEY_FILE, B2_CONFIG_FILE):
        try:
            if os.path.exists(path):
                os.chmod(path, 0o600)
        except OSError:
            pass


if __name__ == "__main__":
    ensure_data_dir()
    migrate_legacy_files()
    harden_credential_files()
    sync_thread = threading.Thread(target=CLOUD_SYNC.run, daemon=True)
    sync_thread.start()
    cal_thread = threading.Thread(target=calendar_sync_loop, daemon=True)
    cal_thread.start()
    push_thread = threading.Thread(target=PUSH_SYNC.run, daemon=True)
    push_thread.start()
    upd_check_thread = threading.Thread(target=update_startup_check, daemon=True)
    upd_check_thread.start()
    # Retry the bind: after a self-update restart the old process may still
    # be releasing the port when the new one starts.
    server = None
    last_exc = None
    for attempt in range(12):
        try:
            server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
            break
        except OSError as exc:
            last_exc = exc
            time.sleep(1)
    if server is None:
        print("Could not bind port {}: {}".format(PORT, last_exc))
        raise SystemExit(1)
    print("Konkur local site running at http://localhost:8765")
    print("Data directory: {}".format(DATA_DIR))
    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
